import { spawnSync } from "node:child_process";
import { access, constants, mkdir, readFile, realpath, rename, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { executorPaths, EXECUTOR_LAUNCH_AGENT_LABEL } from "./executor-paths.js";

const xml = (value) => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
const run = (name, arguments_, allowFailure = false) => { const result = spawnSync(name, arguments_, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }); if (result.error) throw result.error; if (!allowFailure && result.status !== 0) throw new Error(`${name} ${arguments_.join(" ")} failed: ${(result.stderr || result.stdout || result.status).toString().trim()}`); return result; };
const readState = async (statePath) => { try { return JSON.parse(await readFile(statePath, "utf8")); } catch { return { installed: false, version: null }; } };
const pause = (milliseconds) => Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, milliseconds);
const npmForNode = (nodePath) => path.join(path.dirname(nodePath), process.platform === "win32" ? "npm.cmd" : "npm");

export async function stableExecutorNodePath(nodePath = process.execPath, {
  homeDirectory = os.homedir(),
  candidates = [path.join(homeDirectory, "Applications", "Inator Runtime.app", "Contents", "Resources", "runtimes", "node", "current", "bin", "node"), "/opt/homebrew/opt/node@22/bin/node", "/usr/local/opt/node@22/bin/node"],
  inspectVersion = (candidate) => spawnSync(candidate, ["--version"], { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }).stdout
} = {}) {
  const resolved = path.resolve(nodePath);
  for (const candidate of candidates) {
    try {
      await access(candidate, constants.X_OK);
      const candidateMajor = Number.parseInt(String(inspectVersion(candidate)).trim().replace(/^v/, "").split(".")[0], 10);
      if (candidateMajor === 22) return path.resolve(candidate);
    } catch { /* Missing or non-executable candidates are expected during discovery. */ }
  }
  const versionedMatch = resolved.match(/^((?:\/opt\/homebrew|\/usr\/local))\/Cellar\/node@22\/[^/]+\/bin\/node$/);
  if (versionedMatch) {
    const stable = path.join(versionedMatch[1], "opt", "node@22", "bin", "node");
    try { return await realpath(stable) === await realpath(resolved) ? stable : resolved; } catch { return resolved; }
  }
  const match = resolved.match(/^((?:\/opt\/homebrew|\/usr\/local))\/Cellar\/node\/[^/]+\/bin\/node$/);
  if (!match) return resolved;
  const stable = path.join(match[1], "bin", "node");
  try { return await realpath(stable) === await realpath(resolved) ? stable : resolved; } catch { return resolved; }
}

function unload({ userId, allowFailure = true }) {
  run("/bin/launchctl", ["bootout", `gui/${userId}/${EXECUTOR_LAUNCH_AGENT_LABEL}`], allowFailure);
  for (let attempt = 0; attempt < 50; attempt += 1) { if (run("/bin/launchctl", ["print", `gui/${userId}/${EXECUTOR_LAUNCH_AGENT_LABEL}`], true).status !== 0) break; pause(100); }
}

function plist({ nodePath, executable, paths }) {
  return [`<?xml version="1.0" encoding="UTF-8"?>`, `<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">`, `<plist version="1.0"><dict>`, `<key>Label</key><string>${EXECUTOR_LAUNCH_AGENT_LABEL}</string>`, `<key>ProgramArguments</key><array><string>${xml(nodePath)}</string><string>${xml(executable)}</string></array>`, `<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>`, `<key>StandardOutPath</key><string>${xml(paths.stdoutPath)}</string><key>StandardErrorPath</key><string>${xml(paths.stderrPath)}</string>`, `<key>ThrottleInterval</key><integer>5</integer></dict></plist>`, ""].join("\n");
}

export async function diagnoseExecutorInstallation({ homeDirectory = os.homedir(), userId = process.getuid?.(), nodePath = process.execPath } = {}) {
  const paths = executorPaths({ homeDirectory, userId }); const state = await readState(paths.statePath); const releaseRoot = path.join(paths.supportDirectory, "releases", state.version || "uninstalled"); const executable = path.join(releaseRoot, "node_modules", ".bin", "inator-executor");
  let plistPresent = false; let executablePresent = false; try { await access(paths.plistPath); plistPresent = true; } catch { /* Absence is reported below. */ } try { await access(executable); executablePresent = true; } catch { /* Absence is reported below. */ }
  const observed = userId == null ? { status: 1 } : run("/bin/launchctl", ["print", `gui/${userId}/${EXECUTOR_LAUNCH_AGENT_LABEL}`], true);
  return Object.freeze({ ...state, label: EXECUTOR_LAUNCH_AGENT_LABEL, plist: plistPresent, executable: executablePresent, launchd: observed.status === 0 ? "running" : "not-loaded", consistent: state.installed === true && plistPresent && executablePresent, releaseRoot, socketPath: paths.socketPath, nodePath: state.nodePath || nodePath });
}

export async function installExecutorLaunchAgent({ artifactPath, version, homeDirectory = os.homedir(), userId = process.getuid?.(), nodePath = process.execPath } = {}) {
  if (!path.isAbsolute(artifactPath || "") || !version || userId == null) throw new TypeError("An absolute artifactPath, version, and numeric user id are required.");
  nodePath = await stableExecutorNodePath(nodePath, { homeDirectory }); const paths = executorPaths({ homeDirectory, userId }); const prior = await readState(paths.statePath); const releaseRoot = path.join(paths.supportDirectory, "releases", version); const packageFile = path.join(releaseRoot, "node_modules", "@inator", "engine", "package.json"); const executable = path.join(releaseRoot, "node_modules", ".bin", "inator-executor");
  let current = false; try { const manifest = JSON.parse(await readFile(packageFile, "utf8")); current = manifest.name === "@inator/engine" && manifest.version === version; } catch { /* A missing or invalid release must be reinstalled. */ }
  if (!current) { await rm(releaseRoot, { recursive: true, force: true }); await mkdir(releaseRoot, { recursive: true }); run(npmForNode(nodePath), ["install", "--prefix", releaseRoot, "--cache", path.join(paths.supportDirectory, "npm-cache"), "--ignore-scripts", "--no-audit", "--no-fund", artifactPath]); }
  await access(executable); await mkdir(path.dirname(paths.plistPath), { recursive: true }); await mkdir(path.dirname(paths.stdoutPath), { recursive: true }); await writeFile(`${paths.plistPath}.pending`, plist({ nodePath, executable, paths }), { mode: 0o644 }); await rename(`${paths.plistPath}.pending`, paths.plistPath);
  unload({ userId }); run("/bin/launchctl", ["bootstrap", `gui/${userId}`, paths.plistPath]);
  const state = { installed: true, version, previousVersion: prior.version && prior.version !== version ? prior.version : prior.previousVersion || null, artifactPath, nodePath, installedAt: new Date().toISOString() }; await mkdir(paths.supportDirectory, { recursive: true }); await writeFile(`${paths.statePath}.pending`, `${JSON.stringify(state, null, 2)}\n`, { mode: 0o600 }); await rename(`${paths.statePath}.pending`, paths.statePath); return diagnoseExecutorInstallation({ homeDirectory, userId, nodePath });
}

export async function setExecutorLaunchAgentRunning(running, { homeDirectory = os.homedir(), userId = process.getuid?.() } = {}) { const paths = executorPaths({ homeDirectory, userId }); const state = await readState(paths.statePath); if (!state.installed) throw new Error("The pipeline executor is not installed."); if (running) run("/bin/launchctl", ["bootstrap", `gui/${userId}`, paths.plistPath]); else unload({ userId }); return diagnoseExecutorInstallation({ homeDirectory, userId, nodePath: state.nodePath }); }

export async function uninstallExecutorLaunchAgent({ homeDirectory = os.homedir(), userId = process.getuid?.() } = {}) { const paths = executorPaths({ homeDirectory, userId }); const state = await readState(paths.statePath); unload({ userId }); await rm(paths.plistPath, { force: true }); await writeFile(`${paths.statePath}.pending`, `${JSON.stringify({ ...state, installed: false, uninstalledAt: new Date().toISOString() }, null, 2)}\n`, { mode: 0o600 }); await rename(`${paths.statePath}.pending`, paths.statePath); return diagnoseExecutorInstallation({ homeDirectory, userId, nodePath: state.nodePath }); }
