import { ENGINE_PROTOCOL_VERSION, defineActivityEnvelope, defineResultEnvelope, defineWorkEnvelope, defineWorkUsage } from "./protocol.js";

export async function executeWork(workSource, { worker, handlers, signal, onActivity } = {}) {
  const work = defineWorkEnvelope(workSource); const handler = handlers?.[work.method];
  if (!handler) throw new TypeError(`Worker does not support ${work.method}.`);
  const startedAt = new Date().toISOString();
  let usage = Object.freeze([]);
  const reportActivity = async (source) => {
    const activity = defineActivityEnvelope({ ...work, ...(typeof source === "string" ? { phase: source } : source) });
    await onActivity?.(activity);
    return activity;
  };
  const reportUsage = (source) => { usage = defineWorkUsage(source); return usage; };
  try {
    const output = await handler(work.input, { work, worker, signal, reportActivity, reportUsage });
    return defineResultEnvelope({ protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: work.workspaceId, runId: work.runId, workUnitId: work.workUnitId, attemptId: work.attemptId, claimGeneration: work.claimGeneration, inputSignature: work.inputSignature, status: "succeeded", worker: { id: worker.id, version: worker.version }, startedAt, finishedAt: new Date().toISOString(), output, usage });
  } catch (error) {
    return defineResultEnvelope({ protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: work.workspaceId, runId: work.runId, workUnitId: work.workUnitId, attemptId: work.attemptId, claimGeneration: work.claimGeneration, inputSignature: work.inputSignature, status: signal?.aborted ? "cancelled" : "failed", worker: { id: worker.id, version: worker.version }, startedAt, finishedAt: new Date().toISOString(), error: { name: error.name, message: error.message } });
  }
}

export function installJsonLineWorker({ input = process.stdin, output = process.stdout, worker = { id: "worker-local", version: "dev" }, handlers = {} } = {}) {
  input.setEncoding("utf8"); let buffer = ""; let chain = Promise.resolve();
  input.on("data", (chunk) => { buffer += chunk; const lines = buffer.split(/\r?\n/); buffer = lines.pop(); for (const line of lines.filter(Boolean)) chain = chain.then(async () => { try { output.write(`${JSON.stringify({ ok: true, result: await executeWork(JSON.parse(line), { worker, handlers, onActivity: (activity) => output.write(`${JSON.stringify({ ok: true, activity })}\n`) }) })}\n`); } catch (error) { output.write(`${JSON.stringify({ ok: false, error: { name: error.name, message: error.message } })}\n`); } }); });
  return { close: () => input.destroy() };
}
