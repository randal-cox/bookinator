import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { DurableControlPlane } from "./control-plane.js";

const worker = (id) => ({ id, location: "local" });

export async function runPipelineLab({ directory = null, keep = false } = {}) {
  const ownedDirectory = !directory;
  const root = directory || await mkdtemp(path.join(tmpdir(), "inator-pipeline-lab-"));
  const transcript = [];
  let clock = Date.parse("2026-01-01T00:00:00.000Z");
  const record = (event, detail = {}) => transcript.push({ sequence: transcript.length + 1, at: new Date(clock).toISOString(), event, ...detail });
  try {
    const options = { ledgerPath: path.join(root, "events.jsonl"), workspaceId: "commons.pipeline-lab", runId: "lease-recovery", leaseMs: 50, now: () => clock };
    const initial = await new DurableControlPlane(options).open();
    await initial.enqueue({ id: "recoverable", label: "Recover after lost heartbeat", method: "commons.wait", input: { generation: 1 } });
    record("work.enqueued", { workUnitId: "recoverable" });
    const abandoned = await initial.claim(worker("worker-abandoned"));
    record("work.claimed", { attemptId: abandoned.attemptId, claimGeneration: abandoned.claimGeneration });
    clock += 51;
    const recovered = await new DurableControlPlane(options).open();
    const current = await recovered.claim(worker("worker-current"));
    record("claim.recovered", { attemptId: current.attemptId, claimGeneration: current.claimGeneration });
    const late = await recovered.accept({ ...abandoned, status: "succeeded", output: { value: "late" } });
    record("result.retained", { disposition: late.disposition, applicable: late.applicable });
    const accepted = await recovered.accept({ ...current, status: "succeeded", output: { value: "current" } });
    record("result.accepted", { disposition: accepted.disposition, applicable: accepted.applicable });
    const duplicate = await recovered.accept({ ...current, status: "succeeded", output: { value: "duplicate" } });
    record("result.duplicate", { disposition: duplicate.disposition, applicable: duplicate.applicable });
    const snapshot = recovered.snapshot();
    const invariants = {
      exactlyOneAcceptedCurrentResult: snapshot.units[0].result?.value === "current" && snapshot.units[0].attempts.filter(attempt => attempt.disposition === "succeeded").length === 1,
      lateResultRetained: snapshot.units[0].attempts.some(attempt => attempt.disposition === "stale-result"),
      claimGenerationAdvanced: current.claimGeneration === abandoned.claimGeneration + 1,
      boundedActiveProjection: snapshot.progress.active === undefined || snapshot.progress.active <= snapshot.progress.total,
    };
    const ledger = (await readFile(options.ledgerPath, "utf8")).trim().split(/\r?\n/).filter(Boolean).map(JSON.parse);
    return { schemaVersion: "inator.pipeline-lab-report.v1", root, scenario: "lease-recovery-late-and-duplicate-results", passed: Object.values(invariants).every(Boolean), invariants, transcript, ledgerEvents: ledger.length, snapshot };
  } finally {
    if (ownedDirectory && !keep) await rm(root, { recursive: true, force: true });
  }
}
