import http from "node:http";
import net from "node:net";
import { chmod, mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { executeWork } from "./worker-runtime.js";

const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
export const PIPELINE_ADAPTER_PROTOCOL_VERSION = "inator.pipeline-adapter.v1";
export const PIPELINE_CANDIDATE_PROTOCOL_VERSION = "inator.pipeline-candidate.v1";
export const PIPELINE_ARBITRATION_PROTOCOL_VERSION = "inator.pipeline-arbitration.v1";

async function jsonBody(request, maximumBytes = 1024 * 1024) {
  const chunks = []; let size = 0;
  for await (const chunk of request) { size += chunk.length; if (size > maximumBytes) throw new Error("Work envelope exceeds 1 MiB."); chunks.push(chunk); }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
}

function respond(response, status, value) {
  const body = `${JSON.stringify(value)}\n`;
  response.writeHead(status, { "content-type": "application/json", "content-length": Buffer.byteLength(body) }); response.end(body);
}

function listening(socketPath) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ path: socketPath });
    socket.once("connect", () => { socket.destroy(); resolve(true); });
    socket.once("error", () => resolve(false));
  });
}

const adapterDescriptor = (value = {}) => {
  const id = String(value.id || "").trim(); const productId = String(value.productId || "").trim(); const modulePath = String(value.modulePath || "").trim();
  if (!id || !/^[a-z0-9][a-z0-9._-]*$/i.test(id)) throw new TypeError("Adapter id must be a stable token.");
  if (!productId || !/^[a-z0-9][a-z0-9._-]*$/i.test(productId)) throw new TypeError("Adapter productId must be a stable token.");
  if (!path.isAbsolute(modulePath)) throw new TypeError("Adapter modulePath must be absolute.");
  if (value.protocolVersion !== PIPELINE_ADAPTER_PROTOCOL_VERSION) throw new TypeError(`Adapter ${id} must use ${PIPELINE_ADAPTER_PROTOCOL_VERSION}.`);
  const adapterVersion = String(value.adapterVersion || "").trim(); if (!adapterVersion) throw new TypeError(`Adapter ${id} requires adapterVersion.`);
  const registrationGeneration = Math.max(1, Math.trunc(Number(value.registrationGeneration) || 1));
  return Object.freeze({ id, productId, modulePath, adapterVersion, registrationGeneration, protocolVersion: PIPELINE_ADAPTER_PROTOCOL_VERSION, enabled: value.enabled !== false, registeredAt: value.registeredAt || new Date().toISOString() });
};

const pipelineCandidate = (source, descriptor) => {
  const candidate = { ...source, adapterId: descriptor.id, productId: descriptor.productId };
  if (candidate.protocolVersion !== PIPELINE_CANDIDATE_PROTOCOL_VERSION) throw new TypeError(`Adapter ${descriptor.id} returned an unsupported candidate protocol.`);
  for (const field of ["projectId", "workUnitId"]) if (!String(candidate[field] || "").trim()) throw new TypeError(`Adapter ${descriptor.id} candidate requires ${field}.`);
  candidate.rank = Number.isFinite(Number(candidate.rank)) ? Number(candidate.rank) : 0;
  return Object.freeze(candidate);
};

export function createExecutorService({ socketPath, adapterRegistryPath = null, version = "dev", workerId = "inator-local-executor", handlers = {}, pollMs = 750, arbitrateCandidates = null, allowDirectExecution = false } = {}) {
  if (!socketPath) throw new TypeError("socketPath is required.");
  let handled = 0; let active = 0; let closing = false; let wakeTimer = null; let current = null; let activeController = null; const startedAt = new Date().toISOString(); const adapters = new Map(); const adapterErrors = new Map();
  const builtins = { "commons.wait": async (input = {}) => { const waitMs = Math.max(0, Math.min(Number(input.waitMs) || 0, 60_000)); await wait(waitMs); return { summary: input.summary || `Waited ${(waitMs / 1000).toFixed(1)} seconds.`, waitMs }; }, ...handlers };
  const registrySnapshot = () => [...adapters.values()].map(({ descriptor, adapter, diagnostics = {} }) => ({ ...descriptor, state: adapterErrors.has(descriptor.id) ? "error" : adapter ? "ready" : "unavailable", error: adapterErrors.get(descriptor.id) || null, diagnostics: { ...diagnostics } }));
  const saveRegistry = async () => { if (!adapterRegistryPath) return; await mkdir(path.dirname(adapterRegistryPath), { recursive: true, mode: 0o700 }); const pending = `${adapterRegistryPath}.pending`; await writeFile(pending, `${JSON.stringify({ schemaVersion: "inator.executor-adapters.v1", adapters: [...adapters.values()].map(item => item.descriptor) }, null, 2)}\n`, { mode: 0o600 }); await rename(pending, adapterRegistryPath); };
  const loadAdapter = async descriptor => {
    try {
      const cacheKey = new URLSearchParams({ adapterVersion: descriptor.adapterVersion, registrationGeneration: String(descriptor.registrationGeneration) });
      const imported = await import(`${pathToFileURL(descriptor.modulePath).href}?${cacheKey}`);
      if (typeof imported.createPipelineAdapter !== "function") throw new TypeError("Adapter module must export createPipelineAdapter().");
      const adapter = await imported.createPipelineAdapter({ worker: Object.freeze({ id: workerId, version, location: "local" }), registration: descriptor });
      if (!adapter || typeof adapter.candidates !== "function" || typeof adapter.claim !== "function" || typeof adapter.settle !== "function") throw new TypeError("Adapter must provide candidates(), claim(candidate), and settle().");
      adapters.set(descriptor.id, { descriptor, adapter, diagnostics: { loadedAt: new Date().toISOString(), loadedAdapterVersion: descriptor.adapterVersion, loadedRegistrationGeneration: descriptor.registrationGeneration, lastCandidateAt: null, lastClaimAt: null, lastSettledAt: null } }); adapterErrors.delete(descriptor.id); return adapter;
    } catch (error) { adapters.set(descriptor.id, { descriptor, adapter: null, diagnostics: { loadedAt: null } }); adapterErrors.set(descriptor.id, error.message); return null; }
  };
  const register = async raw => {
    const requestedId = String(raw?.id || "").trim(); const existing = adapters.get(requestedId); const requested = adapterDescriptor({ ...raw, registeredAt: existing?.descriptor.registeredAt || raw?.registeredAt, registrationGeneration: existing?.descriptor.registrationGeneration || raw?.registrationGeneration });
    if (existing?.adapter && !adapterErrors.has(requestedId) && ["modulePath", "productId", "adapterVersion", "protocolVersion", "enabled"].every(field => existing.descriptor[field] === requested[field])) return registrySnapshot().find(item => item.id === requestedId);
    const descriptor = adapterDescriptor({ ...requested, registrationGeneration: (existing?.descriptor.registrationGeneration || 0) + 1 });
    await loadAdapter(descriptor); await saveRegistry(); schedule(0); return registrySnapshot().find(item => item.id === descriptor.id);
  };
  const loadRegistry = async () => {
    if (!adapterRegistryPath) return;
    const stored = JSON.parse(await readFile(adapterRegistryPath, "utf8").catch(() => "{\"adapters\":[]}"));
    for (const raw of stored.adapters || []) {
      try { await loadAdapter(adapterDescriptor(raw)); }
      catch (error) {
        // Protocol upgrades must not brick the Highlander before products can
        // refresh their registrations. Retain the legacy identity visibly as
        // incompatible; a normal register call replaces it in place.
        const id = String(raw?.id || "legacy-adapter").trim();
        const descriptor = Object.freeze({ id, productId: String(raw?.productId || ""), modulePath: String(raw?.modulePath || ""), adapterVersion: String(raw?.adapterVersion || "legacy"), registrationGeneration: Math.max(1, Math.trunc(Number(raw?.registrationGeneration) || 1)), protocolVersion: String(raw?.protocolVersion || "legacy"), enabled: false, registeredAt: raw?.registeredAt || new Date().toISOString() });
        adapters.set(id, { descriptor, adapter: null, diagnostics: {} }); adapterErrors.set(id, `Adapter registration is incompatible and must be refreshed: ${error.message}`);
      }
    }
  };
  const cycle = async () => {
    wakeTimer = null; if (closing || active) return;
    const offered = [];
    for (const entry of adapters.values()) {
      if (!entry.descriptor.enabled || !entry.adapter) continue;
      try {
        const values = await entry.adapter.candidates(); entry.diagnostics.lastCandidateAt = new Date().toISOString();
        for (const value of Array.isArray(values) ? values : values ? [values] : []) offered.push(pipelineCandidate(value, entry.descriptor));
        adapterErrors.delete(entry.descriptor.id);
      } catch (error) { adapterErrors.set(entry.descriptor.id, error.message); }
    }
    let decision = { protocolVersion: PIPELINE_ARBITRATION_PROTOCOL_VERSION, selected: null, diagnostics: [] };
    if (offered.length) {
      try {
        if (typeof arbitrateCandidates !== "function") throw new Error("Supervisor pipeline arbitration is unavailable.");
        decision = await arbitrateCandidates({ protocolVersion: PIPELINE_ARBITRATION_PROTOCOL_VERSION, candidates: offered });
      } catch (error) { for (const candidate of offered) adapterErrors.set(candidate.adapterId, error.message); schedule(pollMs); return; }
    }
    if (decision?.protocolVersion !== PIPELINE_ARBITRATION_PROTOCOL_VERSION) { for (const candidate of offered) adapterErrors.set(candidate.adapterId, "Supervisor returned an unsupported arbitration protocol."); schedule(pollMs); return; }
    for (const entry of adapters.values()) entry.diagnostics.lastArbitrationReason = null;
    for (const diagnostic of decision.diagnostics || []) { const rejected = adapters.get(diagnostic.adapterId); if (rejected) rejected.diagnostics.lastArbitrationReason = String(diagnostic.reason || "not-selected"); }
    const selected = decision?.selected; const entry = selected && adapters.get(selected.adapterId);
    if (selected && !offered.some(candidate => candidate.adapterId === selected.adapterId && candidate.productId === selected.productId && candidate.projectId === selected.projectId && candidate.workUnitId === selected.workUnitId)) {
      if (entry) adapterErrors.set(entry.descriptor.id, "Supervisor selected a candidate that was not offered."); schedule(pollMs); return;
    }
    if (entry) {
      let work;
      try { work = await entry.adapter.claim(selected); entry.diagnostics.lastClaimAt = new Date().toISOString(); } catch (error) { adapterErrors.set(entry.descriptor.id, error.message); schedule(pollMs); return; }
      if (!work) { schedule(pollMs); return; }
      if (work.workUnitId !== selected.workUnitId) { adapterErrors.set(entry.descriptor.id, `Adapter claimed ${work.workUnitId} after Supervisor selected ${selected.workUnitId}.`); schedule(pollMs); return; }
      active = 1; current = { adapterId: entry.descriptor.id, productId: entry.descriptor.productId, projectId: selected.projectId, workUnitId: work.workUnitId, attemptId: work.attemptId, startedAt: new Date().toISOString() };
      let heartbeat = null; activeController = new AbortController();
      try {
        if (typeof entry.adapter.heartbeat === "function") heartbeat = setInterval(() => entry.adapter.heartbeat(work).catch(error => adapterErrors.set(entry.descriptor.id, error.message)), 15_000);
        const result = await executeWork(work, { worker: { id: workerId, version }, handlers: { ...builtins, ...(entry.adapter.handlers || {}) }, signal: activeController.signal });
        await entry.adapter.settle(work, result); entry.diagnostics.lastSettledAt = new Date().toISOString(); handled += 1; adapterErrors.delete(entry.descriptor.id);
      } catch (error) { adapterErrors.set(entry.descriptor.id, error.message); try { await entry.adapter.failed?.(work, error); } catch { /* The original adapter failure remains authoritative. */ } }
      finally { if (heartbeat) clearInterval(heartbeat); active = 0; current = null; activeController = null; }
    }
    schedule(pollMs);
  };
  function schedule(delay = pollMs) { if (closing || wakeTimer) return; wakeTimer = setTimeout(() => void cycle(), Math.max(0, delay)); }
  const server = http.createServer(async (request, response) => {
    try {
      const url = new URL(request.url, "http://inator.local");
      if (request.method === "GET" && url.pathname === "/v1/status") return respond(response, 200, { label: "com.inator.pipeline-executor", version, pid: process.pid, state: active ? "working" : "idle", active, handled, startedAt, current, adapters: registrySnapshot() });
      if (request.method === "POST" && url.pathname === "/v1/adapters/register") return respond(response, 200, await register(await jsonBody(request)));
      if (request.method === "POST" && url.pathname === "/v1/wake") { schedule(0); return respond(response, 202, { accepted: true }); }
      if (request.method === "POST" && url.pathname === "/v1/execute") {
        if (!allowDirectExecution) throw new Error("Direct execution is disabled; register an adapter for Supervisor arbitration.");
        const work = await jsonBody(request); active += 1;
        try { const result = await executeWork(work, { worker: { id: workerId, version }, handlers: builtins }); handled += 1; return respond(response, 200, result); }
        finally { active -= 1; }
      }
      return respond(response, 404, { error: "Unknown executor route." });
    } catch (error) { return respond(response, 400, { error: error.message }); }
  });
  return Object.freeze({
    async start() { await mkdir(path.dirname(socketPath), { recursive: true, mode: 0o700 }); if (await listening(socketPath)) throw new Error(`An Inator executor is already listening at ${socketPath}.`); await rm(socketPath, { force: true }); await loadRegistry(); await new Promise((resolve, reject) => { server.once("error", reject); server.listen(socketPath, () => { server.off("error", reject); resolve(); }); }); await chmod(socketPath, 0o600); schedule(0); return this; },
    async close() { closing = true; if (wakeTimer) clearTimeout(wakeTimer); activeController?.abort(new Error("Shared executor is stopping.")); if (server.listening) await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve())); await rm(socketPath, { force: true }); },
    socketPath
  });
}

export function createPipelineArbitrationClient({ socketPath, timeoutMs = 5000 } = {}) {
  if (!socketPath) throw new TypeError("Supervisor socketPath is required.");
  return async (body) => new Promise((resolve, reject) => {
    const payload = JSON.stringify(body); const operation = http.request({ socketPath, method: "POST", path: "/v1/pipeline/arbitrate", headers: { "content-type": "application/json", "content-length": Buffer.byteLength(payload) } }, response => {
      const chunks = []; response.on("data", chunk => chunks.push(chunk)); response.on("end", () => { const value = JSON.parse(Buffer.concat(chunks).toString("utf8")); response.statusCode >= 400 ? reject(new Error(value.error)) : resolve(value); });
    });
    operation.on("error", reject); operation.setTimeout(timeoutMs, () => operation.destroy(new Error("Supervisor arbitration timed out."))); operation.end(payload);
  });
}

export function createExecutorClient({ socketPath, timeoutMs = 65_000 } = {}) {
  const request = (method, pathname, body = null) => new Promise((resolve, reject) => {
    const payload = body == null ? "" : JSON.stringify(body); const operation = http.request({ socketPath, method, path: pathname, headers: payload ? { "content-type": "application/json", "content-length": Buffer.byteLength(payload) } : {} }, (response) => { const chunks = []; response.on("data", (chunk) => chunks.push(chunk)); response.on("end", () => { const value = JSON.parse(Buffer.concat(chunks).toString("utf8")); response.statusCode >= 400 ? reject(new Error(value.error)) : resolve(value); }); });
    operation.on("error", reject); operation.setTimeout(timeoutMs, () => operation.destroy(new Error("Executor request timed out."))); operation.end(payload);
  });
  return Object.freeze({ status: () => request("GET", "/v1/status"), execute: (work) => request("POST", "/v1/execute", work), registerAdapter: descriptor => request("POST", "/v1/adapters/register", descriptor), wake: () => request("POST", "/v1/wake", {}) });
}
