export const INCREMENTAL_GENERATION_PLAN_SCHEMA = "inator.incremental-generation-plan.v1";
export const INCREMENTAL_ARTIFACT_CATALOG_SCHEMA = "inator.incremental-artifact-catalog.v1";

function requiredText(value, label) {
  const text = String(value ?? "").trim();
  if (!text) throw new TypeError(`${label} is required.`);
  return text;
}

function unique(values, label) {
  if (new Set(values).size !== values.length) throw new TypeError(`${label} must be unique.`);
}

function normalizeSpecialists(values = []) {
  if (!Array.isArray(values) || !values.length) throw new TypeError("Incremental specialists must be a non-empty array.");
  const specialists = values.map((value, index) => Object.freeze({ ...value, id: requiredText(value?.id, `Specialist ${index + 1} id`), method: requiredText(value?.method, `Specialist ${index + 1} method`) }));
  unique(specialists.map(({ id }) => id), "Specialist ids");
  return Object.freeze(specialists);
}

function normalizeInputs(values = [], label = "Inputs") {
  if (!Array.isArray(values)) throw new TypeError(`${label} must be an array.`);
  const inputs = values.map((value, index) => {
    const specialistSignatures = Object.fromEntries(Object.entries(value?.specialistSignatures || {}).map(([id, signature]) => [requiredText(id, `${label} ${index + 1} specialist id`), requiredText(signature, `${label} ${index + 1} specialist signature`)]));
    return Object.freeze({ ...value, id: requiredText(value?.id, `${label} ${index + 1} id`), signature: requiredText(value?.signature, `${label} ${index + 1} signature`), specialistSignatures: Object.freeze(specialistSignatures) });
  });
  unique(inputs.map(({ id }) => id), `${label} ids`);
  return Object.freeze(inputs);
}

function normalizeArtifacts(values = [], label = "Artifacts") {
  if (!Array.isArray(values)) throw new TypeError(`${label} must be an array.`);
  const artifacts = values.map((value, index) => Object.freeze({
    ...value,
    id: requiredText(value?.id, `${label} ${index + 1} id`),
    specialistId: requiredText(value?.specialistId, `${label} ${index + 1} specialistId`),
    inputId: requiredText(value?.inputId, `${label} ${index + 1} inputId`),
    inputSignature: requiredText(value?.inputSignature, `${label} ${index + 1} inputSignature`)
  }));
  unique(artifacts.map(({ id }) => id), `${label} ids`);
  unique(artifacts.map(({ specialistId, inputId }) => `${specialistId}\u0000${inputId}`), `${label} specialist/input pairs`);
  return Object.freeze(artifacts);
}

const specialistSignature = (input, specialistId) => input.specialistSignatures[specialistId] || input.signature;
const pairKey = (specialistId, inputId) => `${specialistId}\u0000${inputId}`;

export function planIncrementalGeneration({ generationId, previousGenerationId = null, specialists, inputs = [], previousInputs = [], previousArtifacts = [] } = {}) {
  const normalizedGenerationId = requiredText(generationId, "Generation id");
  const normalizedSpecialists = normalizeSpecialists(specialists);
  const current = normalizeInputs(inputs);
  const previous = normalizeInputs(previousInputs, "Previous inputs");
  const artifacts = normalizeArtifacts(previousArtifacts, "Previous artifacts");
  const specialistIds = new Set(normalizedSpecialists.map(({ id }) => id));
  for (const artifact of artifacts) if (!specialistIds.has(artifact.specialistId)) throw new TypeError(`Previous artifact ${artifact.id} references unknown specialist ${artifact.specialistId}.`);
  const previousById = new Map(previous.map(input => [input.id, input]));
  const currentById = new Map(current.map(input => [input.id, input]));
  const artifactsByPair = new Map(artifacts.map(artifact => [pairKey(artifact.specialistId, artifact.inputId), artifact]));
  const inputStates = current.map(input => {
    const prior = previousById.get(input.id);
    return Object.freeze({ id: input.id, state: !prior ? "new" : prior.signature === input.signature ? "reused" : "changed", signature: input.signature, priorSignature: prior?.signature || null });
  });
  for (const input of previous) if (!currentById.has(input.id)) inputStates.push(Object.freeze({ id: input.id, state: "removed", signature: null, priorSignature: input.signature }));
  const reusedArtifacts = []; const work = [];
  for (const input of current) for (const specialist of normalizedSpecialists) {
    const inputSignature = specialistSignature(input, specialist.id); const prior = artifactsByPair.get(pairKey(specialist.id, input.id));
    if (prior?.inputSignature === inputSignature) reusedArtifacts.push(Object.freeze({ ...prior, disposition: "reused", sourceGenerationId: previousGenerationId }));
    else work.push(Object.freeze({ id: `${specialist.id}:${input.id}`, generationId: normalizedGenerationId, specialistId: specialist.id, method: specialist.method, inputId: input.id, inputSignature, disposition: prior ? "changed" : "new" }));
  }
  const count = state => inputStates.filter(item => item.state === state).length;
  return Object.freeze({
    schemaVersion: INCREMENTAL_GENERATION_PLAN_SCHEMA,
    generationId: normalizedGenerationId,
    previousGenerationId: previousGenerationId == null ? null : requiredText(previousGenerationId, "Previous generation id"),
    specialists: normalizedSpecialists,
    inputs: current,
    inputStates: Object.freeze(inputStates),
    counts: Object.freeze({ inputs: Object.freeze({ reused: count("reused"), new: count("new"), changed: count("changed"), removed: count("removed") }), artifacts: Object.freeze({ reused: reusedArtifacts.length, required: work.length }) }),
    reusedArtifacts: Object.freeze(reusedArtifacts),
    work: Object.freeze(work)
  });
}

export function mergeIncrementalGeneration(plan, producedArtifacts = []) {
  if (plan?.schemaVersion !== INCREMENTAL_GENERATION_PLAN_SCHEMA) throw new TypeError("A valid incremental generation plan is required.");
  const produced = normalizeArtifacts(producedArtifacts, "Produced artifacts");
  const expected = new Map(plan.work.map(item => [pairKey(item.specialistId, item.inputId), item]));
  for (const artifact of produced) {
    const work = expected.get(pairKey(artifact.specialistId, artifact.inputId));
    if (!work) throw new TypeError(`Produced artifact ${artifact.id} was not requested by this generation.`);
    if (artifact.inputSignature !== work.inputSignature) throw new TypeError(`Produced artifact ${artifact.id} does not match the requested input signature.`);
    expected.delete(pairKey(artifact.specialistId, artifact.inputId));
  }
  if (expected.size) throw new TypeError(`Generation ${plan.generationId} is missing ${expected.size} required artifact${expected.size === 1 ? "" : "s"}.`);
  const artifacts = Object.freeze([...plan.reusedArtifacts, ...produced.map(artifact => Object.freeze({ ...artifact, disposition: "produced", generationId: plan.generationId }))]);
  return Object.freeze({ schemaVersion: INCREMENTAL_ARTIFACT_CATALOG_SCHEMA, generationId: plan.generationId, previousGenerationId: plan.previousGenerationId, counts: Object.freeze({ reused: plan.reusedArtifacts.length, produced: produced.length, total: artifacts.length }), artifacts });
}
