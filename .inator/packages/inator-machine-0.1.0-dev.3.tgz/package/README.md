# @inator/machine

Identity-safe host facts and product-owned capability evaluation. Snapshots omit
hostnames, usernames, home directories, workspace paths, and network addresses.
Unknown facts remain unknown; they are never converted into fictional zeroes.

