export const COMMERCIAL_RISK_SCREEN_SCHEMA = "inator.commercial-risk-screen.v1";

const RELEASE_RANK = Object.freeze({
  "local-prototype": 0,
  "private-pilot": 1,
  "public-free": 2,
  commercial: 3,
  regulated: 4,
  unknown: 4
});
const REQUIRED_BEFORE_RANK = Object.freeze({ "private-pilot": 1, "public-release": 2, "commercial-launch": 3, "regulated-use": 4 });

function text(value) { return String(value ?? "").trim(); }
function uncertainStatements(items = []) { return items.filter((item) => /unknown|not established|not verified|incomplete|no production|remain/i.test(text(item))); }

export function screenCommercialRiskProfile(profile) {
  if (!profile || profile.schemaVersion !== 1) throw new TypeError("Commercial-risk profile v1 is required.");
  const findings = [];
  const add = (id, severity, title, evidence, requiredBefore = "public-release") => findings.push({ id, severity, title, evidence, requiredBefore });
  const releaseRank = RELEASE_RANK[profile.releaseIntent] ?? RELEASE_RANK.unknown;
  const releaseBound = releaseRank >= RELEASE_RANK["public-free"];

  if (profile.releaseIntent === "unknown") add("CRS-RELEASE-INTENT-UNKNOWN", "critical", "Release intent is unknown, so risk gates cannot be selected truthfully.", { releaseIntent: profile.releaseIntent }, "private-pilot");
  if (profile.operator?.status !== "confirmed" || !text(profile.operator?.responsibleEntity)) add("CRS-OPERATOR-UNKNOWN", releaseBound ? "critical" : "high", "No accountable operating entity is confirmed.", profile.operator, "public-release");
  if (profile.audience?.status !== "confirmed" || !profile.audience?.intendedUsers?.length) add("CRS-AUDIENCE-UNKNOWN", releaseBound ? "high" : "medium", "The intended audience is not confirmed.", profile.audience, "public-release");
  if (profile.audience?.childrenStatus === "unknown") add("CRS-CHILDREN-SCOPE-UNKNOWN", profile.commercialPractices?.accounts ? "critical" : "high", "Children and teen applicability is unresolved.", { accounts: profile.commercialPractices?.accounts, childrenStatus: profile.audience?.childrenStatus }, "public-release");
  if (profile.commercialPractices?.accounts && ["mixed-audience", "child-directed"].includes(profile.audience?.childrenStatus) && !text(profile.audience?.ageAssurance)) add("CRS-AGE-ASSURANCE-UNSPECIFIED", "critical", "Accounts may include children but the age/consent approach is unspecified.", profile.audience, "public-release");
  if (profile.jurisdictions?.status !== "confirmed" || !profile.jurisdictions?.markets?.length) add("CRS-JURISDICTIONS-UNKNOWN", releaseBound ? "critical" : "high", "Markets and jurisdictions are unresolved.", profile.jurisdictions, "commercial-launch");

  const contacts = profile.contacts || {};
  for (const [kind, severity] of [["support", "high"], ["privacy", "high"], ["accessibility", "high"], ["securityReporting", "critical"]]) {
    if (!text(contacts[kind])) add(`CRS-CONTACT-${kind.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`).toUpperCase()}-MISSING`, releaseBound ? severity : "medium", `No monitored ${kind} contact is declared.`, { contact: kind, value: contacts[kind] }, "public-release");
  }

  const rights = profile.contentRights || {};
  if (!rights.dependenciesReviewed) add("CRS-DEPENDENCY-RIGHTS-UNREVIEWED", "high", "Dependency license obligations are not reviewed.", rights, "public-release");
  if (!rights.assetsReviewed) add("CRS-ASSET-RIGHTS-UNREVIEWED", "high", "Asset, font, icon, and media rights are not reviewed.", rights, "public-release");
  if (!rights.datasetsReviewed) add("CRS-DATASET-RIGHTS-UNREVIEWED", "high", "Dataset and sample-data rights are not reviewed.", rights, "public-release");
  if (rights.generatedContentPolicy === "unknown") add("CRS-GENERATED-CONTENT-POLICY-UNKNOWN", "medium", "Generated-content provenance and permitted-use policy is unknown.", rights, "public-release");

  const data = profile.dataPractices || {};
  if ((data.categories || []).length && !text(contacts.privacy)) add("CRS-DATA-WITHOUT-PRIVACY-ROUTE", "critical", "The product handles declared data but provides no privacy request route.", { categories: data.categories }, "public-release");
  const trackingUnknown = uncertainStatements(data.cookiesAndTracking);
  if (releaseBound && (!(data.cookiesAndTracking || []).length || trackingUnknown.length)) add("CRS-TRACKING-POSTURE-UNVERIFIED", "high", "Cookie, storage, telemetry, or tracking behavior is not verified for the intended release.", { statements: data.cookiesAndTracking || [], uncertain: trackingUnknown }, "public-release");
  const recipientsUnknown = uncertainStatements(data.networkRecipients);
  if (releaseBound && recipientsUnknown.length) add("CRS-NETWORK-RECIPIENTS-UNVERIFIED", "high", "Network recipients are described with unresolved or unverified language.", { uncertain: recipientsUnknown }, "public-release");
  if (!(data.retentionAndDeletion || []).length) add("CRS-RETENTION-DELETION-MISSING", "high", "Retention and deletion behavior is not declared.", {}, "public-release");

  if (profile.commercialPractices?.payments && !text(contacts.support)) add("CRS-PAYMENTS-WITHOUT-SUPPORT", "critical", "Payments are planned without a support route.", {}, "commercial-launch");
  if (profile.commercialPractices?.subscriptions && !profile.commercialPractices?.payments) add("CRS-SUBSCRIPTION-FACTS-INCONSISTENT", "high", "Subscriptions are declared without payments, requiring explicit explanation.", profile.commercialPractices, "commercial-launch");
  if (profile.commercialPractices?.regulatedClaims?.length) add("CRS-REGULATED-CLAIMS-REVIEW", "critical", "Regulated claims require qualified review and substantiation.", { claims: profile.commercialPractices.regulatedClaims }, "regulated-use");
  if (releaseBound && !text(profile.approvedBy)) add("CRS-HUMAN-APPROVAL-MISSING", "critical", "No human release authority approved the commercial-risk facts.", { approvedBy: profile.approvedBy }, "public-release");

  const dueUnknowns = (profile.unknowns || []).filter((item) => releaseRank >= (REQUIRED_BEFORE_RANK[item.requiredBefore] ?? 0));
  for (const item of dueUnknowns) add(`CRS-UNRESOLVED-${text(item.id).toUpperCase()}`, "high", item.question, { consequence: item.consequence, owner: item.owner }, item.requiredBefore);

  return Object.freeze({
    schema: COMMERCIAL_RISK_SCREEN_SCHEMA,
    product: profile.product,
    asOf: profile.asOf,
    releaseIntent: profile.releaseIntent,
    status: findings.length ? "fail" : "pass",
    findings,
    boundaries: [
      "This is deterministic issue spotting from declared facts, not legal advice or compliance certification.",
      "The screen does not infer that collecting a full date of birth is universally required; it requires an audience and age-handling decision when relevant.",
      "A complete-looking profile may still be false and must be reconciled with runtime, organizational, and legal evidence."
    ]
  });
}
