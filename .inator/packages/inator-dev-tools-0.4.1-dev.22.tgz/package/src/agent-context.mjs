import { access, readFile, readdir } from "node:fs/promises";
import path from "node:path";

export const AGENT_CONTEXT_SCHEMA = "inator.agent-context.v1";
const EVIDENCE_ROLES = new Set(["standard", "package", "laboratory", "harvest", "test", "consumer", "reference"]);
export const CODEX_PROFILE_CATALOG = {
  "core-code": {
    description: "Code, shell, tests, review, and ordinary repository work.",
    plugins: {
      "documents@openai-primary-runtime": false,
      "pdf@openai-primary-runtime": false,
      "spreadsheets@openai-primary-runtime": false,
      "presentations@openai-primary-runtime": false,
      "template-creator@openai-primary-runtime": false,
      "google-calendar@openai-curated": false,
      "slack@openai-curated": false,
      "computer-history@openai-bundled": false
    },
    mcpServers: { "mailinator-mail": false }
  },
  "ui-runtime": { description: "Keep the bundled browser and computer-use surfaces available for explicit live acceptance.", plugins: {}, mcpServers: {} },
  "artifact-authoring": {
    description: "Enable document, PDF, spreadsheet, presentation, and reusable-template work.",
    plugins: {
      "documents@openai-primary-runtime": true,
      "pdf@openai-primary-runtime": true,
      "spreadsheets@openai-primary-runtime": true,
      "presentations@openai-primary-runtime": true,
      "template-creator@openai-primary-runtime": true
    },
    mcpServers: {}
  },
  "mail-read-only": { description: "Enable Mailinator's read-only MCP only inside mail.inator.", plugins: {}, mcpServers: { "mailinator-mail": true } }
};

function safeRelativePath(value) {
  return typeof value === "string" && value.length > 0 && !path.isAbsolute(value) && !value.split(/[\\/]/).includes("..");
}

export function validateAgentContextManifest(manifest) {
  const errors = [];
  if (!manifest || typeof manifest !== "object" || Array.isArray(manifest)) return ["Agent context manifest must be an object."];
  if (manifest.schema !== AGENT_CONTEXT_SCHEMA) errors.push(`schema must be ${AGENT_CONTEXT_SCHEMA}.`);
  if (!manifest.product || typeof manifest.product !== "string") errors.push("product is required.");
  if (!manifest.topics || typeof manifest.topics !== "object" || Array.isArray(manifest.topics) || !Object.keys(manifest.topics).length) errors.push("topics must be a non-empty object.");
  if (manifest.privatePaths != null && (!Array.isArray(manifest.privatePaths) || manifest.privatePaths.some((entry) => !safeRelativePath(entry)))) errors.push("privatePaths must contain safe project-relative paths.");
  if (manifest.codexProfiles != null && (!Array.isArray(manifest.codexProfiles) || !manifest.codexProfiles.length || manifest.codexProfiles.some((profile) => !Object.hasOwn(CODEX_PROFILE_CATALOG, profile)))) errors.push(`codexProfiles must contain known profiles: ${Object.keys(CODEX_PROFILE_CATALOG).join(", ")}.`);
  if (manifest.budgets != null && (typeof manifest.budgets !== "object" || Array.isArray(manifest.budgets) || [manifest.budgets.agentInstructionsBytes, manifest.budgets.routeBytes].some((value) => value != null && (!Number.isInteger(value) || value < 1)))) errors.push("budgets values must be positive integer byte limits.");
  for (const [topic, route] of Object.entries(manifest.topics || {})) {
    if (!/^[a-z0-9][a-z0-9-]*$/.test(topic)) errors.push(`Invalid topic id ${topic}.`);
    if (!route || typeof route !== "object" || Array.isArray(route)) { errors.push(`${topic} must be an object.`); continue; }
    if (typeof route.summary !== "string" || !route.summary.trim()) errors.push(`${topic}.summary is required.`);
    if (!Array.isArray(route.evidence) || !route.evidence.length) errors.push(`${topic}.evidence must be a non-empty array.`);
    for (const [index, item] of (route.evidence || []).entries()) {
      if (!item || typeof item !== "object" || Array.isArray(item)) { errors.push(`${topic}.evidence[${index}] must be an object.`); continue; }
      if (!EVIDENCE_ROLES.has(item.role)) errors.push(`${topic}.evidence[${index}].role is invalid.`);
      if (!safeRelativePath(item.path)) errors.push(`${topic}.evidence[${index}].path must be project-relative.`);
      if ((manifest.privatePaths || []).some((privatePath) => item.path === privatePath || item.path?.startsWith(`${privatePath}/`))) errors.push(`${topic}.evidence[${index}].path enters private path ${item.path}.`);
    }
  }
  return errors;
}

export async function readAgentContextManifest(projectDir) {
  const file = path.join(projectDir, "inator.context.json");
  const manifest = JSON.parse(await readFile(file, "utf8"));
  const errors = validateAgentContextManifest(manifest);
  if (errors.length) throw new Error(errors.join("\n"));
  return { file, manifest };
}

export async function auditAgentContext(projectDir) {
  const checks = [];
  let manifest;
  try {
    ({ manifest } = await readAgentContextManifest(projectDir));
    checks.push({ id: "manifest", ok: true, message: "inator.context.json is valid." });
  } catch (error) {
    return { ok: false, checks: [{ id: "manifest", ok: false, message: error.message }] };
  }

  const missing = [];
  const standardPaths = new Set();
  for (const route of Object.values(manifest.topics)) {
    for (const item of route.evidence) {
      try { await access(path.join(projectDir, item.path)); }
      catch { missing.push(item.path); }
      if (item.role === "standard") standardPaths.add(item.path);
    }
  }
  checks.push({ id: "evidence-paths", ok: missing.length === 0, message: missing.length ? `Missing context evidence: ${[...new Set(missing)].join(", ")}.` : "Every context evidence path exists." });

  if (manifest.requireStandardsCoverage) {
    const standardsDir = path.join(projectDir, "docs", "standards");
    const standards = (await readdir(standardsDir)).filter((name) => name.endsWith(".md")).map((name) => `docs/standards/${name}`);
    const uncovered = standards.filter((standard) => !standardPaths.has(standard));
    checks.push({ id: "standards-coverage", ok: uncovered.length === 0, message: uncovered.length ? `Unrouted standards: ${uncovered.join(", ")}.` : `Every standard is routed (${standards.length}).` });
  }

  try {
    const agents = await readFile(path.join(projectDir, "AGENTS.md"), "utf8");
    const routed = /inator context/.test(agents)
      && /reuse before invention/i.test(agents)
      && /Is there already a Commons thing I can use/i.test(agents)
      && /REUSE, DRY, CONFORM/.test(agents);
    checks.push({ id: "agent-entry", ok: routed, message: routed ? "AGENTS.md carries the Commons-first governing question and bounded context routing." : "AGENTS.md must carry the Commons-first governing question, REUSE, DRY, CONFORM, and `inator context`." });
    if (manifest.budgets?.agentInstructionsBytes) {
      const bytes = Buffer.byteLength(agents);
      checks.push({ id: "agent-budget", ok: bytes <= manifest.budgets.agentInstructionsBytes, message: `AGENTS.md uses ${bytes}/${manifest.budgets.agentInstructionsBytes} bytes.` });
    }
  } catch {
    checks.push({ id: "agent-entry", ok: false, message: "AGENTS.md is missing." });
  }

  if (manifest.budgets?.routeBytes) {
    const sizes = Object.entries(manifest.topics).map((entry) => [entry[0], Buffer.byteLength(formatContextRoutes([entry]))]);
    const oversized = sizes.filter(([, bytes]) => bytes > manifest.budgets.routeBytes);
    checks.push({ id: "route-budget", ok: oversized.length === 0, message: oversized.length ? `Oversized routes: ${oversized.map(([id, bytes]) => `${id} (${bytes})`).join(", ")}.` : `Every route stays within ${manifest.budgets.routeBytes} bytes.` });
  }

  if (manifest.codexProfiles) {
    const expected = renderLeanCodexConfig(manifest.codexProfiles);
    let current = "";
    try { current = await readFile(path.join(projectDir, ".codex", "config.toml"), "utf8"); } catch { /* Missing config is reported as a failed check below. */ }
    checks.push({ id: "codex-config", ok: current === expected, message: current === expected ? `Codex config matches ${manifest.codexProfiles.join(" + ")}.` : "Project Codex config is missing or stale; run `inator configure-codex`." });
  }

  return { ok: checks.every(({ ok }) => ok), checks };
}

export function renderLeanCodexConfig(profileIds) {
  const plugins = new Map();
  const mcpServers = new Map();
  for (const id of profileIds) {
    const profile = CODEX_PROFILE_CATALOG[id];
    if (!profile) throw new Error(`Unknown Codex profile ${id}.`);
    for (const [name, enabled] of Object.entries(profile.plugins)) plugins.set(name, enabled);
    for (const [name, enabled] of Object.entries(profile.mcpServers)) mcpServers.set(name, enabled);
  }
  const lines = ["# Generated by @inator/dev-tools. Select profiles in inator.context.json.", `# Profiles: ${profileIds.join(", ")}`, ""];
  for (const [name, enabled] of [...plugins].sort(([left], [right]) => left.localeCompare(right))) lines.push(`[plugins.${JSON.stringify(name)}]`, `enabled = ${enabled}`, "");
  for (const [name, enabled] of [...mcpServers].sort(([left], [right]) => left.localeCompare(right))) lines.push(`[mcp_servers.${name}]`, `enabled = ${enabled}`, "");
  return `${lines.join("\n").trimEnd()}\n`;
}

export function selectContextRoutes(manifest, query = "") {
  const normalized = query.trim().toLowerCase();
  const entries = Object.entries(manifest.topics);
  if (!normalized) return entries;
  const exact = entries.filter(([id]) => id === normalized);
  if (exact.length) return exact;
  const terms = normalized.split(/\s+/).filter(Boolean);
  return entries.filter(([id, route]) => terms.every((term) => `${id} ${route.summary}`.toLowerCase().includes(term)));
}

export function formatContextRoutes(entries) {
  return entries.map(([id, route]) => [
    `${id}: ${route.summary}`,
    ...route.evidence.map(({ role, path: evidencePath }) => `  ${role}: ${evidencePath}`)
  ].join("\n")).join("\n\n");
}

export function formatAgentContextAudit(result) {
  const failures = result.checks.filter(({ ok }) => !ok);
  if (!failures.length) return `[inator]: agent context pass · ${result.checks.length} checks`;
  return [`[inator]: agent context fail · ${failures.length}/${result.checks.length} checks`, ...failures.map(({ id, message }) => `- ${id}: ${message}`)].join("\n");
}
