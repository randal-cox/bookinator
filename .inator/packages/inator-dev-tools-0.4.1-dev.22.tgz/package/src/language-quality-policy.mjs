export const LANGUAGE_QUALITY_POLICY_SCHEMA = "inator.language-quality-policy.v1";

export const DEFAULT_LANGUAGE_QUALITY_POLICY = Object.freeze({
  python: { extensions: [".py", ".pyi"], requiredProfiles: ["ruff", "pylint", "mypy", "bandit"] },
  swift: { extensions: [".swift"], requiredProfiles: ["swiftlint", "swift-execution"] },
  shell: { extensions: [".sh", ".bash", ".zsh"], requiredProfiles: ["shellcheck", "shell-syntax"] },
  javascript: { extensions: [".js", ".mjs", ".cjs"], requiredProfiles: ["eslint", "second-js-linter", "execution-tests"] }
});

export function evaluateLanguageQualityPolicy({ files, configuredProfiles = [], policy = DEFAULT_LANGUAGE_QUALITY_POLICY }) {
  if (!Array.isArray(files) || !Array.isArray(configuredProfiles)) throw new TypeError("files and configuredProfiles must be arrays");
  const configured = new Set(configuredProfiles);
  const languages = [];
  const violations = [];
  for (const [language, rule] of Object.entries(policy)) {
    const matchingFiles = files.filter((file) => rule.extensions.some((extension) => file.endsWith(extension)));
    if (!matchingFiles.length) continue;
    const missingProfiles = rule.requiredProfiles.filter((profile) => !configured.has(profile));
    languages.push({ language, files: matchingFiles.length, requiredProfiles: rule.requiredProfiles, missingProfiles });
    if (missingProfiles.length) violations.push({ id: `LANGUAGE-PROFILE-MISSING-${language.toUpperCase()}`, language, files: matchingFiles.length, missingProfiles, sampleFiles: matchingFiles.slice(0, 8) });
  }
  return Object.freeze({ schema: LANGUAGE_QUALITY_POLICY_SCHEMA, status: violations.length ? "fail" : "pass", languages, violations });
}
