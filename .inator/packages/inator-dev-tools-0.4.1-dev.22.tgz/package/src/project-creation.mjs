const ARCHETYPES = Object.freeze({
  "browser-static": Object.freeze({
    capabilities: Object.freeze(["action-bars", "dialogs", "lists", "product-history", "product-shell", "resources", "workspace"]),
    publicationProfiles: Object.freeze(["static-public"])
  }),
  "local-workbench": Object.freeze({
    capabilities: Object.freeze(["action-bars", "development-serving", "dialogs", "lists", "machine-state", "product-history", "product-shell", "resources", "workspace"]),
    publicationProfiles: Object.freeze(["local-full", "static-public"])
  }),
  "research-compute": Object.freeze({
    capabilities: Object.freeze(["action-bars", "development-serving", "dialogs", "lists", "machine-state", "model-runtime", "pipeline-engine", "pipeline-presentation", "product-history", "product-shell", "resources", "software-inventory", "workspace"]),
    publicationProfiles: Object.freeze(["local-full", "static-public"])
  })
});

function requiredText(value, name) {
  if (typeof value !== "string" || !value.trim()) throw new TypeError(`${name} is required.`);
  return value.trim();
}

function safeProductId(value) {
  const id = requiredText(value, "product.id");
  if (!/^[a-z][a-z0-9-]*(?:\.inator)?$/.test(id)) throw new TypeError("product.id must be lowercase letters, numbers, and hyphens, optionally ending in .inator.");
  return id.endsWith(".inator") ? id : `${id}.inator`;
}

export function normalizeProjectBrief(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new TypeError("Project brief must be an object.");
  const archetype = input.archetype || "browser-static";
  if (!ARCHETYPES[archetype]) throw new TypeError(`Unknown archetype ${archetype}.`);
  const id = safeProductId(input.product?.id || input.id);
  const requested = [...new Set([...(ARCHETYPES[archetype].capabilities), ...(input.capabilities || [])])].sort();
  return Object.freeze({
    schema: "inator.project.v1",
    product: Object.freeze({
      id,
      name: requiredText(input.product?.name || input.name, "product.name"),
      version: input.product?.version || "0.1.0",
      purpose: requiredText(input.product?.purpose || input.purpose, "product.purpose"),
      firstJob: requiredText(input.product?.firstJob || input.firstJob, "product.firstJob"),
      author: requiredText(input.product?.author || input.author, "product.author"),
      canonicalUrl: requiredText(input.product?.canonicalUrl || input.canonicalUrl, "product.canonicalUrl")
    }),
    archetype,
    firstRoute: requiredText(input.firstRoute || "/", "firstRoute"),
    capabilities: Object.freeze(requested),
    publicationProfiles: ARCHETYPES[archetype].publicationProfiles,
    boundaries: Object.freeze({
      localData: input.boundaries?.localData !== false,
      remoteModels: input.boundaries?.remoteModels === true,
      staticPublication: true
    })
  });
}

export function createProjectPlan(brief, destination) {
  const normalized = normalizeProjectBrief(brief);
  const target = requiredText(destination, "destination");
  return Object.freeze({
    schema: "inator.creation-plan.v1",
    destination: target,
    brief: normalized,
    files: Object.freeze([
      "inator.project.json", "creation-plan.json", "inator.json", "config/local-requirements.json", "package.json", "package-lock.json", "index.html",
      "src/main.js", "src/styles.css", "public/dunce-hat.svg",
      "information/about.json", "information/help.json", "information/milestones.json",
      "information/releases.json", "information/roadmap.json", "information/security.json",
      "information/privacy.json", "information/resources.json",
      "test/generated.test.js", "test/greenfield-functional.mjs",
      "evidence/greenfield-acceptance.json", ".gitignore", "README.md"
    ]),
    requiredReferences: Object.freeze([
      "docs/guides/greenfield-builder-handoff.md",
      "docs/guides/greenfield-inator-onboarding.md",
      "docs/guides/greenfield-functional-conformance.md",
      "docs/standards/product-shells.md",
      "docs/standards/workspace-actions.md",
      "docs/standards/workspace-backup-and-restore.md",
      "docs/standards/project-collections.md"
    ]),
    checks: Object.freeze([
      "npm ci", "npm run check", "inator doctor", "inator audit-ui", "inator verify-greenfield --evidence evidence/greenfield-acceptance.json",
      "production build", "healthy local response", "desktop shell journey", "390px shell journey",
      "first collection renders a synthetic record", "primary intake completes with synthetic input",
      "every information destination renders substantive content", "identity save changes role-gated Resources visibility",
      "shared Backup states its completeness boundary",
      "source-pattern UI audit cannot substitute for the functional greenfield report",
      ...(normalized.capabilities.includes("machine-state") ? ["Local System renders observed machine readiness"] : []),
      ...(normalized.capabilities.includes("model-runtime") ? ["Models renders provider inventory with every product role initially unassigned"] : [])
    ]),
    architectureInvariants: Object.freeze([
      "Before product code, ask whether Commons already provides the capability or should be extended: REUSE, DRY, CONFORM.",
      ...(normalized.capabilities.includes("pipeline-engine") ? [
        "Pipeline execution uses the one Commons supervisor/executor; the product contributes work and an adapter, never a scheduler, daemon, LaunchAgent, or server-start recovery hook."
      ] : [])
    ]),
    machineMutations: Object.freeze([])
  });
}

export function projectArchetypes() {
  return ARCHETYPES;
}
