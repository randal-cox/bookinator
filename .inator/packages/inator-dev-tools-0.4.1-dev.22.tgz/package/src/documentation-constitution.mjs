export const DOCUMENTATION_CONSTITUTION_SCHEMA = "inator.documentation-constitution.v1";

const MODALITY_CONFLICTS = new Set(["prohibited|required", "permitted|prohibited"]);
const STATUS_CONFLICTS = new Set(["deferred|implemented", "implemented|missing", "implemented|proposed"]);
const AUTHORITY_RANK = Object.freeze({ runtime: 6, standard: 5, decision: 5, assurance: 4, contract: 4, guide: 3, readme: 2, milestone: 2, example: 1, unknown: 0 });

function clean(value) { return String(value ?? "").trim(); }
function normalized(value) { return clean(value).toLowerCase().replace(/\s+/g, " "); }
function orderedPair(left, right) { return [left, right].sort().join("|"); }
function claimKey(claim) { return [claim.subject, claim.predicate, claim.scope || "global"].map(normalized).join(" :: "); }

export function analyzeDocumentationClaims(input) {
  const claims = Array.isArray(input) ? input : input?.claims;
  if (!Array.isArray(claims)) throw new TypeError("Documentation claims must be an array.");
  const problems = [];
  const ids = new Set();
  const groups = new Map();
  for (const claim of claims) {
    if (!claim?.id || !claim.source?.path || !claim.subject || !claim.predicate) throw new TypeError("Every documentation claim requires id, source.path, subject, and predicate.");
    if (ids.has(claim.id)) problems.push({ id: `DOC-DUPLICATE-ID-${claim.id}`, kind: "duplicate-id", severity: "high", claims: [claim.id] });
    ids.add(claim.id);
    const key = claimKey(claim);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(claim);
    if (!["required", "prohibited", "permitted", "descriptive", "unknown"].includes(claim.modality || "unknown")) problems.push({ id: `DOC-INVALID-MODALITY-${claim.id}`, kind: "invalid-claim", severity: "high", claims: [claim.id] });
  }
  for (const [key, group] of groups) {
    for (let leftIndex = 0; leftIndex < group.length; leftIndex += 1) for (let rightIndex = leftIndex + 1; rightIndex < group.length; rightIndex += 1) {
      const left = group[leftIndex];
      const right = group[rightIndex];
      const claimIds = [left.id, right.id];
      const evidence = [left, right].map((claim) => ({ id: claim.id, path: claim.source.path, line: claim.source.line ?? null, excerpt: claim.source.excerpt ?? null, authority: claim.authority || "unknown" }));
      if (MODALITY_CONFLICTS.has(orderedPair(left.modality || "unknown", right.modality || "unknown"))) problems.push({ id: `DOC-DIRECT-${claimIds.join("-")}`, kind: "direct-contradiction", severity: "critical", key, claims: claimIds, evidence });
      if (STATUS_CONFLICTS.has(orderedPair(left.status || "unknown", right.status || "unknown"))) problems.push({ id: `DOC-STATUS-${claimIds.join("-")}`, kind: "status-contradiction", severity: "high", key, claims: claimIds, evidence });
      if (clean(left.owner) && clean(right.owner) && normalized(left.owner) !== normalized(right.owner) && !["proposed", "historical", "superseded"].includes(left.status) && !["proposed", "historical", "superseded"].includes(right.status)) problems.push({ id: `DOC-OWNER-${claimIds.join("-")}`, kind: "ownership-contradiction", severity: "high", key, claims: claimIds, evidence });
      const leftRank = AUTHORITY_RANK[left.authority] ?? 0;
      const rightRank = AUTHORITY_RANK[right.authority] ?? 0;
      if (leftRank === rightRank && leftRank >= AUTHORITY_RANK.standard && normalized(left.object) !== normalized(right.object)) problems.push({ id: `DOC-AUTHORITY-${claimIds.join("-")}`, kind: "authority-conflict", severity: "critical", key, claims: claimIds, evidence });
      if (left.modality === right.modality && normalized(left.object) !== normalized(right.object) && left.status === "implemented" && right.status === "implemented") problems.push({ id: `DOC-VALUE-${claimIds.join("-")}`, kind: "behavior-description-conflict", severity: "high", key, claims: claimIds, evidence });
    }
  }
  for (const claim of claims) {
    if (["required", "prohibited"].includes(claim.modality) && !(claim.evidence || []).length) problems.push({ id: `DOC-ORPHAN-CLAIM-${claim.id}`, kind: "orphan-claim", severity: "medium", claims: [claim.id], evidence: [{ path: claim.source.path, line: claim.source.line ?? null }] });
  }
  return Object.freeze({ schema: DOCUMENTATION_CONSTITUTION_SCHEMA, claims: claims.length, groups: groups.size, status: problems.length ? "fail" : "pass", problems });
}

export function extractNormativeCandidates({ path, text }) {
  const markers = /\b(MUST(?: NOT)?|SHALL(?: NOT)?|REQUIRED|PROHIBITED|CANNOT|CAN'T|DO NOT|NEVER|ALWAYS|owned by|owner is|status:)\b/i;
  return String(text).split(/\r?\n/).flatMap((line, index) => markers.test(line) ? [{ source: { path, line: index + 1, excerpt: line.trim().slice(0, 500) }, normalized: false, reason: "normative-or-status-language" }] : []);
}
