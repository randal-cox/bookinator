import { createHash, randomUUID } from "node:crypto";
import { lstat, mkdir, mkdtemp, readFile, readdir, realpath, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

export const ADVERSARIAL_FIXTURE_SCHEMA = "inator.adversarial-fixture-set.v1";

export const ADVERSARIAL_FIXTURES = Object.freeze({
  "storage-write-failure": {
    purpose: "Make browser storage writes fail deterministically, including a quota-shaped failure.",
    hook: "storage-write-failure.mjs",
    synthetic: "storage-write-failure.json"
  },
  "corrupt-persisted-json": {
    purpose: "Supply invalid persisted JSON without touching an existing browser profile.",
    hook: "seed-local-storage.mjs",
    synthetic: "corrupt-persisted-json.json"
  },
  "malformed-backup-shape": {
    purpose: "Supply a parseable backup whose nested state has deliberately invalid shapes.",
    synthetic: "malformed-backup-shape.json"
  },
  "partial-restore-write-failure": {
    purpose: "Allow the first restore storage write and fail the next, exposing transaction and rollback behavior.",
    hook: "partial-restore-write-failure.mjs",
    synthetic: "partial-restore-write-failure.json"
  },
  "destructive-delete-restore-state": {
    purpose: "Provide expendable records for delete and restore assays; every identity is visibly synthetic.",
    hook: "seed-local-storage.mjs",
    synthetic: "destructive-delete-restore-state.json"
  }
});

const SYNTHETIC = Object.freeze({
  "storage-write-failure": { mode: "quota", errorName: "QuotaExceededError", failAfter: 0, syntheticOnly: true },
  "corrupt-persisted-json": { entries: [{ key: "inator.synthetic.corrupt", rawValue: "{not-valid-json" }], syntheticOnly: true },
  "malformed-backup-shape": { schema: "inator.synthetic.malformed-backup.v1", projects: "not-an-array", identity: { roles: { unexpectedly: "an object" } }, syntheticOnly: true },
  "partial-restore-write-failure": { mode: "partial", errorName: "InvalidStateError", failAfter: 1, syntheticOnly: true },
  "destructive-delete-restore-state": { entries: [{ key: "inator.synthetic.destructive", value: { projects: [{ id: "SYNTHETIC-DELETE-ME", name: "Disposable project" }], identity: { shortName: "SYNTHETIC", longName: "Synthetic assay identity" } } }], syntheticOnly: true }
});

const STORAGE_HOOK = `// Generated assay hook. Install only in a disposable browser context.\nexport function installStorageWriteFailure({ failAfter = 0, errorName = "QuotaExceededError" } = {}) {\n  let writes = 0;\n  const original = Storage.prototype.setItem;\n  Storage.prototype.setItem = function (...args) {\n    if (writes++ >= failAfter) throw new DOMException("Synthetic adversarial storage failure", errorName);\n    return original.apply(this, args);\n  };\n  return () => { Storage.prototype.setItem = original; };\n}\n`;

const SEED_HOOK = `// Generated assay hook. Install only in a disposable browser context.\nexport function seedSyntheticStorage(storage, fixture) {\n  if (!fixture?.syntheticOnly || !Array.isArray(fixture.entries)) throw new TypeError("Refusing non-synthetic storage seed.");\n  for (const entry of fixture.entries) storage.setItem(entry.key, entry.rawValue ?? JSON.stringify(entry.value));\n}\n`;

function assertSafeSource(source) {
  const resolved = path.resolve(source || "");
  if (!source || resolved === path.parse(resolved).root || resolved === os.homedir()) throw new TypeError("Fixture source must be an explicit artifact directory, never a filesystem or home root.");
  return resolved;
}

function assertFixtureNames(names) {
  const selected = names?.length ? [...new Set(names)] : Object.keys(ADVERSARIAL_FIXTURES);
  for (const name of selected) if (!ADVERSARIAL_FIXTURES[name]) throw new TypeError(`Unknown adversarial fixture ${name}.`);
  return selected;
}

async function copyArtifact(source, destination, inventory, relative = "") {
  const entries = await readdir(source, { withFileTypes: true });
  for (const entry of entries) {
    if ([".git", ".inator"].includes(entry.name)) continue;
    const from = path.join(source, entry.name);
    const rel = path.join(relative, entry.name);
    const to = path.join(destination, entry.name);
    const metadata = await lstat(from);
    if (metadata.isSymbolicLink()) throw new TypeError(`Fixture preparation refuses symbolic links: ${rel}`);
    if (metadata.isDirectory()) { await mkdir(to); await copyArtifact(from, to, inventory, rel); continue; }
    if (!metadata.isFile()) throw new TypeError(`Fixture preparation refuses non-file artifact entries: ${rel}`);
    const bytes = await readFile(from);
    await writeFile(to, bytes, { mode: metadata.mode });
    inventory.push({ path: rel, bytes: bytes.byteLength, sha256: createHash("sha256").update(bytes).digest("hex") });
  }
}

export async function prepareAdversarialFixtures({ sourceDir, fixtures, tempRoot = os.tmpdir(), preparedAt = new Date().toISOString() } = {}) {
  const requestedSource = assertSafeSource(sourceDir);
  const requestedStat = await lstat(requestedSource);
  if (requestedStat.isSymbolicLink()) throw new TypeError("Fixture source must be a real directory, not a symbolic link.");
  const source = await realpath(requestedSource);
  const sourceStat = await lstat(source);
  if (!sourceStat.isDirectory()) throw new TypeError("Fixture source must be a real directory, not a file.");
  const selected = assertFixtureNames(fixtures);
  const root = await realpath(path.resolve(tempRoot));
  if (root === source || root.startsWith(`${source}${path.sep}`)) throw new TypeError("Fixture temporary root must not be inside the source artifact.");
  const workspace = await mkdtemp(path.join(root, "inator-adversary-fixture-"));
  const artifact = path.join(workspace, "artifact");
  const fixtureDirectory = path.join(workspace, "fixtures");
  await mkdir(artifact);
  await mkdir(fixtureDirectory);
  const inventory = [];
  await copyArtifact(source, artifact, inventory);
  inventory.sort((a, b) => a.path.localeCompare(b.path));
  const hooks = new Set();
  for (const name of selected) {
    const definition = ADVERSARIAL_FIXTURES[name];
    await writeFile(path.join(fixtureDirectory, definition.synthetic), `${JSON.stringify(SYNTHETIC[name], null, 2)}\n`);
    if (definition.hook) hooks.add(definition.hook);
  }
  if (hooks.has("storage-write-failure.mjs") || hooks.has("partial-restore-write-failure.mjs")) {
    await writeFile(path.join(fixtureDirectory, "storage-write-failure.mjs"), STORAGE_HOOK);
    if (hooks.has("partial-restore-write-failure.mjs")) await writeFile(path.join(fixtureDirectory, "partial-restore-write-failure.mjs"), STORAGE_HOOK);
  }
  if (hooks.has("seed-local-storage.mjs")) await writeFile(path.join(fixtureDirectory, "seed-local-storage.mjs"), SEED_HOOK);
  const manifest = {
    schema: ADVERSARIAL_FIXTURE_SCHEMA,
    id: randomUUID(),
    preparedAt,
    safety: { disposable: true, sourceReadOnly: true, syntheticDataOnly: true, destructiveActionsExecuted: false },
    source: { path: source, files: inventory.length, digest: createHash("sha256").update(JSON.stringify(inventory)).digest("hex") },
    workspace: { root: workspace, artifact, fixtures: fixtureDirectory },
    fixtures: selected.map((name) => ({ name, ...ADVERSARIAL_FIXTURES[name] })),
    artifactFiles: inventory,
    instructions: [
      "Run the copied artifact only in a disposable browser profile or context.",
      "Install hooks explicitly from the fixtures directory; preparation itself executes none.",
      "Delete only the manifest-declared disposable workspace when the assay is complete."
    ]
  };
  const manifestPath = path.join(workspace, "manifest.json");
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
  return Object.freeze({ workspace, artifact, fixtureDirectory, manifest: manifestPath, value: manifest });
}
