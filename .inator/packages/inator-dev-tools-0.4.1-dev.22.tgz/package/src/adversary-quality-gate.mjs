export const ADVERSARY_QUALITY_GATE_SCHEMA = "inator.adversary-quality-gate.v1";

const SEVERITY = Object.freeze({ info: 0, low: 1, medium: 2, high: 3, critical: 4 });

export function evaluateAdversaryQualityGate({
  findings = [],
  baselineFingerprints = [],
  seededObligations = [],
  toolRuns = [],
  requiredTools = [],
  blockNewAt = "high",
  now = new Date().toISOString(),
  baselineExpiresAt = null
} = {}) {
  const baseline = new Set(baselineFingerprints);
  const threshold = SEVERITY[blockNewAt];
  if (threshold === undefined) throw new TypeError(`Unknown blocking severity ${blockNewAt}.`);
  const newFindings = findings.filter((finding) => !baseline.has(finding.fingerprint));
  const blockingFindings = newFindings.filter((finding) => (SEVERITY[finding.severity] ?? SEVERITY.high) >= threshold);
  const seededMisses = seededObligations.filter((obligation) => !obligation.detected);
  const completedTools = new Set(toolRuns.filter((run) => run.status === "completed").map((run) => run.id));
  const missingTools = requiredTools.filter((tool) => !completedTools.has(tool));
  const expiredBaseline = baselineExpiresAt ? Date.parse(baselineExpiresAt) <= Date.parse(now) : false;
  const invalidFindings = findings.filter((finding) => !finding.fingerprint || !finding.severity || !finding.evidence?.length);
  const blockers = [
    ...blockingFindings.map((finding) => ({ kind: "new-serious-finding", id: finding.fingerprint, severity: finding.severity })),
    ...seededMisses.map((obligation) => ({ kind: "seeded-miss", id: obligation.id })),
    ...missingTools.map((tool) => ({ kind: "missing-required-tool-run", id: tool })),
    ...invalidFindings.map((finding, index) => ({ kind: "invalid-finding-evidence", id: finding.fingerprint || `finding-${index + 1}` })),
    ...(expiredBaseline ? [{ kind: "expired-baseline", id: baselineExpiresAt }] : [])
  ];
  return Object.freeze({
    schema: ADVERSARY_QUALITY_GATE_SCHEMA,
    status: blockers.length ? "fail" : "pass",
    policy: { blockNewAt, baselineExpiresAt },
    counts: { findings: findings.length, baseline: baseline.size, newFindings: newFindings.length, blockingFindings: blockingFindings.length, seededMisses: seededMisses.length, missingTools: missingTools.length, invalidFindings: invalidFindings.length },
    blockers,
    rule: "A baseline acknowledges existing debt; it never suppresses new serious findings, seeded detector misses, missing required runs, evidence-free findings, or expired debt ownership."
  });
}
