import { lstat, mkdir, mkdtemp, readFile, rename, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { createProjectPlan, normalizeProjectBrief } from "./project-creation.mjs";

const json = (value) => `${JSON.stringify(value, null, 2)}\n`;
const quoted = (value) => JSON.stringify(String(value));

function requiredMenus(brief) {
  const routeNoun = String(brief.firstRoute || "").split("/").filter(Boolean)[0] || "projects";
  const inferredPrimary = routeNoun.replaceAll("-", " ").replace(/^./, character => character.toUpperCase());
  const inferredContext = inferredPrimary.endsWith("s") ? inferredPrimary.slice(0, -1) : inferredPrimary;
  const primary = String(brief.interface?.primaryMenu ?? inferredPrimary).trim();
  const context = String(brief.interface?.contextMenu ?? inferredContext).trim();
  if (!primary || !context) throw new TypeError("interface.primaryMenu and interface.contextMenu are required.");
  return { primary, context };
}

function iconSvg(label) {
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" role="img" aria-labelledby="title"><title>${label} dunce hat</title><path fill="#f2c14e" stroke="#143663" stroke-width="3" stroke-linejoin="round" d="M31 5 12 47h39L31 5Z"/><path fill="#fff7d6" stroke="#143663" stroke-width="3" d="M11 47c10 5 31 5 42 0v8c-12 6-32 6-42 0v-8Z"/><path fill="none" stroke="#0c6b78" stroke-width="3" stroke-linecap="round" d="m31 5 14 8"/><circle cx="48" cy="15" r="5" fill="#0c6b78" stroke="#143663" stroke-width="2"/></svg>\n`;
}

function informationRecords(brief) {
  const product = brief.product.name;
  const updatedAt = new Date().toISOString().slice(0, 10);
  return {
    about: { schema: "inator.product-about-record.v1", product, version: brief.product.version, purpose: brief.product.purpose, author: brief.product.author, canonicalUrl: brief.product.canonicalUrl },
    help: { schema: "inator.product-help-record.v1", product, sections: ["start", "tasks", "reference", "faq"], boundary: "Product guidance composed through the Commons Help renderer." },
    milestones: { schema: "inator.product-history.v1", product, updatedAt, milestones: [{ id: "generated", title: "Functional generated application", status: "released", version: brief.product.version, date: updatedAt }, { id: "next", title: "Product-led refinement", status: "next", targetVersion: "0.1.0" }] },
    releases: { schema: "inator.product-releases-record.v1", product, derivedFrom: "information/milestones.json", releases: [{ milestoneId: "generated", version: brief.product.version, date: updatedAt, title: "Generated baseline" }] },
    roadmap: { schema: "inator.roadmap.v1", product, updatedAt, items: [{ id: "refine", title: "Refine the first-use loop", state: "scheduled", milestoneId: "next" }] },
    security: { schema: "inator.product-security.v1", product, updatedAt, summary: "Static browser application with no generated server-side data service.", boundary: "Workspace data stays in the browser." },
    privacy: { schema: "inator.product-privacy.v1", product, updatedAt, summary: "Workspace data stays local unless the user explicitly downloads a backup.", networkBoundary: "No workspace upload endpoint is generated." },
    resources: { schema: "inator.resources.v1", product, updatedAt, resources: [{ id: "readme", title: "Generated application guide", state: "ready", href: "#/help" }] }
  };
}

function mainSource(brief, menus) {
  const name = quoted(brief.product.name);
  const purpose = quoted(brief.product.purpose);
  const primary = quoted(menus.primary);
  const context = quoted(menus.context);
  const generatedOn = new Date().toISOString().slice(0, 10);
  const hasMachine = brief.capabilities.includes("machine-state");
  const hasModels = brief.capabilities.includes("model-runtime");
  const hasPipeline = brief.capabilities.includes("pipeline-engine");
  const engineImport = hasPipeline ? 'import { createDemoPipeline } from "@inator/engine/demo";\n' : "";
  const pipelineState = hasPipeline ? 'const demoPipeline = createDemoPipeline();\nlet pipelineView = null;\n' : "";
  return `${engineImport}import {
  INATOR_STANDARD_ROLE_OPTIONS, composeWorkspaceTesters, createProductAboutContent, createProductAboutPage,
  createProductHelpPage, createProductHistoryView, createProductPrivacyView, createProductRoadmapView,
  createProductSecurityView, createProjectCollection, createProductResourcePage, createStandardProductShellPolicy,
  createWorkspaceBackupView, createWorkspaceCapabilityRegistry, createWorkspaceIdentityView,
  createWorkspaceTestersView, defineProductAbout, defineProductHistory, defineProductInformationContract,
  defineProductPrivacy, defineProductRoadmap, defineProductSecurity, defineResourceCatalog, mountInatorAppShell,
  productShellFooterLinks, testersWorkspaceCapability, createPipelineWorkspace, createWorkspaceMachineView,
  createWorkspaceModelsView, machineWorkspaceCapability, modelsWorkspaceCapability
} from "@inator/ui";
import "@inator/ui/tokens.css";
import "@inator/ui/product-shell.css";
import "@inator/ui/action-bar.css";
import "@inator/ui/list-view.css";
import "@inator/ui/project-collection.css";
import "@inator/ui/project-image-editor.css";
import "@inator/ui/dialog.css";
import "@inator/ui/product-information.css";
import "@inator/ui/tabs.css";
import "@inator/ui/workspace.css";
import "@inator/ui/workspace-backup.css";
import "@inator/ui/workspace-system.css";
import "@inator/ui/pipeline.css";
import "./styles.css";

const PRODUCT = { id: ${quoted(brief.product.id)}, name: ${name}, purpose: ${purpose}, version: ${quoted(brief.product.version)} };
const KEYS = { projects: PRODUCT.id + ".projects", identity: PRODUCT.id + ".identity", selected: PRODUCT.id + ".selected" };
const initialProjects = [{ id: "welcome", name: "A small beginning", text: "This is a synthetic " + ${context}.toLowerCase() + " record. Edit it, rename it, or make another.", updatedAt: new Date().toISOString() }];
const load = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let projects = load(KEYS.projects, initialProjects);
let identity = load(KEYS.identity, { shortName: "Local user", longName: "Local user", roles: [] });
let selectedId = localStorage.getItem(KEYS.selected) || projects[0]?.id || "";
let shell = null;
const HAS_MACHINE = ${hasMachine}; const HAS_MODELS = ${hasModels}; const HAS_PIPELINE = ${hasPipeline};
${pipelineState}

const history = defineProductHistory({ product: PRODUCT.name, updatedAt: "${generatedOn}", milestones: [
  { id: "generated", title: "Functional generated application", summary: "A usable local-first workspace produced by Commons.", status: "released", release: { version: PRODUCT.version, date: "${generatedOn}", title: "Generated baseline" }, deliverables: ["Home, collection editing, identity, and portable backup", "Commons information and developer surfaces"] },
  { id: "next", title: "Product-led refinement", summary: "Replace demonstration content with product-specific evidence without abandoning shared contracts.", status: "next", targetVersion: "0.1.0", deliverables: ["Validate the first real product workflow"] }
] });
const roadmap = defineProductRoadmap({ product: PRODUCT.name, updatedAt: "${generatedOn}", items: [{ id: "refine", title: "Refine the first-use loop", summary: "Use observed product work to improve the generated starting point.", state: "scheduled", milestoneId: "next", tags: ["product"], ease: 3, impact: 4, risk: "low", confidence: "medium", lastReviewedAt: "${generatedOn}" }] }, { milestoneIds: history.milestones.map(item => item.id) });
const privacy = defineProductPrivacy({ product: PRODUCT.name, updatedAt: "${generatedOn}", summary: "This generated app stores its workspace in this browser and makes no network requests after loading.", networkBoundary: "Collection records, identity, selection, and images remain in browser local storage unless you explicitly download a backup.", data: [{ id: "workspace", title: "Local workspace", purpose: "Edit and organize local records.", handling: "Read and written only by this application.", location: "Browser local storage", recipients: "None", retention: "Until you delete browser data or restore a backup", controls: "Edit, delete, export, back up, and restore" }], practices: [{ id: "local", title: "Local-first storage", status: "implemented", detail: "Runtime product state is kept in this browser.", evidenceIds: [] }], evidence: [], exceptions: [] });
const security = defineProductSecurity({ product: PRODUCT.name, updatedAt: "${generatedOn}", summary: "A static browser application with no generated server-side data service.", profiles: [{ id: "static", title: "Static browser deployment", boundary: "The hosting service delivers immutable application assets; workspace data stays in the browser.", responsibility: "Host secures delivery; the product controls local handling." }], controls: [{ id: "boundary", title: "No workspace upload", objective: "Keep workspace content out of the hosting boundary.", status: "implemented", responsibility: "product", detail: "The generated application has no upload endpoint.", evidenceIds: [] }], evidence: [], exceptions: [] });
const resources = defineResourceCatalog({ product: PRODUCT.name, updatedAt: "${generatedOn}", resources: [{ id: "readme", title: "Generated application guide", type: "Guide", state: "ready", description: "The README shipped with this generated project.", roles: ["overview"], format: "Markdown", actions: [{ label: "Open Help", href: "#/help", primary: true }] }] });
const aboutRecord = defineProductAbout({ product: { name: PRODUCT.name, summary: PRODUCT.purpose }, citation: { title: PRODUCT.name, authors: [${quoted(brief.product.author || "Product authors")}], version: PRODUCT.version, year: 2026, url: ${quoted(brief.product.canonicalUrl || "https://inator.com")}, text: ${quoted(`${brief.product.author || "Product authors"}. ${brief.product.name} ${brief.product.version}.`)} } });
const productTests = [{ id: "record-roundtrip", label: ${context} + " round trip", description: "Verify that the selected record is present in persisted product state.", onRun: async () => { if (!projects.some(item => item.id === selectedId)) throw new Error("The selected record was not persisted."); } }];
const testers = composeWorkspaceTesters(productTests);

const information = defineProductInformationContract({ productId: PRODUCT.id, records: Object.fromEntries(["about","help","privacy","security","milestones","releases","roadmap","resources"].map(id => [id, "information/" + id + ".json"])) });
const shellPolicy = createStandardProductShellPolicy({ information, base: "/", capabilities: ["resources"], routes: { about: { href: "#/about" }, help: { href: "#/help" }, resources: { href: "#/resources" } } });
const route = () => (location.hash.startsWith("#/") ? location.hash.slice(2) : location.hash.slice(1)) || "home";
const selected = () => projects.find(project => project.id === selectedId) || null;
const node = (tag, text = "", className = "") => { const element = document.createElement(tag); if (text) element.textContent = text; if (className) element.className = className; return element; };
const download = (name, content, type = "text/plain") => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([content], { type })); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 0); };
function persistProjects() { save(KEYS.projects, projects); localStorage.setItem(KEYS.selected, selectedId); }
function navigate(next) { location.hash = "#/" + next; }

function workspaceRegistry() {
  const extensions = [testersWorkspaceCapability({ href: "#/workspace/testers", tests: productTests })];
  if (HAS_MACHINE) extensions.push(machineWorkspaceCapability({ href: "#/workspace/machine" }));
  if (HAS_MODELS) extensions.push(modelsWorkspaceCapability({ href: "#/workspace/models" }));
  return createWorkspaceCapabilityRegistry({ base: {
    identity: { href: "#/workspace/identity" },
    workspace: { href: "#/workspace/backup" },
    errors: { enabled: false, href: "#/workspace/errors" }
  }, extensions, context: { roles: identity.roles } });
}

function homePage(root) {
  const hero = node("section", "", "generated-home");
  hero.append(node("p", ${quoted(brief.product.firstJob)}, "generated-kicker"), node("h1", PRODUCT.name), node("p", PRODUCT.purpose));
  const action = node("button", "Open " + ${primary}.toLowerCase()); action.type = "button"; action.addEventListener("click", () => navigate("projects")); hero.append(action);
  const current = selected(); if (current) { const resume = node("button", "Continue “" + current.name + "”"); resume.type = "button"; resume.addEventListener("click", () => navigate("text/" + current.id)); hero.append(resume); }
  root.append(hero);
}

function mountShell() {
  shell?.destroy?.();
  const current = selected();
  shell = mountInatorAppShell({
    active: route().split("/")[0], workspaceRegistry: workspaceRegistry(),
    workspaceUtility: { detail: identity.shortName },
    headerMount: document.querySelector("[data-inator-product-header]"),
    footerMount: document.querySelector("[data-inator-product-footer]"),
    brand: { href: "#/", ariaLabel: PRODUCT.name + " home", label: PRODUCT.name, detail: PRODUCT.purpose, image: { src: "/dunce-hat.svg", width: 50, height: 50, alt: "" } },
    navigationLabel: PRODUCT.name,
    navigation: [{ href: "#/projects", route: "projects", label: ${primary}, detail: projects.length + " record" + (projects.length === 1 ? "" : "s") }, ...(HAS_PIPELINE ? [{ href: "#/pipeline", route: "pipeline", label: "Pipeline", detail: "Deterministic fixture" }] : [])],
    contextItem: { href: current ? "#/text/" + current.id : "#/text", route: "text", label: ${context}, detail: current?.name || "No record selected", position: 1 },
    footer: { links: productShellFooterLinks(shellPolicy, { identity }) }
  });
}

function projectsPage(root) {
  const heading = node("header", "", "generated-page-heading"); heading.append(node("h1", ${primary}), node("p", "Each " + ${context}.toLowerCase() + " is one local plain-text record.")); root.append(heading);
  const render = () => { root.replaceChildren(); projectsPage(root); };
  const collection = createProjectCollection({
    records: projects.map(project => ({ ...project, current: project.id === selectedId, secondary: new Blob([project.text]).size + " bytes" })),
    vocabulary: { singular: ${context}, plural: ${primary} }, preferencesKey: PRODUCT.id + ".projects-view",
    project: {},
    columns: [{ id: "size", label: "Size", value: record => new Blob([record.source.text]).size, render: record => node("span", new Blob([record.source.text]).size + " bytes") },
      { id: "updated", label: "Updated", value: record => record.source.updatedAt, render: record => { const time = node("time", new Date(record.source.updatedAt).toLocaleString()); time.dateTime = record.source.updatedAt; return time; } }],
    handlers: {
      newProject() { const id = crypto.randomUUID(); projects.unshift({ id, name: "Untitled " + ${context}.toLowerCase(), text: "", updatedAt: new Date().toISOString() }); selectedId = id; persistProjects(); render(); },
      async importFiles(files) { for (const file of files) { const id = crypto.randomUUID(); projects.unshift({ id, name: file.name.replace(/\\.[^.]+$/, "") || "Imported " + ${context}.toLowerCase(), text: await file.text(), updatedAt: new Date().toISOString() }); selectedId = id; } persistProjects(); render(); },
      exportProjects(records) { download(PRODUCT.id + "-records.json", JSON.stringify(records, null, 2), "application/json"); },
      renameProject(project, name) { projects = projects.map(item => item.id === project.id ? { ...item, name, updatedAt: new Date().toISOString() } : item); persistProjects(); render(); },
      async saveProjectImage(project, next) { let imageSelection = next; if (next.mode === "upload") imageSelection = { mode: "upload", dataUrl: await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(next.file); }) }; projects = projects.map(item => item.id === project.id ? { ...item, imageSelection, updatedAt: new Date().toISOString() } : item); persistProjects(); },
      openProject(project) { selectedId = project.id; persistProjects(); navigate("text/" + project.id); },
      deleteProjects(records) { const ids = new Set(records.map(record => record.id)); projects = projects.filter(project => !ids.has(project.id)); if (!projects.some(project => project.id === selectedId)) selectedId = projects[0]?.id || ""; persistProjects(); render(); }
    }, project: { image: project => project.imageSelection?.mode === "upload" ? { src: project.imageSelection.dataUrl, alt: "Chosen image for " + project.name } : null, imageSelection: project => project.imageSelection || { mode: "automatic" }, automaticImage: project => ({ src: "/dunce-hat.svg", alt: "", label: "Generated product mark" }) }, onRefresh: render
  });
  root.append(collection.element);
}

function textPage(root, id) {
  const project = projects.find(item => item.id === id) || selected();
  if (!project) { root.append(node("h1", "No " + ${context}.toLowerCase() + " selected"), node("p", "Choose one from " + ${primary} + ".")); return; }
  selectedId = project.id; persistProjects();
  const header = node("header", "", "generated-editor-heading"); const title = node("input"); title.value = project.name; title.setAttribute("aria-label", ${context} + " name");
  const count = node("p", "", "generated-count"); const area = node("textarea"); area.value = project.text; area.setAttribute("aria-label", ${context} + " content");
  const updateCount = () => { count.textContent = area.value.length + " characters · " + new Blob([area.value]).size + " bytes"; };
  const commit = () => { project.name = title.value.trim() || "Untitled " + ${context}.toLowerCase(); project.text = area.value; project.updatedAt = new Date().toISOString(); persistProjects(); updateCount(); };
  title.addEventListener("change", commit); area.addEventListener("input", commit); updateCount(); header.append(title, count); root.append(header, area);
}

function identityPage(root) {
  createWorkspaceIdentityView({ mount: root, model: identity, roleOptions: INATOR_STANDARD_ROLE_OPTIONS, async onSave(next) { identity = next; save(KEYS.identity, identity); mountShell(); return next; } });
}
function backupPage(root) {
  let pending = null; let controller; let model = { workspaceName: PRODUCT.name, backup: { state: "idle", detail: "Includes all collection records, names, content, timestamps, image selections, current selection, and local identity." }, restore: { state: "idle", destination: "This browser" } };
  const update = next => { model = next; controller.update(model); };
  controller = createWorkspaceBackupView({ mount: root, model, destinationMode: "fixed", wording: { restoreDescription: "Inspect a backup, then replace this browser's local application state.", restoreSafety: "Nothing changes until you confirm restore" }, async onAction({ action, files }) {
    if (action === "backup") { download(PRODUCT.id + "-backup.json", JSON.stringify({ schema: PRODUCT.id + ".backup.v1", projects, identity, selectedId }, null, 2), "application/json"); update({ ...model, backup: { state: "complete", detail: "Complete portable backup downloaded." } }); }
    if (action === "inspect-backup") { try { pending = JSON.parse(await files[0].text()); if (pending.schema !== PRODUCT.id + ".backup.v1" || !Array.isArray(pending.projects)) throw new Error("This is not a compatible " + PRODUCT.name + " backup."); update({ ...model, restore: { state: "valid", fileName: files[0].name, destination: "This browser", summary: pending.projects.length + " project(s) ready to restore.", errors: [] } }); } catch (error) { pending = null; update({ ...model, restore: { state: "invalid", fileName: files[0]?.name, destination: "This browser", summary: "Backup validation failed.", errors: [error.message] } }); } }
    if (action === "restore" && pending) { projects = pending.projects; identity = pending.identity; selectedId = pending.selectedId; persistProjects(); save(KEYS.identity, identity); pending = null; render(); }
  } });
}
function testersPage(root) { createWorkspaceTestersView({ mount: root, tests: testers }); }
function machinePage(root) {
  createWorkspaceMachineView({ mount: root, navigation: { machine: "#/workspace/machine", models: "#/workspace/models" }, manifest: { status: "ready", generatedAt: new Date().toISOString(), policy: { id: "generated-fixture", version: "1" }, machine: { platform: navigator.platform || "Browser", architecture: "browser-observed" }, guidance: [{ id: "fixture", title: "Generated fixture boundary", summary: "Observed browser readiness only", status: "ready", message: "This surface proves the shared Machine renderer. A local service must replace this bounded browser fixture before claiming host capacity." }], checks: [{ id: "browser", category: "Runtime", label: "Browser application", status: "ready", observedValue: "Rendered in this browser", observedAt: new Date().toISOString(), explanation: "The generated static application is executing." }] } });
}
function modelsPage(root) {
  createWorkspaceModelsView({ mount: root, navigation: { machine: "#/workspace/machine", models: "#/workspace/models" }, model: { provider: { providerId: "unconfigured", providerVersion: "none", installed: false, running: false, apiReachable: false, checkedAt: new Date().toISOString(), operations: [], diagnostic: "No provider is configured by generation." }, queue: { state: "idle", label: "No model work is active." }, components: [], roles: [{ id: "record-reviewer", label: ${context} + " reviewer", purpose: "Review a processed record when a product owner configures a provider.", requiredCapabilities: ["text"], compatibleModelIds: [], assignedModelId: "" }], catalog: [], inventory: [] } });
}
function pipelinePage(root) {
  const heading = node("header", "", "generated-page-heading"); heading.append(node("p", "Deterministic generated fixture", "generated-kicker"), node("h1", "Pipeline"), node("p", "This bounded synthetic run proves presentation and control behavior; it is not product-domain computation."));
  const controls = node("div", "", "generated-pipeline-controls"); const run = node("button", "Run fixture"); run.type = "button"; const status = node("p", "Ready", "generated-pipeline-status"); status.setAttribute("role", "status"); controls.append(run, status); const surface = node("div"); root.append(heading, controls, surface);
  pipelineView?.destroy?.(); pipelineView = createPipelineWorkspace({ mount: surface, pipelines: [{ id: "generated-fixture", label: "Generated fixture", presentation: demoPipeline.snapshot() }], onAction: ({ action }) => { if (action === "start") void demoPipeline.start(); if (action === "stop") demoPipeline.stop(); if (action === "retry") void demoPipeline.retry(); } });
  demoPipeline.subscribe(snapshot => { pipelineView.update([{ id: "generated-fixture", label: "Generated fixture", presentation: snapshot }]); status.textContent = snapshot.status === "complete" ? "Fixture complete" : snapshot.activity.text; });
  run.addEventListener("click", () => void demoPipeline.start());
}
function aboutPage(root) {
  createProductAboutPage({ root, productLabel: PRODUCT.name, productContent: createProductAboutContent({ heading: PRODUCT.name, summary: PRODUCT.purpose, sections: [{ heading: "What it does", content: ${quoted(brief.product.firstJob)} }, { heading: "Version", content: PRODUCT.version }] }), about: aboutRecord, basePath: "#/", recordIds: ["milestones", "roadmap", "security", "privacy"] });
}
function helpPage(root) {
  const content = (heading, paragraphs) => { const section = node("article"); section.append(node("h2", heading), ...paragraphs.map(text => node("p", text))); return section; };
  createProductHelpPage({ root, productLabel: PRODUCT.name, heading: "Work with " + ${primary}.toLowerCase(), introduction: "Create, edit, export, and back up local records.", sections: [
    { id: "start", content: content("Start here", ["Open " + ${primary} + ", create or import a record, then open it to edit. Changes persist in this browser as you type.", "Use the product brand to return Home and continue the currently selected record."]) },
    { id: "tasks", content: content("Everyday tasks", ["Rename a record directly in the list. Select rows to export or delete them, and use the image control to choose a local override.", "Identity and portable backup live in Workspace. Developer tools appear only after adding the Developer role."]) },
    { id: "reference", content: content("Reference", ["Record content, identity, current selection, and image overrides use browser local storage. A backup includes all of those fields.", "Resources are visible to the Team role. Roadmap, releases, security, and privacy are inspectable from About."]) },
    { id: "faq", content: content("FAQ", ["Before clearing browser data, create a backup from Workspace. Restore validates the file before replacing local state.", "This generated app does not send workspace content to a server."]) }
  ] });
}
function recordPage(root, name) {
  if (name === "milestones" || name === "releases") return createProductHistoryView({ mount: root, history, mode: name === "releases" ? "releases" : "roadmap" });
  if (name === "roadmap") return createProductRoadmapView({ mount: root, roadmap, milestoneTitles: Object.fromEntries(history.milestones.map(item => [item.id, (item.release?.version || item.targetVersion || "Unscheduled") + " — " + item.title])) });
  if (name === "security") return createProductSecurityView({ mount: root, security });
  if (name === "privacy") return createProductPrivacyView({ mount: root, privacy });
  if (name === "resources") return createProductResourcePage({ root, catalog: resources, productLabel: PRODUCT.name });
  root.append(node("h1", "Not found"), node("p", "This destination is not part of " + PRODUCT.name + "."));
}

function render() {
  window.scrollTo({ top: 0, left: 0 });
  mountShell(); const root = document.querySelector("main"); root.className = "generated-main"; root.replaceChildren();
  const [page, id] = route().split("/");
  if (page === "home") homePage(root); else if (page === "projects") projectsPage(root); else if (page === "text") textPage(root, id); else if (page === "pipeline" && HAS_PIPELINE) pipelinePage(root); else if (page === "workspace" && id === "identity") identityPage(root); else if (page === "workspace" && id === "testers" && identity.roles.includes("developer")) testersPage(root); else if (page === "workspace" && id === "testers") recordPage(root, "not-found"); else if (page === "workspace" && id === "machine" && HAS_MACHINE) machinePage(root); else if (page === "workspace" && id === "models" && HAS_MODELS) modelsPage(root); else if (page === "workspace") backupPage(root); else if (page === "resources" && identity.roles.includes("team")) recordPage(root, page); else if (page === "resources") recordPage(root, "not-found"); else if (page === "about") aboutPage(root); else if (page === "help") helpPage(root); else recordPage(root, page);
}
addEventListener("hashchange", render); render();
`;
}

function styles() {
  return `:root{font-family:Inter,ui-sans-serif,system-ui,sans-serif;color:#173b38;background:#fff}body{margin:0;min-height:100vh}.generated-main{box-sizing:border-box;width:min(100%,1600px);margin:0 auto;padding:28px clamp(18px,4vw,64px) 64px}.generated-home{padding:clamp(36px,8vw,110px) 0;max-width:850px}.generated-home h1{font-size:clamp(2.5rem,8vw,6rem);line-height:.94;margin:.15em 0}.generated-home>p:not(.generated-kicker){font-size:clamp(1.1rem,2vw,1.5rem);max-width:54ch}.generated-home button{margin:18px 12px 0 0;padding:12px 18px}.generated-kicker{text-transform:uppercase;letter-spacing:.12em;font-weight:700;color:#0c6b78}.generated-page-heading{margin:0 0 22px}.generated-page-heading h1{font-size:clamp(1.8rem,4vw,3.2rem);margin:0}.generated-page-heading p{font-size:1.05rem;color:#516763}.generated-editor-heading{display:flex;align-items:end;justify-content:space-between;gap:20px;margin-bottom:16px}.generated-editor-heading input{font:700 clamp(1.5rem,3vw,2.5rem)/1.1 inherit;border:0;border-bottom:2px solid #adc1bd;padding:8px 2px;min-width:0;flex:1}.generated-count{color:#516763;white-space:nowrap}.generated-main>textarea{box-sizing:border-box;width:100%;min-height:62vh;padding:20px;border:1px solid #9eb4af;border-radius:4px;font:1.05rem/1.65 ui-monospace,SFMono-Regular,Menlo,monospace;resize:vertical}.generated-main :focus-visible{outline:3px solid #d99c16;outline-offset:3px}.generated-pipeline-controls{display:flex;align-items:center;gap:14px;margin:0 0 18px}.generated-pipeline-controls button{padding:10px 16px}.generated-pipeline-status{margin:0}@media(max-width:600px){.generated-editor-heading{align-items:stretch;flex-direction:column}.generated-count{margin:0}.generated-main>textarea{min-height:55vh}}\n`;
}

function functionalAcceptanceSource(brief, menus) {
  return `import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { access, readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { chromium } from "playwright-core";
import { GREENFIELD_ACCEPTANCE_SCHEMA, GREENFIELD_FUNCTIONAL_CHECKS } from "@inator/dev-tools/greenfield-acceptance";
const port = 4179; const url = "http://127.0.0.1:" + port;
const candidates = [process.env.CHROME_PATH, "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/usr/bin/google-chrome", "/usr/bin/chromium"].filter(Boolean);
let executablePath = ""; for (const candidate of candidates) { try { await access(candidate); executablePath = candidate; break; } catch {} }
assert.ok(executablePath, "Greenfield acceptance requires an installed Chrome or Chromium browser (or CHROME_PATH).");
const server = spawn(process.execPath, ["node_modules/vite/bin/vite.js", "preview", "--host", "127.0.0.1", "--port", String(port), "--strictPort"], { stdio: ["ignore", "pipe", "pipe"] });
async function ready() { for (let i=0;i<80;i+=1) { try { if ((await fetch(url)).ok) return; } catch {} await new Promise(r=>setTimeout(r,100)); } throw new Error("Vite preview did not start."); }
async function digest(directory) { const hash=createHash("sha256"); async function visit(dir){ for(const entry of (await readdir(dir,{withFileTypes:true})).sort((a,b)=>a.name.localeCompare(b.name))){ const full=path.join(dir,entry.name); if(entry.isDirectory()) await visit(full); else { hash.update(path.relative(directory,full)); hash.update(await readFile(full)); } } } await visit(directory); return hash.digest("hex"); }
const observations=[]; const journeys=[]; const seen=new Set();
function pass(id, journeyId, action, assertionText){ assert.ok(GREENFIELD_FUNCTIONAL_CHECKS.some(check=>check.id===id), "Unknown acceptance check " + id); seen.add(id); observations.push({id,status:"passed",evidence:[{kind:"dom-interaction",journeyId,action,assertion:assertionText}]}); }
let browser;
try { await ready(); browser=await chromium.launch({headless:true,executablePath});
  const desktopStarted=new Date().toISOString(); const context=await browser.newContext({viewport:{width:1280,height:900},acceptDownloads:true}); const page=await context.newPage(); page.setDefaultTimeout(7000); page.on("pageerror", error => console.error("Browser page error:", error.message)); await page.goto(url+"/#/");
  await page.getByRole("heading",{name:${quoted(brief.product.name)},exact:true}).waitFor(); pass("shell.product-icon","desktop","loaded Home and inspected named brand","brand and Home are visible"); pass("shell.product-name","desktop","read product header and Home heading","exact generated product name is visible");
  await page.getByRole("link",{name:/home/i}).click(); assert.ok(page.url().endsWith("/#/")); pass("actions.outcomes","desktop","activated product brand","brand navigated to distinct Home route");
  await page.goto(url+"/#/projects"); const name=page.getByLabel(/Rename A small beginning/); await name.fill("Acceptance text"); await name.blur(); await page.getByLabel(/Rename Acceptance text/).waitFor(); await page.reload(); await page.getByLabel(/Rename Acceptance text/).waitFor(); pass("projects.collection","desktop","renamed a project and reloaded","rename persisted in the rendered collection");
  await page.getByLabel(/Edit image for Acceptance text/).click(); await page.locator('.inator-project-image-editor input[type="file"]').setInputFiles({name:"acceptance.png",mimeType:"image/png",buffer:Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=","base64")}); const saveImage=page.getByRole("button",{name:"Save image"}); await saveImage.click(); await saveImage.waitFor({state:"hidden"}); await page.reload(); await page.locator('.inator-project-image img[src^="data:image/png"]').waitFor(); pass("states.truthful","desktop","uploaded a project image and reloaded","explicit image selection persisted without a placeholder");
  await page.goto(url+"/#/workspace/identity"); const shortName=page.getByLabel(/Short name/i); await shortName.fill("Acceptance User"); const developer=page.getByText("Developer",{exact:true}); await developer.click(); const team=page.getByText("Team representative",{exact:true}); await team.click(); await page.getByRole("button",{name:"Save",exact:true}).click(); await page.reload(); assert.equal(await page.getByLabel(/Short name/i).inputValue(),"Acceptance User"); pass("workspace.identity","desktop","edited roles and identity, saved, and reloaded","identity persisted");
  await page.goto(url+"/#/workspace/testers"); await page.getByText("Commons shell",{exact:true}).waitFor(); await page.getByText(${quoted(menus.context + " round trip")},{exact:true}).waitFor(); pass("workspace.tester-role","desktop","opened developer-gated Testers","Commons and product testers are composed");
  await page.goto(url+"/#/resources"); await page.getByRole("heading",{name:"Resources"}).waitFor(); pass("footer.role-gating","desktop","opened team-gated Resources","Resources rendered after role grant");
  await page.goto(url+"/#/workspace/identity"); await page.getByText("Developer",{exact:true}).click(); await page.getByText("Team representative",{exact:true}).click(); await page.getByRole("button",{name:"Save",exact:true}).click(); await page.goto(url+"/#/workspace/testers"); await page.getByRole("heading",{name:"Not found"}).waitFor(); await page.goto(url+"/#/resources"); await page.getByRole("heading",{name:"Not found"}).waitFor(); pass("roles.live-update","desktop","removed Developer and Team roles without reload","gated destinations disappeared and direct entry was refused");
  await page.goto(url+"/#/about"); await page.getByRole("tab",{name:"Inator ecosystem"}).waitFor(); await page.getByText(/How to cite|Citation/i).first().waitFor(); pass("about.composition","desktop","opened About","product content, citation, records, and ecosystem tab rendered");
  for (const [route,heading] of [["milestones",/milestone/i],["releases",/release/i],["roadmap",/roadmap|feature/i],["security",/Security & assurance/i],["privacy",/Privacy & verified practice/i]]) { await page.goto(url+"/#/"+route); await page.getByText(heading).first().waitFor(); await page.reload(); await page.getByText(heading).first().waitFor(); }
  pass("about.standard-records","desktop","visited and reloaded every standard record route","Commons history, roadmap, security, and privacy renderers survived reload"); pass("routing.reload","desktop","used direct URLs and reloads","advertised destinations remained addressable");
  await page.goto(url+"/#/help"); for(const label of ["Start here","Everyday tasks","Reference","FAQ"]) await page.getByRole("tab",{name:label}).waitFor(); pass("help.composition","desktop","opened Help and inspected tabs","standard four-part reading flow rendered");
  await page.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight)); await page.evaluate(() => { location.hash = "#/workspace/identity"; }); await page.getByRole("heading",{name:"Identity",exact:true}).waitFor(); assert.equal(await page.evaluate(() => window.scrollY),0); pass("routing.scroll-reset","desktop","scrolled to the document end and changed hash route","the Identity route opened at scroll position zero");
  ${brief.capabilities.includes("machine-state") ? 'await page.goto(url+"/#/workspace/machine"); await page.getByRole("heading",{name:"Machine",exact:true}).waitFor(); await page.getByText("Browser application",{exact:true}).waitFor(); pass("workspace.machine","desktop","opened the declared Machine destination","the shared Machine surface rendered its browser-observation boundary");' : ""}
  ${brief.capabilities.includes("model-runtime") ? `await page.goto(url+"/#/workspace/models"); await page.getByRole("heading",{name:"Models",exact:true}).waitFor(); const assignment=page.getByLabel(${quoted(`Assign ${menus.context} reviewer`)}); assert.equal(await assignment.inputValue(),""); pass("workspace.models","desktop","opened the declared Models destination and inspected the product role","the shared Models surface rendered with its role explicitly unassigned");` : ""}
  ${brief.capabilities.includes("pipeline-engine") ? 'await page.goto(url+"/#/pipeline"); await page.getByRole("heading",{name:"Pipeline",exact:true}).waitFor(); await page.getByRole("button",{name:"Run fixture",exact:true}).click(); await page.getByText("Fixture complete",{exact:true}).waitFor({timeout:20000}); pass("pipeline.fixture","desktop","ran the declared synthetic Pipeline fixture","the shared Pipeline workspace reported Fixture complete");' : ""}
  await page.goto(url+"/#/workspace/backup"); const downloadEvent=page.waitForEvent("download"); await page.getByRole("button",{name:/Create backup/i}).click(); const backupDownload=await downloadEvent; const backupPath=await backupDownload.path(); assert.ok(backupPath); await page.goto(url+"/#/projects"); const renamed=page.getByLabel(/Rename Acceptance text/); await renamed.fill("Changed after backup"); await renamed.blur(); await page.getByLabel(/Rename Changed after backup/).waitFor(); await page.goto(url+"/#/workspace/backup"); await page.locator('input[accept*="inator-backup"]').last().setInputFiles(backupPath); await page.getByRole("button",{name:/Restore workspace/i}).last().click(); await page.goto(url+"/#/projects"); await page.getByLabel(/Rename Acceptance text/).waitFor(); await page.locator('.inator-project-image img[src^="data:image/png"]').waitFor(); pass("workspace.backup","desktop","downloaded, changed, and restored a backup","text and explicit image selection were restored");
  pass("workspace.initial","desktop","opened required Workspace destinations","Identity and Backup are functional"); pass("shell.projects-context","desktop","selected and renamed a project","Projects retains one current text context"); pass("css.sealed","desktop","exercised Commons controls under product stylesheet","shared controls remained operable"); pass("release.identity","desktop","loaded built app identity","browser product version is rendered from generated record"); pass("privacy.build-boundary","desktop","inspected privacy record and built output","privacy boundary is explicit and no fixture was used");
  journeys.push({id:"desktop",driver:"browser",viewport:{width:1280,height:900},startedAt:desktopStarted,endedAt:new Date().toISOString()}); await context.close();
  const narrowStarted=new Date().toISOString(); const narrow=await browser.newContext({viewport:{width:390,height:844}}); const small=await narrow.newPage(); small.setDefaultTimeout(7000); await small.goto(url+"/#/projects"); const menu=small.getByRole("button",{name:/navigation menu/i}); await menu.click(); await small.getByRole("menuitem",{name:${quoted(menus.primary)}}).waitFor(); await small.getByRole("menuitem",{name:/Workspace|Identity/}).first().waitFor(); pass("shell.narrow-menu","narrow","opened shell menu at exactly 390 CSS pixels","primary and Workspace navigation are in the accessible menu"); await menu.press("Escape"); assert.equal(await menu.evaluate(el=>document.activeElement===el),true); pass("shell.keyboard","narrow","dismissed menu with Escape","focus returned to the menu trigger"); journeys.push({id:"narrow",driver:"browser",viewport:{width:390,height:844},startedAt:narrowStarted,endedAt:new Date().toISOString()}); await narrow.close();
  for(const check of GREENFIELD_FUNCTIONAL_CHECKS.filter(check => !check.capability || ${JSON.stringify(brief.capabilities)}.includes(check.capability))) assert.ok(seen.has(check.id),"Functional suite did not execute " + check.id);
  await writeFile("evidence/greenfield-acceptance.json",JSON.stringify({schema:GREENFIELD_ACCEPTANCE_SCHEMA,target:{url,buildSha256:await digest("dist"),capabilities:${JSON.stringify(brief.capabilities)}},journeys,observations},null,2)+"\\n");
} finally { await browser?.close(); server.kill("SIGTERM"); }
`;
}

async function assertDestinationAbsent(target) {
  try {
    await lstat(target);
    throw new Error(`Refusing to overwrite existing project at ${target}.`);
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
}

export async function generateProject({ brief: rawBrief, destination, planDestination = destination, commonsPath }) {
  const brief = normalizeProjectBrief(rawBrief);
  const menus = requiredMenus(rawBrief);
  const target = path.resolve(destination);
  await assertDestinationAbsent(target);
  const plan = createProjectPlan(rawBrief, path.resolve(planDestination));
  for (const directory of ["src", "public", "test", "evidence", "information", "config"]) await mkdir(path.join(target, directory), { recursive: true });
  const packageData = { name: brief.product.id, version: brief.product.version, private: true, type: "module", scripts: { dev: "vite --host 127.0.0.1", build: "vite build", test: "node --test test/*.test.js", "test:functional": "node test/greenfield-functional.mjs", check: "npm test && npm run build && npm run test:functional && npm run inator:verify", "inator:verify": "inator verify-greenfield --project . --evidence evidence/greenfield-acceptance.json" }, devDependencies: { "playwright-core": "^1.55.0", vite: "^7.3.6" } };
  await writeFile(path.join(target, "package.json"), json(packageData));
  await writeFile(path.join(target, "inator.json"), json({
    $schema: "https://inator.com/schemas/consumer-v1.json",
    schemaVersion: 1,
    product: { id: brief.product.id, name: brief.product.name, version: brief.product.version },
    localRequirements: { manifest: "config/local-requirements.json" },
    capabilities: {}
  }));
  await writeFile(path.join(target, "config/local-requirements.json"), json({
    schemaVersion: "inator-local-requirements.0.1-draft",
    productId: brief.product.id,
    profiles: [
      { id: "local-full", label: "Local workbench", execution: "browser-local", publication: "private", description: "Generated local execution profile; no external runtime is required until product work declares one." },
      { id: "static-public", label: "Static publication", execution: "browser-static", publication: "public", description: "Read-only static publication boundary." }
    ],
    requirements: []
  }));
  await writeFile(path.join(target, "inator.project.json"), json({ ...rawBrief, ...brief, interface: menus }));
  await writeFile(path.join(target, "creation-plan.json"), json(plan));
  await writeFile(path.join(target, "index.html"), `<!doctype html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="/dunce-hat.svg"><title>${brief.product.name}</title></head><body><header data-inator-product-header></header><main></main><footer data-inator-product-footer></footer><script type="module" src="/src/main.js"></script></body></html>\n`);
  await writeFile(path.join(target, "src/main.js"), mainSource(brief, menus));
  await writeFile(path.join(target, "src/styles.css"), styles());
  await writeFile(path.join(target, "test/greenfield-functional.mjs"), functionalAcceptanceSource(brief, menus));
  await writeFile(path.join(target, "public/dunce-hat.svg"), iconSvg(brief.product.name));
  for (const [id, record] of Object.entries(informationRecords(brief))) await writeFile(path.join(target, "information", `${id}.json`), json(record));
  await writeFile(path.join(target, "README.md"), `# ${brief.product.name}\n\nGenerated by Inator Commons. Do not replace standard shell surfaces with product-local imitations.\n`);
  await writeFile(path.join(target, ".gitignore"), "node_modules/\ndist/\n.inator/rollback/\nevidence/*.json\n!evidence/.gitkeep\n");
  await writeFile(path.join(target, "evidence/.gitkeep"), "");
  await writeFile(path.join(target, "test/generated.test.js"), `import test from "node:test"; import assert from "node:assert/strict"; import brief from "../inator.project.json" with { type: "json" }; test("generated product identity is complete",()=>{ assert.equal(brief.product.id, ${quoted(brief.product.id)}); assert.ok(brief.product.name); assert.ok(brief.interface.primary); assert.ok(brief.interface.context); });\n`);
  return Object.freeze({ target, brief, plan, files: plan.files });
}

export async function createVerifiedProject({ brief, destination, commonsPath, verify }) {
  if (typeof verify !== "function") throw new TypeError("createVerifiedProject requires a verification callback.");
  const target = path.resolve(destination);
  await assertDestinationAbsent(target);
  const parent = path.dirname(target);
  await mkdir(parent, { recursive: true });
  const stagingRoot = await mkdtemp(path.join(parent, `.${path.basename(target)}.inator-create-`));
  const stagedTarget = path.join(stagingRoot, path.basename(target));
  try {
    const generated = await generateProject({ brief, destination: stagedTarget, planDestination: target, commonsPath });
    await verify(generated);
    await rename(stagedTarget, target);
    await rm(stagingRoot, { recursive: true, force: true });
    return Object.freeze({ ...generated, target, diagnosticPath: null });
  } catch (error) {
    error.message = `${error.message}\nGenerated diagnostics were retained at ${stagedTarget}.`;
    error.diagnosticPath = stagedTarget;
    throw error;
  }
}
