export const GREENFIELD_ACCEPTANCE_SCHEMA = "inator.greenfield-acceptance.v1";
const FUNCTIONAL_EVIDENCE_KINDS = new Set(["dom-interaction", "navigation", "browser-state", "persisted-state", "download-inspection", "build-inspection"]);

export const GREENFIELD_FUNCTIONAL_CHECKS = Object.freeze([
  ["shell.product-icon", "Product icon is visible, named, and activates Home."],
  ["shell.product-name", "Product name is visible in the standard shell."],
  ["shell.projects-context", "The collection route exposes and persists one selected record context."],
  ["workspace.initial", "Identity and Backup destinations open and participate in the tested journeys."],
  ["workspace.identity", "Identity opens the standard Identity view and persists an edit."],
  ["workspace.tester-role", "Tester/Debug appears for developer and disappears when that role is removed."],
  ["footer.role-gating", "Footer is About, Help, then role-gated Resources with the standard separator."],
  ["about.composition", "About contains product content, Citation, standard records, and the Inator ecosystem tab."],
  ["about.standard-records", "Roadmap, Milestones/Releases, Security, and Privacy use standard Commons views."],
  ["help.composition", "Help uses the standard Start, Tasks, Reference, and FAQ reading flow."],
  ["shell.narrow-menu", "At 390px one accessible menu contains primary, contextual, and Workspace navigation."],
  ["shell.keyboard", "Escape closes the narrow menu and restores focus to its trigger."],
  ["routing.reload", "Every advertised destination survives direct entry and a fresh reload."],
  ["roles.live-update", "Role-gated destinations update in both directions without reload."],
  ["workspace.backup", "A downloaded backup restores the tested record text and explicit image selection after mutation."],
  ["projects.collection", "The generated collection persists a record rename across reload."],
  ["actions.outcomes", "Activating the tested product-brand action navigates to a distinct Home route."],
  ["states.truthful", "An explicit record image persists across reload without being replaced by a placeholder."],
  ["css.sealed", "The exercised shared controls remain operable with the generated product stylesheet loaded."],
  ["release.identity", "Installed Commons versions, browser-visible product version, health, and release evidence agree."],
  ["privacy.build-boundary", "The generated privacy boundary is visible and the acceptance journey uses only synthetic fixture content."],
  ["routing.scroll-reset", "A hash-route transition resets the document to the top before the destination is used."],
  ["workspace.machine", "A declared machine-state capability renders the shared Machine surface and names its observation boundary.", "machine-state"],
  ["workspace.models", "A declared model-runtime capability renders the shared Models surface with its product role unassigned.", "model-runtime"],
  ["pipeline.fixture", "A declared pipeline-engine capability renders the shared Pipeline workspace and completes its synthetic fixture.", "pipeline-engine"]
].map(([id, description, capability]) => Object.freeze({ id, description, ...(capability ? { capability } : {}) })));

function assertion(condition, message) {
  if (!condition) throw new TypeError(message);
}

export function evaluateGreenfieldAcceptance(report) {
  assertion(report && typeof report === "object" && !Array.isArray(report), "Greenfield acceptance report must be an object.");
  assertion(report.schema === GREENFIELD_ACCEPTANCE_SCHEMA, `Greenfield acceptance report must use ${GREENFIELD_ACCEPTANCE_SCHEMA}.`);
  assertion(typeof report.target?.url === "string" && /^https?:\/\//.test(report.target.url), "Greenfield acceptance target.url must be an HTTP(S) URL.");
  assertion(typeof report.target?.buildSha256 === "string" && /^[a-f0-9]{64}$/.test(report.target.buildSha256), "Greenfield acceptance target.buildSha256 is required.");
  assertion(report.target.capabilities === undefined || (Array.isArray(report.target.capabilities) && report.target.capabilities.every(value => typeof value === "string")), "Greenfield acceptance target.capabilities must be an array of strings when present.");
  assertion(Array.isArray(report.journeys) && report.journeys.length >= 2, "Greenfield acceptance requires desktop and narrow browser journeys.");
  for (const [name, width] of [["desktop", 1000], ["narrow", 390]]) {
    const journey = report.journeys.find((candidate) => candidate.id === name);
    assertion(journey, `Greenfield acceptance is missing the ${name} journey.`);
    assertion(journey.driver === "browser", `${name} journey must be produced by a browser driver.`);
    assertion(Number.isFinite(journey.viewport?.width), `${name} journey needs a numeric viewport width.`);
    if (name === "desktop") assertion(journey.viewport.width >= width, "Desktop journey must be at least 1000 CSS pixels wide.");
    else assertion(journey.viewport.width === width, "Narrow journey must run at exactly 390 CSS pixels.");
    assertion(typeof journey.startedAt === "string" && !Number.isNaN(Date.parse(journey.startedAt)), `${name} journey needs startedAt.`);
    assertion(typeof journey.endedAt === "string" && !Number.isNaN(Date.parse(journey.endedAt)), `${name} journey needs endedAt.`);
  }
  assertion(Array.isArray(report.observations), "Greenfield acceptance observations must be an array.");
  const byId = new Map();
  for (const observation of report.observations) {
    assertion(typeof observation?.id === "string", "Every greenfield observation needs an id.");
    assertion(!byId.has(observation.id), `Duplicate greenfield observation ${observation.id}.`);
    byId.set(observation.id, observation);
  }
  const declaredCapabilities = new Set(report.target.capabilities || []);
  const requiredChecks = GREENFIELD_FUNCTIONAL_CHECKS.filter(check => !check.capability || declaredCapabilities.has(check.capability));
  const failed = [];
  for (const check of requiredChecks) {
    const observation = byId.get(check.id);
    if (!observation) { failed.push({ ...check, reason: "missing" }); continue; }
    if (observation.status !== "passed") { failed.push({ ...check, reason: observation.status || "invalid-status", detail: observation.detail || "" }); continue; }
    if (!Array.isArray(observation.evidence) || observation.evidence.length < 1) { failed.push({ ...check, reason: "missing-functional-evidence" }); continue; }
    if (!observation.evidence.every((item) => item && FUNCTIONAL_EVIDENCE_KINDS.has(item.kind) && item.journeyId && item.action && item.assertion)) failed.push({ ...check, reason: "incomplete-or-nonfunctional-evidence" });
  }
  return Object.freeze({ ok: failed.length === 0, required: requiredChecks.length, passed: requiredChecks.length - failed.length, failed });
}

export function formatGreenfieldAcceptance(result) {
  if (result.ok) return `Greenfield functional conformance passed: ${result.passed}/${result.required} browser-observed checks.`;
  return [`Greenfield functional conformance failed: ${result.passed}/${result.required} checks passed.`, ...result.failed.map((failure) => `- [${failure.id}] ${failure.description} (${failure.reason})`)].join("\n");
}
