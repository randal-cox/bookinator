import { createHash } from "node:crypto";
import { mkdir, readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";

export const ADVERSARIAL_ASSAY_SCHEMA = "inator.adversarial-assay.v1";
export const ADVERSARIAL_COLLECTION_SCHEMA = "inator.adversarial-collection.v1";
export const DEFAULT_UI_CRITIC_ROLES = Object.freeze(["contract-archaeologist", "functional-breaker", "visual-critic"]);
export const ADVERSARY_ROLE_INSTRUCTIONS = Object.freeze({
  "contract-archaeologist": "Derive the complete obligation set from governing standards before inspecting implementation claims. Identify missing, weakened, duplicated, or product-specific substitutes for shared contracts. A systemic root cause increases the number of affected obligations you must inspect; it never ends the search.",
  "functional-breaker": "Inspect and execute behavior tests. For every interactive obligation distinguish render, activation, intermediate state, outcome, failure, recovery, and persisted or external result. Seek claims that pass when any one of those stages is absent.",
  "visual-critic": "Operate the live built product at every required viewport as an angry advocate for the human who must actually use it. Treat hidden, clipped, ambiguous, crowded, ugly, or visually absent controls as usability injuries until direct probing falsifies that concern. Reconcile visual presence with DOM and accessibility presence, inspect component-local overflow, and capture your own evidence.",
  "test-critic": "Measure fault sensitivity with safe isolated mutations or seeded fixtures. Identify tests that remain green after meaningful behavior breaks.",
  "code-health-critic": "Protect future humans and agents from code that is needlessly hard to understand, test, change, recover, or reuse. Inspect names, responsibilities, complexity, nesting, duplication, dead paths, error handling, async ownership, retry/idempotency, resource lifecycle, boundary validation, observability, reversibility, architecture, Commons reuse, and history hotspots. Use static tools as leads, then cite code and explain the concrete maintenance or failure consequence. Enumerate affected sites instead of stopping at one root cause. Do not prescribe refactoring until the behavior and ownership contract are understood.",
  "documentation-contradiction-critic": "Treat documentation as executable governance. Build a source-cited claim ledger across standards, decisions, milestones, guides, READMEs, diagrams, indexes, examples, tests, and current runtime evidence. Seek contradictions in authority, ownership, status, behavior, commands, paths, versions, and assurance. Distinguish direct contradiction, stale description, missing evidence, ambiguity, and intentionally historical material. Never infer agreement merely because a keyword appears or infer a handoff from words such as blocked or deferred.",
  "security-hunter": "Develop an explicit threat model, identify assets and trust boundaries, then seek exploitable data-handling, injection, dependency, authorization, storage, backup/import, build, and runtime failures. Treat unsupported security claims as attack hypotheses, not assurances. Use safe disposable payloads and report what remains untested.",
  "commercial-risk-critic": "Act as an opinionated launch-blocking issue spotter for accessibility, privacy, children and age handling, cookies/tracking, consumer claims, licensing, data rights, and related commercial risk. Prefer authoritative current sources, distinguish legal uncertainty and jurisdiction, and never claim legal certification. Optimize for surfacing risks that require counsel or product policy, not for reassuring the builder.",
  "accessibility-specialist": "Protect disabled humans' ability to perceive, understand, navigate, and operate every complete workflow. Combine automated checks with manual keyboard, focus, zoom/reflow, contrast, name-role-state, status/error announcement, target, pointer-alternative, and assistive-technology inspection. Treat an automated clean result as incomplete evidence and report concrete human consequences.",
  verifier: "Reproduce disputed findings against the exact artifact without implementing repairs. Classify confirmed, needs-validation, rejected, or assay-defect."
});

const text = (value) => String(value ?? "").trim();

export function createAdversarialAssayPacket({
  id,
  createdAt = new Date().toISOString(),
  mode = "discovery",
  option = "same-chat",
  repository,
  revision,
  dirty = false,
  buildDigest,
  included = [],
  excluded = [],
  stopConditions = [],
  claims = [],
  roles = DEFAULT_UI_CRITIC_ROLES,
  contextRefs = [],
  obligationRefs = []
} = {}) {
  const normalizedRoles = [...new Set(roles.map(text).filter(Boolean))];
  for (const role of normalizedRoles) if (!ADVERSARY_ROLE_INSTRUCTIONS[role]) throw new TypeError(`Unknown adversary role ${role}.`);
  if (!text(id) || !text(repository) || !text(revision)) throw new TypeError("Adversarial assay id, repository, and revision are required.");
  if (!included.length) throw new TypeError("Adversarial assay requires at least one included scope.");
  if (!claims.length) throw new TypeError("Adversarial assay requires at least one claim to falsify.");
  return Object.freeze({
    schema: ADVERSARIAL_ASSAY_SCHEMA,
    id: text(id),
    mode,
    option,
    createdAt,
    artifact: { repository: text(repository), revision: text(revision), dirty: Boolean(dirty), ...(buildDigest ? { buildDigest: text(buildDigest) } : {}) },
    scope: { included: included.map(text).filter(Boolean), excluded: excluded.map(text).filter(Boolean), stopConditions: stopConditions.map(text).filter(Boolean) },
    claims: claims.map((claim, index) => typeof claim === "string" ? { id: `claim-${index + 1}`, text: text(claim), standardRefs: [...contextRefs] } : claim),
    obligationRefs: obligationRefs.map(text).filter(Boolean),
    critics: normalizedRoles.map((role, index) => ({ id: `critic-${index + 1}-${role}`, role, status: "planned" })),
    findings: [],
    coverage: []
  });
}

export function renderAdversaryPrompt(packet, critic) {
  const instruction = ADVERSARY_ROLE_INSTRUCTIONS[critic.role];
  if (!instruction) throw new TypeError(`Unknown adversary role ${critic.role}.`);
  return `You are ${critic.id}, an independent read-only ${critic.role} in a blind Discovery pass.

${instruction}

Artifact
- Repository: ${packet.artifact.repository}
- Revision: ${packet.artifact.revision}
- Dirty: ${packet.artifact.dirty}

Included scope
${packet.scope.included.map((item) => `- ${item}`).join("\n")}

Excluded scope
${packet.scope.excluded.length ? packet.scope.excluded.map((item) => `- ${item}`).join("\n") : "- Nothing beyond the included scope is authorized."}

Claims to falsify
${packet.claims.map((claim) => `- [${claim.id}] ${claim.text}${claim.standardRefs?.length ? `\n  Standards: ${claim.standardRefs.join(", ")}` : ""}`).join("\n")}

Task-specific obligation inventories
${packet.obligationRefs?.length ? packet.obligationRefs.map((item) => `- ${item}`).join("\n") : "- None supplied. Derive and report the applicable obligations; do not assume this means none exist."}

Rules
- Do not edit files, repair defects, or communicate with the builder or other critics.
- Optimize Discovery for recall. A false positive costs adjudication time; a false negative preserves false confidence. Report a specific evidence-backed suspicion at appropriately lower confidence instead of suppressing it because a benign explanation is possible.
- Derive expectations from the cited standards and the exact artifact, not from symbol, route, selector, label, renderer, or test-name presence.
- Do not search for or ask for known findings before returning your blind report.
- Stop before private-data exposure, irreversible/destructive action, or external side effects outside scope.
- Record findings with claim, precondition, action, observation, expected behavior, severity, confidence, reproduction, and exact evidence references.
- Build an obligation matrix before concluding. Give every applicable obligation two separate statuses: (1) artifact behavior independently observed and (2) submitted evidence sufficiency. Use proved, falsified, blocked, deferred, or out-of-scope with evidence for each dimension. Your own successful re-test does not make the candidate's submitted evidence sufficient. Finding one systemic root cause does not discharge the affected obligations; expand it across every surface it can falsely certify.
- For every rendered interactive control, separately record whether you activated it and observed its intermediate state, success outcome, failure outcome, recovery, and durable or external effect. Presence is never execution.
- Before returning, audit every blocked, skipped, or deferred item. Either inspect it now or emit one machine-collectable line per item in exactly this form: "- Deferred [DEF-ID]: DESCRIPTION; owner: CRITIC_ID; required evidence: EVIDENCE". DEF-ID must be unique in this assay and CRITIC_ID must be an exact critic id from this packet. The named owner must inspect it and emit "- Closed [DEF-ID]: DISPOSITION; evidence: EVIDENCE" in that critic's raw report. Assignment without a closure is still open work. If no packet critic can honestly close it, use "owner: unstaffed" and name the required role in the description. Unowned, inferred, multiply closed, wrong-owner, or unclosed deferrals are assay failures.
- Before returning, promote every obligation that the candidate claims passed but your matrix marks falsified, blocked, deferred, or unsupported into a specific evidence-overclaim finding. Do not leave the mismatch buried only in a matrix.
- Record coverage attempted, blocked, skipped, deferred, and out of scope. A short findings list is not a success signal; within scope, reward additional distinct falsifications rather than stopping after the first root cause. Do not optimize for approval rate, precision, or agreement with the builder.
- Return the raw report before any synthesis or known-specimen disclosure.
`;
}

export async function writeAdversarialAssayPacket({ projectDir, packet, outputDir } = {}) {
  const root = path.resolve(projectDir);
  const target = path.resolve(root, outputDir || path.join(".inator", "adversary", packet.id));
  if (!target.startsWith(`${root}${path.sep}`)) throw new TypeError("Adversarial assay output must stay inside the project.");
  await mkdir(target, { recursive: true });
  await writeFile(path.join(target, "packet.json"), `${JSON.stringify(packet, null, 2)}\n`);
  for (const critic of packet.critics) await writeFile(path.join(target, `${critic.id}.md`), renderAdversaryPrompt(packet, critic));
  return Object.freeze({ directory: target, packet: path.join(target, "packet.json"), prompts: packet.critics.map((critic) => path.join(target, `${critic.id}.md`)) });
}

function rawReportCandidates(critic) {
  return [`raw-${critic.role}.md`, `raw-${critic.id}.md`];
}

function findingHeadings(source) {
  const findingsStart = source.search(/^## Findings(?: ledger)?\s*$/im);
  if (findingsStart < 0) return [];
  const remainder = source.slice(findingsStart).split(/\r?\n/);
  const headings = [];
  for (let index = 1; index < remainder.length; index += 1) {
    const line = remainder[index];
    if (/^##\s+/.test(line)) break;
    const match = line.match(/^###\s+(.+?)\s*$/);
    if (match) headings.push(match[1]);
  }
  return headings;
}

function deferralRecords(source, critics, criticId) {
  return source.split(/\r?\n/).flatMap((line, index) => {
    const record = line.match(/^\s*- Deferred(?: \[([^\]]+)\])?: (.+?); owner: ([^;]+); required evidence: (.+)\s*$/);
    if (!record) return [];
    const declaredOwner = record[3].trim();
    const owner = critics.find(({ id }) => id === declaredOwner)?.id || null;
    return [{ id: record[1]?.trim() || `legacy-${criticId}-${index + 1}`, explicitId: Boolean(record[1]), description: record[2].trim(), requiredEvidence: record[4].trim(), line: index + 1, text: line.trim().slice(0, 500), owner, declaredOwner }];
  });
}

function closureRecords(source) {
  return source.split(/\r?\n/).flatMap((line, index) => {
    const record = line.match(/^\s*- Closed \[([^\]]+)\]: (.+?); evidence: (.+)\s*$/);
    if (!record) return [];
    return [{ id: record[1].trim(), disposition: record[2].trim(), evidence: record[3].trim(), line: index + 1, text: line.trim().slice(0, 500) }];
  });
}

export async function collectAdversarialAssay({ packetDir, outputFile = "collection.json", collectedAt = new Date().toISOString() } = {}) {
  const directory = path.resolve(packetDir);
  const packetPath = path.join(directory, "packet.json");
  const packet = JSON.parse(await readFile(packetPath, "utf8"));
  if (packet.schema !== ADVERSARIAL_ASSAY_SCHEMA || !Array.isArray(packet.critics)) throw new TypeError("Packet is not an inator.adversarial-assay.v1 packet.");
  const outputPath = path.resolve(directory, outputFile);
  if (!outputPath.startsWith(`${directory}${path.sep}`)) throw new TypeError("Adversarial collection output must stay inside the packet directory.");
  const reports = [];
  const missingReports = [];
  for (const critic of packet.critics) {
    let selected;
    for (const candidate of rawReportCandidates(critic)) {
      const candidatePath = path.join(directory, candidate);
      try { if ((await stat(candidatePath)).isFile()) { selected = candidatePath; break; } } catch (error) { if (error.code !== "ENOENT") throw error; }
    }
    if (!selected) {
      missingReports.push({ criticId: critic.id, role: critic.role, expected: rawReportCandidates(critic) });
      continue;
    }
    const source = await readFile(selected, "utf8");
    const headings = findingHeadings(source);
    const deferrals = deferralRecords(source, packet.critics, critic.id);
    const closures = closureRecords(source);
    const severities = {};
    for (const heading of headings) {
      const severity = heading.match(/\b(critical|medium-high|high|medium|low)\b/i)?.[1]?.toLowerCase() || "unspecified";
      severities[severity] = (severities[severity] || 0) + 1;
    }
    reports.push({
      criticId: critic.id,
      role: critic.role,
      file: path.basename(selected),
      bytes: Buffer.byteLength(source),
      sha256: createHash("sha256").update(source).digest("hex"),
      findings: { count: headings.length, severities, headings },
      deferrals: { count: deferrals.length, unowned: deferrals.filter(({ owner }) => !owner).length, records: deferrals },
      closures: { count: closures.length, records: closures }
    });
  }
  const allDeferrals = reports.flatMap((report) => report.deferrals.records.map((record) => ({ ...record, sourceCriticId: report.criticId, sourceFile: report.file })));
  const allClosures = reports.flatMap((report) => report.closures.records.map((record) => ({ ...record, criticId: report.criticId, file: report.file })));
  const duplicateDeferralIds = [...new Set(allDeferrals.map(({ id }) => id).filter((id, index, ids) => ids.indexOf(id) !== index))];
  const closureAudit = allDeferrals.map((deferral) => {
    const matches = allClosures.filter(({ id }) => id === deferral.id);
    const valid = Boolean(deferral.owner) && deferral.explicitId && matches.length === 1 && matches[0].criticId === deferral.owner;
    const reason = !deferral.owner ? "unowned" : !deferral.explicitId ? "legacy-id-cannot-close" : matches.length === 0 ? "unclosed" : matches.length > 1 ? "multiply-closed" : matches[0].criticId !== deferral.owner ? "wrong-owner" : "closed";
    return { deferralId: deferral.id, owner: deferral.owner, sourceCriticId: deferral.sourceCriticId, closureCount: matches.length, closedBy: matches.map(({ criticId }) => criticId), valid, reason };
  });
  const orphanClosures = allClosures.filter((closure) => !allDeferrals.some(({ id }) => id === closure.id));
  const manifest = {
    schema: ADVERSARIAL_COLLECTION_SCHEMA,
    assayId: packet.id,
    collectedAt,
    packet: { file: "packet.json", sha256: createHash("sha256").update(await readFile(packetPath)).digest("hex") },
    reports,
    summary: {
      expectedReports: packet.critics.length,
      collectedReports: reports.length,
      missingReports: missingReports.length,
      findings: reports.reduce((sum, report) => sum + report.findings.count, 0),
      deferrals: reports.reduce((sum, report) => sum + report.deferrals.count, 0),
      closures: reports.reduce((sum, report) => sum + report.closures.count, 0),
      unownedDeferrals: reports.reduce((sum, report) => sum + report.deferrals.unowned, 0),
      openDeferrals: closureAudit.filter(({ valid }) => !valid).length,
      invalidClosures: orphanClosures.length + duplicateDeferralIds.length
    },
    gaps: {
      missingReports,
      unownedDeferrals: reports.flatMap((report) => report.deferrals.records.filter(({ owner }) => !owner).map((record) => ({ criticId: report.criticId, file: report.file, ...record }))),
      closureAudit,
      orphanClosures,
      duplicateDeferralIds
    },
    parserLimitations: [
      "Finding counts include only level-three headings inside an explicit Findings or Findings ledger section.",
      "Deferrals include only exact '- Deferred [DEF-ID]: ...; owner: ...; required evidence: ...' records, plus legacy records retained as deliberately unclosable gaps; prose and obligation-matrix statuses are not handoffs.",
      "Closures include only exact '- Closed [DEF-ID]: ...; evidence: ...' records and are valid only once, in the declared owner's raw report.",
      "Deferral ownership is recognized only when owner exactly matches a packet critic id; 'unstaffed', unknown, and ambiguous ownership remains unowned.",
      "Collection inventories report structure and hashes; it does not adjudicate findings or claim coverage completeness."
    ]
  };
  await writeFile(outputPath, `${JSON.stringify(manifest, null, 2)}\n`);
  return Object.freeze({ manifest, output: outputPath, ok: manifest.summary.missingReports === 0 && manifest.summary.unownedDeferrals === 0 && manifest.summary.openDeferrals === 0 && manifest.summary.invalidClosures === 0 });
}
