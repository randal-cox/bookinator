import { createHash } from "node:crypto";
import { chmod, copyFile, mkdir, mkdtemp, readFile, readdir, rename, rm, stat, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { CAPABILITY_CATALOG, diagnoseProject, MANIFEST_FILENAME, MANIFEST_SCHEMA, readJson } from "./manifest.mjs";
import { discoverServers, formatServers, selectServers, stopServers } from "./server-control.mjs";
import { assertCurrentUIAuditBaseline, auditUI, createUIAuditBaseline, formatUIAudit } from "./ui-audit.mjs";
import { auditAgentContext, formatAgentContextAudit, formatContextRoutes, readAgentContextManifest, renderLeanCodexConfig, selectContextRoutes } from "./agent-context.mjs";
import { evaluateGreenfieldAcceptance, formatGreenfieldAcceptance } from "./greenfield-acceptance.mjs";
import { createVerifiedProject } from "./project-generator.mjs";
import { collectAdversarialAssay, createAdversarialAssayPacket, writeAdversarialAssayPacket } from "./adversarial-assay.mjs";
import { ADVERSARIAL_FIXTURES, prepareAdversarialFixtures } from "./adversarial-fixtures.mjs";

const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function usage() {
  return `Usage: inator <command> [options]

Commands:
  servers [list] [SELECTOR...]       List verified running Inator development servers
  servers stop SELECTOR...           Stop servers by product, PID, or port
  servers stop --all                 Stop every verified Inator development server
  doctor                             Diagnose a consumer installation without changing it
  context [TOPIC...]                 Return a bounded route to authoritative project evidence
  audit-agent-context                Validate context routes, evidence, and agent entry points
  configure-codex                    Generate the declared lean project Codex configuration
  require CAPABILITY...              Install exact packages for requested capabilities
  rollback                           Restore the snapshot before the last adoption
  audit-ui [ROOT...]                 Audit default or explicit product source roots
  create BRIEF DESTINATION           Create a functional Commons application from a saved brief
  verify-greenfield                 Validate browser-observed greenfield acceptance evidence
  adversary prepare [ROLE...]       Freeze a blind review packet and critic prompts
  adversary collect DIRECTORY       Hash and inventory immutable raw critic reports
  adversary fixtures [NAME...]      Copy an artifact into a disposable failure-fixture workspace

Options:
  --all                     Select every verified server (servers stop only)
  --project DIR             Consumer directory (default: invoking project)
  --source DIR              Inator Commons source checkout for require
  --accept-audit-baseline   Record current UI findings during explicit adoption
  --baseline FILE           Compare UI findings with a reviewed baseline
  --write-baseline FILE     Write current UI findings for review
  --evidence FILE           Functional acceptance report to verify
  --target DIR              Artifact repository or generated project to criticize
  --scope TEXT              Included adversarial scope (repeatable)
  --claim TEXT              Claim to falsify (repeatable)
  --obligations FILE       Task-specific obligation inventory (repeatable)
  --output DIR              Project-relative packet output directory
  --dry-run                 Print the adoption plan without changing files
  --json                    Emit machine-readable output where supported
  -h, --help                Show this help
`;
}

function parse(arguments_) {
  const values = [...arguments_];
  const command = values.shift() || "help";
  let subcommand = null;
  if (command === "servers" || command === "adversary") {
    if (["list", "stop", "install"].includes(values[0])) subcommand = values.shift();
    else if (command === "servers") subcommand = "list";
    if (command === "adversary" && ["prepare", "collect", "fixtures"].includes(values[0])) subcommand = values.shift();
  }
  const options = { projectDir: path.resolve(process.env.INATOR_PROJECT_DIR || process.cwd()), sourceDir: process.env.INATOR_COMMONS_SOURCE_DIR || "", targetDir: "", output: "", scopes: [], claims: [], obligationRefs: [], dryRun: false, json: false, all: false, acceptAuditBaseline: false, baseline: "", writeBaseline: "", evidence: "", capabilities: [], subcommand };
  for (let index = 0; index < values.length; index += 1) {
    const argument = values[index];
    const next = () => {
      const value = values[index + 1];
      if (!value) throw new Error(`${argument} requires a value.`);
      index += 1;
      return value;
    };
    if (argument === "--project") options.projectDir = path.resolve(next());
    else if (argument === "--source") options.sourceDir = path.resolve(next());
    else if (argument === "--accept-audit-baseline") options.acceptAuditBaseline = true;
    else if (argument === "--baseline") options.baseline = next();
    else if (argument === "--write-baseline") options.writeBaseline = next();
    else if (argument === "--evidence") options.evidence = next();
    else if (argument === "--target") options.targetDir = path.resolve(next());
    else if (argument === "--scope") options.scopes.push(next());
    else if (argument === "--claim") options.claims.push(next());
    else if (argument === "--obligations") options.obligationRefs.push(next());
    else if (argument === "--output") options.output = next();
    else if (argument === "--dry-run") options.dryRun = true;
    else if (argument === "--json") options.json = true;
    else if (argument === "--all") options.all = true;
    else if (argument === "-h" || argument === "--help") options.help = true;
    else if (argument.startsWith("-")) throw new Error(`Unknown option ${argument}.`);
    else options.capabilities.push(argument);
  }
  return { command, options };
}

function runCommand(command, arguments_, { cwd, label, allowFailure = false, capture = false, env } = {}) {
  const result = spawnSync(command, arguments_, { cwd, env, encoding: "utf8", stdio: label || capture ? ["inherit", "pipe", "pipe"] : "inherit" });
  if (label && result.stdout?.trim()) process.stdout.write(`${result.stdout.trimEnd()}\n`);
  if (label && result.stderr?.trim()) process.stderr.write(`${result.stderr.trimEnd()}\n`);
  if (result.error) throw result.error;
  if (!allowFailure && result.status !== 0) throw new Error(`${label || command} failed with status ${result.status}.`);
  return result;
}

function projectCommandEnvironment(projectDir, environment = process.env) {
  return { ...environment, INATOR_PROJECT_DIR: path.resolve(projectDir) };
}

function artifactBaseName(packageName, version) {
  return `${packageName.replace(/^@/, "").replaceAll("/", "-")}-${version}.tgz`;
}

async function snapshotProject(projectDir, extraFiles = []) {
  const files = [...new Set(["package.json", "package-lock.json", MANIFEST_FILENAME, "inator.product-information.json", ".gitignore", ".inator/ui-audit-baseline.json", "bin/serve", "bin/inator", ...extraFiles.filter(Boolean)])];
  const values = {};
  for (const relative of files) {
    try { values[relative] = await readFile(path.join(projectDir, relative), "utf8"); }
    catch { values[relative] = null; }
  }
  const packagesDir = path.join(projectDir, ".inator", "packages");
  try { values.__artifacts = await readdir(packagesDir); }
  catch { values.__artifacts = []; }
  return values;
}

async function ensureProductInformationManifest(projectDir, manifest, productName) {
  manifest.information ||= { manifest: "inator.product-information.json" };
  const relative = manifest.information.manifest;
  if (path.isAbsolute(relative) || relative.split(/[\\/]/).includes("..")) throw new Error("information.manifest must be a safe project-relative JSON path.");
  const target = path.join(projectDir, relative);
  try { await readFile(target, "utf8"); return; } catch (error) { if (error.code !== "ENOENT") throw error; }
  const destinations = ["about", "help", "privacy", "security", "milestones", "releases", "roadmap"];
  const records = Object.fromEntries(destinations.map((id) => [id, { source: relative, status: "needs-product-content" }]));
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, `${JSON.stringify({ schema: "inator.product-information-contract.v1", productId: productName, records }, null, 2)}\n`);
}

async function restoreSnapshot(projectDir, snapshot) {
  for (const [relative, contents] of Object.entries(snapshot)) {
    if (relative === "__artifacts") continue;
    const target = path.join(projectDir, relative);
    if (contents == null) await rm(target, { force: true });
    else {
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, contents);
    }
  }
  const packagesDir = path.join(projectDir, ".inator", "packages");
  let artifacts = [];
  try { artifacts = await readdir(packagesDir); } catch { /* No package cache means there are no extra artifacts to remove. */ }
  for (const artifact of artifacts) if (!snapshot.__artifacts.includes(artifact)) await rm(path.join(packagesDir, artifact), { force: true });
}

async function prepareRollback(projectDir, snapshot) {
  const rollbackDir = path.join(projectDir, ".inator", "rollback");
  const pendingDir = path.join(rollbackDir, "pending");
  const archivedArtifacts = path.join(pendingDir, "artifacts");
  await rm(pendingDir, { recursive: true, force: true });
  await mkdir(archivedArtifacts, { recursive: true });
  for (const artifact of snapshot.__artifacts) {
    await copyFile(path.join(projectDir, ".inator", "packages", artifact), path.join(archivedArtifacts, artifact));
  }
  await writeFile(path.join(pendingDir, "last.json"), `${JSON.stringify({ createdAt: new Date().toISOString(), snapshot }, null, 2)}\n`);
  return pendingDir;
}

async function commitRollback(projectDir, pendingDir) {
  const rollbackDir = path.dirname(pendingDir);
  await rm(path.join(rollbackDir, "artifacts"), { recursive: true, force: true });
  await rm(path.join(rollbackDir, "last.json"), { force: true });
  await rename(path.join(pendingDir, "artifacts"), path.join(rollbackDir, "artifacts"));
  await rename(path.join(pendingDir, "last.json"), path.join(rollbackDir, "last.json"));
  await rm(pendingDir, { recursive: true, force: true });
}

async function restoreArchivedArtifacts(projectDir, snapshot, archiveDir) {
  const packagesDir = path.join(projectDir, ".inator", "packages");
  await mkdir(packagesDir, { recursive: true });
  for (const artifact of snapshot.__artifacts) {
    await copyFile(path.join(archiveDir, artifact), path.join(packagesDir, artifact));
  }
}

async function pruneUnreferencedArtifacts(projectDir, packageJson) {
  const packagesDir = path.join(projectDir, ".inator", "packages");
  const specifications = { ...(packageJson.dependencies || {}), ...(packageJson.devDependencies || {}) };
  const retained = new Set(Object.values(specifications)
    .filter((value) => typeof value === "string" && value.startsWith("file:.inator/packages/"))
    .map((value) => path.basename(value.slice("file:".length))));
  for (const artifact of await readdir(packagesDir)) {
    if (artifact.endsWith(".tgz") && !retained.has(artifact)) await rm(path.join(packagesDir, artifact));
  }
}

async function ensureIgnoredRollback(projectDir) {
  const file = path.join(projectDir, ".gitignore");
  let value = "";
  try { value = await readFile(file, "utf8"); } catch { /* A missing ignore file starts empty. */ }
  if (!value.split(/\r?\n/).includes(".inator/rollback/")) {
    if (value && !value.endsWith("\n")) value += "\n";
    value += ".inator/rollback/\n";
    await writeFile(file, value);
  }
}

async function packRequirement(sourceDir, requirement, artifactDir) {
  const sourcePackage = path.join(sourceDir, requirement.packagePath);
  const packageJson = await readJson(path.join(sourcePackage, "package.json"));
  await mkdir(artifactDir, { recursive: true });
  const stagingDir = await mkdtemp(path.join(os.tmpdir(), "inator-pack-"));
  try {
    const result = runCommand("npm", ["pack", sourcePackage, "--json", "--pack-destination", stagingDir, "--cache", path.join(os.tmpdir(), "inator-npm-cache")], { cwd: sourceDir, capture: true });
    const packed = JSON.parse(result.stdout);
    if (packed.length !== 1) throw new Error(`Packing ${requirement.packageName} produced ${packed.length} artifacts.`);
    const metadata = packed[0];
    if (metadata.name !== packageJson.name || metadata.version !== packageJson.version) {
      throw new Error(`Packed artifact identity does not match ${packageJson.name} ${packageJson.version}.`);
    }
    if (!metadata.integrity || !metadata.files?.some(({ path: file }) => file === "package.json")) {
      throw new Error(`Packed artifact for ${packageJson.name} is missing integrity or package metadata.`);
    }
    const produced = path.join(stagingDir, metadata.filename);
    const targetName = artifactBaseName(requirement.packageName, packageJson.version);
    const target = path.join(artifactDir, targetName);
    let existingIntegrity = "";
    try {
      const existing = await readFile(target);
      existingIntegrity = `sha512-${createHash("sha512").update(existing).digest("base64")}`;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    if (existingIntegrity && existingIntegrity !== metadata.integrity) {
      throw new Error(`${targetName} already exists with different bytes. Bump ${packageJson.name}'s version before repacking it.`);
    }
    if (!existingIntegrity) await copyFile(produced, target);
    if ((await stat(target)).size < 1) throw new Error(`Packed artifact ${targetName} is empty.`);
    return { ...requirement, version: packageJson.version, artifact: targetName };
  } finally {
    await rm(stagingDir, { recursive: true, force: true });
  }
}

function requestedRequirements(capabilities) {
  const requirements = new Map();
  const expandedCapabilities = capabilities.includes("product-shell")
    ? [...capabilities, ...(!capabilities.includes("ui-conformance") ? ["ui-conformance"] : [])]
    : capabilities;
  for (const capability of expandedCapabilities) {
    const definition = CAPABILITY_CATALOG[capability];
    if (!definition) throw new Error(`Unknown capability ${capability}. Available capabilities: ${Object.keys(CAPABILITY_CATALOG).join(", ")}.`);
    if (!requirements.has(definition.packageName)) requirements.set(definition.packageName, { ...definition, capabilities: [] });
    requirements.get(definition.packageName).capabilities.push(capability);
  }
  return [...requirements.values()];
}

function synchronizePackageCapabilities(manifest, packedRequirements) {
  manifest.capabilities ||= {};
  for (const requirement of packedRequirements) {
    for (const [capability, current] of Object.entries(manifest.capabilities)) {
      if (current?.package === requirement.packageName) {
        manifest.capabilities[capability] = { ...current, version: requirement.version };
      }
    }
    for (const capability of requirement.capabilities) {
      manifest.capabilities[capability] = { package: requirement.packageName, version: requirement.version };
    }
  }
  return manifest;
}

function conformanceAuditScript(existing, useBaseline) {
  const current = typeof existing === "string" && /^inator audit-ui(?:\s|$)/.test(existing.trim())
    ? existing.trim().replace(/\s+--baseline\s+\S+/g, "")
    : "inator audit-ui";
  return useBaseline ? `${current} --baseline .inator/ui-audit-baseline.json` : current;
}
async function existingManifest(projectDir) {
  try { return await readJson(path.join(projectDir, MANIFEST_FILENAME)); }
  catch { return null; }
}

async function discoverServeEnvironment(projectDir, manifest) {
  const environment = { ...(manifest?.development?.serve?.environment || {}) };
  try {
    const wrapper = await readFile(path.join(projectDir, "bin", "serve"), "utf8");
    for (const match of wrapper.matchAll(/\b(SERVE_[A-Z0-9_]+|PORT)="([^"\n]*)"/g)) {
      const [, name, value] = match;
      if (!value.includes("$") && environment[name] == null) environment[name] = value;
    }
    for (const match of wrapper.matchAll(/\b(SERVE_[A-Z0-9_]+|PORT)="\$\{\1:-([^}"$]*)\}"/g)) {
      const [, name, value] = match;
      if (environment[name] == null) environment[name] = value;
    }
    const legacyPort = wrapper.match(/\blegacy_port="\$\{PORT:-\$\{INATOR_PORT:-([0-9]+)\}\}"/);
    if (legacyPort && environment.PORT == null) environment.PORT = legacyPort[1];
  } catch { /* A missing legacy launcher contributes no inferred environment. */ }
  return Object.fromEntries(Object.entries(environment).sort(([left], [right]) => left.localeCompare(right)));
}

function shellSingleQuote(value) { return `'${String(value).replaceAll("'", `'\\''`)}'`; }

function renderServeWrapper(template, environment) {
  const marker = "  # @inator:serve-environment";
  if (!template.includes(marker)) throw new Error("Consumer launcher template is missing its environment marker.");
  const lines = Object.entries(environment).map(([name, value]) => `serve_environment+=(${shellSingleQuote(`${name}=${value}`)})`);
  return template.replace(marker, lines.length ? lines.join("\n") : "");
}

function preservesProductLauncher(wrapper = "") {
  return wrapper.includes("node_modules/.bin/inator-serve") && wrapper.includes('"$launcher" "$@" --');
}

function uiRulesPath({ projectDir, sourceDir }) {
  const auditsCommonsItself = sourceDir && path.resolve(projectDir) === path.resolve(sourceDir);
  return auditsCommonsItself
    ? path.join(sourceDir, "docs", "standards", "ui-conformance-rules.json")
    : sourceDir
      ? path.join(sourceDir, "packages", "dev-tools", "standards", "ui-conformance-rules.json")
      : path.join(packageRoot, "standards", "ui-conformance-rules.json");
}

async function writeAuditBaseline(projectDir, result, relative = ".inator/ui-audit-baseline.json") {
  const target = path.resolve(projectDir, relative);
  if (!target.startsWith(`${path.resolve(projectDir)}${path.sep}`)) throw new Error("UI audit baseline must stay inside the project.");
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, `${JSON.stringify(createUIAuditBaseline(result.errors), null, 2)}\n`);
  return target;
}

async function requireCapabilities(options) {
  if (!options.capabilities.length) throw new Error("require needs at least one capability.");
  if (!options.sourceDir) throw new Error("require needs --source DIR or INATOR_COMMONS_SOURCE_DIR so it can create immutable artifacts.");
  const projectDir = path.resolve(options.projectDir);
  const sourceDir = path.resolve(options.sourceDir);
  const packageJsonPath = path.join(projectDir, "package.json");
  const packageJson = await readJson(packageJsonPath);
  let manifest = await existingManifest(projectDir);
  const serveEnvironment = await discoverServeEnvironment(projectDir, manifest);
  const productName = manifest?.product?.name || serveEnvironment.SERVE_PROJECT_NAME || packageJson.name || path.basename(projectDir);
  const requirements = requestedRequirements(options.capabilities);
  const versions = [];
  for (const requirement of requirements) {
    const sourcePackage = await readJson(path.join(sourceDir, requirement.packagePath, "package.json"));
    versions.push({ ...requirement, version: sourcePackage.version, artifact: artifactBaseName(requirement.packageName, sourcePackage.version) });
  }

  console.log(`[inator]: ${options.dryRun ? "Would install" : "Installing"} ${options.capabilities.join(", ")} in ${projectDir}`);
  for (const requirement of versions) console.log(`[inator]: ${requirement.packageName} ${requirement.version} -> .inator/packages/${requirement.artifact}`);
  if (options.dryRun) return;

  const snapshot = await snapshotProject(projectDir, [manifest?.information?.manifest]);
  const artifactDir = path.join(projectDir, ".inator", "packages");
  let pendingRollback = "";
  try {
    if (options.acceptAuditBaseline) {
      const baselineResult = await auditUI({ projectDir, rulesPath: uiRulesPath({ projectDir, sourceDir }) });
      await writeAuditBaseline(projectDir, baselineResult);
      console.log(`[inator]: Recorded ${baselineResult.errors.length} pre-existing UI finding${baselineResult.errors.length === 1 ? "" : "s"} for explicit review.`);
    }
    const packed = [];
    for (const requirement of requirements) packed.push(await packRequirement(sourceDir, requirement, artifactDir));

    packageJson.dependencies ||= {};
    packageJson.devDependencies ||= {};
    for (const requirement of packed) {
      delete packageJson.dependencies[requirement.packageName];
      delete packageJson.devDependencies[requirement.packageName];
      packageJson[requirement.dependencyGroup][requirement.packageName] = `file:.inator/packages/${requirement.artifact}`;
    }
    if (!Object.keys(packageJson.dependencies).length) delete packageJson.dependencies;
    if (!Object.keys(packageJson.devDependencies).length) delete packageJson.devDependencies;
    if (requirements.some(({ capabilities }) => capabilities.includes("ui-conformance"))) {
      packageJson.scripts ||= {};
      packageJson.scripts["inator:ui-check"] = conformanceAuditScript(
        packageJson.scripts["inator:ui-check"],
        options.acceptAuditBaseline || snapshot[".inator/ui-audit-baseline.json"] != null
      );
      if (packageJson.scripts.check && !packageJson.scripts.check.includes("inator:ui-check")) packageJson.scripts.check += " && npm run inator:ui-check";
      else if (!packageJson.scripts.check) packageJson.scripts.check = "npm run inator:ui-check";
    }
    await writeFile(packageJsonPath, `${JSON.stringify(packageJson, null, 2)}\n`);

    manifest ||= { capabilities: {} };
    manifest.$schema = MANIFEST_SCHEMA;
    manifest.schemaVersion = 1;
    manifest.product = { ...(manifest.product || {}), name: productName, version: packageJson.version || "0.0.0" };
    synchronizePackageCapabilities(manifest, packed);
    manifest.capabilities = Object.fromEntries(Object.entries(manifest.capabilities).sort(([left], [right]) => left.localeCompare(right)));
    if (options.capabilities.includes("development-serving")) manifest.development = { ...(manifest.development || {}), serve: { environment: serveEnvironment } };
    if (options.capabilities.includes("product-shell")) await ensureProductInformationManifest(projectDir, manifest, productName);
    manifest = {
      $schema: manifest.$schema,
      schemaVersion: manifest.schemaVersion,
      product: manifest.product,
      ...(manifest.development ? { development: manifest.development } : {}),
      ...(manifest.controlRoom ? { controlRoom: manifest.controlRoom } : {}),
      ...(manifest.deploymentProfile ? { deploymentProfile: manifest.deploymentProfile } : {}),
      ...(manifest.information ? { information: manifest.information } : {}),
      ...(manifest.localRequirements ? { localRequirements: manifest.localRequirements } : {}),
      capabilities: manifest.capabilities
    };
    await writeFile(path.join(projectDir, MANIFEST_FILENAME), `${JSON.stringify(manifest, null, 2)}\n`);

    if (options.capabilities.includes("development-serving")) {
      const template = path.join(sourceDir, "packages", "dev-tools", "templates", "consumer", "bin", "serve");
      const commandTemplate = path.join(sourceDir, "packages", "dev-tools", "templates", "consumer", "bin", "inator");
      await mkdir(path.join(projectDir, "bin"), { recursive: true });
      const servePath = path.join(projectDir, "bin", "serve");
      let existingServe = "";
      try { existingServe = await readFile(servePath, "utf8"); } catch { /* A missing launcher is replaced from the shared template. */ }
      if (!preservesProductLauncher(existingServe)) await writeFile(servePath, renderServeWrapper(await readFile(template, "utf8"), serveEnvironment));
      await chmod(path.join(projectDir, "bin", "serve"), 0o755);
      await copyFile(commandTemplate, path.join(projectDir, "bin", "inator"));
      await chmod(path.join(projectDir, "bin", "inator"), 0o755);
    }
    await ensureIgnoredRollback(projectDir);

    runCommand("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: projectDir, label: "Installing pinned Commons artifacts" });
    const diagnosis = await diagnoseProject(projectDir);
    if (!diagnosis.ok) throw new Error(`Installation diagnosis failed:\n${diagnosis.checks.filter(({ ok }) => !ok).map(({ message }) => `- ${message}`).join("\n")}`);
    if (packageJson.scripts?.check) runCommand("npm", ["run", "check"], {
      cwd: projectDir,
      env: projectCommandEnvironment(projectDir),
      label: "Consumer conformance checks"
    });
    pendingRollback = await prepareRollback(projectDir, snapshot);
    await pruneUnreferencedArtifacts(projectDir, packageJson);
    await commitRollback(projectDir, pendingRollback);
    pendingRollback = "";
    console.log(`[inator]: Adoption complete. Review package.json, package-lock.json, inator.json${manifest.information ? `, ${manifest.information.manifest}` : ""}, bin/serve, and .inator/packages/.`);
  } catch (error) {
    await restoreSnapshot(projectDir, snapshot);
    if (pendingRollback) {
      await restoreArchivedArtifacts(projectDir, snapshot, path.join(pendingRollback, "artifacts"));
      await rm(pendingRollback, { recursive: true, force: true });
    }
    runCommand("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: projectDir, label: "Restoring previous installation", allowFailure: true });
    await restoreSnapshot(projectDir, snapshot);
    throw new Error(`Adoption failed and project files were restored. ${error.message}`, { cause: error });
  }
}

async function doctor(options) {
  const diagnosis = await diagnoseProject(options.projectDir);
  if (options.json) console.log(JSON.stringify(diagnosis, null, 2));
  else {
    console.log(`[inator]: ${diagnosis.product} at ${diagnosis.projectDir}`);
    for (const check of diagnosis.checks) console.log(`${check.ok ? "✓" : "✗"} ${check.message}`);
    console.log(diagnosis.ok ? "[inator]: Commons installation is healthy." : "[inator]: Commons installation needs attention.");
  }
  if (!diagnosis.ok) process.exitCode = 1;
}

async function rollback(options) {
  const projectDir = path.resolve(options.projectDir);
  const rollbackFile = path.join(projectDir, ".inator", "rollback", "last.json");
  const archivedArtifacts = path.join(projectDir, ".inator", "rollback", "artifacts");
  const record = await readJson(rollbackFile);
  await restoreSnapshot(projectDir, record.snapshot);
  await restoreArchivedArtifacts(projectDir, record.snapshot, archivedArtifacts);
  runCommand("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: projectDir, label: "Restoring locked dependencies" });
  await restoreSnapshot(projectDir, record.snapshot);
  await restoreArchivedArtifacts(projectDir, record.snapshot, archivedArtifacts);
  await rm(path.dirname(rollbackFile), { recursive: true, force: true });
  console.log(`[inator]: Restored the adoption snapshot from ${record.createdAt}.`);
}

async function auditUICommand(options) {
  const rulesPath = uiRulesPath(options);
  const result = await auditUI({ projectDir: options.projectDir, rulesPath, roots: options.capabilities });
  if (options.writeBaseline) {
    const target = await writeAuditBaseline(options.projectDir, result, options.writeBaseline);
    console.log(`[inator]: Wrote ${result.errors.length} current finding${result.errors.length === 1 ? "" : "s"} to ${target} for review.`);
    return;
  }
  if (options.baseline) {
    const baseline = await readJson(path.resolve(options.projectDir, options.baseline));
    assertCurrentUIAuditBaseline(baseline);
    const reviewed = new Set(baseline.findings);
    result.reviewedErrors = result.errors.filter((finding) => reviewed.has(finding));
    result.resolvedBaselineFindings = baseline.findings.filter((finding) => !result.errors.includes(finding));
    result.errors = result.errors.filter((finding) => !reviewed.has(finding));
  }
  if (options.json) console.log(JSON.stringify(result, null, 2)); else console.log(formatUIAudit(result));
  if (result.reviewedErrors?.length) console.log(`Reviewed UI debt retained: ${result.reviewedErrors.length} finding${result.reviewedErrors.length === 1 ? "" : "s"}.`);
  if (result.errors.length) process.exitCode = 1;
}

async function listServers(options) {
  const running = await discoverServers();
  const selected = options.capabilities.length ? selectServers(running, options.capabilities) : running;
  if (options.json) console.log(JSON.stringify(selected, null, 2));
  else console.log(formatServers(selected));
}

async function stopServerSelection(options) {
  if (options.dryRun) throw new Error("servers stop does not support --dry-run; list targets with inator servers first.");
  if (!options.all && !options.capabilities.length) throw new Error("servers stop needs one or more product, PID, or port selectors, or --all.");
  const running = await discoverServers();
  const selected = selectServers(running, options.capabilities, options.all);
  if (!selected.length) { console.log("No verified Inator development servers are running."); return; }
  const stopped = await stopServers(selected);
  if (options.json) console.log(JSON.stringify({ stopped }, null, 2));
  else for (const server of stopped) console.log(`[inator]: Stopped ${server.product} on port ${server.port} (PID ${server.pid}).`);
}

async function contextCommand(options) {
  const { manifest } = await readAgentContextManifest(options.projectDir);
  const query = options.capabilities.join(" ");
  const entries = selectContextRoutes(manifest, query);
  if (!entries.length) throw new Error(`No context route matches ${JSON.stringify(query)}.`);
  if (options.json) console.log(JSON.stringify({ schema: manifest.schema, product: manifest.product, topics: Object.fromEntries(entries) }, null, 2));
  else console.log(formatContextRoutes(entries));
}

async function auditAgentContextCommand(options) {
  const result = await auditAgentContext(options.projectDir);
  if (options.json) console.log(JSON.stringify(result, null, 2));
  else console.log(formatAgentContextAudit(result));
  if (!result.ok) process.exitCode = 1;
}

async function configureCodex(options) {
  const { manifest } = await readAgentContextManifest(options.projectDir);
  if (!manifest.codexProfiles?.length) throw new Error("inator.context.json must declare codexProfiles before configuration is generated.");
  const target = path.join(options.projectDir, ".codex", "config.toml");
  const rendered = renderLeanCodexConfig(manifest.codexProfiles);
  if (options.dryRun) { process.stdout.write(rendered); return; }
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, rendered);
  console.log(`[inator]: Wrote ${path.relative(options.projectDir, target)} from ${manifest.codexProfiles.join(" + ")}.`);
}

async function verifyGreenfield(options) {
  const relative = options.evidence || "evidence/greenfield-acceptance.json";
  const target = path.resolve(options.projectDir, relative);
  if (!target.startsWith(`${path.resolve(options.projectDir)}${path.sep}`)) throw new Error("Greenfield acceptance evidence must stay inside the project.");
  const report = JSON.parse(await readFile(target, "utf8"));
  const result = evaluateGreenfieldAcceptance(report);
  if (options.json) console.log(JSON.stringify(result, null, 2));
  else console.log(formatGreenfieldAcceptance(result));
  if (!result.ok) process.exitCode = 1;
}

async function createProject(options) {
  const [briefFile, destination] = options.capabilities;
  if (!briefFile || !destination) throw new Error("create requires BRIEF and DESTINATION.");
  const brief = JSON.parse(await readFile(path.resolve(options.projectDir, briefFile), "utf8"));
  const commonsPath = options.sourceDir || path.resolve(packageRoot, "../..");
  const result = await createVerifiedProject({
    brief,
    destination: path.resolve(options.projectDir, destination),
    commonsPath,
    verify: async generated => requireCapabilities({
      ...options,
      projectDir: generated.target,
      sourceDir: commonsPath,
      capabilities: generated.brief.capabilities,
      acceptAuditBaseline: false
    })
  });
  if (options.json) console.log(JSON.stringify(result, null, 2));
  else console.log(`[inator]: Created and functionally verified ${result.brief.product.name} at ${result.target}.`);
}

function gitValue(projectDir, arguments_, fallback) {
  const result = runCommand("git", arguments_, { cwd: projectDir, capture: true, allowFailure: true });
  return result.status === 0 && result.stdout.trim() ? result.stdout.trim() : fallback;
}

async function prepareAdversary(options) {
  const targetDir = options.targetDir || options.projectDir;
  const revision = gitValue(targetDir, ["rev-parse", "HEAD"], `unversioned-${Date.now()}`);
  const dirty = Boolean(gitValue(targetDir, ["status", "--porcelain"], ""));
  const repository = path.basename(targetDir);
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const packet = createAdversarialAssayPacket({
    id: `${repository}-${stamp}`,
    repository: targetDir,
    revision,
    dirty,
    included: options.scopes.length ? options.scopes : ["The built product, its governing Commons contracts, and the evidence used to claim conformance."],
    excluded: ["Private user data", "Destructive changes", "External writes or publication"],
    stopConditions: ["Stop before exposing private data, causing irreversible loss, or producing unauthorized external side effects."],
    claims: options.claims.length ? options.claims : ["The artifact behaves as a coherent standard Inator and its current evidence truthfully proves the claimed contracts."],
    roles: options.capabilities.length ? options.capabilities : undefined,
    contextRefs: ["docs/standards/adversarial-development.md", "docs/guides/inator-visual-assay.md"],
    obligationRefs: options.obligationRefs
  });
  const result = await writeAdversarialAssayPacket({ projectDir: options.projectDir, packet, outputDir: options.output });
  if (options.json) console.log(JSON.stringify({ packet, output: result }, null, 2));
  else {
    console.log(`[inator]: Prepared blind ${packet.option} ${packet.mode} packet ${packet.id}.`);
    console.log(`[inator]: Artifact ${packet.artifact.revision}${packet.artifact.dirty ? " with declared dirty state" : ""}.`);
    console.log(`[inator]: Packet: ${result.packet}`);
    for (const [index, critic] of packet.critics.entries()) console.log(`[inator]: ${critic.role}: ${result.prompts[index]}`);
    if (revision.startsWith("unversioned-")) console.log("[inator]: Warning: target is not a Git revision; capture a build digest before treating dynamic evidence as immutable.");
  }
}

async function collectAdversary(options) {
  const directory = options.capabilities[0];
  if (!directory || options.capabilities.length !== 1) throw new Error("adversary collect requires exactly one packet DIRECTORY.");
  const packetDir = path.resolve(options.projectDir, directory);
  const projectRoot = path.resolve(options.projectDir);
  if (packetDir !== projectRoot && !packetDir.startsWith(`${projectRoot}${path.sep}`)) throw new Error("Adversarial packet directory must stay inside the project.");
  const result = await collectAdversarialAssay({ packetDir, outputFile: options.output || "collection.json" });
  if (options.json) console.log(JSON.stringify(result.manifest, null, 2));
  else {
    const { summary } = result.manifest;
    console.log(`[inator]: Collected ${summary.collectedReports}/${summary.expectedReports} raw reports with ${summary.findings} explicitly structured findings.`);
    console.log(`[inator]: Coverage gaps: ${summary.missingReports} missing reports; ${summary.unownedDeferrals}/${summary.deferrals} deferral records unowned.`);
    console.log(`[inator]: Manifest: ${result.output}`);
  }
  if (!result.ok) process.exitCode = 1;
}

async function prepareFailureFixtures(options) {
  if (!options.targetDir) throw new Error("adversary fixtures requires an explicit --target artifact directory.");
  if (options.output) throw new Error("adversary fixtures always uses an operating-system temporary directory; --output is not allowed.");
  const result = await prepareAdversarialFixtures({ sourceDir: options.targetDir, fixtures: options.capabilities });
  if (options.json) console.log(JSON.stringify(result.value, null, 2));
  else {
    console.log(`[inator]: Prepared ${result.value.fixtures.length} inert failure fixtures in disposable workspace ${result.workspace}.`);
    console.log(`[inator]: Copied artifact: ${result.artifact}`);
    console.log(`[inator]: Manifest: ${result.manifest}`);
    console.log(`[inator]: Available fixtures: ${Object.keys(ADVERSARIAL_FIXTURES).join(", ")}`);
  }
}

export async function run(arguments_) {
  const { command, options } = parse(arguments_);
  if (options.help || command === "help") { console.log(usage()); return; }
  if (command === "servers" && options.subcommand === "list") return listServers(options);
  if (command === "servers" && options.subcommand === "stop") return stopServerSelection(options);
  if (command === "servers" && options.subcommand === "install") throw new Error("servers install is reserved for future operating-system service installation; it is not implemented yet.");
  if (command === "doctor") return doctor(options);
  if (command === "context") return contextCommand(options);
  if (command === "audit-agent-context") return auditAgentContextCommand(options);
  if (command === "configure-codex") return configureCodex(options);
  if (command === "require") return requireCapabilities(options);
  if (command === "rollback") return rollback(options);
  if (command === "audit-ui") return auditUICommand(options);
  if (command === "create") return createProject(options);
  if (command === "verify-greenfield") return verifyGreenfield(options);
  if (command === "adversary" && options.subcommand === "prepare") return prepareAdversary(options);
  if (command === "adversary" && options.subcommand === "collect") return collectAdversary(options);
  if (command === "adversary" && options.subcommand === "fixtures") return prepareFailureFixtures(options);
  throw new Error(`Unknown command ${command}.\n\n${usage()}`);
}

export { conformanceAuditScript, discoverServeEnvironment, parse, preservesProductLauncher, projectCommandEnvironment, renderServeWrapper, requestedRequirements, synchronizePackageCapabilities };
