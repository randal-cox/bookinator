export const TEST_RISK_TRIAGE_SCHEMA = "inator.test-risk-triage.v1";

const CATEGORY_ORDER = Object.freeze([
  "essential-now",
  "essential-hard",
  "important-next",
  "cheap-confidence",
  "low-marginal-value",
  "unassessable"
]);

function bounded(value, min = 0, max = 5) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(min, Math.min(max, number)) : null;
}

export function triageTestTarget(target) {
  if (!target?.id) throw new TypeError("A test-risk target requires an id.");
  const impact = bounded(target.impact);
  const exposure = bounded(target.exposure);
  const change = bounded(target.change);
  const structural = bounded(target.structural);
  const evidenceGap = bounded(target.evidenceGap);
  const difficulty = bounded(target.difficulty);
  const observability = bounded(target.observability);
  const supplied = { impact, exposure, change, structural, evidenceGap, difficulty, observability };
  const unknowns = Object.entries(supplied).filter(([, value]) => value === null).map(([key]) => key);
  const reasons = Array.isArray(target.reasons) ? [...target.reasons] : [];
  if (unknowns.length >= 3) return { ...target, schema: TEST_RISK_TRIAGE_SCHEMA, category: "unassessable", unknowns, reasons: [...reasons, `Missing ${unknowns.join(", ")}.`], dimensions: supplied };

  const known = (value) => value ?? 2.5;
  const consequence = known(impact) + known(exposure);
  const likelihood = known(change) + known(structural);
  const need = consequence + likelihood + known(evidenceGap);
  let category;
  if (need >= 18 && known(difficulty) >= 4) category = "essential-hard";
  else if (need >= 16) category = "essential-now";
  else if (need >= 11) category = "important-next";
  else if (known(difficulty) <= 2 && known(evidenceGap) >= 2) category = "cheap-confidence";
  else category = "low-marginal-value";
  return {
    ...target,
    schema: TEST_RISK_TRIAGE_SCHEMA,
    category,
    categoryRank: CATEGORY_ORDER.indexOf(category),
    unknowns,
    dimensions: supplied,
    rationale: { consequence, likelihood, need, difficulty: known(difficulty), observability: known(observability) },
    reasons
  };
}

export function triageTestTargets(targets) {
  if (!Array.isArray(targets)) throw new TypeError("Test-risk targets must be an array.");
  const results = targets.map(triageTestTarget).sort((left, right) => left.categoryRank - right.categoryRank || (right.rationale?.need || 0) - (left.rationale?.need || 0) || left.id.localeCompare(right.id));
  return Object.freeze({
    schema: TEST_RISK_TRIAGE_SCHEMA,
    generatedAt: new Date().toISOString(),
    targets: results,
    counts: Object.fromEntries(CATEGORY_ORDER.map((category) => [category, results.filter((target) => target.category === category).length])),
    interpretation: "Categories preserve dimensions, reasons, and unknowns. They are queues for adversarial review, not a claim that testing is sufficient."
  });
}
