# @inator/dev-tools

The installable development-tooling boundary for Inator applications.

It provides:

- `inator-serve`, the shared deterministic local launcher;
- `inator servers`, a verified inventory of running Inator development servers;
- `inator servers stop PRODUCT...` and `inator servers stop --all`, guarded
  normal shutdowns that re-check PID, port, and project root before signaling;
- `inator doctor`, a read-only consumer installation diagnosis;
- `inator context [TOPIC]`, bounded navigation to authoritative project
  evidence without loading an entire code map or documentation tree;
- `inator audit-agent-context`, deterministic validation of context routes,
  their evidence targets, standards coverage, and the agent entry point;
- `inator configure-codex`, explicit generation of the lean project-scoped
  Codex configuration declared by `codexProfiles` in `inator.context.json`;
- `inator require`, deliberate capability adoption with pinned artifacts and
  conformance checks; and
- `inator rollback`, restoration of the most recent adoption snapshot;
- `inator audit-ui [ROOT...]`, the package-owned standards-smell audit across
  default or explicit product source roots; and
- `@inator/dev-tools/deployment-profile`, the non-operative Common Ground
  deployment-inventory validator used by `inator doctor`.

Commons packages are packed into the consumer's
`.inator/packages/` directory. The consumer therefore remains installable from
a clean clone without a sibling Commons checkout or a live package registry.
The manifest records capabilities; npm records the deduplicated packages that
provide them.

Products that embed Vite in their own HTTP server must pass that server as
`httpServer` when creating the middleware options:

```js
const server = createServer(handleRequest);
const vite = await createViteServer(viteMiddlewareOptions({ httpServer: server }));
```

This mounts Vite's hot-reload connection on the product server. It prevents
multiple simultaneously running Inators from competing for Vite's fallback
port while preserving live reload for each product.

Projects with the `development-serving` capability receive thin `bin/serve`
and `bin/inator` wrappers. From any such checkout:

```sh
./bin/inator servers
./bin/inator servers list
./bin/inator servers stop fboe.inator rho.inator
./bin/inator servers stop --all
```

Only listeners registered by the shared launcher and still verified against
their PID, port, project root, and `bin/serve` are eligible. Unregistered or
ambiguous listeners are omitted rather than guessed at. Shutdown uses `SIGTERM`
and never escalates to a force kill.
