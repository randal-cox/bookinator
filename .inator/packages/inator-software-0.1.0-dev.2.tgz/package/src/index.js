export const SOFTWARE_INVENTORY_VERSION = "inator-software-inventory.0.1-draft";
export const LOCAL_REQUIREMENTS_VERSION = "inator-local-requirements.0.1-draft";
export const SOFTWARE_STATES = Object.freeze(["unknown", "missing", "available", "installing", "installed", "stopped", "running", "failed"]);
export const LOCAL_REQUIREMENT_KINDS = Object.freeze(["native-package", "command", "runtime", "python-package", "service", "model-provider", "model", "library"]);

const required = (value, label) => { const text = String(value || "").trim(); if (!text) throw new TypeError(`${label} is required.`); return text; };
const object = (value, label) => { if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object.`); return value; };
const timestamp = (value, label) => { const text = required(value, label); if (Number.isNaN(Date.parse(text))) throw new TypeError(`${label} must be an ISO timestamp.`); return text; };

function defineRequirementProfile(source) {
  const value = object(source, "Local requirement profile");
  return Object.freeze({
    id: required(value.id, "profile id"),
    label: String(value.label || value.id),
    execution: required(value.execution, "profile execution"),
    publication: required(value.publication, "profile publication"),
    description: String(value.description || "")
  });
}

function defineLocalRequirement(source, profileIds) {
  const value = object(source, "Local requirement");
  const kind = required(value.kind, "requirement kind");
  if (!LOCAL_REQUIREMENT_KINDS.includes(kind)) throw new TypeError(`Unknown local requirement kind ${kind}.`);
  const profiles = [...new Set((value.profiles || []).map(String))];
  if (!profiles.length) throw new TypeError(`Local requirement ${value.id || "unknown"} must name at least one profile.`);
  for (const profile of profiles) if (!profileIds.has(profile)) throw new TypeError(`Local requirement ${value.id || "unknown"} names unknown profile ${profile}.`);
  return Object.freeze({
    id: required(value.id, "requirement id"), label: String(value.label || value.id), kind,
    profiles: Object.freeze(profiles), required: value.required !== false,
    provider: value.provider == null ? null : String(value.provider),
    version: value.version == null ? null : String(value.version),
    command: value.command == null ? null : String(value.command),
    package: value.package == null ? null : String(value.package),
    capabilities: Object.freeze([...new Set((value.capabilities || []).map(String))]),
    purpose: String(value.purpose || ""),
    install: value.install ? Object.freeze({ strategy: required(value.install.strategy, "install strategy"), approval: String(value.install.approval || "required") }) : null
  });
}

export function defineLocalRequirementsManifest(source) {
  const value = object(source, "Local requirements manifest");
  const profiles = (value.profiles || []).map(defineRequirementProfile);
  const profileIds = new Set(profiles.map(({ id }) => id));
  if (!profiles.length) throw new TypeError("Local requirements manifest requires at least one profile.");
  if (profileIds.size !== profiles.length) throw new TypeError("Local requirement profile ids must be unique.");
  const requirements = (value.requirements || []).map((item) => defineLocalRequirement(item, profileIds));
  if (new Set(requirements.map(({ id }) => id)).size !== requirements.length) throw new TypeError("Local requirement ids must be unique.");
  return Object.freeze({ schemaVersion: LOCAL_REQUIREMENTS_VERSION, productId: required(value.productId, "product id"), profiles: Object.freeze(profiles), requirements: Object.freeze(requirements) });
}

export function requirementsForProfile(manifestSource, profileId) {
  const manifest = defineLocalRequirementsManifest(manifestSource);
  const profile = manifest.profiles.find(({ id }) => id === profileId);
  if (!profile) throw new TypeError(`Unknown local requirement profile ${profileId}.`);
  return Object.freeze({ ...profile, productId: manifest.productId, requirements: Object.freeze(manifest.requirements.filter((item) => item.profiles.includes(profileId))) });
}

export function defineSoftwareProvider(source) {
  const value = object(source, "Software provider");
  for (const field of ["hostname", "username", "homeDirectory", "absolutePath", "pid"]) if (Object.hasOwn(value, field)) throw new TypeError(`Software provider must not expose ${field}.`);
  return Object.freeze({
    id: required(value.id, "provider id"),
    label: String(value.label || value.id),
    kind: String(value.kind || "system"),
    operations: Object.freeze([...new Set((value.operations || ["observe"]).map(String))])
  });
}

export function defineSoftwareRecord(source) {
  const value = object(source, "Software record");
  const state = SOFTWARE_STATES.includes(value.state) ? value.state : "unknown";
  return Object.freeze({
    id: required(value.id, "software id"), providerId: required(value.providerId, "software providerId"),
    label: String(value.label || value.id), kind: String(value.kind || "runtime"),
    version: value.version == null ? null : String(value.version), state,
    command: value.command == null ? null : String(value.command),
    capabilities: Object.freeze([...new Set((value.capabilities || []).map(String))]),
    evidence: Object.freeze((value.evidence || []).map((entry) => Object.freeze({ kind: required(entry.kind, "evidence kind"), summary: required(entry.summary, "evidence summary") }))),
    observedAt: value.observedAt ? timestamp(value.observedAt, "software observedAt") : null,
    failure: value.failure ? Object.freeze({ code: String(value.failure.code || "unknown"), message: required(value.failure.message, "failure message"), occurredAt: timestamp(value.failure.occurredAt, "failure occurredAt") }) : null
  });
}

export function defineSoftwareInventory(source = {}) {
  const value = object(source, "Software inventory");
  const providers = (value.providers || []).map(defineSoftwareProvider);
  const providerIds = new Set(providers.map(({ id }) => id));
  if (providerIds.size !== providers.length) throw new TypeError("Software inventory provider ids must be unique.");
  const records = (value.records || []).map(defineSoftwareRecord);
  if (new Set(records.map(({ id }) => id)).size !== records.length) throw new TypeError("Software inventory record ids must be unique.");
  for (const record of records) if (!providerIds.has(record.providerId)) throw new TypeError(`Software record ${record.id} names unknown provider ${record.providerId}.`);
  return Object.freeze({ schemaVersion: SOFTWARE_INVENTORY_VERSION, revision: Math.max(0, Number(value.revision) || 0), observedAt: timestamp(value.observedAt || new Date().toISOString(), "inventory observedAt"), providers: Object.freeze(providers), records: Object.freeze(records) });
}

export function reduceSoftwareInventory(inventorySource, event, { now = () => new Date() } = {}) {
  const inventory = defineSoftwareInventory(inventorySource); const action = object(event, "Software inventory event");
  const id = required(action.id, "software event id"); const current = inventory.records.find((record) => record.id === id);
  if (!current && action.type !== "observed") throw new TypeError(`Software event ${action.type} requires an observed record.`);
  let next;
  if (action.type === "observed") next = defineSoftwareRecord({ ...current, ...action.record, id, observedAt: action.record?.observedAt || now().toISOString(), failure: action.record?.failure ?? null });
  else if (action.type === "install-started") next = defineSoftwareRecord({ ...current, state: "installing", failure: null });
  else if (action.type === "install-failed") next = defineSoftwareRecord({ ...current, state: "failed", failure: { code: action.code || "install-failed", message: required(action.message, "failure message"), occurredAt: action.occurredAt || now().toISOString() } });
  else if (action.type === "removed") next = defineSoftwareRecord({ ...current, state: "missing", version: null, failure: null, observedAt: now().toISOString() });
  else throw new TypeError(`Unknown software inventory event ${action.type}.`);
  const records = inventory.records.filter((record) => record.id !== id); records.push(next);
  return defineSoftwareInventory({ ...inventory, revision: inventory.revision + 1, observedAt: now().toISOString(), records });
}

export function createSoftwareInventoryStore({ load, save, initial = { providers: [], records: [] }, now = () => new Date() } = {}) {
  if (typeof save !== "function") throw new TypeError("Software inventory store requires save.");
  let state = null;
  const read = async () => state ||= defineSoftwareInventory(typeof load === "function" ? await load() || initial : initial);
  return Object.freeze({
    async snapshot() { return read(); },
    async dispatch(event) { state = reduceSoftwareInventory(await read(), event, { now }); await save(state); return state; }
  });
}
