import { createHash } from "node:crypto";
import { chmod, copyFile, mkdir, mkdtemp, readFile, readdir, rename, rm, stat, writeFile } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { CAPABILITY_CATALOG, diagnoseProject, MANIFEST_FILENAME, MANIFEST_SCHEMA, readJson } from "./manifest.mjs";
import { discoverServers, formatServers, selectServers, stopServers } from "./server-control.mjs";
import { assertCurrentUIAuditBaseline, auditUI, createUIAuditBaseline, formatUIAudit } from "./ui-audit.mjs";

const packageRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

function usage() {
  return `Usage: inator <command> [options]\n\nCommands:\n  servers [list] [SELECTOR...]       List verified running Inator development servers\n  servers stop SELECTOR...           Stop servers by product, PID, or port\n  servers stop --all                 Stop every verified Inator development server\n  doctor                             Diagnose a consumer installation without changing it\n  require CAPABILITY...              Install exact packages for requested capabilities\n  rollback                           Restore the snapshot before the last adoption\n  audit-ui [ROOT...]                 Audit default or explicit product source roots\n\nOptions:\n  --all                     Select every verified server (servers stop only)\n  --project DIR             Consumer directory (default: invoking project)\n  --source DIR              Inator Commons source checkout for require\n  --accept-audit-baseline   Record current UI findings during explicit adoption\n  --baseline FILE           Compare UI findings with a reviewed baseline\n  --write-baseline FILE     Write current UI findings for review\n  --dry-run                 Print the adoption plan without changing files\n  --json                    Emit machine-readable output where supported\n  -h, --help                Show this help\n`;
}

function parse(arguments_) {
  const values = [...arguments_];
  const command = values.shift() || "help";
  let subcommand = null;
  if (command === "servers") {
    if (["list", "stop", "install"].includes(values[0])) subcommand = values.shift();
    else subcommand = "list";
  }
  const options = { projectDir: path.resolve(process.env.INATOR_PROJECT_DIR || process.cwd()), sourceDir: process.env.INATOR_COMMONS_SOURCE_DIR || "", dryRun: false, json: false, all: false, acceptAuditBaseline: false, baseline: "", writeBaseline: "", capabilities: [], subcommand };
  for (let index = 0; index < values.length; index += 1) {
    const argument = values[index];
    const next = () => {
      const value = values[index + 1];
      if (!value) throw new Error(`${argument} requires a value.`);
      index += 1;
      return value;
    };
    if (argument === "--project") options.projectDir = path.resolve(next());
    else if (argument === "--source") options.sourceDir = path.resolve(next());
    else if (argument === "--accept-audit-baseline") options.acceptAuditBaseline = true;
    else if (argument === "--baseline") options.baseline = next();
    else if (argument === "--write-baseline") options.writeBaseline = next();
    else if (argument === "--dry-run") options.dryRun = true;
    else if (argument === "--json") options.json = true;
    else if (argument === "--all") options.all = true;
    else if (argument === "-h" || argument === "--help") options.help = true;
    else if (argument.startsWith("-")) throw new Error(`Unknown option ${argument}.`);
    else options.capabilities.push(argument);
  }
  return { command, options };
}

function runCommand(command, arguments_, { cwd, label, allowFailure = false, capture = false } = {}) {
  const result = spawnSync(command, arguments_, { cwd, encoding: "utf8", stdio: label || capture ? ["inherit", "pipe", "pipe"] : "inherit" });
  if (label && result.stdout?.trim()) process.stdout.write(`${result.stdout.trimEnd()}\n`);
  if (label && result.stderr?.trim()) process.stderr.write(`${result.stderr.trimEnd()}\n`);
  if (result.error) throw result.error;
  if (!allowFailure && result.status !== 0) throw new Error(`${label || command} failed with status ${result.status}.`);
  return result;
}

function artifactBaseName(packageName, version) {
  return `${packageName.replace(/^@/, "").replaceAll("/", "-")}-${version}.tgz`;
}

async function snapshotProject(projectDir) {
  const files = ["package.json", "package-lock.json", MANIFEST_FILENAME, ".gitignore", ".inator/ui-audit-baseline.json", "bin/serve", "bin/inator"];
  const values = {};
  for (const relative of files) {
    try { values[relative] = await readFile(path.join(projectDir, relative), "utf8"); }
    catch { values[relative] = null; }
  }
  const packagesDir = path.join(projectDir, ".inator", "packages");
  try { values.__artifacts = await readdir(packagesDir); }
  catch { values.__artifacts = []; }
  return values;
}

async function restoreSnapshot(projectDir, snapshot) {
  for (const [relative, contents] of Object.entries(snapshot)) {
    if (relative === "__artifacts") continue;
    const target = path.join(projectDir, relative);
    if (contents == null) await rm(target, { force: true });
    else {
      await mkdir(path.dirname(target), { recursive: true });
      await writeFile(target, contents);
    }
  }
  const packagesDir = path.join(projectDir, ".inator", "packages");
  let artifacts = [];
  try { artifacts = await readdir(packagesDir); } catch {}
  for (const artifact of artifacts) if (!snapshot.__artifacts.includes(artifact)) await rm(path.join(packagesDir, artifact), { force: true });
}

async function prepareRollback(projectDir, snapshot) {
  const rollbackDir = path.join(projectDir, ".inator", "rollback");
  const pendingDir = path.join(rollbackDir, "pending");
  const archivedArtifacts = path.join(pendingDir, "artifacts");
  await rm(pendingDir, { recursive: true, force: true });
  await mkdir(archivedArtifacts, { recursive: true });
  for (const artifact of snapshot.__artifacts) {
    await copyFile(path.join(projectDir, ".inator", "packages", artifact), path.join(archivedArtifacts, artifact));
  }
  await writeFile(path.join(pendingDir, "last.json"), `${JSON.stringify({ createdAt: new Date().toISOString(), snapshot }, null, 2)}\n`);
  return pendingDir;
}

async function commitRollback(projectDir, pendingDir) {
  const rollbackDir = path.dirname(pendingDir);
  await rm(path.join(rollbackDir, "artifacts"), { recursive: true, force: true });
  await rm(path.join(rollbackDir, "last.json"), { force: true });
  await rename(path.join(pendingDir, "artifacts"), path.join(rollbackDir, "artifacts"));
  await rename(path.join(pendingDir, "last.json"), path.join(rollbackDir, "last.json"));
  await rm(pendingDir, { recursive: true, force: true });
}

async function restoreArchivedArtifacts(projectDir, snapshot, archiveDir) {
  const packagesDir = path.join(projectDir, ".inator", "packages");
  await mkdir(packagesDir, { recursive: true });
  for (const artifact of snapshot.__artifacts) {
    await copyFile(path.join(archiveDir, artifact), path.join(packagesDir, artifact));
  }
}

async function pruneUnreferencedArtifacts(projectDir, packageJson) {
  const packagesDir = path.join(projectDir, ".inator", "packages");
  const specifications = { ...(packageJson.dependencies || {}), ...(packageJson.devDependencies || {}) };
  const retained = new Set(Object.values(specifications)
    .filter((value) => typeof value === "string" && value.startsWith("file:.inator/packages/"))
    .map((value) => path.basename(value.slice("file:".length))));
  for (const artifact of await readdir(packagesDir)) {
    if (artifact.endsWith(".tgz") && !retained.has(artifact)) await rm(path.join(packagesDir, artifact));
  }
}

async function ensureIgnoredRollback(projectDir) {
  const file = path.join(projectDir, ".gitignore");
  let value = "";
  try { value = await readFile(file, "utf8"); } catch {}
  if (!value.split(/\r?\n/).includes(".inator/rollback/")) {
    if (value && !value.endsWith("\n")) value += "\n";
    value += ".inator/rollback/\n";
    await writeFile(file, value);
  }
}

async function packRequirement(sourceDir, requirement, artifactDir) {
  const sourcePackage = path.join(sourceDir, requirement.packagePath);
  const packageJson = await readJson(path.join(sourcePackage, "package.json"));
  await mkdir(artifactDir, { recursive: true });
  const stagingDir = await mkdtemp(path.join(os.tmpdir(), "inator-pack-"));
  try {
    const result = runCommand("npm", ["pack", sourcePackage, "--json", "--pack-destination", stagingDir, "--cache", path.join(os.tmpdir(), "inator-npm-cache")], { cwd: sourceDir, capture: true });
    const packed = JSON.parse(result.stdout);
    if (packed.length !== 1) throw new Error(`Packing ${requirement.packageName} produced ${packed.length} artifacts.`);
    const metadata = packed[0];
    if (metadata.name !== packageJson.name || metadata.version !== packageJson.version) {
      throw new Error(`Packed artifact identity does not match ${packageJson.name} ${packageJson.version}.`);
    }
    if (!metadata.integrity || !metadata.files?.some(({ path: file }) => file === "package.json")) {
      throw new Error(`Packed artifact for ${packageJson.name} is missing integrity or package metadata.`);
    }
    const produced = path.join(stagingDir, metadata.filename);
    const targetName = artifactBaseName(requirement.packageName, packageJson.version);
    const target = path.join(artifactDir, targetName);
    let existingIntegrity = "";
    try {
      const existing = await readFile(target);
      existingIntegrity = `sha512-${createHash("sha512").update(existing).digest("base64")}`;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    if (existingIntegrity && existingIntegrity !== metadata.integrity) {
      throw new Error(`${targetName} already exists with different bytes. Bump ${packageJson.name}'s version before repacking it.`);
    }
    if (!existingIntegrity) await copyFile(produced, target);
    if ((await stat(target)).size < 1) throw new Error(`Packed artifact ${targetName} is empty.`);
    return { ...requirement, version: packageJson.version, artifact: targetName };
  } finally {
    await rm(stagingDir, { recursive: true, force: true });
  }
}

function requestedRequirements(capabilities) {
  const requirements = new Map();
  for (const capability of capabilities) {
    const definition = CAPABILITY_CATALOG[capability];
    if (!definition) throw new Error(`Unknown capability ${capability}. Available capabilities: ${Object.keys(CAPABILITY_CATALOG).join(", ")}.`);
    if (!requirements.has(definition.packageName)) requirements.set(definition.packageName, { ...definition, capabilities: [] });
    requirements.get(definition.packageName).capabilities.push(capability);
  }
  return [...requirements.values()];
}

function synchronizePackageCapabilities(manifest, packedRequirements) {
  manifest.capabilities ||= {};
  for (const requirement of packedRequirements) {
    for (const [capability, current] of Object.entries(manifest.capabilities)) {
      if (current?.package === requirement.packageName) {
        manifest.capabilities[capability] = { ...current, version: requirement.version };
      }
    }
    for (const capability of requirement.capabilities) {
      manifest.capabilities[capability] = { package: requirement.packageName, version: requirement.version };
    }
  }
  return manifest;
}
async function existingManifest(projectDir) {
  try { return await readJson(path.join(projectDir, MANIFEST_FILENAME)); }
  catch { return null; }
}

async function discoverServeEnvironment(projectDir, manifest) {
  const environment = { ...(manifest?.development?.serve?.environment || {}) };
  try {
    const wrapper = await readFile(path.join(projectDir, "bin", "serve"), "utf8");
    for (const match of wrapper.matchAll(/\b(SERVE_[A-Z0-9_]+|PORT)="([^"\n]*)"/g)) {
      const [, name, value] = match;
      if (!value.includes("$") && environment[name] == null) environment[name] = value;
    }
    for (const match of wrapper.matchAll(/\b(SERVE_[A-Z0-9_]+|PORT)="\$\{\1:-([^}"$]*)\}"/g)) {
      const [, name, value] = match;
      if (environment[name] == null) environment[name] = value;
    }
    const legacyPort = wrapper.match(/\blegacy_port="\$\{PORT:-\$\{INATOR_PORT:-([0-9]+)\}\}"/);
    if (legacyPort && environment.PORT == null) environment.PORT = legacyPort[1];
  } catch {}
  return Object.fromEntries(Object.entries(environment).sort(([left], [right]) => left.localeCompare(right)));
}

function shellSingleQuote(value) { return `'${String(value).replaceAll("'", `'\\''`)}'`; }

function renderServeWrapper(template, environment) {
  const marker = "  # @inator:serve-environment";
  if (!template.includes(marker)) throw new Error("Consumer launcher template is missing its environment marker.");
  const lines = Object.entries(environment).map(([name, value]) => `serve_environment+=(${shellSingleQuote(`${name}=${value}`)})`);
  return template.replace(marker, lines.length ? lines.join("\n") : "");
}

function uiRulesPath({ projectDir, sourceDir }) {
  const auditsCommonsItself = sourceDir && path.resolve(projectDir) === path.resolve(sourceDir);
  return auditsCommonsItself
    ? path.join(sourceDir, "docs", "standards", "ui-conformance-rules.json")
    : sourceDir
      ? path.join(sourceDir, "packages", "dev-tools", "standards", "ui-conformance-rules.json")
      : path.join(packageRoot, "standards", "ui-conformance-rules.json");
}

async function writeAuditBaseline(projectDir, result, relative = ".inator/ui-audit-baseline.json") {
  const target = path.resolve(projectDir, relative);
  if (!target.startsWith(`${path.resolve(projectDir)}${path.sep}`)) throw new Error("UI audit baseline must stay inside the project.");
  await mkdir(path.dirname(target), { recursive: true });
  await writeFile(target, `${JSON.stringify(createUIAuditBaseline(result.errors), null, 2)}\n`);
  return target;
}

async function requireCapabilities(options) {
  if (!options.capabilities.length) throw new Error("require needs at least one capability.");
  if (!options.sourceDir) throw new Error("require needs --source DIR or INATOR_COMMONS_SOURCE_DIR so it can create immutable artifacts.");
  const projectDir = path.resolve(options.projectDir);
  const sourceDir = path.resolve(options.sourceDir);
  const packageJsonPath = path.join(projectDir, "package.json");
  const packageJson = await readJson(packageJsonPath);
  let manifest = await existingManifest(projectDir);
  const serveEnvironment = await discoverServeEnvironment(projectDir, manifest);
  const productName = manifest?.product?.name || serveEnvironment.SERVE_PROJECT_NAME || packageJson.name || path.basename(projectDir);
  const requirements = requestedRequirements(options.capabilities);
  const versions = [];
  for (const requirement of requirements) {
    const sourcePackage = await readJson(path.join(sourceDir, requirement.packagePath, "package.json"));
    versions.push({ ...requirement, version: sourcePackage.version, artifact: artifactBaseName(requirement.packageName, sourcePackage.version) });
  }

  console.log(`[inator]: ${options.dryRun ? "Would install" : "Installing"} ${options.capabilities.join(", ")} in ${projectDir}`);
  for (const requirement of versions) console.log(`[inator]: ${requirement.packageName} ${requirement.version} -> .inator/packages/${requirement.artifact}`);
  if (options.dryRun) return;

  const snapshot = await snapshotProject(projectDir);
  const artifactDir = path.join(projectDir, ".inator", "packages");
  let pendingRollback = "";
  try {
    if (options.acceptAuditBaseline) {
      const baselineResult = await auditUI({ projectDir, rulesPath: uiRulesPath({ projectDir, sourceDir }) });
      await writeAuditBaseline(projectDir, baselineResult);
      console.log(`[inator]: Recorded ${baselineResult.errors.length} pre-existing UI finding${baselineResult.errors.length === 1 ? "" : "s"} for explicit review.`);
    }
    const packed = [];
    for (const requirement of requirements) packed.push(await packRequirement(sourceDir, requirement, artifactDir));

    packageJson.dependencies ||= {};
    packageJson.devDependencies ||= {};
    for (const requirement of packed) {
      delete packageJson.dependencies[requirement.packageName];
      delete packageJson.devDependencies[requirement.packageName];
      packageJson[requirement.dependencyGroup][requirement.packageName] = `file:.inator/packages/${requirement.artifact}`;
    }
    if (!Object.keys(packageJson.dependencies).length) delete packageJson.dependencies;
    if (!Object.keys(packageJson.devDependencies).length) delete packageJson.devDependencies;
    if (options.capabilities.includes("development-serving")) {
      packageJson.scripts ||= {};
      packageJson.scripts["inator:ui-check"] = options.acceptAuditBaseline || snapshot[".inator/ui-audit-baseline.json"] != null
        ? "inator audit-ui --baseline .inator/ui-audit-baseline.json"
        : "inator audit-ui";
      if (packageJson.scripts.check && !packageJson.scripts.check.includes("inator:ui-check")) packageJson.scripts.check += " && npm run inator:ui-check";
      else if (!packageJson.scripts.check) packageJson.scripts.check = "npm run inator:ui-check";
    }
    await writeFile(packageJsonPath, `${JSON.stringify(packageJson, null, 2)}\n`);

    manifest ||= { capabilities: {} };
    manifest.$schema = MANIFEST_SCHEMA;
    manifest.schemaVersion = 1;
    manifest.product = { ...(manifest.product || {}), name: productName, version: packageJson.version || "0.0.0" };
    synchronizePackageCapabilities(manifest, packed);
    manifest.capabilities = Object.fromEntries(Object.entries(manifest.capabilities).sort(([left], [right]) => left.localeCompare(right)));
    if (options.capabilities.includes("development-serving")) manifest.development = { ...(manifest.development || {}), serve: { environment: serveEnvironment } };
    manifest = {
      $schema: manifest.$schema,
      schemaVersion: manifest.schemaVersion,
      product: manifest.product,
      ...(manifest.development ? { development: manifest.development } : {}),
      ...(manifest.controlRoom ? { controlRoom: manifest.controlRoom } : {}),
      ...(manifest.deploymentProfile ? { deploymentProfile: manifest.deploymentProfile } : {}),
      capabilities: manifest.capabilities
    };
    await writeFile(path.join(projectDir, MANIFEST_FILENAME), `${JSON.stringify(manifest, null, 2)}\n`);

    if (options.capabilities.includes("development-serving")) {
      const template = path.join(sourceDir, "packages", "dev-tools", "templates", "consumer", "bin", "serve");
      const commandTemplate = path.join(sourceDir, "packages", "dev-tools", "templates", "consumer", "bin", "inator");
      await mkdir(path.join(projectDir, "bin"), { recursive: true });
      await writeFile(path.join(projectDir, "bin", "serve"), renderServeWrapper(await readFile(template, "utf8"), serveEnvironment));
      await chmod(path.join(projectDir, "bin", "serve"), 0o755);
      await copyFile(commandTemplate, path.join(projectDir, "bin", "inator"));
      await chmod(path.join(projectDir, "bin", "inator"), 0o755);
    }
    await ensureIgnoredRollback(projectDir);

    runCommand("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: projectDir, label: "Installing pinned Commons artifacts" });
    const diagnosis = await diagnoseProject(projectDir);
    if (!diagnosis.ok) throw new Error(`Installation diagnosis failed:\n${diagnosis.checks.filter(({ ok }) => !ok).map(({ message }) => `- ${message}`).join("\n")}`);
    if (packageJson.scripts?.check) runCommand("npm", ["run", "check"], { cwd: projectDir, label: "Consumer conformance checks" });
    pendingRollback = await prepareRollback(projectDir, snapshot);
    await pruneUnreferencedArtifacts(projectDir, packageJson);
    await commitRollback(projectDir, pendingRollback);
    pendingRollback = "";
    console.log("[inator]: Adoption complete. Review package.json, package-lock.json, inator.json, bin/serve, and .inator/packages/.");
  } catch (error) {
    await restoreSnapshot(projectDir, snapshot);
    if (pendingRollback) {
      await restoreArchivedArtifacts(projectDir, snapshot, path.join(pendingRollback, "artifacts"));
      await rm(pendingRollback, { recursive: true, force: true });
    }
    runCommand("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: projectDir, label: "Restoring previous installation", allowFailure: true });
    await restoreSnapshot(projectDir, snapshot);
    throw new Error(`Adoption failed and project files were restored. ${error.message}`);
  }
}

async function doctor(options) {
  const diagnosis = await diagnoseProject(options.projectDir);
  if (options.json) console.log(JSON.stringify(diagnosis, null, 2));
  else {
    console.log(`[inator]: ${diagnosis.product} at ${diagnosis.projectDir}`);
    for (const check of diagnosis.checks) console.log(`${check.ok ? "✓" : "✗"} ${check.message}`);
    console.log(diagnosis.ok ? "[inator]: Commons installation is healthy." : "[inator]: Commons installation needs attention.");
  }
  if (!diagnosis.ok) process.exitCode = 1;
}

async function rollback(options) {
  const projectDir = path.resolve(options.projectDir);
  const rollbackFile = path.join(projectDir, ".inator", "rollback", "last.json");
  const archivedArtifacts = path.join(projectDir, ".inator", "rollback", "artifacts");
  const record = await readJson(rollbackFile);
  await restoreSnapshot(projectDir, record.snapshot);
  await restoreArchivedArtifacts(projectDir, record.snapshot, archivedArtifacts);
  runCommand("npm", ["install", "--ignore-scripts", "--no-audit", "--no-fund"], { cwd: projectDir, label: "Restoring locked dependencies" });
  await restoreSnapshot(projectDir, record.snapshot);
  await restoreArchivedArtifacts(projectDir, record.snapshot, archivedArtifacts);
  await rm(path.dirname(rollbackFile), { recursive: true, force: true });
  console.log(`[inator]: Restored the adoption snapshot from ${record.createdAt}.`);
}

async function auditUICommand(options) {
  const rulesPath = uiRulesPath(options);
  const result = await auditUI({ projectDir: options.projectDir, rulesPath, roots: options.capabilities });
  if (options.writeBaseline) {
    const target = await writeAuditBaseline(options.projectDir, result, options.writeBaseline);
    console.log(`[inator]: Wrote ${result.errors.length} current finding${result.errors.length === 1 ? "" : "s"} to ${target} for review.`);
    return;
  }
  if (options.baseline) {
    const baseline = await readJson(path.resolve(options.projectDir, options.baseline));
    assertCurrentUIAuditBaseline(baseline);
    const reviewed = new Set(baseline.findings);
    result.reviewedErrors = result.errors.filter((finding) => reviewed.has(finding));
    result.resolvedBaselineFindings = baseline.findings.filter((finding) => !result.errors.includes(finding));
    result.errors = result.errors.filter((finding) => !reviewed.has(finding));
  }
  if (options.json) console.log(JSON.stringify(result, null, 2)); else console.log(formatUIAudit(result));
  if (result.reviewedErrors?.length) console.log(`Reviewed UI debt retained: ${result.reviewedErrors.length} finding${result.reviewedErrors.length === 1 ? "" : "s"}.`);
  if (result.errors.length) process.exitCode = 1;
}

async function listServers(options) {
  const running = await discoverServers();
  const selected = options.capabilities.length ? selectServers(running, options.capabilities) : running;
  if (options.json) console.log(JSON.stringify(selected, null, 2));
  else console.log(formatServers(selected));
}

async function stopServerSelection(options) {
  if (options.dryRun) throw new Error("servers stop does not support --dry-run; list targets with inator servers first.");
  if (!options.all && !options.capabilities.length) throw new Error("servers stop needs one or more product, PID, or port selectors, or --all.");
  const running = await discoverServers();
  const selected = selectServers(running, options.capabilities, options.all);
  if (!selected.length) { console.log("No verified Inator development servers are running."); return; }
  const stopped = await stopServers(selected);
  if (options.json) console.log(JSON.stringify({ stopped }, null, 2));
  else for (const server of stopped) console.log(`[inator]: Stopped ${server.product} on port ${server.port} (PID ${server.pid}).`);
}

export async function run(arguments_) {
  const { command, options } = parse(arguments_);
  if (options.help || command === "help") { console.log(usage()); return; }
  if (command === "servers" && options.subcommand === "list") return listServers(options);
  if (command === "servers" && options.subcommand === "stop") return stopServerSelection(options);
  if (command === "servers" && options.subcommand === "install") throw new Error("servers install is reserved for future operating-system service installation; it is not implemented yet.");
  if (command === "doctor") return doctor(options);
  if (command === "require") return requireCapabilities(options);
  if (command === "rollback") return rollback(options);
  if (command === "audit-ui") return auditUICommand(options);
  throw new Error(`Unknown command ${command}.\n\n${usage()}`);
}

export { discoverServeEnvironment, parse, renderServeWrapper, requestedRequirements, synchronizePackageCapabilities };
