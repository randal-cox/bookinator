export const DEPLOYMENT_PROFILE_SCHEMA = "inator.deployment-profile.v1";
export const DEPLOYMENT_PROFILE_FILENAME = "inator.deployment.json";

const ENVIRONMENTS = new Set(["local", "web-static", "web-service"]);
const PUBLICATION_CLASSES = new Set(["private", "restricted", "partner", "public"]);
const CAPABILITY_CLASSES = new Set(["browser-safe", "service-required", "local-compute", "publication-only", "unavailable"]);
const ID_PATTERN = /^[a-z][a-z0-9-]*$/;
const CAPABILITY_ID_PATTERN = /^[a-z][a-z0-9.-]*$/;

function isRecord(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function duplicateIds(items) {
  const seen = new Set();
  return items.map(({ id }) => id).filter((id) => seen.size === seen.add(id).size);
}

export function validateDeploymentProfile(value) {
  const errors = [];
  if (!isRecord(value)) return ["Deployment profile must be a JSON object."];
  if (value.schema !== DEPLOYMENT_PROFILE_SCHEMA) errors.push(`schema must be ${DEPLOYMENT_PROFILE_SCHEMA}.`);
  if (typeof value.productId !== "string" || !value.productId.trim()) errors.push("productId is required.");
  if (!Array.isArray(value.profiles) || value.profiles.length === 0) return [...errors, "profiles must be a non-empty array."];
  const duplicateProfiles = duplicateIds(value.profiles.filter(isRecord));
  if (duplicateProfiles.length) errors.push(`Profile ids must be unique: ${[...new Set(duplicateProfiles)].join(", ")}.`);
  value.profiles.forEach((profile, profileIndex) => {
    const location = `profiles[${profileIndex}]`;
    if (!isRecord(profile)) { errors.push(`${location} must be an object.`); return; }
    if (!ID_PATTERN.test(profile.id || "")) errors.push(`${location}.id must be a lowercase kebab-case id.`);
    if (!ENVIRONMENTS.has(profile.environment)) errors.push(`${location}.environment is unknown.`);
    if (typeof profile.basePath !== "string" || !profile.basePath.startsWith("/")) errors.push(`${location}.basePath must begin with /.`);
    if (!PUBLICATION_CLASSES.has(profile.publicationClass)) errors.push(`${location}.publicationClass is unknown.`);
    if (!Array.isArray(profile.capabilities)) { errors.push(`${location}.capabilities must be an array.`); return; }
    const duplicateCapabilities = duplicateIds(profile.capabilities.filter(isRecord));
    if (duplicateCapabilities.length) errors.push(`${location} capability ids must be unique: ${[...new Set(duplicateCapabilities)].join(", ")}.`);
    profile.capabilities.forEach((capability, capabilityIndex) => {
      const capabilityLocation = `${location}.capabilities[${capabilityIndex}]`;
      if (!isRecord(capability)) { errors.push(`${capabilityLocation} must be an object.`); return; }
      if (!CAPABILITY_ID_PATTERN.test(capability.id || "")) errors.push(`${capabilityLocation}.id is invalid.`);
      if (!CAPABILITY_CLASSES.has(capability.classification)) errors.push(`${capabilityLocation}.classification is unknown.`);
      if (capability.classification === "service-required" && (typeof capability.service !== "string" || !capability.service.trim())) errors.push(`${capabilityLocation}.service is required for service-required capabilities.`);
      if (capability.classification === "unavailable" && (typeof capability.note !== "string" || !capability.note.trim())) errors.push(`${capabilityLocation}.note is required for unavailable capabilities.`);
    });
  });
  return errors;
}
