import { access, realpath } from "node:fs/promises";
import { spawnSync } from "node:child_process";
import path from "node:path";
import { readRegisteredServers } from "../lib/server-registry.mjs";

function capture(command, arguments_, { allowFailure = false } = {}) {
  const result = spawnSync(command, arguments_, { encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] });
  if (result.error) throw result.error;
  if (!allowFailure && result.status !== 0) {
    throw new Error(`${command} failed: ${(result.stderr || result.stdout || `status ${result.status}`).trim()}`);
  }
  return result.stdout || "";
}

export function parseLsofListeners(output) {
  const listeners = [];
  let processRecord = null;
  for (const line of String(output).split(/\r?\n/)) {
    const field = line[0];
    const value = line.slice(1);
    if (field === "p") {
      processRecord = { pid: Number(value), command: "" };
    } else if (field === "c" && processRecord) {
      processRecord.command = value;
    } else if (field === "n" && processRecord) {
      const port = Number(value.match(/:(\d+)(?:\s|$)/)?.[1]);
      if (Number.isInteger(port)) listeners.push({ ...processRecord, address: value, port });
    }
  }
  return [...new Map(listeners.map((listener) => [`${listener.pid}:${listener.port}`, listener])).values()];
}

async function exists(file) {
  try { await access(file); return true; } catch { return false; }
}

async function isInatorProject(root) {
  if (!(await exists(path.join(root, "bin", "serve")))) return false;
  if (await exists(path.join(root, "inator.json"))) return true;
  if (path.basename(root).toLowerCase().includes("inator")) return true;
  return path.basename(path.dirname(root)).toLowerCase() === "inators";
}

export async function discoverServers({ run = capture, records = null } = {}) {
  const servers = [];
  for (const record of records || await readRegisteredServers()) {
    if (record.schemaVersion !== 1 || !Number.isInteger(record.launcherPid) || !Number.isInteger(record.listenerPid)
      || !Number.isInteger(record.port) || !record.product || !record.root) continue;
    let root = record.root;
    try { root = await realpath(root); } catch { root = path.resolve(root); }
    if (!(await isInatorProject(root))) continue;
    const listener = run("lsof", ["-a", "-p", String(record.listenerPid), `-iTCP:${record.port}`, "-sTCP:LISTEN", "-t"], { allowFailure: true }).trim();
    if (!listener.split(/\s+/).includes(String(record.listenerPid))) continue;
    try { process.kill(record.launcherPid, 0); } catch { continue; }
    servers.push({
      product: record.product,
      version: record.version || "",
      pid: record.launcherPid,
      listenerPid: record.listenerPid,
      port: record.port,
      url: record.url,
      root,
      startedAt: record.startedAt || ""
    });
  }
  return servers.sort((left, right) => left.product.localeCompare(right.product) || left.port - right.port);
}

export function selectServers(servers, selectors, all = false) {
  if (all) return [...servers];
  const requested = selectors.flatMap((selector) => String(selector).split(",")).map((selector) => selector.trim()).filter(Boolean);
  const selected = new Map();
  const unmatched = [];
  for (const selector of requested) {
    const normalized = selector.toLowerCase();
    const matches = servers.filter((server) => [
      server.product.toLowerCase(),
      path.basename(server.root).toLowerCase(),
      String(server.pid),
      String(server.port),
      `:${server.port}`
    ].includes(normalized));
    if (!matches.length) unmatched.push(selector);
    for (const server of matches) selected.set(`${server.pid}:${server.port}`, server);
  }
  if (unmatched.length) throw new Error(`No verified Inator server matches: ${unmatched.join(", ")}.`);
  return [...selected.values()];
}

export function formatServers(servers) {
  if (!servers.length) return "No verified Inator development servers are running.";
  const rows = servers.map((server) => [server.product, String(server.pid), String(server.port), server.url, server.root]);
  const headings = ["PRODUCT", "PID", "PORT", "URL", "ROOT"];
  const widths = headings.map((heading, index) => Math.max(heading.length, ...rows.map((row) => row[index].length)));
  return [headings, ...rows].map((row) => row.map((value, index) => value.padEnd(widths[index])).join("  ").trimEnd()).join("\n");
}

function sleep(milliseconds) { return new Promise((resolve) => setTimeout(resolve, milliseconds)); }

export async function stopServers(targets, { discover = discoverServers, signal = process.kill, timeoutMs = 5000 } = {}) {
  const results = [];
  for (const target of targets) {
    const live = (await discover()).find((server) => server.pid === target.pid && server.listenerPid === target.listenerPid && server.port === target.port && server.root === target.root);
    if (!live) throw new Error(`${target.product} changed or stopped before shutdown; refusing to signal PID ${target.pid}.`);
    signal(target.pid, "SIGTERM");
    const deadline = Date.now() + timeoutMs;
    let stopped = false;
    while (Date.now() < deadline) {
      await sleep(100);
      const remains = (await discover()).some((server) => server.pid === target.pid && server.listenerPid === target.listenerPid && server.port === target.port && server.root === target.root);
      if (!remains) { stopped = true; break; }
    }
    if (!stopped) throw new Error(`${target.product} did not release port ${target.port} after 5 seconds; it was not force-killed.`);
    results.push(target);
  }
  return results;
}
