import { access, readFile } from "node:fs/promises";
import path from "node:path";
import { validateDeploymentProfile } from "./deployment-profile.mjs";

export const MANIFEST_FILENAME = "inator.json";
export const MANIFEST_SCHEMA = "https://inator.com/schemas/consumer-v1.json";

function isServeEnvironmentName(name) {
  return name === "PORT" || /^SERVE_[A-Z0-9_]+$/.test(name);
}

export const CAPABILITY_CATALOG = Object.freeze({
  "development-serving": { packageName: "@inator/dev-tools", packagePath: "packages/dev-tools", dependencyGroup: "devDependencies" },
  "pipeline-engine": { packageName: "@inator/engine", packagePath: "packages/engine", dependencyGroup: "dependencies" },
  "machine-state": { packageName: "@inator/machine", packagePath: "packages/machine", dependencyGroup: "dependencies" },
  "model-runtime": { packageName: "@inator/models", packagePath: "packages/models", dependencyGroup: "dependencies" },
  "action-bars": { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" },
  dialogs: { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies", styleEntrypoints: ["@inator/ui/dialog.css"] },
  lists: { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" },
  "pipeline-presentation": { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" },
  "product-history": { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" },
  "product-shell": { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" },
  resources: { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" },
  workspace: { packageName: "@inator/ui", packagePath: "packages/ui", dependencyGroup: "dependencies" }
});

export async function readJson(file) {
  return JSON.parse(await readFile(file, "utf8"));
}

export function validateManifest(manifest) {
  const errors = [];
  if (!manifest || typeof manifest !== "object" || Array.isArray(manifest)) return ["Manifest must be a JSON object."];
  if (manifest.schemaVersion !== 1) errors.push("schemaVersion must be 1.");
  if (!manifest.product || typeof manifest.product.name !== "string" || !manifest.product.name.trim()) errors.push("product.name is required.");
  const controlRoom = manifest.controlRoom;
  if (controlRoom != null && (typeof controlRoom !== "object" || Array.isArray(controlRoom))) errors.push("controlRoom must be an object.");
  if (controlRoom?.icon != null && typeof controlRoom.icon !== "string") errors.push("controlRoom.icon must be a string.");
  for (const [group, keys] of [["ui", ["url"]], ["health", ["url"]], ["lifecycle", ["adapter"]]]) {
    const value = controlRoom?.[group];
    if (value != null && (typeof value !== "object" || Array.isArray(value))) errors.push(`controlRoom.${group} must be an object.`);
    for (const key of keys) if (value?.[key] != null && typeof value[key] !== "string") errors.push(`controlRoom.${group}.${key} must be a string.`);
  }
  if (controlRoom?.capabilities != null && (!Array.isArray(controlRoom.capabilities) || controlRoom.capabilities.some((value) => typeof value !== "string"))) errors.push("controlRoom.capabilities must be an array of strings.");
  if (manifest.deploymentProfile != null && (typeof manifest.deploymentProfile !== "string" || !manifest.deploymentProfile.trim())) errors.push("deploymentProfile must be a non-empty string.");
  const serveEnvironment = manifest.development?.serve?.environment;
  if (serveEnvironment != null && (typeof serveEnvironment !== "object" || Array.isArray(serveEnvironment))) errors.push("development.serve.environment must be an object.");
  else for (const [name, value] of Object.entries(serveEnvironment || {})) {
    if (!isServeEnvironmentName(name)) errors.push(`Invalid serve environment key ${name}.`);
    if (typeof value !== "string" || /[\r\n\0]/.test(value)) errors.push(`Serve environment value ${name} must be a single-line string.`);
  }
  if (!manifest.capabilities || typeof manifest.capabilities !== "object" || Array.isArray(manifest.capabilities)) {
    errors.push("capabilities must be an object.");
    return errors;
  }
  for (const [name, requirement] of Object.entries(manifest.capabilities)) {
    const definition = CAPABILITY_CATALOG[name];
    if (!definition) errors.push(`Unknown capability ${name}.`);
    if (!requirement || typeof requirement !== "object") {
      errors.push(`Capability ${name} must be an object.`);
      continue;
    }
    if (typeof requirement.package !== "string" || !requirement.package) errors.push(`Capability ${name} requires package.`);
    else if (definition && requirement.package !== definition.packageName) {
      errors.push(`Capability ${name} must use ${definition.packageName}; found ${requirement.package}.`);
    }
    if (typeof requirement.version !== "string" || !requirement.version) errors.push(`Capability ${name} requires version.`);
  }
  return errors;
}

export async function diagnoseProject(projectDirectory) {
  const projectDir = path.resolve(projectDirectory);
  const checks = [];
  let packageJson;
  let manifest;

  try {
    packageJson = await readJson(path.join(projectDir, "package.json"));
    checks.push({ id: "package-json", ok: true, message: `package.json identifies ${packageJson.name || path.basename(projectDir)}.` });
  } catch (error) {
    return { ok: false, projectDir, product: path.basename(projectDir), checks: [{ id: "package-json", ok: false, message: `Cannot read package.json: ${error.message}` }] };
  }

  try {
    manifest = await readJson(path.join(projectDir, MANIFEST_FILENAME));
    const errors = validateManifest(manifest);
    checks.push({ id: "manifest", ok: errors.length === 0, message: errors.length ? errors.join(" ") : `${MANIFEST_FILENAME} is valid.` });
    if (errors.length) return { ok: false, projectDir, product: packageJson.name || path.basename(projectDir), checks };
  } catch (error) {
    checks.push({ id: "manifest", ok: false, message: `${MANIFEST_FILENAME} is missing or invalid: ${error.message}` });
    return { ok: false, projectDir, product: packageJson.name || path.basename(projectDir), checks };
  }

  if (manifest.deploymentProfile != null) {
    const relative = manifest.deploymentProfile;
    if (path.isAbsolute(relative) || relative.split(/[\\/]/).includes("..")) {
      checks.push({ id: "deployment-profile", ok: false, message: "deploymentProfile must be a safe project-relative JSON path." });
    } else {
      try {
        const deploymentProfile = await readJson(path.join(projectDir, relative));
        const errors = validateDeploymentProfile(deploymentProfile);
        checks.push({ id: "deployment-profile", ok: errors.length === 0, message: errors.length ? errors.join(" ") : `${relative} is a valid deployment-profile inventory.` });
      } catch (error) {
        checks.push({ id: "deployment-profile", ok: false, message: `${relative} is missing or invalid: ${error.message}` });
      }
    }
  }

  const requirements = new Map();
  for (const [capability, requirement] of Object.entries(manifest.capabilities)) {
    const key = `${requirement.package}@${requirement.version}`;
    if (!requirements.has(key)) requirements.set(key, { ...requirement, capabilities: [] });
    requirements.get(key).capabilities.push(capability);
  }

  for (const requirement of requirements.values()) {
    const declared = packageJson.dependencies?.[requirement.package] ?? packageJson.devDependencies?.[requirement.package];
    const pinned = typeof declared === "string" && (declared === requirement.version || /^file:\.inator\/packages\/[^/]+\.tgz$/.test(declared));
    checks.push({
      id: `declared:${requirement.package}`,
      ok: pinned,
      message: pinned
        ? `${requirement.package} is pinned by package.json for ${requirement.capabilities.join(", ")}.`
        : `${requirement.package} must be pinned at ${requirement.version}; found ${declared || "no dependency"}.`
    });

    if (typeof declared === "string" && declared.startsWith("file:.inator/packages/")) {
      const artifact = path.join(projectDir, declared.slice("file:".length));
      try {
        await access(artifact);
        checks.push({ id: `artifact:${requirement.package}`, ok: true, message: `${path.basename(artifact)} is present.` });
      } catch {
        checks.push({ id: `artifact:${requirement.package}`, ok: false, message: `${path.basename(artifact)} is missing.` });
      }
    }

    try {
      const installed = await readJson(path.join(projectDir, "node_modules", ...requirement.package.split("/"), "package.json"));
      checks.push({
        id: `installed:${requirement.package}`,
        ok: installed.version === requirement.version,
        message: installed.version === requirement.version
          ? `${requirement.package} ${installed.version} is installed.`
          : `${requirement.package} ${installed.version} is installed; ${requirement.version} is required.`
      });
    } catch {
      checks.push({ id: `installed:${requirement.package}`, ok: false, message: `${requirement.package} ${requirement.version} is not installed.` });
    }
  }

  const needsLauncher = Object.hasOwn(manifest.capabilities, "development-serving");
  if (needsLauncher) {
    try {
      const wrapper = await readFile(path.join(projectDir, "bin", "serve"), "utf8");
      const installed = wrapper.includes("node_modules/.bin/inator-serve") && !wrapper.includes("INATOR_COMMONS_DIR");
      checks.push({ id: "launcher-wrapper", ok: installed, message: installed ? "bin/serve delegates to the installed launcher." : "bin/serve still depends on a Commons checkout or forks launcher behavior." });
      const expectedEnvironment = manifest.development?.serve?.environment || {};
      const configurationPresent = Object.entries(expectedEnvironment).every(([name, value]) => wrapper.includes(`${name}=${value}`));
      checks.push({ id: "launcher-configuration", ok: configurationPresent, message: configurationPresent ? "bin/serve preserves the declared product launcher settings." : "bin/serve does not preserve every declared launcher setting." });
    } catch {
      checks.push({ id: "launcher-wrapper", ok: false, message: "bin/serve is missing." });
      checks.push({ id: "launcher-configuration", ok: false, message: "Launcher configuration cannot be verified." });
    }
    try {
      const wrapper = await readFile(path.join(projectDir, "bin", "inator"), "utf8");
      const installed = wrapper.includes("node_modules/.bin/inator") && wrapper.includes("INATOR_PROJECT_DIR");
      checks.push({ id: "command-wrapper", ok: installed, message: installed ? "bin/inator delegates to the installed project command." : "bin/inator does not delegate to the installed project command." });
    } catch {
      checks.push({ id: "command-wrapper", ok: false, message: "bin/inator is missing." });
    }
  }

  try {
    const lockfile = await readJson(path.join(projectDir, "package-lock.json"));
    const root = lockfile.packages?.[""] || {};
    const mismatches = [];
    for (const requirement of requirements.values()) {
      const declared = packageJson.dependencies?.[requirement.package] ?? packageJson.devDependencies?.[requirement.package];
      const locked = root.dependencies?.[requirement.package] ?? root.devDependencies?.[requirement.package];
      if (locked !== declared) mismatches.push(`${requirement.package}: ${locked || "missing"}`);
    }
    checks.push({
      id: "lockfile",
      ok: mismatches.length === 0,
      message: mismatches.length
        ? `package-lock.json does not match package.json (${mismatches.join(", ")}).`
        : "package-lock.json records the exact Commons installation."
    });
  } catch {
    checks.push({ id: "lockfile", ok: false, message: "package-lock.json is missing." });
  }

  return { ok: checks.every(({ ok }) => ok), projectDir, product: manifest.product.name, checks };
}
