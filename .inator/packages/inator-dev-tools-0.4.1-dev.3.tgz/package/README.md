# @inator/dev-tools

The installable development-tooling boundary for Inator applications.

It provides:

- `inator-serve`, the shared deterministic local launcher;
- `inator servers`, a verified inventory of running Inator development servers;
- `inator servers stop PRODUCT...` and `inator servers stop --all`, guarded
  normal shutdowns that re-check PID, port, and project root before signaling;
- `inator doctor`, a read-only consumer installation diagnosis;
- `inator require`, deliberate capability adoption with pinned artifacts and
  conformance checks; and
- `inator rollback`, restoration of the most recent adoption snapshot;
- `inator audit-ui [ROOT...]`, the package-owned standards-smell audit across
  default or explicit product source roots; and
- `@inator/dev-tools/deployment-profile`, the non-operative Common Ground
  deployment-inventory validator used by `inator doctor`.

Commons packages are packed into the consumer's
`.inator/packages/` directory. The consumer therefore remains installable from
a clean clone without a sibling Commons checkout or a live package registry.
The manifest records capabilities; npm records the deduplicated packages that
provide them.

Projects with the `development-serving` capability receive thin `bin/serve`
and `bin/inator` wrappers. From any such checkout:

```sh
./bin/inator servers
./bin/inator servers list
./bin/inator servers stop fboe.inator rho.inator
./bin/inator servers stop --all
```

Only listeners registered by the shared launcher and still verified against
their PID, port, project root, and `bin/serve` are eligible. Unregistered or
ambiguous listeners are omitted rather than guessed at. Shutdown uses `SIGTERM`
and never escalates to a force kill.
