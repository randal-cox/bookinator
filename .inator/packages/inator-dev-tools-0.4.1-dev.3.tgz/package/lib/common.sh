#!/usr/bin/env bash

inator_trim() {
  local value="$1"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

inator_load_env_file() {
  local file="$1"
  local line line_number=0 key value
  [[ -f "$file" ]] || return 0

  while IFS= read -r line || [[ -n "$line" ]]; do
    line_number=$((line_number + 1))
    line="$(inator_trim "$line")"
    [[ -z "$line" || "${line:0:1}" == "#" ]] && continue
    [[ "$line" == export\ * ]] && line="$(inator_trim "${line#export }")"
    if [[ "$line" != *=* ]]; then
      printf 'Invalid configuration line %s:%s (expected NAME=value).\n' "$file" "$line_number" >&2
      return 2
    fi

    key="$(inator_trim "${line%%=*}")"
    value="$(inator_trim "${line#*=}")"
    if [[ ! "$key" =~ ^[A-Za-z_][A-Za-z0-9_]*$ ]]; then
      printf 'Invalid configuration key %s at %s:%s.\n' "$key" "$file" "$line_number" >&2
      return 2
    fi
    if [[ ${#value} -ge 2 && "${value:0:1}" == '"' && "${value: -1}" == '"' ]]; then
      value="${value:1:${#value}-2}"
    elif [[ ${#value} -ge 2 && "${value:0:1}" == "'" && "${value: -1}" == "'" ]]; then
      value="${value:1:${#value}-2}"
    fi
    printf -v "$key" '%s' "$value"
    export "$key"
  done < "$file"
}

inator_safe_id() {
  [[ "$1" =~ ^[A-Za-z0-9][A-Za-z0-9._-]*$ ]]
}

inator_resolve_file() {
  local project_dir="$1" value="$2"
  if [[ "$value" == /* ]]; then printf '%s' "$value"; else printf '%s/%s' "$project_dir" "$value"; fi
}

inator_stop_process_tree() {
  local process_id="$1" child_id children
  [[ "$process_id" =~ ^[0-9]+$ ]] || return 0
  children="$(pgrep -P "$process_id" 2>/dev/null || true)"
  while IFS= read -r child_id; do
    [[ -n "$child_id" ]] || continue
    inator_stop_process_tree "$child_id"
  done <<< "$children"
  kill "$process_id" 2>/dev/null || true
}

inator_process_is_descendant() {
  local process_id="$1" ancestor_id="$2" parent_id
  [[ "$process_id" =~ ^[0-9]+$ && "$ancestor_id" =~ ^[0-9]+$ ]] || return 1
  while [[ "$process_id" -gt 1 ]]; do
    [[ "$process_id" == "$ancestor_id" ]] && return 0
    parent_id="$(ps -p "$process_id" -o ppid= 2>/dev/null | tr -d '[:space:]')"
    [[ "$parent_id" =~ ^[0-9]+$ ]] || return 1
    process_id="$parent_id"
  done
  return 1
}

inator_project_dir() {
  local bundled_root="$1" candidate
  if [[ -n "${INATOR_PROJECT_DIR:-}" ]]; then
    candidate="$INATOR_PROJECT_DIR"
  elif [[ -n "${INIT_CWD:-}" && -f "$INIT_CWD/package.json" ]]; then
    candidate="$INIT_CWD"
  elif [[ "$PWD" != "$bundled_root" && -f "$PWD/package.json" ]]; then
    candidate="$PWD"
  else
    candidate="$bundled_root"
  fi
  [[ -d "$candidate" ]] || { printf 'Inator project directory does not exist: %s\n' "$candidate" >&2; return 2; }
  (cd "$candidate" && pwd -P)
}

inator_log() {
  local label="$1"
  shift
  printf '[%s]: %s\n' "$label" "$*"
}

inator_warn() {
  local label="$1"
  shift
  printf '[%s]: %s\n' "$label" "$*" >&2
}

inator_resolve_url() {
  local target="$1" host="$2" port="$3"
  target="${target//@HOST@/$host}"
  target="${target//@PORT@/$port}"
  if [[ "$target" == /* ]]; then printf 'http://%s:%s%s' "$host" "$port" "$target"; else printf '%s' "$target"; fi
}

inator_print_serve_banner() {
  local title="$1"
  shift
  local width=46 interior=44 left right border entry label target
  if ((${#title} > interior)); then title="${title:0:interior}"; fi
  left=$(((interior - ${#title}) / 2))
  right=$((interior - ${#title} - left))
  printf -v border '%*s' "$width" ''
  border="${border// /#}"
  printf '%s\n#%*s%s%*s#\n%s\n' "$border" "$left" '' "$title" "$right" '' "$border"
  if (($# == 1)); then
    entry="$1"
    target="${entry#*=}"
    printf 'url: %s\n\n' "$target"
    return
  fi
  printf 'urls:\n'
  for entry in "$@"; do
    label="${entry%%=*}"
    target="${entry#*=}"
    printf '  %s: %s\n' "$label" "$target"
  done
  printf '\n'
}
