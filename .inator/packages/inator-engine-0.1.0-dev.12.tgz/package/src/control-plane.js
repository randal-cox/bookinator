import { appendFile, mkdir, readFile } from "node:fs/promises";
import path from "node:path";
import { ENGINE_PROTOCOL_VERSION, assessWorkBudget, authorizePlacement, classifyActivity, classifyResult, defineActivityEnvelope, defineResultEnvelope, defineWorkBudget, defineWorkEnvelope, inputSignature } from "./index.js";

const clone = (value) => structuredClone(value);
export class DurableControlPlane {
  constructor({ ledgerPath, workspaceId, runId, now = Date.now, leaseMs = 30_000 } = {}) {
    if (!ledgerPath || !workspaceId || !runId) throw new TypeError("ledgerPath, workspaceId, and runId are required.");
    this.ledgerPath = path.resolve(ledgerPath); this.workspaceId = workspaceId; this.runId = runId; this.now = now; this.leaseMs = leaseMs;
    this.events = []; this.units = new Map(); this.artifacts = new Map(); this.edges = new Map(); this.humanTasks = new Map(); this.appliedExpansions = new Set(); this.sequence = 0; this.graphRevision = 0; this.writeChain = Promise.resolve(); this.paused = false;
  }

  async open() {
    await mkdir(path.dirname(this.ledgerPath), { recursive: true });
    let source = ""; try { source = await readFile(this.ledgerPath, "utf8"); } catch (error) { if (error.code !== "ENOENT") throw error; }
    source.split(/\r?\n/).filter(Boolean).forEach((line, index) => { try { this.#apply(JSON.parse(line), false); } catch (error) { throw new Error(`Invalid engine ledger record ${index + 1}: ${error.message}`); } });
    await this.expireClaims(); return this;
  }

  async #record(type, payload) {
    const event = { protocolVersion: ENGINE_PROTOCOL_VERSION, sequence: ++this.sequence, at: new Date(this.now()).toISOString(), type, workspaceId: this.workspaceId, runId: this.runId, payload: clone(payload) };
    this.writeChain = this.writeChain.then(() => appendFile(this.ledgerPath, `${JSON.stringify(event)}\n`, "utf8")); await this.writeChain; this.#apply(event, true); return clone(event);
  }

  #apply(event, retain = true) {
    if (event.workspaceId !== this.workspaceId || event.runId !== this.runId) throw new TypeError("Ledger event crosses the control-plane boundary.");
    this.sequence = Math.max(this.sequence, Number(event.sequence) || 0); if (retain) this.events.push(event); else this.events.push(clone(event));
    const payload = event.payload || {}; const unit = payload.workUnitId ? this.units.get(payload.workUnitId) : null;
    if (event.type === "run.initialized") this.#applyExpansion(payload.expansion);
    if (event.type === "work.enqueued") this.units.set(payload.workUnitId, { ...payload, status: "waiting", claimGeneration: 0, attempts: [] });
    if (event.type === "control.paused") this.paused = true;
    if (event.type === "control.resumed") this.paused = false;
    if (event.type === "claim.issued" && unit) { unit.status = "running"; unit.claimGeneration = payload.claimGeneration; unit.claim = { ...payload }; unit.activity = null; unit.attempts.push({ attemptId: payload.attemptId, claimGeneration: payload.claimGeneration, status: "running", claimedAt: event.at, activities: [] }); }
    if (event.type === "claim.heartbeat" && unit?.claim?.attemptId === payload.attemptId) unit.claim.leaseExpiresAt = payload.leaseExpiresAt;
    if (event.type === "activity.reported" && unit) { const attempt = unit.attempts.find((item) => item.attemptId === payload.activity.attemptId); if (attempt) attempt.activities.push({ ...clone(payload.activity), reportedAt: event.at, disposition: payload.disposition }); if (payload.applicable && unit.claim?.attemptId === payload.activity.attemptId) { unit.activity = { ...clone(payload.activity), reportedAt: event.at }; unit.claim.leaseExpiresAt = payload.leaseExpiresAt; } }
    if (event.type === "claim.expired" && unit?.claim?.attemptId === payload.attemptId) { unit.status = "waiting"; unit.attempts.find((attempt) => attempt.attemptId === payload.attemptId).status = "expired"; unit.claim = null; unit.activity = null; }
    if (event.type === "result.retained" && unit) { const attempt = unit.attempts.find((item) => item.attemptId === payload.result.attemptId); if (attempt) Object.assign(attempt, { status: payload.result.status, finishedAt: event.at, disposition: payload.disposition, usage: clone(payload.result.usage), budgetAssessment: clone(payload.budgetAssessment) }); if (payload.applicable) { unit.status = payload.result.status === "succeeded" ? "complete" : payload.result.status; unit.acceptedAttemptId = payload.result.status === "succeeded" ? payload.result.attemptId : null; unit.result = payload.result.output ?? null; unit.claim = null; unit.activity = null; if (payload.expansion) this.#applyExpansion(payload.expansion); } }
    if (event.type === "human.answer-committed") { const task = this.humanTasks.get(payload.taskId); if (task) { task.status = "complete"; task.answerArtifactId = payload.answer.id; } this.artifacts.set(payload.answer.id, { ...clone(payload.answer), current: true }); this.#applyExpansion(payload.expansion); }
    if (event.type === "graph.invalidated") { this.#applyInvalidation(payload); this.graphRevision += 1; }
    if (event.type === "human.answer-revised") { const prior = this.artifacts.get(payload.priorAnswerId); if (prior) Object.assign(prior, { current: false, supersededBy: payload.answer.id }); this.artifacts.set(payload.answer.id, { ...clone(payload.answer), current: true, supersedes: payload.priorAnswerId }); for (const task of this.humanTasks.values()) if (task.answerArtifactId === payload.priorAnswerId) task.answerArtifactId = payload.answer.id; this.#applyInvalidation(payload); this.#applyExpansion(payload.expansion); }
  }

  #applyInvalidation(payload) { for (const id of payload.invalidatedIds) { const artifact = this.artifacts.get(id); if (artifact) Object.assign(artifact, { current: false, invalidatedBy: [...payload.changedIds], invalidatedReason: payload.reason }); const work = this.units.get(id); if (work) Object.assign(work, { status: "stale", acceptedAttemptId: null, invalidatedBy: [...payload.changedIds], staleInputSignature: work.inputSignature }); } }

  #applyExpansion(expansion) {
    if (!expansion || this.appliedExpansions.has(expansion.id)) return;
    for (const artifact of expansion.artifacts || []) this.artifacts.set(artifact.id, { current: true, ...clone(artifact) });
    for (const edge of expansion.edges || []) this.edges.set(edge.id, clone(edge));
    for (const task of expansion.humanTasks || []) this.humanTasks.set(task.id, { ...clone(task), status: task.status || "ready" });
    for (const work of expansion.workUnits || []) this.units.set(work.id, { workUnitId: work.id, label: work.label, method: work.method, input: clone(work.input), inputSignature: inputSignature(work.input), priority: work.priority || 0, placementPolicy: work.placementPolicy || { mode: "local-only" }, budget: defineWorkBudget(work.budget), status: "waiting", claimGeneration: 0, attempts: [], activity: null });
    this.appliedExpansions.add(expansion.id); this.graphRevision += 1;
  }

  #validateExpansion(source = {}, { additionalIds = [] } = {}) {
    const expansion = clone(source); if (!String(expansion.id || "").trim()) throw new TypeError("Expansion id is required.");
    for (const [field, existing] of [["artifacts", this.artifacts], ["edges", this.edges], ["humanTasks", this.humanTasks]]) { expansion[field] ||= []; const ids = expansion[field].map(({ id }) => id); if (ids.some((id) => !id) || new Set(ids).size !== ids.length) throw new TypeError(`Expansion ${field} ids must be present and unique.`); if (ids.some((id) => existing.has(id))) throw new TypeError(`Expansion ${expansion.id} conflicts with existing ${field}.`); }
    expansion.workUnits ||= []; const workIds = expansion.workUnits.map(({ id }) => id); if (workIds.some((id) => !id) || new Set(workIds).size !== workIds.length || workIds.some((id) => this.units.has(id))) throw new TypeError(`Expansion ${expansion.id} work-unit ids must be new and unique.`);
    const knownIds = new Set([...this.artifacts.keys(), ...this.units.keys(), ...additionalIds, ...expansion.artifacts.map(({ id }) => id), ...workIds]);
    for (const edge of expansion.edges) if (!knownIds.has(edge.sourceId) || !knownIds.has(edge.targetId)) throw new TypeError(`Expansion edge ${edge.id} references an unknown source or target.`);
    return expansion;
  }

  async initialize(expansion) {
    if (this.events.length) throw new Error("A durable run can only be initialized once."); const validated = this.#validateExpansion(expansion); await this.#record("run.initialized", { expansion: validated }); return this.snapshot();
  }

  async enqueue({ id, label, input, method = "commons.wait", priority = 0, placementPolicy = { mode: "local-only" }, budget = null }) {
    if (this.units.has(id)) return this.snapshot();
    await this.#record("work.enqueued", { workUnitId: id, label, method, input: clone(input), inputSignature: inputSignature(input), priority, placementPolicy, budget: defineWorkBudget(budget) }); return this.snapshot();
  }

  async claim(worker) {
    await this.expireClaims(); if (this.paused) return null;
    const unit = [...this.units.values()].filter(({ status }) => status === "waiting").sort((a, b) => b.priority - a.priority)[0]; if (!unit) return null;
    const claimGeneration = unit.claimGeneration + 1; const attemptId = `${unit.workUnitId}.attempt.${claimGeneration}`; const leaseExpiresAt = new Date(this.now() + this.leaseMs).toISOString();
    const work = defineWorkEnvelope({ protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: this.workspaceId, runId: this.runId, workUnitId: unit.workUnitId, attemptId, claimGeneration, inputSignature: unit.inputSignature, placementPolicy: unit.placementPolicy, budget: unit.budget, method: unit.method, input: unit.input });
    const placement = authorizePlacement(work, worker); if (!placement.allowed) throw new Error(`Worker ${placement.workerId} is not authorized for this work unit.`);
    await this.#record("claim.issued", { workUnitId: unit.workUnitId, attemptId, claimGeneration, workerId: worker.id, leaseExpiresAt, work }); return work;
  }

  async heartbeat({ workUnitId, attemptId }) {
    const unit = this.units.get(workUnitId); if (!unit?.claim || unit.claim.attemptId !== attemptId) return false;
    await this.#record("claim.heartbeat", { workUnitId, attemptId, leaseExpiresAt: new Date(this.now() + this.leaseMs).toISOString() }); return true;
  }

  async reportActivity(activitySource) {
    const activity = defineActivityEnvelope(activitySource); const unit = this.units.get(activity.workUnitId);
    if (!unit) throw new TypeError(`Unknown work unit ${activity.workUnitId}.`);
    const classification = unit.claim ? classifyActivity(unit.claim.work, activity) : Object.freeze({ retained: true, applicable: false, disposition: "stale-activity" }); const leaseExpiresAt = new Date(this.now() + this.leaseMs).toISOString();
    await this.#record("activity.reported", { workUnitId: unit.workUnitId, activity, ...classification, leaseExpiresAt });
    return classification;
  }

  async accept(resultSource, { expansion = null } = {}) {
    const result = defineResultEnvelope(resultSource); const unit = this.units.get(result.workUnitId); if (!unit) throw new TypeError(`Unknown work unit ${result.workUnitId}.`);
    const work = unit.claim?.work || { protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: this.workspaceId, runId: this.runId, workUnitId: unit.workUnitId, attemptId: result.attemptId, claimGeneration: unit.claimGeneration, inputSignature: unit.inputSignature, placementPolicy: unit.placementPolicy };
    const classification = classifyResult(work, result); if (classification.applicable && expansion?.id && this.appliedExpansions.has(expansion.id)) return { ...classification, expansion: "already-applied" };
    const budgetAssessment = unit.budget ? assessWorkBudget(unit.budget, result.usage) : null; const validatedExpansion = classification.applicable && expansion ? this.#validateExpansion(expansion) : null; await this.#record("result.retained", { workUnitId: unit.workUnitId, result, ...classification, budgetAssessment, expansion: validatedExpansion }); return { ...classification, ...(budgetAssessment ? { budgetAssessment } : {}), ...(validatedExpansion ? { expansion: "applied" } : {}) };
  }

  async commitAnswer({ taskId, answer, expansion }) {
    const task = this.humanTasks.get(taskId); if (!task || task.status !== "ready") throw new Error(`Human task ${taskId} is not ready.`); if (!answer?.id || !answer?.actor?.id || !answer?.committedAt) throw new TypeError("An answer requires id, actor.id, and committedAt.");
    if (this.appliedExpansions.has(expansion?.id)) return { committed: false, reason: "already-applied" }; const validated = this.#validateExpansion(expansion, { additionalIds: [answer.id] }); await this.#record("human.answer-committed", { taskId, answer: clone(answer), expansion: validated }); return { committed: true, graphRevision: this.graphRevision };
  }

  async reviseAnswer({ priorAnswerId, answer, expansion, reason = "answer-superseded" }) {
    const prior = this.artifacts.get(priorAnswerId); if (!prior || prior.kind !== "answer" || prior.current === false) throw new Error(`Answer ${priorAnswerId} is not current.`); if (!answer?.id || !answer?.actor?.id || !answer?.committedAt) throw new TypeError("A revised answer requires id, actor.id, and committedAt."); if (answer.id === priorAnswerId || this.artifacts.has(answer.id)) throw new TypeError("A revised answer requires a new artifact id.");
    const validated = this.#validateExpansion(expansion, { additionalIds: [answer.id] }); const preview = this.previewInvalidation([priorAnswerId]); await this.#record("human.answer-revised", { priorAnswerId, answer: clone(answer), expansion: validated, ...preview, reason }); return { revised: true, invalidatedIds: preview.invalidatedIds, graphRevision: this.graphRevision };
  }

  previewInvalidation(changedIds) {
    const changed = new Set(changedIds); const invalidated = new Set(); const queue = [...changed]; const kinds = new Set(["requires-current", "requires-accepted", "requires-set", "invalidates"]);
    while (queue.length) { const sourceId = queue.shift(); for (const edge of this.edges.values()) if (edge.sourceId === sourceId && kinds.has(edge.kind) && !changed.has(edge.targetId) && !invalidated.has(edge.targetId)) { invalidated.add(edge.targetId); queue.push(edge.targetId); } }
    return { changedIds: [...changed], invalidatedIds: [...invalidated] };
  }

  async invalidate(changedIds, { reason = "input-revised" } = {}) { const preview = this.previewInvalidation(changedIds); await this.#record("graph.invalidated", { ...preview, reason }); return { ...preview, graphRevision: this.graphRevision }; }

  async expireClaims() {
    const now = this.now(); for (const unit of this.units.values()) if (unit.status === "running" && Date.parse(unit.claim.leaseExpiresAt) <= now) await this.#record("claim.expired", { workUnitId: unit.workUnitId, attemptId: unit.claim.attemptId });
  }

  async pause() { await this.#record("control.paused", {}); return this.snapshot(); }
  async resume() { await this.#record("control.resumed", {}); return this.snapshot(); }
  snapshot() { const units = [...this.units.values()].map(clone); const currentUnits = units.filter(({ status }) => !["stale", "superseded"].includes(status)); const humanTasks = [...this.humanTasks.values()].map(clone); const active = currentUnits.some(({ status }) => status === "running"); const readyHuman = humanTasks.some(({ status }) => status === "ready"); return { protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: this.workspaceId, runId: this.runId, paused: this.paused, sequence: this.sequence, graphRevision: this.graphRevision, state: active ? "running" : readyHuman ? "waiting-for-human" : currentUnits.some(({ status }) => status === "waiting") ? "ready" : currentUnits.length && currentUnits.every(({ status }) => status === "complete") ? "complete" : "idle", units, artifacts: [...this.artifacts.values()].map(clone), edges: [...this.edges.values()].map(clone), humanTasks, events: clone(this.events), progress: { completed: currentUnits.filter(({ status }) => status === "complete").length, total: currentUnits.length, retainedUnits: units.length, staleUnits: units.length - currentUnits.length } }; }
}
