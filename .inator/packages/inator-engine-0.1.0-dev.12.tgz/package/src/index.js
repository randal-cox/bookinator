import { createHash } from "node:crypto";

export { createDemoPipeline, DEMO_PIPELINE_TASKS } from "./demo-pipeline.js";
export { DurableControlPlane } from "./control-plane.js";
export { executeWork, installJsonLineWorker } from "./worker-runtime.js";
export { PIPELINE_ATTEMPT_DISPOSITIONS, PIPELINE_ESTIMATE_CONFIDENCES, PIPELINE_GATE_STATES, PIPELINE_PROJECT_PRIORITIES, PIPELINE_RECOVERY_POLICIES, PIPELINE_RETRY_POLICIES, PIPELINE_SNAPSHOT_SCHEMA, PIPELINE_STOP_BOUNDARIES, PIPELINE_UNIT_STATUSES, assertPipelineSnapshotConformance, definePipelineSnapshot, pipelineControlIntent, pipelineDispatchOrder, pipelineSnapshotConformance } from "./pipeline-contract.js";
export { createPipelineExemplarController, createPopulatedPipelineExemplar } from "./pipeline-exemplar.js";

export const ENGINE_PROTOCOL_VERSION = "inator-engine.0.1-draft";

export const PIPELINE_ACTIVITY_PHASES = Object.freeze([
  "preparing",
  "connecting",
  "ingesting",
  "generating",
  "verifying",
  "committing"
]);

export const PIPELINE_BUDGET_ENFORCEMENTS = Object.freeze(["hard", "soft"]);

export const EDGE_KINDS = Object.freeze([
  "requires-current",
  "requires-accepted",
  "requires-set",
  "invalidates",
  "refines",
  "prompted-by",
  "answered-by",
  "produced-by",
  "supersedes",
  "observes"
]);

const INVALIDATING_EDGE_KINDS = new Set([
  "requires-current",
  "requires-accepted",
  "requires-set",
  "invalidates"
]);

function requiredText(value, label) {
  const text = String(value || "").trim();
  if (!text) throw new TypeError(`${label} is required.`);
  return text;
}

function plainObject(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new TypeError(`${label} must be an object.`);
  }
  return value;
}

function finiteNonnegative(value, label) {
  if (value == null || value === "") throw new TypeError(`${label} must be a finite nonnegative number.`);
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) throw new TypeError(`${label} must be a finite nonnegative number.`);
  return number;
}

function normalizeMeasure(source, label, amountField) {
  const value = plainObject(source, label);
  return Object.freeze({
    ...value,
    id: requiredText(value.id, `${label} id`),
    [amountField]: finiteNonnegative(value[amountField], `${label} ${amountField}`),
    unit: requiredText(value.unit, `${label} unit`)
  });
}

export function defineWorkBudget(source) {
  if (source == null) return null;
  const value = plainObject(source, "Work budget");
  const limitSources = value.limits || [];
  if (!Array.isArray(limitSources)) throw new TypeError("Work budget limits must be an array.");
  const limits = limitSources.map((limit, index) => {
    const normalized = normalizeMeasure(limit, `Work budget limit ${index + 1}`, "maximum");
    const enforcement = String(limit.enforcement || "hard");
    if (!PIPELINE_BUDGET_ENFORCEMENTS.includes(enforcement)) throw new TypeError(`Work budget limit ${normalized.id} enforcement must be one of ${PIPELINE_BUDGET_ENFORCEMENTS.join(", ")}.`);
    return Object.freeze({ ...normalized, enforcement });
  });
  if (new Set(limits.map(({ id }) => id)).size !== limits.length) throw new TypeError("Work budget limit ids must be unique.");
  return Object.freeze({ ...value, limits: Object.freeze(limits) });
}

export function defineWorkUsage(source = []) {
  const values = Array.isArray(source) ? source : plainObject(source, "Work usage").measurements || [];
  if (!Array.isArray(values)) throw new TypeError("Work usage measurements must be an array.");
  const measurements = values.map((measurement, index) => normalizeMeasure(measurement, `Work usage measurement ${index + 1}`, "amount"));
  if (new Set(measurements.map(({ id }) => id)).size !== measurements.length) throw new TypeError("Work usage measurement ids must be unique.");
  return Object.freeze(measurements);
}

export function assessWorkBudget(budgetSource, usageSource = []) {
  const budget = defineWorkBudget(budgetSource);
  const usage = defineWorkUsage(usageSource);
  if (!budget) return Object.freeze({ conformant: true, exceededIds: Object.freeze([]), warnings: Object.freeze([]), unreportedIds: Object.freeze([]) });
  const measurements = new Map(usage.map((measurement) => [measurement.id, measurement]));
  const exceededIds = [];
  const warnings = [];
  const unreportedIds = [];
  for (const limit of budget.limits) {
    const measurement = measurements.get(limit.id);
    if (!measurement) { unreportedIds.push(limit.id); continue; }
    if (measurement.unit !== limit.unit) throw new TypeError(`Work usage ${limit.id} uses ${measurement.unit}; budget requires ${limit.unit}.`);
    if (measurement.amount <= limit.maximum) continue;
    if (limit.enforcement === "hard") exceededIds.push(limit.id);
    else warnings.push(limit.id);
  }
  return Object.freeze({ conformant: exceededIds.length === 0, exceededIds: Object.freeze(exceededIds), warnings: Object.freeze(warnings), unreportedIds: Object.freeze(unreportedIds) });
}

function canonicalValue(value) {
  if (Array.isArray(value)) return value.map(canonicalValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.keys(value).sort().map((key) => [key, canonicalValue(value[key])]));
  }
  return value;
}

export function stableStringify(value) {
  return JSON.stringify(canonicalValue(value));
}

export function inputSignature(value) {
  return `sha256:${createHash("sha256").update(stableStringify(value)).digest("hex")}`;
}

function edgeKind(value) {
  const kind = requiredText(value, "Dependency edge kind");
  if (!EDGE_KINDS.includes(kind) && !kind.includes(":")) {
    throw new TypeError(`Unknown shared edge kind ${kind}; product edge kinds must be namespaced.`);
  }
  return kind;
}

export function defineGraph(source) {
  const value = plainObject(source, "Graph");
  const workspaceId = requiredText(value.workspaceId, "Graph workspaceId");
  const nodes = (value.nodes || []).map((node, index) => {
    const item = plainObject(node, `Node ${index}`);
    return Object.freeze({ ...item, id: requiredText(item.id, `Node ${index} id`), workspaceId: requiredText(item.workspaceId, `Node ${index} workspaceId`) });
  });
  const nodeIds = new Set(nodes.map(({ id }) => id));
  if (nodeIds.size !== nodes.length) throw new TypeError("Graph node ids must be unique.");
  for (const node of nodes) if (node.workspaceId !== workspaceId) throw new TypeError(`Node ${node.id} crosses the graph workspace boundary.`);
  const edges = (value.edges || []).map((edge, index) => {
    const item = plainObject(edge, `Edge ${index}`);
    const normalized = {
      ...item,
      id: requiredText(item.id, `Edge ${index} id`),
      kind: edgeKind(item.kind),
      sourceId: requiredText(item.sourceId, `Edge ${index} sourceId`),
      targetId: requiredText(item.targetId, `Edge ${index} targetId`)
    };
    if (!nodeIds.has(normalized.sourceId) || !nodeIds.has(normalized.targetId)) throw new TypeError(`Edge ${normalized.id} references an unknown node.`);
    return Object.freeze(normalized);
  });
  if (new Set(edges.map(({ id }) => id)).size !== edges.length) throw new TypeError("Graph edge ids must be unique.");
  return Object.freeze({ ...value, workspaceId, nodes: Object.freeze(nodes), edges: Object.freeze(edges) });
}

export function invalidatedNodeIds(graphSource, changedNodeIds) {
  const graph = defineGraph(graphSource);
  const changed = new Set(changedNodeIds || []);
  const unknown = [...changed].filter((id) => !graph.nodes.some((node) => node.id === id));
  if (unknown.length) throw new TypeError(`Changed node ids are unknown: ${unknown.join(", ")}.`);
  const invalidated = new Set();
  const queue = [...changed];
  while (queue.length) {
    const sourceId = queue.shift();
    for (const edge of graph.edges) {
      if (edge.sourceId !== sourceId || !INVALIDATING_EDGE_KINDS.has(edge.kind)) continue;
      if (changed.has(edge.targetId) || invalidated.has(edge.targetId)) continue;
      invalidated.add(edge.targetId);
      queue.push(edge.targetId);
    }
  }
  return graph.nodes.map(({ id }) => id).filter((id) => invalidated.has(id));
}

export function defineWorkEnvelope(source) {
  const value = plainObject(source, "Work envelope");
  const envelope = {
    ...value,
    protocolVersion: requiredText(value.protocolVersion, "Work envelope protocolVersion"),
    workspaceId: requiredText(value.workspaceId, "Work envelope workspaceId"),
    runId: requiredText(value.runId, "Work envelope runId"),
    workUnitId: requiredText(value.workUnitId, "Work envelope workUnitId"),
    attemptId: requiredText(value.attemptId, "Work envelope attemptId"),
    claimGeneration: Number(value.claimGeneration),
    inputSignature: requiredText(value.inputSignature, "Work envelope inputSignature"),
    placementPolicy: plainObject(value.placementPolicy, "Work envelope placementPolicy"),
    budget: defineWorkBudget(value.budget)
  };
  if (!Number.isSafeInteger(envelope.claimGeneration) || envelope.claimGeneration < 1) throw new TypeError("Work envelope claimGeneration must be a positive integer.");
  for (const field of ["hostname", "pid", "loopbackUrl", "absolutePath"]) {
    if (Object.hasOwn(envelope, field)) throw new TypeError(`Work envelope durable identity cannot contain ${field}.`);
  }
  return Object.freeze(envelope);
}

export function defineActivityEnvelope(source) {
  const value = plainObject(source, "Activity envelope");
  const progress = value.progress == null ? null : (() => {
    const sourceProgress = plainObject(value.progress, "Activity progress");
    const completed = finiteNonnegative(sourceProgress.completed, "Activity progress completed");
    const total = finiteNonnegative(sourceProgress.total, "Activity progress total");
    if (total <= 0 || completed > total) throw new TypeError("Activity progress requires 0 <= completed <= total and total > 0.");
    return Object.freeze({ ...sourceProgress, completed, total, unit: requiredText(sourceProgress.unit, "Activity progress unit") });
  })();
  const envelope = {
    ...value,
    protocolVersion: requiredText(value.protocolVersion, "Activity envelope protocolVersion"),
    workspaceId: requiredText(value.workspaceId, "Activity envelope workspaceId"),
    runId: requiredText(value.runId, "Activity envelope runId"),
    workUnitId: requiredText(value.workUnitId, "Activity envelope workUnitId"),
    attemptId: requiredText(value.attemptId, "Activity envelope attemptId"),
    claimGeneration: Number(value.claimGeneration),
    inputSignature: requiredText(value.inputSignature, "Activity envelope inputSignature"),
    phase: requiredText(value.phase, "Activity envelope phase"),
    detail: value.detail == null ? null : requiredText(value.detail, "Activity envelope detail"),
    progress
  };
  if (!Number.isSafeInteger(envelope.claimGeneration) || envelope.claimGeneration < 1) throw new TypeError("Activity envelope claimGeneration must be a positive integer.");
  for (const field of ["hostname", "pid", "loopbackUrl", "absolutePath"]) {
    if (Object.hasOwn(envelope, field)) throw new TypeError(`Activity envelope durable identity cannot contain ${field}.`);
  }
  return Object.freeze(envelope);
}

export function authorizePlacement(workEnvelope, worker) {
  const envelope = defineWorkEnvelope(workEnvelope);
  const candidate = plainObject(worker, "Worker placement");
  const workerId = requiredText(candidate.id, "Worker placement id");
  const location = requiredText(candidate.location, "Worker placement location");
  const allowed = envelope.placementPolicy.mode === "local-only"
    ? location === "local" && (!envelope.placementPolicy.machineId || envelope.placementPolicy.machineId === candidate.machineId)
    : (envelope.placementPolicy.allowedWorkerIds || []).includes(workerId);
  return Object.freeze({ allowed, workerId, reason: allowed ? "placement-authorized" : "placement-not-authorized" });
}

export function defineResultEnvelope(source) {
  const value = plainObject(source, "Result envelope");
  return Object.freeze({
    ...value,
    protocolVersion: requiredText(value.protocolVersion, "Result envelope protocolVersion"),
    workspaceId: requiredText(value.workspaceId, "Result envelope workspaceId"),
    runId: requiredText(value.runId, "Result envelope runId"),
    workUnitId: requiredText(value.workUnitId, "Result envelope workUnitId"),
    attemptId: requiredText(value.attemptId, "Result envelope attemptId"),
    claimGeneration: Number(value.claimGeneration),
    inputSignature: requiredText(value.inputSignature, "Result envelope inputSignature"),
    status: requiredText(value.status, "Result envelope status"),
    usage: defineWorkUsage(value.usage || [])
  });
}

export function classifyResult(workEnvelope, resultEnvelope) {
  const work = defineWorkEnvelope(workEnvelope);
  const result = defineResultEnvelope(resultEnvelope);
  const current = sameClaim(work, result);
  return Object.freeze({
    retained: true,
    applicable: current && result.status === "succeeded",
    disposition: current ? result.status : "stale-result"
  });
}

function sameClaim(work, candidate) {
  return ["protocolVersion", "workspaceId", "runId", "workUnitId", "attemptId"]
    .every((field) => work[field] === candidate[field])
    && work.claimGeneration === candidate.claimGeneration
    && work.inputSignature === candidate.inputSignature;
}

export function classifyActivity(workEnvelope, activityEnvelope) {
  const work = defineWorkEnvelope(workEnvelope);
  const activity = defineActivityEnvelope(activityEnvelope);
  const applicable = sameClaim(work, activity);
  return Object.freeze({ retained: true, applicable, disposition: applicable ? "current" : "stale-activity" });
}
