# @inator/engine

Early, headless contracts and a first durable vertical slice for Inator
computation. The package contains no product stages, UI, provider client,
ambient workspace authority, or service installation behavior.

rho.inator is the first durable-control-plane consumer. Its synthetic
evidence-refinement workflow exercises exact input signatures, typed
dependencies, retained attempts, selective invalidation, claim generations,
and local-only worker placement. book.inator is the production presentation and
protocol exemplar through a Python adapter; its successful real chapter run is
evidence for the shared contract, not a reason to make Node authoritative.

This package is deliberately pre-release.

## Observable demo runner

`createDemoPipeline()` (also available from the browser-safe
`@inator/engine/demo` subpath) is a deliberately slow, headless pipeline used by the
Commons engine-room lab and consumer conformance tests. Its default tasks wait
two seconds apiece. It exercises one authoritative job at a time, monotonically
increasing claim generations, task-boundary stopping, requested failure, retry,
and retained attempt history. Products may replace its task names while keeping
the same lifecycle; it is not a production scheduler.

## Durable vertical slice

`DurableControlPlane` replays an append-only JSONL ledger, reconstructs eligible
work after restart, issues leased claims, retains every result, and prevents an
expired worker from applying a late result after a newer generation claims the
same unit.

Long-running workers can report transport-neutral activity envelopes through
`reportActivity()`. The control plane saves every report on its attempt,
projects only the authoritative generation as current, and renews that claim's
lease. `executeWork()` passes handlers `reportActivity` and `reportUsage`
callbacks, so model calls and large deterministic imports can expose real
subphases and measurements without changing their product output contract.

Work budgets are named limits rather than model-specific fields. For example,
a consumer may separately declare `source-input`, `model-output`,
`verification-output`, and `wall-clock` limits in records, tokens, bytes, or
seconds. `assessWorkBudget()` compares retained attempt usage with that policy;
the engine never invents usage a provider or worker did not report. A worker or
provider adapter enforces hard limits before or during execution; assessment
records overruns but cannot retroactively stop computation that already ran.

Atomic pipeline units may also carry an optional app-supplied `estimate` with
`durationMs`, a human-readable `basis`, `confidence`, and optional provenance
fields. Products own the predictor because they understand meaningful input
size, model identity, fixed overhead, and comparable work. Shared pipeline UI
uses that estimate first, then falls back to observed timings for the same
method, and finally to a coarse whole-pipeline median. An absent estimate is
valid; Commons must not invent product-specific scaling variables.

`installJsonLineWorker()` is the first worker-process adapter. The included
`inator-demo-worker` executable accepts one bounded work envelope per line on
standard input and returns one result envelope per line on standard output. It
is a proving transport, not the final local socket or LaunchAgent runtime.
Neither side opens a product database or scans a workspace.

Model providers remain outside the engine. `@inator/models` supplies a
`createModelWorkHandler()` adapter that plugs into `executeWork()` under a
namespaced method such as `models.invoke`; the durable engine sees only the
transport-neutral work and result envelopes.
