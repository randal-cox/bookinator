import { installFileIntake } from "./intake.js";

export const WORKSPACE_BACKUP_VIEW_STATES = Object.freeze([
  "idle",
  "inspecting",
  "valid",
  "invalid",
  "working",
  "complete",
  "failed"
]);

function optionalText(value) {
  return String(value ?? "").trim() || null;
}

function normalizeState(value, fallback = "idle") {
  return WORKSPACE_BACKUP_VIEW_STATES.includes(value) ? value : fallback;
}

export function normalizeWorkspaceBackupView(input = {}) {
  return {
    workspaceName: optionalText(input.workspaceName) || "Current workspace",
    backup: {
      state: normalizeState(input.backup?.state),
      detail: optionalText(input.backup?.detail)
    },
    restore: {
      state: normalizeState(input.restore?.state),
      fileName: optionalText(input.restore?.fileName),
      destination: optionalText(input.restore?.destination),
      summary: optionalText(input.restore?.summary),
      errors: (input.restore?.errors || []).map((value) => String(value).trim()).filter(Boolean)
    }
  };
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
}

function actionButton(label, action, model, onAction, { disabled = false, busy = false } = {}) {
  const button = element("button", "inator-workspace-backup__action", label);
  button.type = "button";
  button.disabled = disabled || busy;
  if (busy) button.setAttribute("aria-busy", "true");
  button.addEventListener("click", () => onAction?.({ action, model }));
  return button;
}

function render(mount, rawModel, onAction, { wording = {}, destinationMode = "choose", accept = ".inator-backup,.zip,application/zip" } = {}) {
  const model = normalizeWorkspaceBackupView(rawModel);
  const labels = {
    title: wording.title || "Backup and restore",
    backupHeading: wording.backupHeading || "Backup",
    backupDescription: wording.backupDescription || "Create a complete portable copy of this workspace.",
    backupAction: wording.backupAction || "Create backup",
    restoreHeading: wording.restoreHeading || "Restore",
    restoreDescription: wording.restoreDescription || "Inspect a backup, then restore it to a new local destination.",
    chooseBackup: wording.chooseBackup || "Choose or drop a workspace backup",
    restoreSafety: wording.restoreSafety || "The existing workspace will not be changed",
    chooseDestination: wording.chooseDestination || "Choose new destination",
    noDestination: wording.noDestination || "No destination chosen",
    fixedDestination: wording.fixedDestination || "Current application",
    restoreAction: wording.restoreAction || "Restore workspace"
  };
  const article = element("article", "inator-workspace-backup");
  const header = element("header", "inator-workspace-backup__header");
  header.append(
    element("h2", "", labels.title),
    element("p", "", model.workspaceName)
  );

  const backup = element("section", "inator-workspace-backup__section");
  backup.append(
    element("h3", "", labels.backupHeading),
    element("p", "", labels.backupDescription)
  );
  backup.append(actionButton(labels.backupAction, "backup", model, onAction, {
    busy: model.backup.state === "working"
  }));
  if (model.backup.detail) backup.append(element("p", "inator-workspace-backup__result", model.backup.detail));

  const restore = element("section", "inator-workspace-backup__section");
  restore.append(
    element("h3", "", labels.restoreHeading),
    element("p", "", labels.restoreDescription)
  );

  const well = element("button", "inator-workspace-backup__well");
  well.type = "button";
  well.append(
    element("strong", "", model.restore.fileName || labels.chooseBackup),
    element("small", "", model.restore.state === "inspecting" ? "Inspecting…" : labels.restoreSafety)
  );
  restore.append(well);

  const status = element("div", "inator-workspace-backup__status");
  status.dataset.state = model.restore.state;
  status.setAttribute("role", model.restore.state === "invalid" || model.restore.state === "failed" ? "alert" : "status");
  if (model.restore.summary) status.append(element("p", "", model.restore.summary));
  if (model.restore.errors.length) {
    const list = element("ul", "");
    for (const message of model.restore.errors) list.append(element("li", "", message));
    status.append(list);
  }
  if (status.childElementCount) restore.append(status);

  if (destinationMode !== "none") {
    const destination = element("div", "inator-workspace-backup__destination");
    if (destinationMode === "choose") {
      destination.append(actionButton(labels.chooseDestination, "choose-destination", model, onAction, {
        disabled: model.restore.state !== "valid"
      }));
    } else {
      destination.append(element("strong", "", "Restore target"));
    }
    destination.append(element("span", "", model.restore.destination || (destinationMode === "fixed" ? labels.fixedDestination : labels.noDestination)));
    restore.append(destination);
  }
  restore.append(actionButton(labels.restoreAction, "restore", model, onAction, {
    disabled: model.restore.state !== "valid" || (destinationMode === "choose" && !model.restore.destination),
    busy: model.restore.state === "working"
  }));

  article.append(header, backup, restore);
  mount.replaceChildren(article);
  const intake = installFileIntake(well, {
    accept,
    multiple: false,
    onFiles: (files) => onAction?.({ action: "inspect-backup", files, model })
  });
  return { model, intake };
}

export function createWorkspaceBackupView({ mount, model, onAction, wording, destinationMode, accept } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createWorkspaceBackupView requires a DOM mount element.");
  const options = { wording, destinationMode, accept };
  let current = render(mount, model, onAction, options);
  return {
    get model() { return current.model; },
    update(nextModel) {
      current.intake.destroy();
      current = render(mount, nextModel, onAction, options);
      return current.model;
    },
    destroy() {
      current.intake.destroy();
      mount.replaceChildren();
    }
  };
}
