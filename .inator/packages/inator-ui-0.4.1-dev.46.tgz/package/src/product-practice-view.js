import { PRODUCT_PRIVACY_SCHEMA, PRODUCT_SECURITY_SCHEMA, defineProductPrivacy, defineProductSecurity } from "./product-practice.js";

const element = (tag, className, text) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
};

const titleCase = (value) => String(value).replace(/-/g, " ").replace(/\b\w/g, (letter) => letter.toUpperCase());

function evidenceList(ids, byId) {
  const list = element("ul", "inator-practice-evidence");
  for (const id of ids) {
    const item = byId.get(id);
    const row = element("li");
    row.append(element("strong", "", item.title), document.createTextNode(` — ${item.verifies} (${item.verifiedAt})`));
    list.append(row);
  }
  return list;
}

function recordCard(record, byId, kind = "practice") {
  const card = element("article", `inator-practice-card inator-practice-card--${record.status}`);
  const header = element("header");
  header.append(element("h2", "", record.title), element("span", "inator-practice-status", titleCase(record.status)));
  card.append(header, element("p", "inator-practice-detail", record.detail));
  if (kind === "security") {
    const meta = element("dl", "inator-practice-meta");
    meta.append(element("dt", "", "Objective"), element("dd", "", record.objective), element("dt", "", "Responsibility"), element("dd", "", titleCase(record.responsibility)));
    card.append(meta);
  }
  if (record.evidenceIds.length) card.append(evidenceList(record.evidenceIds, byId));
  else card.append(element("p", "inator-practice-no-evidence", "No evidence is cited for this claim."));
  return card;
}

function shell(manifest, label) {
  const root = element("div", "inator-practice-view");
  const hero = element("header", "inator-practice-hero");
  hero.append(element("p", "inator-information-kicker", `${manifest.product} ${label}`), element("h1", "", label), element("p", "", manifest.summary), element("small", "", `Record updated ${manifest.updatedAt}`));
  root.append(hero);
  return root;
}

function exceptionsSection(records) {
  if (!records.length) return null;
  const section = element("section", "inator-practice-exceptions");
  section.append(element("h2", "", "Named exceptions"));
  for (const record of records) section.append(element("p", "", `${record.title}: ${record.reason} Owner: ${record.owner}. Review by ${record.reviewBy}.`));
  return section;
}

export function createProductPrivacyView({ mount, privacy } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createProductPrivacyView requires a DOM mount element.");
  const manifest = privacy?.schema === PRODUCT_PRIVACY_SCHEMA ? privacy : defineProductPrivacy(privacy);
  const root = shell(manifest, "Privacy & verified practice");
  const boundary = element("section", "inator-practice-boundary");
  boundary.append(element("h2", "", "Data and network boundary"), element("p", "", manifest.networkBoundary));
  const data = element("section", "inator-practice-data");
  data.append(element("h2", "", "What happens to information"));
  for (const item of manifest.data) {
    const details = element("article", "inator-practice-data-card");
    details.append(element("h3", "", item.title));
    const list = element("dl", "inator-practice-meta");
    for (const [term, value] of [["Purpose", item.purpose], ["Handling", item.handling], ["Lives in", item.location], ["Recipients", item.recipients], ["Retention", item.retention], ["Your controls", item.controls]]) list.append(element("dt", "", term), element("dd", "", value));
    details.append(list); data.append(details);
  }
  const claims = element("section", "inator-practice-claims");
  claims.append(element("h2", "", "Verified practices"));
  const byId = new Map(manifest.evidence.map((item) => [item.id, item]));
  for (const record of manifest.practices) claims.append(recordCard(record, byId));
  root.append(boundary, data, claims);
  const namedExceptions = exceptionsSection(manifest.exceptions); if (namedExceptions) root.append(namedExceptions);
  mount.replaceChildren(root);
  return Object.freeze({ manifest, root, destroy: () => root.remove() });
}

export function createProductSecurityView({ mount, security } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createProductSecurityView requires a DOM mount element.");
  const manifest = security?.schema === PRODUCT_SECURITY_SCHEMA ? security : defineProductSecurity(security);
  const root = shell(manifest, "Security & assurance");
  const profiles = element("section", "inator-practice-profiles"); profiles.append(element("h2", "", "Deployment profiles and responsibility"));
  for (const profile of manifest.profiles) {
    const card = element("article", "inator-practice-data-card");
    card.append(element("h3", "", profile.title), element("p", "", profile.boundary), element("p", "", `Responsibility: ${profile.responsibility}`)); profiles.append(card);
  }
  const controls = element("section", "inator-practice-claims"); controls.append(element("h2", "", "Control summary"));
  const byId = new Map(manifest.evidence.map((item) => [item.id, item]));
  for (const record of manifest.controls) controls.append(recordCard(record, byId, "security"));
  root.append(profiles, controls);
  const namedExceptions = exceptionsSection(manifest.exceptions); if (namedExceptions) root.append(namedExceptions);
  mount.replaceChildren(root);
  return Object.freeze({ manifest, root, destroy: () => root.remove() });
}
