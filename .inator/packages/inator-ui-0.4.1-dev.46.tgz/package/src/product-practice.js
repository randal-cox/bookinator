export const PRODUCT_PRIVACY_SCHEMA = "inator.product-privacy.v1";
export const PRODUCT_SECURITY_SCHEMA = "inator.product-security.v1";
export const PRACTICE_STATUSES = Object.freeze(["implemented", "partial", "planned", "unavailable", "not-applicable"]);
export const SECURITY_RESPONSIBILITIES = Object.freeze(["product", "host", "customer", "shared", "not-applicable"]);

const requiredText = (value, field) => {
  const text = String(value ?? "").trim();
  if (!text) throw new TypeError(`${field} is required.`);
  return text;
};

const optionalText = (value) => String(value ?? "").trim() || null;

function isoDate(value, field) {
  const date = requiredText(value, field);
  const parsed = new Date(`${date}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== date) {
    throw new TypeError(`${field} must use a real YYYY-MM-DD date: ${date}`);
  }
  return date;
}

function uniqueRecords(records, label, normalize) {
  const ids = new Set();
  return Object.freeze((records || []).map((record, index) => {
    const id = requiredText(record?.id, `${label}[${index}].id`);
    if (ids.has(id)) throw new TypeError(`Duplicate ${label} id: ${id}`);
    ids.add(id);
    return Object.freeze({ id, ...normalize(record, `${label}[${index}]`) });
  }));
}

function evidence(records = []) {
  return uniqueRecords(records, "evidence", (record, field) => Object.freeze({
    title: requiredText(record.title, `${field}.title`),
    verifies: requiredText(record.verifies, `${field}.verifies`),
    kind: requiredText(record.kind, `${field}.kind`),
    locator: optionalText(record.locator),
    verifiedAt: isoDate(record.verifiedAt, `${field}.verifiedAt`),
    audience: optionalText(record.audience) || "public"
  }));
}

function exceptions(records = []) {
  return uniqueRecords(records, "exceptions", (record, field) => Object.freeze({
    title: requiredText(record.title, `${field}.title`),
    reason: requiredText(record.reason, `${field}.reason`),
    owner: requiredText(record.owner, `${field}.owner`),
    reviewBy: isoDate(record.reviewBy, `${field}.reviewBy`),
    status: normalizeStatus(record.status || "partial", `${field}.status`)
  }));
}

function normalizeStatus(value, field) {
  const status = requiredText(value, field);
  if (!PRACTICE_STATUSES.includes(status)) throw new TypeError(`${field} must be one of: ${PRACTICE_STATUSES.join(", ")}.`);
  return status;
}

function evidenceIds(record, knownEvidence, field) {
  const ids = Object.freeze([...new Set((record.evidenceIds || []).map((id) => requiredText(id, field))) ]);
  for (const id of ids) if (!knownEvidence.has(id)) throw new TypeError(`${field} references unknown evidence: ${id}`);
  return ids;
}

export function defineProductPrivacy(source = {}) {
  const normalizedEvidence = evidence(source.evidence);
  const knownEvidence = new Set(normalizedEvidence.map(({ id }) => id));
  const data = uniqueRecords(source.data, "data", (record, field) => Object.freeze({
    title: requiredText(record.title, `${field}.title`),
    purpose: requiredText(record.purpose, `${field}.purpose`),
    handling: requiredText(record.handling, `${field}.handling`),
    location: requiredText(record.location, `${field}.location`),
    recipients: requiredText(record.recipients, `${field}.recipients`),
    retention: requiredText(record.retention, `${field}.retention`),
    controls: requiredText(record.controls, `${field}.controls`)
  }));
  const practices = uniqueRecords(source.practices, "practices", (record, field) => Object.freeze({
    title: requiredText(record.title, `${field}.title`),
    status: normalizeStatus(record.status, `${field}.status`),
    detail: requiredText(record.detail, `${field}.detail`),
    evidenceIds: evidenceIds(record, knownEvidence, `${field}.evidenceIds`)
  }));
  return Object.freeze({
    schema: PRODUCT_PRIVACY_SCHEMA,
    product: requiredText(source.product, "product"),
    updatedAt: isoDate(source.updatedAt, "updatedAt"),
    summary: requiredText(source.summary, "summary"),
    networkBoundary: requiredText(source.networkBoundary, "networkBoundary"),
    data,
    practices,
    evidence: normalizedEvidence,
    exceptions: exceptions(source.exceptions)
  });
}

export function defineProductSecurity(source = {}) {
  const normalizedEvidence = evidence(source.evidence);
  const knownEvidence = new Set(normalizedEvidence.map(({ id }) => id));
  const profiles = uniqueRecords(source.profiles, "profiles", (record, field) => Object.freeze({
    title: requiredText(record.title, `${field}.title`),
    boundary: requiredText(record.boundary, `${field}.boundary`),
    responsibility: requiredText(record.responsibility, `${field}.responsibility`)
  }));
  const controls = uniqueRecords(source.controls, "controls", (record, field) => {
    const responsibility = requiredText(record.responsibility, `${field}.responsibility`);
    if (!SECURITY_RESPONSIBILITIES.includes(responsibility)) throw new TypeError(`${field}.responsibility must be one of: ${SECURITY_RESPONSIBILITIES.join(", ")}.`);
    return Object.freeze({
      title: requiredText(record.title, `${field}.title`),
      objective: requiredText(record.objective, `${field}.objective`),
      status: normalizeStatus(record.status, `${field}.status`),
      responsibility,
      detail: requiredText(record.detail, `${field}.detail`),
      evidenceIds: evidenceIds(record, knownEvidence, `${field}.evidenceIds`)
    });
  });
  return Object.freeze({
    schema: PRODUCT_SECURITY_SCHEMA,
    product: requiredText(source.product, "product"),
    updatedAt: isoDate(source.updatedAt, "updatedAt"),
    summary: requiredText(source.summary, "summary"),
    profiles,
    controls,
    evidence: normalizedEvidence,
    exceptions: exceptions(source.exceptions)
  });
}
