export const LIST_PREFERENCES_SCHEMA = "inator.list-preferences.v1";

const normalizedText = (value) => String(value ?? "")
  .normalize("NFKD")
  .replace(/\p{M}/gu, "")
  .toLocaleLowerCase()
  .replace(/[\p{P}\p{S}\s]+/gu, "");

const compareValues = (left, right) => {
  if (left == null && right == null) return 0;
  if (left == null) return 1;
  if (right == null) return -1;
  if (typeof left === "number" && typeof right === "number") return left - right;
  if (left instanceof Date && right instanceof Date) return left.getTime() - right.getTime();
  return String(left).localeCompare(String(right), undefined, { numeric: true, sensitivity: "base" });
};

function normalizeColumns(columns) {
  const ids = new Set();
  return columns.map((column) => {
    const id = String(column.id ?? "").trim();
    if (!id) throw new TypeError("Every list column needs an id");
    if (ids.has(id)) throw new TypeError(`Duplicate list column id: ${id}`);
    ids.add(id);
    const value = typeof column.value === "function" ? column.value : (record) => record[id];
    return Object.freeze({
      ...column,
      id,
      label: String(column.label ?? id),
      required: Boolean(column.required),
      sortable: column.sortable !== false,
      searchable: column.searchable !== false,
      visible: column.visible !== false,
      value,
      searchValue: typeof column.searchValue === "function" ? column.searchValue : value,
      filterValue: typeof column.filterValue === "function" ? column.filterValue : value,
      format: typeof column.format === "function" ? column.format : (raw) => String(raw ?? "")
    });
  });
}

const normalizeFilters = (filters = {}) => new Map(
  Object.entries(filters)
    .map(([id, values]) => [id, new Set(Array.isArray(values) ? values.map(String) : [String(values)])])
    .filter(([, values]) => values.size)
);

const normalizePageSize = (value, fallback = 10) => {
  const candidate = Number(value);
  return Number.isInteger(candidate) && candidate > 0 ? candidate : fallback;
};

export function createListModel({ columns, records = [], getId = (record) => record.id, initialState = {} }) {
  const normalizedColumns = normalizeColumns(columns);
  const columnsById = new Map(normalizedColumns.map((column) => [column.id, column]));
  const initialVisible = new Set(initialState.visibleColumns ?? normalizedColumns.filter((column) => column.visible).map((column) => column.id));
  normalizedColumns.filter((column) => column.required).forEach((column) => initialVisible.add(column.id));

  let sourceRecords = [...records];
  let query = String(initialState.query ?? "");
  let filters = normalizeFilters(initialState.filters);
  let sort = initialState.sort?.id && columnsById.get(initialState.sort.id)?.sortable
    ? { id: initialState.sort.id, direction: initialState.sort.direction === "desc" ? "desc" : "asc" }
    : null;
  let visibleColumns = new Set([...initialVisible].filter((id) => columnsById.has(id)));
  let selectedIds = new Set(initialState.selectedIds ?? []);
  let rememberedSelection = new Set(initialState.rememberedSelection ?? []);
  let pageSize = normalizePageSize(initialState.pageSize);
  let page = Number.isInteger(initialState.page) && initialState.page > 0 ? initialState.page : 1;

  const recordId = (record) => String(getId(record));

  function matchingRecords() {
    const needle = normalizedText(query);
    const filtered = sourceRecords.filter((record) => {
      if (needle && !normalizedColumns.some((column) => column.searchable && normalizedText(column.searchValue(record)).includes(needle))) return false;
      for (const [id, accepted] of filters) {
        const column = columnsById.get(id);
        if (!column) continue;
        const raw = column.filterValue(record);
        const values = (Array.isArray(raw) ? raw : [raw]).map((value) => String(value));
        if (!values.some((value) => accepted.has(value))) return false;
      }
      return true;
    });
    if (!sort) return filtered;
    const column = columnsById.get(sort.id);
    const direction = sort.direction === "desc" ? -1 : 1;
    return filtered
      .map((record, index) => ({ record, index }))
      .sort((left, right) => direction * compareValues(column.value(left.record), column.value(right.record)) || left.index - right.index)
      .map(({ record }) => record);
  }

  function selectionFor(recordsInView) {
    const ids = recordsInView.map(recordId);
    const selectedVisible = ids.filter((id) => selectedIds.has(id));
    return {
      selectedCount: selectedVisible.length,
      totalCount: ids.length,
      checked: ids.length > 0 && selectedVisible.length === ids.length,
      indeterminate: selectedVisible.length > 0 && selectedVisible.length < ids.length,
      visibleIds: ids
    };
  }

  function snapshot() {
    const matching = matchingRecords();
    const pageCount = Math.max(1, Math.ceil(matching.length / pageSize));
    page = Math.min(Math.max(page, 1), pageCount);
    const startIndex = matching.length ? (page - 1) * pageSize : 0;
    const currentRecords = matching.slice(startIndex, startIndex + pageSize);
    return {
      records: [...sourceRecords],
      visibleRecords: currentRecords,
      columns: normalizedColumns.filter((column) => visibleColumns.has(column.id)),
      allColumns: [...normalizedColumns],
      query,
      filters: Object.fromEntries([...filters].map(([id, values]) => [id, [...values]])),
      sort: sort ? { ...sort } : null,
      selectedIds: new Set(selectedIds),
      selection: selectionFor(currentRecords),
      pagination: {
        page,
        pageSize,
        pageCount,
        startIndex,
        endIndex: startIndex + currentRecords.length,
        matchingCount: matching.length,
        hasPrevious: page > 1,
        hasNext: page < pageCount
      }
    };
  }

  const api = {
    snapshot,
    setRecords(nextRecords) {
      sourceRecords = [...nextRecords];
      const validIds = new Set(sourceRecords.map(recordId));
      selectedIds = new Set([...selectedIds].filter((id) => validIds.has(id)));
      rememberedSelection = new Set([...rememberedSelection].filter((id) => validIds.has(id)));
      return snapshot();
    },
    setQuery(nextQuery) { query = String(nextQuery ?? ""); page = 1; return snapshot(); },
    setFilter(columnId, values) {
      if (!columnsById.has(columnId)) throw new TypeError(`Unknown list column: ${columnId}`);
      const next = new Set((Array.isArray(values) ? values : values == null || values === "" ? [] : [values]).map(String));
      if (next.size) filters.set(columnId, next); else filters.delete(columnId);
      page = 1;
      return snapshot();
    },
    sortBy(columnId) {
      const column = columnsById.get(columnId);
      if (!column?.sortable) return snapshot();
      sort = sort?.id === columnId
        ? { id: columnId, direction: sort.direction === "asc" ? "desc" : "asc" }
        : { id: columnId, direction: "asc" };
      page = 1;
      return snapshot();
    },
    setColumnVisible(columnId, visible) {
      const column = columnsById.get(columnId);
      if (!column) throw new TypeError(`Unknown list column: ${columnId}`);
      if (column.required || visible) visibleColumns.add(columnId); else visibleColumns.delete(columnId);
      return snapshot();
    },
    toggleSelection(id) {
      const key = String(id);
      selectedIds.has(key) ? selectedIds.delete(key) : selectedIds.add(key);
      const state = selectionFor(snapshot().visibleRecords);
      if (state.indeterminate) rememberedSelection = new Set(state.visibleIds.filter((visibleId) => selectedIds.has(visibleId)));
      return snapshot();
    },
    cycleVisibleSelection() {
      const state = selectionFor(snapshot().visibleRecords);
      if (state.indeterminate) {
        rememberedSelection = new Set(state.visibleIds.filter((id) => selectedIds.has(id)));
        state.visibleIds.forEach((id) => selectedIds.add(id));
      } else if (state.checked) {
        state.visibleIds.forEach((id) => selectedIds.delete(id));
      } else {
        const remembered = state.visibleIds.filter((id) => rememberedSelection.has(id));
        (remembered.length && remembered.length < state.visibleIds.length ? remembered : state.visibleIds).forEach((id) => selectedIds.add(id));
      }
      return snapshot();
    },
    clearSelection() { selectedIds.clear(); return snapshot(); },
    setPage(nextPage) {
      const candidate = Number(nextPage);
      if (Number.isInteger(candidate)) page = candidate;
      return snapshot();
    },
    setPageSize(nextPageSize) {
      pageSize = normalizePageSize(nextPageSize, pageSize);
      page = 1;
      return snapshot();
    },
    preferences() {
      return {
        schema: LIST_PREFERENCES_SCHEMA,
        visibleColumns: normalizedColumns.filter((column) => visibleColumns.has(column.id)).map((column) => column.id),
        sort: sort ? { ...sort } : null,
        filters: Object.fromEntries([...filters].map(([id, values]) => [id, [...values]])),
        pageSize
      };
    },
    applyPreferences(preferences) {
      if (preferences?.schema !== LIST_PREFERENCES_SCHEMA) return snapshot();
      if (Array.isArray(preferences.visibleColumns)) {
        visibleColumns = new Set(preferences.visibleColumns.filter((id) => columnsById.has(id)));
        normalizedColumns.filter((column) => column.required).forEach((column) => visibleColumns.add(column.id));
      }
      if (preferences.sort?.id && columnsById.get(preferences.sort.id)?.sortable) {
        sort = { id: preferences.sort.id, direction: preferences.sort.direction === "desc" ? "desc" : "asc" };
      }
      filters = normalizeFilters(preferences.filters);
      pageSize = normalizePageSize(preferences.pageSize, pageSize);
      page = 1;
      return snapshot();
    },
    reset() {
      query = String(initialState.query ?? "");
      filters = normalizeFilters(initialState.filters);
      sort = initialState.sort?.id && columnsById.get(initialState.sort.id)?.sortable
        ? { id: initialState.sort.id, direction: initialState.sort.direction === "desc" ? "desc" : "asc" }
        : null;
      visibleColumns = new Set(initialVisible);
      selectedIds.clear();
      rememberedSelection.clear();
      pageSize = normalizePageSize(initialState.pageSize);
      page = Number.isInteger(initialState.page) && initialState.page > 0 ? initialState.page : 1;
      return snapshot();
    }
  };
  return api;
}
