function normalizeError(error) {
  const count = Number(error?.count);
  return Number.isSafeInteger(count) && count > 0
    ? {
        count,
        label: String(error?.label || count + " unresolved " + (count === 1 ? "incident" : "incidents"))
      }
    : null;
}

function normalizeStatus(status) {
  if (!status) return null;
  const label = String(typeof status === "string" ? status : status.label || "").trim();
  return label ? { label, tone: String(status.tone || "neutral") } : null;
}

function normalizeUtilityItem(item = {}) {
  if (!item.href || !item.label) return null;
  return {
    ...item,
    href: String(item.href),
    label: String(item.label),
    detail: String(item.detail || ""),
    route: String(item.route || ""),
    ariaLabel: String(item.ariaLabel || ""),
    status: normalizeStatus(item.status),
    error: normalizeError(item.error)
  };
}

export function normalizeProductUtility(utility) {
  if (!utility) return null;
  return {
    ...utility,
    error: normalizeError(utility.error),
    items: (utility.items || []).map(normalizeUtilityItem).filter(Boolean)
  };
}
