const ID = /^[a-z][a-z0-9.-]*$/;
const EVIDENCE_KINDS = new Set(["source", "fixture", "independent-implementation", "observed-data", "human-review"]);
const EVIDENCE_STATUSES = new Set(["supported", "passed", "failed", "inconclusive", "pending"]);
const ARTIFACT_ROLES = new Set(["input", "executable", "expected-output", "configuration", "documentation", "citation"]);
const ARTIFACT_INSPECTION_MODES = new Set(["text", "code", "structured-data", "table"]);

function text(value, label) { const result = String(value ?? "").trim(); if (!result) throw new TypeError(`${label} is required.`); return result; }
function id(value, label) { const result = text(value, label); if (!ID.test(result)) throw new TypeError(`${label} must be a stable lowercase id.`); return result; }
function items(value, label) { if (!Array.isArray(value)) throw new TypeError(`${label} must be an array.`); return value; }
function unique(records, label) { const seen = new Set(); for (const record of records) { if (seen.has(record.id)) throw new TypeError(`${label} ids must be unique: ${record.id}.`); seen.add(record.id); } return records; }
function frozen(record) { return Object.freeze(record); }

export function defineProvenance(source = {}) {
  const inputs = unique(items(source.inputs, "inputs").map((input, index) => frozen({ id: id(input.id, `inputs[${index}].id`), label: text(input.label, `inputs[${index}].label`), ...(input.version ? { version: text(input.version, "input.version") } : {}), ...(input.integrity ? { integrity: normalizeIntegrity(input.integrity, "input.integrity") } : {}) })), "input");
  const steps = unique(items(source.steps, "steps").map((step, index) => frozen({ id: id(step.id, `steps[${index}].id`), label: text(step.label, `steps[${index}].label`), kind: text(step.kind, `steps[${index}].kind`), inputIds: frozen(items(step.inputIds || [], "step.inputIds").map(String)), dependsOnStepIds: frozen(items(step.dependsOnStepIds || [], "step.dependsOnStepIds").map(String)) })), "step");
  const inputIds = new Set(inputs.map((input) => input.id)); const stepIds = new Set(steps.map((step) => step.id));
  for (const step of steps) {
    for (const reference of step.inputIds) if (!inputIds.has(reference)) throw new TypeError(`Step ${step.id} references unknown input ${reference}.`);
    for (const reference of step.dependsOnStepIds) if (!stepIds.has(reference) || reference === step.id) throw new TypeError(`Step ${step.id} references invalid dependency ${reference}.`);
  }
  const claimIds = frozen(items(source.subject?.claimIds || [], "subject.claimIds").map((value, index) => id(value, `subject.claimIds[${index}]`)));
  return frozen({ schema: "inator.provenance.v1", id: id(source.id, "provenance.id"), schemaVersion: text(source.schemaVersion, "provenance.schemaVersion"), subject: frozen({ id: id(source.subject?.id, "subject.id"), label: text(source.subject?.label, "subject.label"), kind: text(source.subject?.kind, "subject.kind"), claimIds }), producer: frozen({ id: id(source.producer?.id, "producer.id"), label: text(source.producer?.label, "producer.label"), version: text(source.producer?.version, "producer.version") }), inputs: frozen(inputs), steps: frozen(steps) });
}

export function defineEvidenceLedger(source = {}) {
  const entries = unique(items(source.entries, "evidence.entries").map((entry, index) => {
    const kind = text(entry.kind, `entries[${index}].kind`); const status = text(entry.status, `entries[${index}].status`);
    if (!EVIDENCE_KINDS.has(kind)) throw new TypeError(`entries[${index}].kind is unknown.`);
    if (!EVIDENCE_STATUSES.has(status)) throw new TypeError(`entries[${index}].status is unknown.`);
    if (["passed", "failed"].includes(status) && !entry.criterion) throw new TypeError(`entries[${index}].criterion is required for ${status} evidence.`);
    return frozen({ id: id(entry.id, `entries[${index}].id`), claimId: id(entry.claimId, `entries[${index}].claimId`), kind, status, summary: text(entry.summary, `entries[${index}].summary`), ...(entry.basis ? { basis: text(entry.basis, "evidence basis") } : {}), ...(entry.criterion ? { criterion: text(entry.criterion, "evidence criterion") } : {}), ...(entry.result ? { result: text(entry.result, "evidence result") } : {}), ...(entry.source ? { source: frozen({ label: text(entry.source.label, "evidence source label"), href: text(entry.source.href, "evidence source href") }) } : {}), ...(entry.openWork ? { openWork: text(entry.openWork, "evidence openWork") } : {}) });
  }), "evidence entry");
  return frozen({ schema: "inator.evidence-ledger.v1", id: id(source.id, "evidence.id"), entries: frozen(entries) });
}

export function defineLimitations(source = {}) {
  const exclusions = items(source.doesNotEstablish, "limitations.doesNotEstablish").map((value) => text(value, "limitation exclusion"));
  if (!exclusions.length) throw new TypeError("limitations.doesNotEstablish requires at least one explicit boundary.");
  const openQuestions = unique(items(source.openQuestions || [], "limitations.openQuestions").map((question, index) => frozen({ id: id(question.id, `openQuestions[${index}].id`), text: text(question.text, `openQuestions[${index}].text`), status: "open" })), "open question");
  return frozen({ schema: "inator.limitations.v1", id: id(source.id, "limitations.id"), claimId: id(source.claimId, "limitations.claimId"), boundary: text(source.boundary, "limitations.boundary"), doesNotEstablish: frozen(exclusions), openQuestions: frozen(openQuestions) });
}

function normalizeIntegrity(value, label) {
  const algorithm = text(value?.algorithm, `${label}.algorithm`).toLowerCase();
  if (algorithm !== "sha256") throw new TypeError(`${label}.algorithm must be sha256.`);
  const digest = text(value?.value, `${label}.value`);
  if (!/^[a-f0-9]{64}$/i.test(digest)) throw new TypeError(`${label}.value must be a SHA-256 digest.`);
  return frozen({ algorithm, value: digest.toLowerCase() });
}

export function defineReproductionPacket(source = {}) {
  const artifacts = unique(items(source.artifacts, "reproduction.artifacts").map((artifact, index) => {
    const role = id(artifact.role, `artifacts[${index}].role`);
    if (!ARTIFACT_ROLES.has(role) && !role.startsWith("x-")) throw new TypeError(`artifacts[${index}].role is unknown; product extensions must start with x-.`);
    const filename = artifact.filename ? text(artifact.filename, "artifact.filename") : "";
    if (filename && (filename.includes("/") || filename.includes("\\"))) throw new TypeError(`artifacts[${index}].filename must be a portable filename.`);
    let inspection;
    if (artifact.inspection) {
      const mode = id(artifact.inspection.mode, `artifacts[${index}].inspection.mode`);
      if (!ARTIFACT_INSPECTION_MODES.has(mode)) throw new TypeError(`artifacts[${index}].inspection.mode is unknown.`);
      inspection = frozen({ mode, ...(artifact.inspection.syntax ? { syntax: text(artifact.inspection.syntax, "artifact inspection syntax") } : {}), ...(artifact.inspection.description ? { description: text(artifact.inspection.description, "artifact inspection description") } : {}) });
    }
    return frozen({ id: id(artifact.id, `artifacts[${index}].id`), label: text(artifact.label, `artifacts[${index}].label`), role, mediaType: text(artifact.mediaType, `artifacts[${index}].mediaType`), integrity: normalizeIntegrity(artifact.integrity, `artifacts[${index}].integrity`), ...(filename ? { filename } : {}), ...(artifact.instructions ? { instructions: text(artifact.instructions, "artifact.instructions") } : {}), ...(artifact.href ? { href: text(artifact.href, "artifact.href") } : {}), ...(inspection ? { inspection } : {}) });
  }), "artifact");
  return frozen({ schema: "inator.reproduction-packet.v1", id: id(source.id, "reproduction.id"), version: text(source.version, "reproduction.version"), instructions: text(source.instructions, "reproduction.instructions"), expectedOutputs: frozen(items(source.expectedOutputs, "reproduction.expectedOutputs").map((value) => text(value, "expected output"))), artifacts: frozen(artifacts) });
}

export function defineGeneratedArtifactLedger(source = {}) {
  const generatedAt = text(source.generatedAt, "generatedArtifacts.generatedAt");
  if (Number.isNaN(Date.parse(generatedAt))) throw new TypeError("generatedArtifacts.generatedAt must be an ISO-compatible timestamp.");
  const artifacts = unique(items(source.artifacts, "generatedArtifacts.artifacts").map((artifact, index) => {
    const role = id(artifact.role, `generatedArtifacts.artifacts[${index}].role`);
    if (!ARTIFACT_ROLES.has(role) && !role.startsWith("x-")) throw new TypeError(`generatedArtifacts.artifacts[${index}].role is unknown; product extensions must start with x-.`);
    const filename = text(artifact.filename, `generatedArtifacts.artifacts[${index}].filename`);
    if (filename.includes("/") || filename.includes("\\")) throw new TypeError(`generatedArtifacts.artifacts[${index}].filename must be a portable filename.`);
    const mode = id(artifact.inspection?.mode, `generatedArtifacts.artifacts[${index}].inspection.mode`);
    if (!ARTIFACT_INSPECTION_MODES.has(mode)) throw new TypeError(`generatedArtifacts.artifacts[${index}].inspection.mode is unknown.`);
    return frozen({ id: id(artifact.id, `generatedArtifacts.artifacts[${index}].id`), label: text(artifact.label, `generatedArtifacts.artifacts[${index}].label`), role, filename, mediaType: text(artifact.mediaType, `generatedArtifacts.artifacts[${index}].mediaType`), integrity: normalizeIntegrity(artifact.integrity, `generatedArtifacts.artifacts[${index}].integrity`), inspection: frozen({ mode, ...(artifact.inspection.syntax ? { syntax: text(artifact.inspection.syntax, "generated artifact inspection syntax") } : {}), ...(artifact.inspection.description ? { description: text(artifact.inspection.description, "generated artifact inspection description") } : {}) }) });
  }), "generated artifact");
  return frozen({ schema: "inator.generated-artifact-ledger.v1", id: id(source.id, "generatedArtifacts.id"), snapshotId: text(source.snapshotId, "generatedArtifacts.snapshotId"), generatedAt: new Date(generatedAt).toISOString(), artifacts: frozen(artifacts) });
}

export function defineTrustSurface(source = {}) {
  const sections = [source.provenance, source.evidence, source.limitations, source.reproduction].filter(Boolean);
  if (!sections.length) throw new TypeError("A trust surface requires at least one trust contract.");
  const provenance = source.provenance ? defineProvenance(source.provenance) : null;
  const evidence = source.evidence ? defineEvidenceLedger(source.evidence) : null;
  const limitations = source.limitations ? defineLimitations(source.limitations) : null;
  if (provenance) {
    const claimIds = new Set([provenance.subject.id, ...provenance.subject.claimIds]);
    for (const entry of evidence?.entries || []) if (!claimIds.has(entry.claimId)) throw new TypeError(`Evidence ${entry.id} references undeclared claim ${entry.claimId}.`);
    if (limitations && !claimIds.has(limitations.claimId)) throw new TypeError(`Limitations reference undeclared claim ${limitations.claimId}.`);
  }
  return frozen({ schema: "inator.trust-surface.v1", id: id(source.id, "trust.id"), title: text(source.title, "trust.title"), ...(provenance ? { provenance } : {}), ...(evidence ? { evidence } : {}), ...(limitations ? { limitations } : {}), ...(source.reproduction ? { reproduction: defineReproductionPacket(source.reproduction) } : {}) });
}

export const TRUST_EVIDENCE_KINDS = frozen([...EVIDENCE_KINDS]);
export const TRUST_EVIDENCE_STATUSES = frozen([...EVIDENCE_STATUSES]);
export const TRUST_ARTIFACT_ROLES = frozen([...ARTIFACT_ROLES]);
export const TRUST_ARTIFACT_INSPECTION_MODES = frozen([...ARTIFACT_INSPECTION_MODES]);
