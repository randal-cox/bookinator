import { createDialogSurface } from "./dialog.js";

function element(tag, className, value) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (value != null) node.textContent = String(value);
  return node;
}

export function createConfirmationDialog({
  mount = document.body,
  context = "Confirm action",
  title = "Are you sure?",
  message = "",
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  danger = false
} = {}) {
  if (!mount?.append) throw new TypeError("A confirmation dialog requires a mount element.");

  const detailNode = element("p", "inator-confirmation-dialog__detail");
  const status = element("span", "");
  status.dataset.dialogStatus = "";
  status.setAttribute("aria-live", "polite");
  const cancel = element("button", "", cancelLabel);
  cancel.type = "button";
  cancel.dataset.dialogClose = "";
  const confirm = element("button", danger ? "danger" : "primary", confirmLabel);
  confirm.type = "button";

  let pending = null;
  const surface = createDialogSurface({
    mount,
    context,
    title,
    description: message,
    bodyContent: [detailNode],
    footerContent: [status, cancel, confirm],
    className: "inator-confirmation-dialog",
    controllerOptions: {
      initialFocus: () => cancel,
      closeOnBackdrop: false,
      onClose: () => { pending = null; }
    }
  });
  const {
    backdrop,
    dialog,
    contextNode,
    titleNode,
    descriptionNode,
    controller
  } = surface;

  confirm.addEventListener("click", async () => {
    if (!pending?.onConfirm) return;
    controller.setBusy(true, pending.busyMessage || "Working\u2026");
    try {
      await pending.onConfirm();
      controller.close("confirmed", { force: true });
    } catch (error) {
      controller.setBusy(false, "Could not complete action: " + (error?.message || error));
    }
  });

  return {
    open(configuration = {}, opener = document.activeElement) {
      pending = configuration;
      contextNode.textContent = configuration.context || context;
      titleNode.textContent = configuration.title || title;
      descriptionNode.textContent = configuration.message || message;
      descriptionNode.hidden = !descriptionNode.textContent;
      detailNode.textContent = configuration.detail || "";
      detailNode.hidden = !detailNode.textContent;
      cancel.textContent = configuration.cancelLabel || cancelLabel;
      confirm.textContent = configuration.confirmLabel || confirmLabel;
      confirm.className = configuration.danger ?? danger ? "danger" : "primary";
      status.textContent = "";
      controller.setBusy(false);
      controller.open(opener);
    },
    close: controller.close,
    destroy: surface.destroy,
    backdrop,
    dialog
  };
}
