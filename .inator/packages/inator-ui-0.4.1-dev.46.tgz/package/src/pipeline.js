export const PIPELINE_STATUSES = Object.freeze([
  "queued",
  "running",
  "blocked",
  "complete",
  "failed",
  "stopping",
  "stopped",
  "stale",
  "waiting-for-human"
]);

export const PIPELINE_ATTEMPT_STATUSES = Object.freeze([
  "running",
  "succeeded",
  "failed",
  "cancelled",
  "superseded"
]);

export const PIPELINE_CONTROL_KINDS = Object.freeze(["start", "stop", "retry", "reset"]);

const STATUS_META = Object.freeze({
  queued: { label: "Waiting", tone: "quiet", busy: false },
  running: { label: "Running", tone: "active", busy: true },
  blocked: { label: "Blocked", tone: "warning", busy: false },
  complete: { label: "Complete", tone: "success", busy: false },
  failed: { label: "Failed", tone: "danger", busy: false },
  stopping: { label: "Stopping", tone: "warning", busy: true },
  stopped: { label: "Stopped", tone: "quiet", busy: false },
  stale: { label: "Stale", tone: "warning", busy: false },
  "waiting-for-human": { label: "Waiting for a person", tone: "warning", busy: false }
});

const CONTROL_LABELS = Object.freeze({
  start: "Start",
  stop: "Stop",
  retry: "Retry",
  reset: "Start over"
});

function requiredText(value, label) {
  const text = String(value ?? "").trim();
  if (!text) throw new TypeError(`${label} is required.`);
  return text;
}

function optionalText(value) {
  const text = String(value ?? "").trim();
  return text || null;
}

function statusFrom(value, allowed, label, fallback = "queued") {
  const status = value == null ? fallback : String(value);
  if (!allowed.includes(status)) throw new TypeError(`${label} has unsupported status "${status}".`);
  return status;
}

function normalizeProgress(value, label) {
  if (value == null) return null;
  const completed = Number(value.completed);
  const total = Number(value.total);
  if (!Number.isFinite(completed) || !Number.isFinite(total) || completed < 0 || total <= 0 || completed > total) {
    throw new TypeError(`${label} progress requires 0 <= completed <= total and total > 0.`);
  }
  return {
    completed,
    total,
    label: optionalText(value.label),
    basis: optionalText(value.basis),
    percent: (completed / total) * 100
  };
}

function normalizeActivity(value = {}) {
  const state = statusFrom(value.state, PIPELINE_STATUSES, "Pipeline activity", "queued");
  return {
    state,
    text: optionalText(value.text),
    task: optionalText(value.task),
    item: optionalText(value.item),
    actor: optionalText(value.actor)
  };
}

function normalizeDiagnostic(value = {}, index) {
  const severity = ["info", "warning", "error"].includes(value.severity)
    ? value.severity
    : "error";
  return {
    code: optionalText(value.code) || `DIAGNOSTIC_${index + 1}`,
    message: requiredText(value.message, `Diagnostic ${index + 1} message`),
    severity
  };
}

function normalizeAttempt(value = {}, stageId, index) {
  const durationSeconds = value.durationSeconds == null ? null : Number(value.durationSeconds);
  return {
    id: requiredText(value.id, `Attempt ${index + 1} id`),
    status: statusFrom(value.status, PIPELINE_ATTEMPT_STATUSES, `Attempt ${value.id || index + 1}`, "running"),
    actor: optionalText(value.actor),
    method: optionalText(value.method),
    startedAt: optionalText(value.startedAt),
    completedAt: optionalText(value.completedAt),
    durationSeconds: Number.isFinite(durationSeconds) && durationSeconds >= 0 ? durationSeconds : null,
    claimGeneration: Number.isSafeInteger(Number(value.claimGeneration)) ? Number(value.claimGeneration) : null,
    input: value.input ?? null,
    output: value.output ?? null,
    inspectRef: optionalText(value.inspectRef),
    diagnostics: (value.diagnostics || []).map(normalizeDiagnostic),
    stageId
  };
}

function normalizeBlockingReason(value = {}, index) {
  return {
    code: optionalText(value.code) || `BLOCKED_${index + 1}`,
    message: requiredText(value.message, `Blocking reason ${index + 1} message`),
    dependencyId: optionalText(value.dependencyId)
  };
}

function normalizeStage(value = {}, index) {
  const id = requiredText(value.id, `Stage ${index + 1} id`);
  const attempts = (value.attempts || []).map((attempt, attemptIndex) => normalizeAttempt(attempt, id, attemptIndex));
  const attemptIds = new Set(attempts.map(({ id: attemptId }) => attemptId));
  if (attemptIds.size !== attempts.length) throw new TypeError(`Stage "${id}" contains duplicate attempt ids.`);

  const status = statusFrom(value.status, PIPELINE_STATUSES, `Stage "${id}"`);
  const blockingReasons = (value.blockingReasons || []).map(normalizeBlockingReason);
  if (status === "blocked" && blockingReasons.length === 0) {
    throw new TypeError(`Blocked stage "${id}" requires at least one blocking reason.`);
  }

  const currentAttemptId = optionalText(value.currentAttemptId);
  const acceptedAttemptId = optionalText(value.acceptedAttemptId);
  for (const [field, attemptId] of [["currentAttemptId", currentAttemptId], ["acceptedAttemptId", acceptedAttemptId]]) {
    if (attemptId && !attemptIds.has(attemptId)) throw new TypeError(`Stage "${id}" ${field} does not name one of its attempts.`);
  }

  return {
    id,
    sequence: Number.isFinite(value.sequence) ? Number(value.sequence) : index,
    sourceIndex: index,
    label: requiredText(value.label, `Stage "${id}" label`),
    detail: optionalText(value.detail),
    status,
    statusMeta: pipelineStatusMeta(status),
    method: optionalText(value.method),
    actor: optionalText(value.actor),
    dependsOn: [...new Set((value.dependsOn || []).map((dependency) => requiredText(dependency, `Stage "${id}" dependency`)))],
    blockingReasons,
    progress: normalizeProgress(value.progress, `Stage "${id}"`),
    activity: value.activity ? normalizeActivity(value.activity) : null,
    currentAttemptId,
    acceptedAttemptId,
    inspectRef: optionalText(value.inspectRef),
    attempts
  };
}

function normalizeJob(value = {}, index) {
  return {
    id: requiredText(value.id, `Job ${index + 1} id`),
    stageId: requiredText(value.stageId, `Job ${value.id || index + 1} stageId`),
    label: requiredText(value.label, `Job ${value.id || index + 1} label`),
    status: statusFrom(value.status, PIPELINE_STATUSES, `Job "${value.id || index + 1}"`),
    attemptId: optionalText(value.attemptId),
    startedAt: optionalText(value.startedAt),
    authoritative: Boolean(value.authoritative)
  };
}

function normalizeControl(kind, value) {
  if (!value) return { kind, label: CONTROL_LABELS[kind], visible: false, enabled: false, reason: null };
  return {
    kind,
    label: optionalText(value.label) || CONTROL_LABELS[kind],
    visible: value.visible !== false,
    enabled: value.enabled !== false,
    reason: optionalText(value.reason)
  };
}

export function pipelineStatusMeta(status) {
  const normalized = statusFrom(status, PIPELINE_STATUSES, "Pipeline", "queued");
  return { status: normalized, ...STATUS_META[normalized] };
}

export function pipelineAttemptInspection(stage = {}) {
  const attempts = Array.isArray(stage.attempts) ? stage.attempts : [];
  const attempt = attempts.find(({ id }) => id === stage.currentAttemptId)
    || attempts.find(({ id }) => id === stage.acceptedAttemptId)
    || attempts.at(-1)
    || null;
  return {
    stageId: requiredText(stage.id, "Pipeline inspection stage id"),
    stageLabel: requiredText(stage.label, "Pipeline inspection stage label"),
    statusMeta: pipelineStatusMeta(stage.status),
    attempt,
    views: {
      overview: true,
      input: attempt?.input != null,
      output: attempt?.output != null
    }
  };
}

export function normalizePipelinePresentation(input = {}) {
  const id = requiredText(input.id, "Pipeline presentation id");
  const stages = (input.stages || []).map(normalizeStage)
    .sort((left, right) => left.sequence - right.sequence || left.sourceIndex - right.sourceIndex);
  const stageIds = new Set(stages.map(({ id: stageId }) => stageId));
  if (stageIds.size !== stages.length) throw new TypeError("Pipeline presentation contains duplicate stage ids.");

  for (const stage of stages) {
    for (const dependencyId of stage.dependsOn) {
      if (!stageIds.has(dependencyId)) throw new TypeError(`Stage "${stage.id}" names unknown dependency "${dependencyId}".`);
    }
    for (const reason of stage.blockingReasons) {
      if (reason.dependencyId && !stageIds.has(reason.dependencyId)) {
        throw new TypeError(`Stage "${stage.id}" names unknown blocking dependency "${reason.dependencyId}".`);
      }
    }
  }

  const jobs = (input.jobs || []).map(normalizeJob);
  const jobIds = new Set(jobs.map(({ id: jobId }) => jobId));
  if (jobIds.size !== jobs.length) throw new TypeError("Pipeline presentation contains duplicate job ids.");
  for (const job of jobs) {
    if (!stageIds.has(job.stageId)) throw new TypeError(`Job "${job.id}" names unknown stage "${job.stageId}".`);
  }

  const markedJobs = jobs.filter(({ authoritative }) => authoritative);
  if (markedJobs.length > 1) throw new TypeError("Pipeline presentation may mark only one authoritative current job.");
  const currentJobId = optionalText(input.currentJobId);
  if (currentJobId && !jobIds.has(currentJobId)) throw new TypeError(`Current job "${currentJobId}" is not present in jobs.`);
  if (markedJobs.length === 1 && markedJobs[0].id !== currentJobId) {
    throw new TypeError("The authoritative job marker must agree with currentJobId.");
  }

  const status = statusFrom(input.status, PIPELINE_STATUSES, `Pipeline "${id}"`);
  if (["running", "stopping"].includes(status) && !currentJobId) {
    throw new TypeError(`Pipeline "${id}" is ${status} but has no authoritative current job.`);
  }

  const controls = Object.fromEntries(
    PIPELINE_CONTROL_KINDS.map((kind) => [kind, normalizeControl(kind, input.controls?.[kind])])
  );

  return {
    id,
    projectId: optionalText(input.projectId),
    workspaceId: optionalText(input.workspaceId),
    label: optionalText(input.label) || "Pipeline",
    status,
    statusMeta: pipelineStatusMeta(status),
    reviewStatus: optionalText(input.reviewStatus),
    activity: normalizeActivity(input.activity || { state: status }),
    progress: normalizeProgress(input.progress, `Pipeline "${id}"`),
    stages,
    jobs: jobs.map((job) => ({ ...job, authoritative: job.id === currentJobId })),
    currentJobId,
    currentJob: currentJobId ? jobs.find(({ id: jobId }) => jobId === currentJobId) : null,
    humanTasks: (input.humanTasks || []).map((task, index) => ({ id: requiredText(task.id, `Human task ${index + 1} id`), label: requiredText(task.label, `Human task ${index + 1} label`), detail: optionalText(task.detail), actionLabel: optionalText(task.actionLabel) || "Respond", status: optionalText(task.status) || "ready" })),
    controls
  };
}
