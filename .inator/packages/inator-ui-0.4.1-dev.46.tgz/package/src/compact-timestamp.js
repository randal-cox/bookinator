function dateParts(date) {
  return [
    String(date.getFullYear()).padStart(4, "0"),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ];
}

function timeParts(date) {
  return [
    String(date.getHours()).padStart(2, "0"),
    String(date.getMinutes()).padStart(2, "0"),
    String(date.getSeconds()).padStart(2, "0")
  ];
}

export function formatCompactTimestamp(value) {
  const date = value instanceof Date ? new Date(value.getTime()) : new Date(value);
  if (!Number.isFinite(date.getTime())) {
    return Object.freeze({ valid: false, date: "Unknown date", time: "Unknown time", datetime: "" });
  }
  return Object.freeze({
    valid: true,
    date: dateParts(date).join("-"),
    time: timeParts(date).join(":"),
    datetime: date.toISOString()
  });
}

export function createCompactTimestamp(value) {
  const formatted = formatCompactTimestamp(value);
  const node = document.createElement("time");
  node.className = "inator-compact-timestamp";
  if (formatted.datetime) node.dateTime = formatted.datetime;
  const date = document.createElement("span");
  date.textContent = formatted.date;
  const time = document.createElement("span");
  time.textContent = formatted.time;
  node.append(date, time);
  return node;
}
