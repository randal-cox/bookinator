const text = (value) => String(value ?? "");

function element(tag, className, content) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (content != null) node.textContent = text(content);
  return node;
}

function section(title, value, { pre = false, description = "" } = {}) {
  const node = element("section", "inator-diagnostic-inspector__section");
  if (title === "Raw incident JSON") node.classList.add("inator-diagnostic-inspector__raw");
  node.append(element("h3", "", title));
  if (description) node.append(element("p", "inator-diagnostic-inspector__description", description));
  node.append(element(pre ? "pre" : "p", "", value || "Not recorded"));
  return node;
}

function messageText(message) {
  if (typeof message === "string") return message;
  if (message?.name || message?.message) return [message.name, message.message].filter(Boolean).join(": ");
  return JSON.stringify(message, null, 2);
}

export function createDiagnosticIncidentInspector({
  mount,
  incident,
  onViewed = () => {}
} = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createDiagnosticIncidentInspector requires a DOM mount element.");
  if (!incident?.id || !incident?.visitId) {
    throw new TypeError("A diagnostic incident with stable incident and visit ids is required.");
  }

  const entries = Array.isArray(incident.entries) ? incident.entries : [];
  const article = element("article", "inator-diagnostic-inspector");
  const header = element("header", "inator-diagnostic-inspector__header");
  header.append(
    element("h2", "", "Incident detail"),
    element("p", "", `${incident.startedAt || entries[0]?.receivedAt || "Unknown time"} to ${incident.endedAt || entries.at(-1)?.receivedAt || "Unknown time"} · ${incident.errorCount || 0} errors · ${entries.length} retained entries`)
  );

  const messages = entries.flatMap((entry) => (entry.messages || []).map((message) => (
    `[${entry.occurredAt || entry.receivedAt || "unknown"}] ${entry.level || "log"} / ${entry.kind || "runtime"}\n${messageText(message)}`
  ))).join("\n\n");
  const stacks = entries.flatMap((entry) => (entry.messages || [])
    .map((message) => typeof message === "object" ? message?.stack : "")
    .filter(Boolean))
    .join("\n\n");
  const pageContext = JSON.stringify(entries.map((entry) => ({
    url: entry.page?.url || entry.url,
    scriptSource: entry.page?.scriptSource || entry.scriptSource || null,
    readiness: entry.page?.readiness || entry.readiness,
    activeElement: entry.page?.activeElement || entry.activeElement,
    viewport: entry.page?.viewport || entry.viewport,
    structure: entry.page?.structure || entry.structure,
    classification: entry.classification || null
  })), null, 2);
  const browser = JSON.stringify({
    incidentId: incident.id,
    visitId: incident.visitId,
    visitStartedAt: incident.visitStartedAt,
    project: incident.project || null,
    startedAt: incident.startedAt,
    endedAt: incident.endedAt,
    url: incident.url,
    interactionSequence: incident.interactionSequence,
    trigger: incident.trigger || null,
    viewedAt: incident.viewedAt || null,
    resolvedAt: incident.resolvedAt || null,
    userAgents: [...new Set(entries.map(({ userAgent }) => userAgent).filter(Boolean))]
  }, null, 2);

  article.append(
    header,
    section("Interaction trigger", JSON.stringify(incident.trigger || null, null, 2), { pre: true }),
    section("Grouped messages", messages, { pre: true }),
    section("Technical trace", stacks, { pre: true, description: "The code path active when the failure occurred. This helps a developer locate its origin." }),
    section("Page and DOM structure", pageContext, { pre: true }),
    section("Browser and incident metadata", browser, { pre: true }),
    section("Raw incident JSON", JSON.stringify(incident, null, 2), { pre: true })
  );
  mount.replaceChildren(article);
  onViewed({ id: String(incident.id), incident });
  return { incident, destroy() { mount.replaceChildren(); } };
}

export function createDiagnosticRecordInspector(options = {}) {
  return createDiagnosticIncidentInspector({
    ...options,
    incident: options.incident || options.record
  });
}
