function requiredText(value, field) {
  const text = String(value || "").trim();
  if (!text) throw new TypeError(field + " is required");
  return text;
}

function node(tag, className = "", text = "") {
  const element = document.createElement(tag);
  if (className) element.className = className;
  if (text) element.textContent = text;
  return element;
}

function normalizePresentation(source = {}) {
  const id = requiredText(source.id, "Presentation id");
  const slides = (source.slides || []).map((slide, index) => ({
    id: slide.id || "slide-" + (index + 1),
    kicker: String(slide.kicker || "").trim(),
    title: requiredText(slide.title, "Slide title"),
    body: String(slide.body || "").trim(),
    heroMark: String(slide.heroMark || "").trim(),
    hideMark: Boolean(slide.hideMark),
    identitySlide: Boolean(slide.identitySlide),
    points: (slide.points || []).map((point) => requiredText(point, "Slide point")),
    visual: slide.visual ? {
      kind: ["cards", "flow", "window", "image"].includes(slide.visual.kind) ? slide.visual.kind : "cards",
      label: String(slide.visual.label || "").trim(),
      src: String(slide.visual.src || "").trim(),
      items: (slide.visual.items || []).map((item) => typeof item === "string" ? { label: requiredText(item, "Visual item") } : ({
        label: requiredText(item?.label, "Visual item label"),
        detail: String(item?.detail || "").trim(),
        icon: String(item?.icon || "").trim(),
        tone: String(item?.tone || "").trim()
      }))
    } : null,
    note: String(slide.note || "").trim()
  }));
  if (!slides.length) throw new TypeError("A presentation requires at least one slide");
  return { id, title: requiredText(source.title, "Presentation title"), product: requiredText(source.product, "Presentation product"), mark: String(source.mark || "").trim(), slides };
}

function slideVisual(visual) {
  const figure = node("figure", `inator-presentation-visual inator-presentation-visual--${visual.kind}`);
  if (visual.label) figure.setAttribute("aria-label", visual.label);
  if (visual.kind === "image" && visual.src) {
    const image = document.createElement("img");
    image.className = "inator-presentation-visual__graphic";
    image.src = visual.src;
    image.alt = visual.label;
    figure.append(image);
    return figure;
  }
  const content = node("div", "inator-presentation-visual__content");
  visual.items.forEach((item, index) => {
    const card = node("div", "inator-presentation-visual__item");
    if (item.tone) card.dataset.tone = item.tone;
    if (visual.kind === "flow") card.append(node("span", "inator-presentation-visual__step", String(index + 1)));
    if (item.icon) {
      const icon = document.createElement("img");
      icon.className = "inator-presentation-visual__icon";
      icon.src = item.icon;
      icon.alt = "";
      card.append(icon);
    }
    const copy = node("span", "");
    copy.append(node("strong", "", item.label));
    if (item.detail) copy.append(node("small", "", item.detail));
    card.append(copy);
    content.append(card);
  });
  figure.append(content);
  return figure;
}

function slideContent(slide, index, total, mark = "") {
  const article = node("article", "inator-presentation-slide");
  if (slide.visual) article.classList.add("inator-presentation-slide--visual");
  if (slide.identitySlide) article.classList.add("inator-presentation-slide--identity");
  article.dataset.slide = slide.id;
  const meta = node("div", "inator-presentation-slide__meta");
  const identity = node("span", "inator-presentation-slide__identity");
  if (mark && !slide.hideMark) {
    const image = document.createElement("img");
    image.src = mark;
    image.alt = "";
    identity.append(image);
  }
  identity.append(node("span", "", slide.kicker || "Slide"));
  meta.append(identity, node("span", "", (index + 1) + " / " + total));
  const copy = node("div", "inator-presentation-slide__copy");
  copy.append(node("h1", "", slide.title));
  if (slide.body) copy.append(node("p", "inator-presentation-slide__body", slide.body));
  if (slide.points.length) {
    const list = node("ul", "inator-presentation-slide__points");
    slide.points.forEach((point) => list.append(node("li", "", point)));
    copy.append(list);
  }
  article.append(meta, copy);
  if (slide.heroMark) {
    const heroMark = document.createElement("img");
    heroMark.className = "inator-presentation-slide__hero-mark";
    heroMark.src = slide.heroMark;
    heroMark.alt = "";
    article.append(heroMark);
  }
  if (slide.visual) article.append(slideVisual(slide.visual));
  return article;
}

function channelFor(id) {
  try { return typeof BroadcastChannel === "function" ? new BroadcastChannel("inator-presentation-" + id) : null; }
  catch { return null; }
}

export function createResourcePresentation({ mount, presentation: source, mode = "audience", resourcesHref = "../" } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("A presentation mount element is required");
  if (!["audience", "presenter", "notes"].includes(mode)) throw new TypeError("Unknown presentation mode: " + mode);
  const presentation = normalizePresentation(source);
  const channel = channelFor(presentation.id);
  let index = 0;
  mount.className = "inator-resource-presentation";
  mount.dataset.mode = mode;

  const hrefFor = (nextMode) => nextMode === "audience" ? "./" : "./?view=" + nextMode;
  const select = (next, { broadcast = mode === "presenter" } = {}) => {
    index = Math.max(0, Math.min(next, presentation.slides.length - 1));
    render();
    if (broadcast) channel?.postMessage({ index });
  };

  const renderAudience = () => {
    const stage = node("section", "inator-presentation-stage");
    stage.setAttribute("aria-label", `${presentation.title} slide ${index + 1} of ${presentation.slides.length}`);
    stage.append(slideContent(presentation.slides[index], index, presentation.slides.length, presentation.mark));
    const progress = node("div", "inator-presentation-progress");
    progress.setAttribute("role", "progressbar");
    progress.setAttribute("aria-label", "Presentation progress");
    progress.setAttribute("aria-valuemin", "1");
    progress.setAttribute("aria-valuemax", String(presentation.slides.length));
    progress.setAttribute("aria-valuenow", String(index + 1));
    const fill = node("span");
    fill.style.width = ((index + 1) / presentation.slides.length * 100) + "%";
    progress.append(fill);
    mount.replaceChildren(stage, progress);
  };

  const renderPresenter = () => {
    const toolbar = node("header", "inator-presenter-toolbar");
    const back = node("a", "", "Resources");
    back.href = resourcesHref;
    const audience = node("a", "primary", "Open audience window");
    audience.href = hrefFor("audience");
    audience.target = "_blank";
    toolbar.append(back, node("strong", "", presentation.title), audience);
    const current = presentation.slides[index];
    const nextSlide = presentation.slides[index + 1];
    const grid = node("section", "inator-presenter-grid");
    const currentCard = node("article", "current");
    currentCard.append(node("span", "", "Current · " + (index + 1) + " / " + presentation.slides.length), node("h1", "", current.title), node("p", "", current.note || current.body || "No speaker note recorded."));
    const nextCard = node("article", "next");
    nextCard.append(node("span", "", "Next"), node("h2", "", nextSlide?.title || "End of deck"), node("p", "", nextSlide?.note || nextSlide?.body || ""));
    grid.append(currentCard, nextCard);
    const controls = node("nav", "inator-presenter-controls");
    [["First", 0], ["Previous", index - 1], ["Next", index + 1], ["Last", presentation.slides.length - 1]].forEach(([label, target]) => {
      const button = node("button", label === "Next" ? "primary" : "", label);
      button.type = "button";
      button.disabled = target < 0 || target >= presentation.slides.length || target === index;
      button.addEventListener("click", () => select(target));
      controls.append(button);
    });
    const notes = node("a", "inator-presenter-notes-link", "Slides + notes");
    notes.href = hrefFor("notes");
    mount.replaceChildren(toolbar, grid, controls, notes);
  };

  const renderNotes = () => {
    const toolbar = node("header", "inator-notes-toolbar");
    const back = node("a", "", "Resources");
    back.href = resourcesHref;
    toolbar.append(back, node("strong", "", presentation.title + " · slides + notes"), node("span", "", "Print or save as PDF"));
    const pages = node("section", "inator-notes-pages");
    presentation.slides.forEach((slide, slideIndex) => {
      const page = node("article", "inator-notes-page");
      page.append(slideContent(slide, slideIndex, presentation.slides.length, presentation.mark));
      const note = node("aside", "");
      note.append(node("strong", "", "Speaker note"), node("p", "", slide.note || "No speaker note recorded."));
      page.append(note);
      pages.append(page);
    });
    mount.replaceChildren(toolbar, pages);
  };

  const render = () => {
    if (mode === "audience") renderAudience();
    if (mode === "presenter") renderPresenter();
    if (mode === "notes") renderNotes();
  };
  const onKey = (event) => {
    if (mode === "notes") return;
    if (event.key === "ArrowRight" || event.key === "PageDown") select(Math.min(index + 1, presentation.slides.length - 1), { broadcast: mode === "presenter" });
    if (event.key === "ArrowLeft" || event.key === "PageUp") select(Math.max(index - 1, 0), { broadcast: mode === "presenter" });
    if (event.key === "Home") select(0, { broadcast: mode === "presenter" });
    if (event.key === "End") select(presentation.slides.length - 1, { broadcast: mode === "presenter" });
  };
  const onMessage = (event) => {
    if (mode === "audience" && Number.isInteger(event.data?.index)) select(event.data.index, { broadcast: false });
  };
  window.addEventListener("keydown", onKey);
  channel?.addEventListener("message", onMessage);
  render();
  return Object.freeze({
    select,
    destroy() {
      window.removeEventListener("keydown", onKey);
      channel?.removeEventListener("message", onMessage);
      channel?.close();
      mount.replaceChildren();
    }
  });
}
