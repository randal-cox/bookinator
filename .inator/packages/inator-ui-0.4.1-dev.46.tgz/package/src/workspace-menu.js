export const WORKSPACE_ACTION_IDS = Object.freeze([
  "edit-actor",
  "backup-and-restore",
  "errors"
]);

const ACTION_DEFAULTS = Object.freeze({
  "edit-actor": { label: "Edit identity", detail: "Change the short and long names used for attribution" },
  "backup-and-restore": { label: "Backup and restore", detail: "Open the complete portable-workspace workflow" },
  "errors": { label: "Errors", detail: "Inspect retained local diagnostic errors" }
});

function requiredText(value, label) {
  const text = String(value ?? "").trim();
  if (!text) throw new TypeError(`${label} is required.`);
  return text;
}

function normalizeAction(id, value = {}) {
  return {
    id,
    label: String(value.label ?? ACTION_DEFAULTS[id].label).trim() || ACTION_DEFAULTS[id].label,
    detail: String(value.detail ?? ACTION_DEFAULTS[id].detail).trim(),
    enabled: value.enabled !== false,
    busy: Boolean(value.busy),
    reason: String(value.reason ?? "").trim() || null
  };
}

export function normalizeWorkspaceMenu(input = {}) {
  const actor = {
    shortName: requiredText(input.actor?.shortName, "Actor short name"),
    longName: requiredText(input.actor?.longName, "Actor long name"),
    roles: [...new Set((input.actor?.roles || []).map(String))]
  };
  const actionIds = input.diagnostics?.visible ? WORKSPACE_ACTION_IDS : WORKSPACE_ACTION_IDS.slice(0, 2);
  return {
    label: String(input.label ?? "Workspace").trim() || "Workspace",
    workspaceName: String(input.workspaceName ?? "").trim() || null,
    actor,
    diagnosticsVisible: Boolean(input.diagnostics?.visible),
    actions: actionIds.map((id) => normalizeAction(id, input.actions?.[id]))
  };
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
}

function render(details, rawConfiguration, onAction) {
  const configuration = normalizeWorkspaceMenu(rawConfiguration);
  const summary = element("summary", "inator-workspace-menu__summary");
  const title = element("span", "inator-workspace-menu__title", configuration.label);
  const identity = element("span", "inator-workspace-menu__identity");
  identity.append(
    element("strong", "", configuration.actor.shortName),
    element("small", "", configuration.actor.longName)
  );
  summary.append(title, identity);

  const panel = element("div", "inator-workspace-menu__panel");
  if (configuration.workspaceName) panel.append(element("p", "inator-workspace-menu__workspace", configuration.workspaceName));
  for (const action of configuration.actions) {
    const button = element("button", "inator-workspace-menu__action");
    button.type = "button";
    button.dataset.action = action.id;
    button.disabled = !action.enabled || action.busy;
    if (action.busy) button.setAttribute("aria-busy", "true");
    if (action.reason) button.title = action.reason;
    button.append(
      element("strong", "", action.label),
      element("small", "", action.busy ? "Working…" : action.detail)
    );
    button.addEventListener("click", () => {
      details.open = false;
      onAction?.({ action: action.id, actor: configuration.actor, configuration });
    });
    panel.append(button);
  }

  details.replaceChildren(summary, panel);
  return configuration;
}

export function createWorkspaceMenu({ mount, configuration, onAction } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createWorkspaceMenu requires a DOM mount element.");
  const details = element("details", "inator-workspace-menu");
  mount.replaceChildren(details);
  let current = render(details, configuration, onAction);

  const closeOnOutsideClick = (event) => {
    if (details.open && !details.contains(event.target)) details.open = false;
  };
  const closeOnEscape = (event) => {
    if (event.key === "Escape" && details.open) {
      details.open = false;
      details.querySelector("summary")?.focus();
    }
  };
  document.addEventListener("click", closeOnOutsideClick);
  details.addEventListener("keydown", closeOnEscape);

  return {
    get configuration() { return current; },
    update(nextConfiguration) {
      current = render(details, nextConfiguration, onAction);
      return current;
    },
    destroy() {
      document.removeEventListener("click", closeOnOutsideClick);
      details.removeEventListener("keydown", closeOnEscape);
      mount.replaceChildren();
    }
  };
}
