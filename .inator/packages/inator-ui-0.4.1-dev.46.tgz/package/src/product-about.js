export const PRODUCT_ABOUT_SCHEMA = "inator.product-about.v1";
export const CITATION_EXPORT_FORMATS = Object.freeze(["csl-json", "bibtex", "ris"]);

function requiredText(value, label) {
  const result = String(value ?? "").trim();
  if (!result) throw new TypeError(`${label} is required.`);
  return result;
}

function citationKey(value, title, year) {
  const candidate = String(value || `${title}-${year}`).normalize("NFKD").replace(/[^a-zA-Z0-9]+/g, "-").replace(/^-|-$/g, "").toLowerCase();
  if (!candidate) throw new TypeError("citation.key must contain a letter or number.");
  return candidate;
}

function bibtexValue(value) {
  return String(value).replace(/\\/g, "\\textbackslash{}").replace(/([{}])/g, "\\$1");
}

export function citationExportArtifacts(citationSource = {}) {
  const title = requiredText(citationSource.title, "citation.title");
  const authors = (citationSource.authors || []).map((author) => requiredText(author, "citation author"));
  if (!authors.length) throw new TypeError("citation.authors requires at least one author.");
  const version = requiredText(citationSource.version, "citation.version");
  const year = Number(citationSource.year);
  if (!Number.isInteger(year) || year < 2000) throw new TypeError("citation.year must be a four-digit year.");
  const url = requiredText(citationSource.url, "citation.url");
  const key = citationKey(citationSource.key, title, year);
  const csl = [{ id: key, type: "software", title, author: authors.map((literal) => ({ literal })), issued: { "date-parts": [[year]] }, version, URL: url }];
  const bibtex = `@misc{${key},\n  author = {${authors.map(bibtexValue).join(" and ")}},\n  title = {${bibtexValue(title)}},\n  year = {${year}},\n  howpublished = {Software},\n  note = {Version ${bibtexValue(version)}},\n  url = {${bibtexValue(url)}}\n}\n`;
  const ris = [`TY  - COMP`, ...authors.map((author) => `AU  - ${author}`), `TI  - ${title}`, `PY  - ${year}`, `UR  - ${url}`, `N1  - Version ${version}`, "ER  - ", ""].join("\n");
  return Object.freeze([
    Object.freeze({ id: "csl-json", label: "CSL JSON", filename: `${key}.json`, mediaType: "application/vnd.citationstyles.csl+json", content: `${JSON.stringify(csl, null, 2)}\n` }),
    Object.freeze({ id: "bibtex", label: "BibTeX", filename: `${key}.bib`, mediaType: "application/x-bibtex", content: bibtex }),
    Object.freeze({ id: "ris", label: "RIS", filename: `${key}.ris`, mediaType: "application/x-research-info-systems", content: ris })
  ]);
}

export function defineProductAbout(source = {}) {
  const product = { name: requiredText(source.product?.name, "product.name"), summary: requiredText(source.product?.summary, "product.summary") };
  const authors = (source.citation?.authors || []).map((author) => requiredText(author, "citation author"));
  if (!authors.length) throw new TypeError("citation.authors requires at least one author.");
  const citation = {
    title: requiredText(source.citation?.title || product.name, "citation.title"), authors,
    version: requiredText(source.citation?.version, "citation.version"), year: Number(source.citation?.year),
    url: requiredText(source.citation?.url, "citation.url"), text: requiredText(source.citation?.text, "citation.text")
  };
  if (!Number.isInteger(citation.year) || citation.year < 2000) throw new TypeError("citation.year must be a four-digit year.");
  citation.key = citationKey(source.citation?.key, citation.title, citation.year);
  citation.exports = citationExportArtifacts(citation);
  return Object.freeze({ schema: PRODUCT_ABOUT_SCHEMA, product: Object.freeze(product), citation: Object.freeze({ ...citation, authors: Object.freeze(authors) }) });
}
