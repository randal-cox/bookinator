import {
  createActionBar,
  createCollectionSurface,
  createActionRegion,
  createActionRow,
  createToolButton
} from "./action-bar.js";
import { createConfirmationDialog } from "./confirmation-dialog.js";
import { createInatorIcon } from "./icons.js";
import { createListModel } from "./list-model.js";
import { createListView } from "./list-view.js";
import { createCompactTimestamp } from "./compact-timestamp.js";

const text = (value) => String(value ?? "").trim();

function conciseSummary(incident) {
  if (text(incident.summary)) return text(incident.summary);
  const first = incident.entries?.flatMap(({ messages = [] }) => messages)?.[0];
  if (typeof first === "string") return first;
  return text(first?.message || first?.name || "Diagnostic incident");
}

function validDate(value, fallback) {
  const primary = Date.parse(value || "");
  if (Number.isFinite(primary)) return new Date(primary);
  const secondary = Date.parse(fallback || "");
  return new Date(Number.isFinite(secondary) ? secondary : 0);
}

function fallbackReceivedAt(incident) {
  return incident.entries?.find(({ receivedAt }) => Number.isFinite(Date.parse(receivedAt || "")))?.receivedAt
    || incident.receivedAt
    || incident.endedAt;
}

function routeFor(incident) {
  const value = incident.endUrl || incident.startUrl || incident.url;
  try {
    const url = new URL(value);
    return `${url.pathname}${url.search}`;
  } catch {
    return text(value);
  }
}

function readableIdentity(target = {}) {
  const value = target.ariaLabel || target.name || target.id || target.dataAction || target.tag;
  return text(value).replace(/^inator:/, "").replace(/-/g, " ");
}

function triggerLabel(incident) {
  const trigger = incident.trigger;
  if (!trigger || trigger.type === "legacy-rollup") return "Trigger not recorded — legacy incident";
  if (trigger.type === "page-load") return "During page load";
  if (["navigation", "popstate", "hashchange"].includes(trigger.type)) return "After navigation";
  const identity = readableIdentity(trigger.target) || "control";
  if (trigger.type === "click") return "Clicked " + identity;
  if (trigger.type === "submit") return "Submitted " + identity;
  if (trigger.type === "change") return "Changed " + identity;
  return "After " + text(trigger.type || "interaction").replace(/-/g, " ");
}

function normalizeIncident(incident) {
  const id = text(incident.id);
  const visitId = text(incident.visitId);
  if (!id || !visitId) throw new TypeError("Workspace Error incidents require stable incident and visit ids.");
  const occurredDate = validDate(incident.startedAt, fallbackReceivedAt(incident));
  return {
    ...incident,
    id,
    visitId,
    name: conciseSummary(incident),
    summary: conciseSummary(incident),
    route: routeFor(incident),
    projectLabel: text(incident.project?.name || incident.projectName || incident.project?.id || incident.projectId || "Unassigned"),
    errorCount: Number(incident.errorCount) || 0,
    warningCount: Number(incident.warningCount) || 0,
    triggerLabel: triggerLabel(incident),
    entryCount: Number(incident.entryCount) || incident.entries?.length || 0,
    occurredDate,
    occurredLabel: occurredDate.toISOString()
  };
}

export function diagnosticIncidentDeletion(incidents = []) {
  const selectedIds = incidents.map(({ id }) => text(id)).filter(Boolean);
  return {
    incidents,
    selectedIds,
    incidentCount: selectedIds.length,
    rawEntryCount: incidents.reduce((count, incident) => count + (incident.entries?.length || 0), 0)
  };
}

export function createWorkspaceErrorsModel(incidents = [], initialState = {}) {
  const normalized = incidents.map(normalizeIncident);
  return createListModel({
    records: normalized,
    columns: [
      {
        id: "time",
        label: "Date / time",
        required: true,
        value: (incident) => incident.occurredDate,
        searchValue: (incident) => incident.occurredLabel,
        format: (_value, incident) => incident.occurredLabel,
        render: (_incident, value) => createCompactTimestamp(value)
      },
      { id: "route", label: "URL", required: true, value: (incident) => incident.route },
      { id: "trigger", label: "Preceding action", required: true, value: (incident) => incident.triggerLabel },
      { id: "errors", label: "Errors", required: true, value: (incident) => incident.errorCount },
      { id: "warnings", label: "Warnings", required: true, value: (incident) => incident.warningCount },
      { id: "summary", label: "Summary", value: conciseSummary },
      { id: "project", label: "Project", value: (incident) => incident.projectLabel }
    ],
    initialState: {
      pageSize: 25,
      sort: { id: "time", direction: "desc" },
      ...initialState
    }
  });
}

export function createWorkspaceErrorsView({
  mount,
  incidents = [],
  records = null,
  initialState = {},
  onInspect = () => {},
  onExport = () => {},
  onDeleteRequest = () => {},
  onChange = () => {}
} = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createWorkspaceErrorsView requires a DOM mount element.");
  const initialIncidents = records || incidents;
  const model = createWorkspaceErrorsModel(initialIncidents, initialState);

  const columns = createToolButton({
    icon: createInatorIcon("columns"),
    label: "Columns"
  });
  const exportSelected = createToolButton({
    icon: createInatorIcon("export"),
    label: "Export",
    disabled: true
  });
  const deleteSelected = createToolButton({
    icon: createInatorIcon("delete"),
    label: "Delete",
    disabled: true,
    className: "inator-tool-button--danger"
  });
  const independent = createActionRegion({ children: [columns] });
  const selection = createActionRegion({
    separated: true,
    children: [exportSelected, deleteSelected]
  });
  const bar = createActionBar({
    label: "Diagnostic incident actions",
    rows: [createActionRow({ children: [independent, selection] })]
  });
  const listMount = document.createElement("div");
  const surface = createCollectionSurface({ actionBar: bar, listMount });
  mount.replaceChildren(surface);

  const confirmation = createConfirmationDialog({
    mount: mount.ownerDocument?.body || document.body,
    context: "Delete retained diagnostics",
    confirmLabel: "Delete",
    danger: true
  });

  const selectedIncidents = () => {
    const snapshot = model.snapshot();
    return snapshot.records.filter((incident) => snapshot.selectedIds.has(String(incident.id)));
  };
  const updateActions = (snapshot = model.snapshot()) => {
    const hasSelection = snapshot.selectedIds.size > 0;
    exportSelected.disabled = !hasSelection;
    deleteSelected.disabled = !hasSelection;
  };
  exportSelected.addEventListener("click", () => onExport({
    scope: "selected",
    incidents: selectedIncidents(),
    selectedIds: [...model.snapshot().selectedIds]
  }));
  deleteSelected.addEventListener("click", () => {
    const deletion = diagnosticIncidentDeletion(selectedIncidents());
    confirmation.open({
      title: `Delete ${deletion.incidentCount} diagnostic ${deletion.incidentCount === 1 ? "incident" : "incidents"}?`,
      message: `This removes ${deletion.rawEntryCount} retained raw ${deletion.rawEntryCount === 1 ? "entry" : "entries"}.`,
      detail: "This action cannot be undone.",
      confirmLabel: "Delete",
      danger: true,
      busyMessage: "Deleting retained diagnostic incident\u2026",
      onConfirm: () => onDeleteRequest(deletion)
    }, deleteSelected);
  });

  const list = createListView({
    mount: listMount,
    model,
    searchPlaceholder: "Search diagnostic incidents",
    emptyTitle: "No diagnostic incidents",
    emptyDetail: "First-party runtime incidents will appear here.",
    filters: [
      {
        id: "project",
        label: "Project",
        options: [...new Set(initialIncidents.map((incident) => (
          incident.project?.name || incident.projectName || incident.project?.id || incident.projectId
        )).filter(Boolean))]
      }
    ],
    columnButton: columns,
    rowActionLabel: (incident) => `Inspect ${conciseSummary(incident)}`,
    rowActionIcon: "inspect",
    onRowAction: onInspect,
    onChange: (snapshot) => {
      updateActions(snapshot);
      onChange(snapshot);
    }
  });
  updateActions();
  const snapshot = list.render();

  return {
    model,
    snapshot,
    surface,
    update(nextIncidents) {
      model.setRecords(nextIncidents.map(normalizeIncident));
      return list.render();
    },
    destroy() {
      confirmation.destroy();
      mount.replaceChildren();
    }
  };
}
