import { createTabController } from "./tabs.js";

const MODES = new Set(["text", "code", "structured-data", "table"]);
let inspectorSequence = 0;

function requiredText(value, label) { const result = String(value ?? "").trim(); if (!result) throw new TypeError(`${label} is required.`); return result; }

export function normalizeInspectableArtifacts(values) {
  if (!Array.isArray(values) || !values.length) throw new TypeError("Inspectable artifacts require a non-empty array.");
  const seen = new Set();
  return Object.freeze(values.map((value, index) => {
    const id = requiredText(value.id, `artifacts[${index}].id`);
    if (seen.has(id)) throw new TypeError(`Artifact ids must be unique: ${id}.`);
    seen.add(id);
    const mode = requiredText(value.inspection?.mode, `artifacts[${index}].inspection.mode`);
    if (!MODES.has(mode)) throw new TypeError(`artifacts[${index}].inspection.mode is not inspectable.`);
    return Object.freeze({ id, label: requiredText(value.label, `artifacts[${index}].label`), filename: requiredText(value.filename, `artifacts[${index}].filename`), mediaType: requiredText(value.mediaType, `artifacts[${index}].mediaType`), content: String(value.content ?? ""), inspection: Object.freeze({ mode, ...(value.inspection.syntax ? { syntax: requiredText(value.inspection.syntax, "inspection.syntax") } : {}), ...(value.inspection.description ? { description: requiredText(value.inspection.description, "inspection.description") } : {}) }) });
  }));
}

function visibleContent(artifact) {
  if (artifact.inspection.mode === "structured-data" && artifact.inspection.syntax === "json") {
    try { return JSON.stringify(JSON.parse(artifact.content), null, 2); } catch { return artifact.content; }
  }
  return artifact.content;
}

function defaultDownload(artifact) {
  const url = URL.createObjectURL(new Blob([artifact.content], { type: artifact.mediaType }));
  const link = document.createElement("a"); link.href = url; link.download = artifact.filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function createArtifactInspector({ mount, artifacts, initialArtifactId = null, inset = false, onCopy = null, onDownload = null } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("An artifact inspector mount element is required.");
  const instanceId = `inator-artifact-inspector-${++inspectorSequence}`;
  let values = normalizeInspectableArtifacts(artifacts);
  let selectedId = initialArtifactId && values.some(({ id }) => id === initialArtifactId) ? initialArtifactId : values[0].id;
  let tabsController = null;
  const root = document.createElement("section"); root.className = `inator-artifact-inspector${inset ? " inator-artifact-inspector--inset" : ""}`; root.setAttribute("aria-label", "Inspectable artifacts");
  const status = document.createElement("p"); status.className = "inator-artifact-inspector__status"; status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");

  const render = () => {
    root.replaceChildren();
    const tablist = document.createElement("div"); tablist.className = "inator-artifact-inspector__tabs"; tablist.setAttribute("role", "tablist"); tablist.setAttribute("aria-label", "Artifact files");
    const panels = document.createElement("div"); panels.className = "inator-artifact-inspector__panels";
    values.forEach((artifact) => {
      const safeId = artifact.id.replace(/[^a-zA-Z0-9_-]/g, "-");
      const tab = document.createElement("button"); tab.type = "button"; tab.id = `${instanceId}-tab-${safeId}`; tab.setAttribute("role", "tab"); tab.setAttribute("aria-controls", `${instanceId}-panel-${safeId}`); tab.setAttribute("aria-selected", String(artifact.id === selectedId)); tab.textContent = artifact.label; tab.dataset.artifactId = artifact.id; tablist.append(tab);
      const panel = document.createElement("section"); panel.id = `${instanceId}-panel-${safeId}`; panel.setAttribute("role", "tabpanel"); panel.setAttribute("aria-labelledby", tab.id); panel.dataset.mode = artifact.inspection.mode;
      const header = document.createElement("header"); const identity = document.createElement("div"); const name = document.createElement("strong"); name.textContent = artifact.filename; const description = document.createElement("span"); description.textContent = artifact.inspection.description || "Generated artifact"; identity.append(name, description);
      const actions = document.createElement("div"); actions.className = "inator-artifact-inspector__actions";
      const copy = document.createElement("button"); copy.type = "button"; copy.textContent = "Copy"; copy.addEventListener("click", async () => { try { if (onCopy) await onCopy(artifact); else await navigator.clipboard.writeText(artifact.content); status.textContent = `${artifact.filename} copied.`; } catch (error) { status.textContent = `Could not copy ${artifact.filename}: ${error?.message || error}`; } });
      const download = document.createElement("button"); download.type = "button"; download.textContent = "Download file"; download.addEventListener("click", async () => { try { if (onDownload) await onDownload(artifact); else defaultDownload(artifact); status.textContent = `${artifact.filename} downloaded.`; } catch (error) { status.textContent = `Could not download ${artifact.filename}: ${error?.message || error}`; } });
      actions.append(copy, download); header.append(identity, actions);
      const content = document.createElement("pre"); content.tabIndex = 0; content.dataset.syntax = artifact.inspection.syntax || artifact.inspection.mode; content.textContent = visibleContent(artifact);
      panel.append(header, content); panels.append(panel);
    });
    root.append(tablist, panels, status);
    tabsController = createTabController({ root, initialTabId: `${instanceId}-tab-${selectedId.replace(/[^a-zA-Z0-9_-]/g, "-")}`, onSelect(tab) { selectedId = tab.dataset.artifactId; status.textContent = ""; } });
  };
  render(); mount.replaceChildren(root);
  return Object.freeze({ root, get selectedArtifact() { return values.find(({ id }) => id === selectedId); }, select(id, options) { const artifact = values.find((value) => value.id === id); return artifact ? tabsController.select(`${instanceId}-tab-${id.replace(/[^a-zA-Z0-9_-]/g, "-")}`, options) : false; }, update(nextArtifacts, { selectedArtifactId = selectedId } = {}) { values = normalizeInspectableArtifacts(nextArtifacts); selectedId = values.some(({ id }) => id === selectedArtifactId) ? selectedArtifactId : values[0].id; render(); }, destroy() { root.remove(); } });
}

export const ARTIFACT_INSPECTION_MODES = Object.freeze([...MODES]);
