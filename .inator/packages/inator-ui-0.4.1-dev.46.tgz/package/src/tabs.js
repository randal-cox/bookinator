export function createTabController({ root = document, initialTabId = null, onSelect = null } = {}) {
  const tablist = root.querySelector('[role="tablist"]');
  if (!tablist) throw new TypeError("A tablist is required.");
  const tabs = [...tablist.querySelectorAll('[role="tab"]')];
  if (!tabs.length) throw new TypeError("At least one tab is required.");
  const panels = new Map(tabs.map((tab) => {
    const id = tab.getAttribute("aria-controls");
    const panel = id && root.querySelector(`#${CSS.escape(id)}`);
    if (!panel) throw new TypeError(`Tab ${tab.id || tab.textContent} requires an aria-controls panel.`);
    return [tab, panel];
  }));
  const select = (next, { focus = false } = {}) => {
    const tab = typeof next === "string" ? tabs.find(({ id }) => id === next) : next;
    if (!tab || !panels.has(tab)) return false;
    for (const candidate of tabs) { const selected = candidate === tab; candidate.setAttribute("aria-selected", String(selected)); candidate.tabIndex = selected ? 0 : -1; panels.get(candidate).hidden = !selected; }
    if (focus) tab.focus();
    onSelect?.(tab, panels.get(tab));
    return true;
  };
  tabs.forEach((tab, index) => {
    tab.addEventListener("click", () => select(tab));
    tab.addEventListener("keydown", (event) => { if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) return; event.preventDefault(); const nextIndex = event.key === "Home" ? 0 : event.key === "End" ? tabs.length - 1 : (index + (event.key === "ArrowRight" ? 1 : -1) + tabs.length) % tabs.length; select(tabs[nextIndex], { focus: true }); });
  });
  const requested = initialTabId && tabs.find(({ id }) => id === initialTabId);
  const declared = tabs.find((tab) => tab.getAttribute("aria-selected") === "true");
  select(requested || declared || tabs[0]);
  return Object.freeze({ select, tabs: Object.freeze(tabs), panels });
}
