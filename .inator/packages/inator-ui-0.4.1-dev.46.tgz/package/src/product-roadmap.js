export const PRODUCT_ROADMAP_SCHEMA = "inator.roadmap.v1";
export const ROADMAP_STATES = Object.freeze(["candidate", "scheduled", "delivered", "declined"]);
export const ROADMAP_SCORE_MIN = 1;
export const ROADMAP_SCORE_MAX = 5;

const requiredText = (value, field) => {
  const text = String(value || "").trim();
  if (!text) throw new TypeError(`${field} is required`);
  return text;
};

const optionalText = (value) => String(value || "").trim() || null;

function score(value, field) {
  if (value == null || value === "" || String(value).trim().toLowerCase() === "unknown") return null;
  const number = Number(value);
  if (!Number.isInteger(number) || number < ROADMAP_SCORE_MIN || number > ROADMAP_SCORE_MAX) {
    throw new TypeError(`${field} must be an integer from ${ROADMAP_SCORE_MIN} to ${ROADMAP_SCORE_MAX}`);
  }
  return number;
}

function isoDate(value, field) {
  const date = requiredText(value, field);
  const parsed = new Date(`${date}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== date) {
    throw new TypeError(`${field} must use a real YYYY-MM-DD date: ${date}`);
  }
  return date;
}

export function defineProductRoadmap(source = {}, { milestoneIds = [] } = {}) {
  const ids = new Set();
  const knownMilestones = new Set(milestoneIds.map(String));
  const items = (source.items || []).map((item, order) => {
    const id = requiredText(item.id, "Roadmap item id");
    if (ids.has(id)) throw new TypeError(`Duplicate roadmap item id: ${id}`);
    ids.add(id);
    const state = item.state || (item.milestoneId ? "scheduled" : "candidate");
    if (!ROADMAP_STATES.includes(state)) throw new TypeError(`Invalid roadmap state: ${state}`);
    const milestoneId = optionalText(item.milestoneId);
    if (state === "scheduled" && !milestoneId) throw new TypeError(`Scheduled roadmap item ${id} requires milestoneId`);
    if (milestoneId && knownMilestones.size && !knownMilestones.has(milestoneId)) throw new TypeError(`Unknown milestoneId ${milestoneId} on roadmap item ${id}`);
    const ease = score(item.ease, `Roadmap item ${id} ease`);
    const impact = score(item.impact, `Roadmap item ${id} impact`);
    return Object.freeze({
      id,
      title: requiredText(item.title, "Roadmap item title"),
      summary: requiredText(item.summary, "Roadmap item summary"),
      state,
      milestoneId,
      tags: Object.freeze([...new Set((item.tags || []).map((tag) => String(tag).trim()).filter(Boolean))]),
      ease,
      impact,
      payoff: ease == null || impact == null ? null : ease * impact,
      risk: optionalText(item.risk) || "unscoped",
      confidence: optionalText(item.confidence) || "unscoped",
      lastReviewedAt: isoDate(item.lastReviewedAt || source.updatedAt, `Roadmap item ${id} lastReviewedAt`),
      order
    });
  });
  return Object.freeze({
    schema: PRODUCT_ROADMAP_SCHEMA,
    product: requiredText(source.product, "Product name"),
    updatedAt: isoDate(source.updatedAt, "Roadmap update date"),
    items: Object.freeze(items)
  });
}

export function roadmapItemsForView(roadmap, { schedule = "scheduled" } = {}) {
  if (!roadmap?.items) throw new TypeError("A normalized product roadmap is required");
  if (schedule === "all") return [...roadmap.items];
  if (schedule === "unscheduled") return roadmap.items.filter(({ milestoneId, state }) => !milestoneId && state === "candidate");
  if (schedule !== "scheduled") throw new TypeError(`Unknown roadmap schedule filter: ${schedule}`);
  return roadmap.items.filter(({ milestoneId, state }) => Boolean(milestoneId) && ["scheduled", "delivered"].includes(state));
}
