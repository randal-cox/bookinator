import {
  PIPELINE_CONTROL_KINDS,
  normalizePipelinePresentation,
  pipelineAttemptInspection
} from "./pipeline.js";
import { createDialogSurface } from "./dialog.js";

const CONTROL_ICONS = Object.freeze({ start: "▶", stop: "■", retry: "↻", reset: "⟲" });

function formatDuration(attempt) {
  let seconds = Number(attempt?.durationSeconds);
  if ((!Number.isFinite(seconds) || seconds < 0) && attempt?.startedAt) {
    const end = attempt.completedAt ? new Date(attempt.completedAt) : new Date();
    seconds = (end - new Date(attempt.startedAt)) / 1000;
  }
  if (!Number.isFinite(seconds) || seconds < 0) return "Not recorded";
  if (seconds < 60) return `${seconds.toFixed(seconds < 10 ? 1 : 0)} seconds`;
  const minutes = Math.floor(seconds / 60);
  return `${minutes}m ${Math.round(seconds % 60)}s`;
}

function jsonText(value) {
  return value == null ? "Not available for this attempt." : JSON.stringify(value, null, 2);
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
}

function progressNode(progress) {
  if (!progress) return null;
  const wrapper = element("div", "inator-pipeline-progress");
  const meter = document.createElement("progress");
  meter.max = progress.total;
  meter.value = progress.completed;
  const label = progress.label || `${progress.completed} of ${progress.total}`;
  meter.setAttribute("aria-label", label);
  wrapper.append(meter, element("span", "", label));
  return wrapper;
}

function diagnosticsNode(diagnostics) {
  if (!diagnostics.length) return null;
  const list = element("ul", "inator-pipeline-diagnostics");
  for (const diagnostic of diagnostics) {
    const item = element("li", "", diagnostic.message);
    item.dataset.severity = diagnostic.severity;
    item.title = diagnostic.code;
    list.append(item);
  }
  return list;
}

function attemptsNode(stage, pipeline, onInspect) {
  if (!stage.attempts.length) return null;
  const details = element("details", "inator-pipeline-attempts");
  details.append(element("summary", "", `${stage.attempts.length} attempt${stage.attempts.length === 1 ? "" : "s"}`));
  const list = element("ol", "");

  for (const attempt of stage.attempts) {
    const item = element("li", "inator-pipeline-attempt");
    const heading = element("div", "inator-pipeline-attempt__heading");
    heading.append(
      element("strong", "", attempt.id),
      element("span", "", attempt.status)
    );
    if (attempt.id === stage.currentAttemptId) heading.append(element("em", "", "Current"));
    if (attempt.id === stage.acceptedAttemptId) heading.append(element("em", "", "Accepted"));
    item.append(heading);

    const facts = [attempt.actor, attempt.method, attempt.startedAt, attempt.completedAt].filter(Boolean);
    if (facts.length) item.append(element("p", "inator-pipeline-attempt__facts", facts.join(" · ")));
    const diagnostics = diagnosticsNode(attempt.diagnostics);
    if (diagnostics) item.append(diagnostics);
    if (attempt.inspectRef && onInspect) {
      const inspect = element("button", "inator-pipeline-inspect", "Inspect attempt");
      inspect.type = "button";
      inspect.addEventListener("click", () => onInspect({
        type: "attempt",
        inspectRef: attempt.inspectRef,
        attempt,
        stage,
        pipeline
      }));
      item.append(inspect);
    }
    list.append(item);
  }
  details.append(list);
  return details;
}

function inspectorDialog() {
  const tabs = element("div", "inator-run-inspector__tabs");
  tabs.setAttribute("role", "tablist");
  const panel = element("article", "inator-run-inspector__panel");
  const inspectorBody = element("div", "inator-run-inspector__content");
  inspectorBody.append(tabs, panel);
  const done = element("button", "primary", "Done");
  done.type = "button";
  done.dataset.dialogClose = "";
  const surface = createDialogSurface({
    context: "Pipeline run",
    title: "Run details",
    description: "Status, timing, provenance, and saved payloads",
    bodyContent: inspectorBody,
    footerContent: done,
    className: "inator-run-inspector",
    wide: true,
    controllerOptions: { closeOnBackdrop: false }
  });
  const views = ["overview", "input", "output"];
  const buttons = new Map();
  let selectedStage = null;
  let selectedAttempt = null;
  let selectedView = "overview";

  function show(view) {
    selectedView = view;
    for (const [name, button] of buttons) button.setAttribute("aria-selected", String(name === view));
    panel.replaceChildren();
    if (view === "overview") {
      const heading = element("h3", "", "Attempt record");
      const facts = element("dl", "inator-run-inspector__facts");
      const rows = [
        ["State", selectedStage.statusMeta.label],
        ["Attempt", selectedAttempt?.id || "No attempt issued"],
        ["Worker", selectedAttempt?.actor || "Not assigned"],
        ["Method", selectedAttempt?.method || selectedStage.method || "Not recorded"],
        ["Claim", selectedAttempt?.claimGeneration ? `Generation ${selectedAttempt.claimGeneration}` : "Not issued"],
        ["Started", selectedAttempt?.startedAt || "Not started"],
        ["Finished", selectedAttempt?.completedAt || "Not finished"],
        ["Elapsed", selectedAttempt ? formatDuration(selectedAttempt) : "Not started"]
      ];
      for (const [label, value] of rows) facts.append(element("dt", "", label), element("dd", "", value));
      panel.append(heading, facts);
      const diagnostics = diagnosticsNode(selectedAttempt?.diagnostics || []);
      if (diagnostics) panel.append(diagnostics);
    } else {
      panel.append(element("h3", "", view === "input" ? "Input JSON" : "Output JSON"));
      panel.append(element("pre", "inator-run-inspector__json", jsonText(selectedAttempt?.[view])));
    }
  }

  for (const view of views) {
    const button = element("button", "", view === "overview" ? "Run details" : `${view[0].toUpperCase()}${view.slice(1)} JSON`);
    button.type = "button";
    button.setAttribute("role", "tab");
    button.addEventListener("click", () => show(view));
    buttons.set(view, button);
    tabs.append(button);
  }
  function select(stage) {
    const inspection = pipelineAttemptInspection(stage);
    selectedStage = stage;
    selectedAttempt = inspection.attempt;
    surface.contextNode.textContent = selectedAttempt ? "Saved pipeline attempt" : "Pipeline step";
    surface.titleNode.textContent = stage.label;
    buttons.get("input").disabled = !inspection.views.input;
    buttons.get("output").disabled = !inspection.views.output;
    if (buttons.get(selectedView).disabled) selectedView = "overview";
    show(selectedView);
  }

  return {
    open(stage, opener) {
      selectedView = "overview";
      select(stage);
      surface.open(opener);
    },
    refresh(pipeline) {
      if (surface.backdrop.hidden || !selectedStage) return;
      const stage = pipeline.stages.find(({ id }) => id === selectedStage.id);
      if (stage) select(stage);
    },
    destroy() {
      surface.destroy();
    }
  };
}

function stageNode(stage, pipeline, onInspect, openInspector) {
  const item = element("li", "inator-pipeline-stage");
  item.dataset.status = stage.status;
  if (pipeline.currentJob?.stageId === stage.id) item.dataset.currentJob = "true";

  const disclosure = element("div", "inator-pipeline-stage__disclosure");
  const summary = element("button", "inator-pipeline-stage__summary");
  summary.type = "button";
  summary.setAttribute("aria-expanded", "false");

  const marker = element("span", "inator-pipeline-stage__marker");
  marker.setAttribute("aria-hidden", "true");
  const body = element("span", "inator-pipeline-stage__body");
  const heading = element("span", "inator-pipeline-stage__heading");
  heading.append(element("strong", "", stage.label));
  if (pipeline.currentJob?.stageId === stage.id) heading.append(element("em", "", "Current job"));
  body.append(heading);
  if (stage.detail) body.append(element("span", "inator-pipeline-stage__detail", stage.detail));

  const facts = [stage.actor, stage.method].filter(Boolean);
  if (facts.length) body.append(element("span", "inator-pipeline-stage__facts", facts.join(" · ")));
  const progress = progressNode(stage.progress);
  if (progress) body.append(progress);

  const badge = element("button", "inator-pipeline-stage__status", stage.statusMeta.label);
  badge.type = "button";
  badge.title = `Inspect status, elapsed time, input, and output for ${stage.label}`;
  badge.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    openInspector(stage, badge);
  });
  summary.append(marker, body);

  const result = element("div", "inator-pipeline-stage__result");
  result.hidden = true;
  summary.addEventListener("click", () => {
    result.hidden = !result.hidden;
    summary.setAttribute("aria-expanded", String(!result.hidden));
  });
  if (stage.blockingReasons.length) {
    const reasons = element("ul", "inator-pipeline-blocking");
    for (const reason of stage.blockingReasons) reasons.append(element("li", "", reason.message));
    result.append(reasons);
  }
  const attempts = attemptsNode(stage, pipeline, onInspect);
  const acceptedAttempt = stage.attempts.find(({ id }) => id === stage.acceptedAttemptId);
  const latestAttempt = acceptedAttempt || stage.attempts.at(-1);
  const resultSummary = latestAttempt?.output?.summary
    || (stage.status === "failed" ? "This attempt failed; its diagnostics and input remain inspectable."
      : stage.status === "running" ? "Work is underway. Input is available; output does not exist yet."
        : "No result has been produced for this step yet.");
  result.append(element("p", "inator-pipeline-stage__result-summary", resultSummary));
  if (attempts) result.append(attempts);
  else result.append(element("p", "inator-pipeline-stage__empty", "No attempt has been issued for this step."));
  disclosure.append(summary, badge, result);
  item.append(disclosure);
  return item;
}

function render(mount, rawPresentation, onAction, onInspect, onHumanTask, inspector) {
  const pipeline = normalizePipelinePresentation(rawPresentation);
  mount.className = "inator-pipeline";
  mount.dataset.status = pipeline.status;

  const header = element("header", "inator-pipeline__header");
  const title = element("div", "inator-pipeline__title");
  title.append(
    element("h2", "", pipeline.label),
    element("p", "inator-pipeline__activity", pipeline.activity.text || pipeline.statusMeta.label)
  );
  header.append(title);
  const overallProgress = progressNode(pipeline.progress);
  if (overallProgress) header.append(overallProgress);

  const controls = element("div", "inator-pipeline__controls");
  controls.setAttribute("aria-label", `${pipeline.label} controls`);
  for (const kind of PIPELINE_CONTROL_KINDS) {
    const control = pipeline.controls[kind];
    if (!control.visible) continue;
    const button = element("button", "inator-pipeline-control");
    button.type = "button";
    button.dataset.kind = kind;
    button.disabled = !control.enabled;
    if (control.reason) button.title = control.reason;
    const icon = element("span", "", CONTROL_ICONS[kind]);
    icon.setAttribute("aria-hidden", "true");
    button.append(icon, document.createTextNode(control.label));
    button.addEventListener("click", () => onAction?.({ action: kind, pipeline }));
    controls.append(button);
  }
  if (controls.childElementCount) header.append(controls);

  const humanTasks = element("section", "inator-pipeline__human-tasks");
  humanTasks.setAttribute("aria-label", "Ready human tasks");
  for (const task of pipeline.humanTasks.filter(({ status }) => status === "ready")) { const copy = element("div", ""); copy.append(element("strong", "", task.label)); if (task.detail) copy.append(element("span", "", task.detail)); const button = element("button", "inator-pipeline-control", task.actionLabel); button.type = "button"; button.addEventListener("click", () => onHumanTask?.({ task, pipeline })); humanTasks.append(copy, button); }

  const stages = element("ol", "inator-pipeline__stages");
  for (const stage of pipeline.stages) stages.append(stageNode(stage, pipeline, onInspect, inspector.open));
  mount.replaceChildren(header, ...(humanTasks.childElementCount ? [humanTasks] : []), stages);
  return pipeline;
}

export function createPipelineView({ mount, presentation, onAction, onInspect, onHumanTask } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createPipelineView requires a DOM mount element.");
  const inspector = inspectorDialog();
  let current = render(mount, presentation, onAction, onInspect, onHumanTask, inspector);
  return {
    get presentation() { return current; },
    update(nextPresentation) {
      current = render(mount, nextPresentation, onAction, onInspect, onHumanTask, inspector);
      inspector.refresh(current);
      return current;
    },
    destroy() {
      mount.replaceChildren();
      inspector.destroy();
      mount.classList.remove("inator-pipeline");
      delete mount.dataset.status;
    }
  };
}
