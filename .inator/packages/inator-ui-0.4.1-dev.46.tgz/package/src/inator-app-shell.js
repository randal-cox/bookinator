import { mountProductShell } from "./product-shell.js";
import { workspaceUtilityFromCapabilities } from "./workspace-capabilities.js";

export function normalizeInatorAppShellConfig({
  workspaceRegistry,
  workspaceUtility = {},
  ...productShell
} = {}) {
  if (!workspaceRegistry?.capabilities) {
    throw new TypeError("An Inator application shell requires a Workspace capability registry.");
  }
  return {
    ...productShell,
    utility: workspaceUtilityFromCapabilities(workspaceRegistry, workspaceUtility)
  };
}

export function mountInatorAppShell(options = {}) {
  return mountProductShell(normalizeInatorAppShellConfig(options));
}
