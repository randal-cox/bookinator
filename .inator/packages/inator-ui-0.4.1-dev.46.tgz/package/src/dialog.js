const interactiveSelector = [
  "button:not([disabled])",
  "[href]",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[tabindex]:not([tabindex='-1'])"
].join(",");

function focusableWithin(dialog) {
  return [...dialog.querySelectorAll(interactiveSelector)]
    .filter((element) => !element.hidden && element.getAttribute("aria-hidden") !== "true");
}

export function installMovableDialog(dialog) {
  if (!dialog || dialog.dataset.inatorMovable === "true") return () => {};
  dialog.dataset.inatorMovable = "true";
  const handle = dialog.querySelector("[data-dialog-drag-handle]");
  if (!handle) return () => {};
  let drag = null;

  const start = (event) => {
    if (event.defaultPrevented || event.button !== 0 || event.target.closest("button, input, select, textarea, a, label, summary, [contenteditable], [data-no-dialog-drag]")) return;
    const rect = dialog.getBoundingClientRect();
    const styles = getComputedStyle(dialog);
    drag = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      originX: Number.parseFloat(styles.getPropertyValue("--inator-dialog-x")) || 0,
      originY: Number.parseFloat(styles.getPropertyValue("--inator-dialog-y")) || 0,
      rect
    };
    handle.setPointerCapture?.(event.pointerId);
    dialog.classList.add("is-dragging");
    event.preventDefault();
  };
  const move = (event) => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    const wantedX = drag.originX + event.clientX - drag.startX;
    const wantedY = drag.originY + event.clientY - drag.startY;
    const minimumX = drag.originX - drag.rect.left;
    const maximumX = drag.originX + innerWidth - drag.rect.right;
    const minimumY = drag.originY - drag.rect.top;
    const maximumY = drag.originY + innerHeight - drag.rect.bottom;
    dialog.style.setProperty("--inator-dialog-x", `${Math.min(maximumX, Math.max(minimumX, wantedX))}px`);
    dialog.style.setProperty("--inator-dialog-y", `${Math.min(maximumY, Math.max(minimumY, wantedY))}px`);
  };
  const finish = (event) => {
    if (!drag || event.pointerId !== drag.pointerId) return;
    drag = null;
    dialog.classList.remove("is-dragging");
  };

  handle.addEventListener("pointerdown", start);
  handle.addEventListener("pointermove", move);
  handle.addEventListener("pointerup", finish);
  handle.addEventListener("pointercancel", finish);
  return () => {
    handle.removeEventListener("pointerdown", start);
    handle.removeEventListener("pointermove", move);
    handle.removeEventListener("pointerup", finish);
    handle.removeEventListener("pointercancel", finish);
    delete dialog.dataset.inatorMovable;
  };
}

export function createDialogController(backdrop, options = {}) {
  if (!(backdrop instanceof HTMLElement)) throw new TypeError("A dialog backdrop element is required");
  const dialog = assertDialogConformance(backdrop, { requireController: false });
  let returnTarget = null;
  let dirtyGuardOpen = false;
  let obscuredSiblings = [];
  const removeMovement = installMovableDialog(dialog);
  backdrop.dataset.inatorDialogControlled = "true";

  const focusInitial = () => {
    const requested = typeof options.initialFocus === "function" ? options.initialFocus(dialog) : null;
    (requested || dialog.querySelector("[autofocus]") || focusableWithin(dialog)[0] || dialog).focus({ preventScroll: true });
  };
  const close = (reason = "close", { force = false } = {}) => {
    if (!force && options.isDirty?.()) {
      dirtyGuardOpen = true;
      backdrop.classList.add("has-discard-warning");
      const guard = backdrop.querySelector("[data-dialog-discard-warning]");
      if (guard) guard.hidden = false;
      backdrop.querySelector("[data-dialog-keep-editing]")?.focus();
      options.onDirtyClose?.(reason);
      return false;
    }
    dirtyGuardOpen = false;
    backdrop.classList.remove("has-discard-warning");
    const guard = backdrop.querySelector("[data-dialog-discard-warning]");
    if (guard) guard.hidden = true;
    document.removeEventListener("keydown", onKeydown, true);
    backdrop.hidden = true;
    obscuredSiblings.forEach(({ element, inert, ariaHidden }) => {
      element.inert = inert;
      if (ariaHidden === null) element.removeAttribute("aria-hidden");
      else element.setAttribute("aria-hidden", ariaHidden);
    });
    obscuredSiblings = [];
    options.onClose?.(reason);
    if (returnTarget?.isConnected) returnTarget.focus({ preventScroll: true });
    returnTarget = null;
    return true;
  };
  const open = (opener = document.activeElement) => {
    returnTarget = opener instanceof HTMLElement ? opener : null;
    dialog.style.removeProperty("--inator-dialog-x");
    dialog.style.removeProperty("--inator-dialog-y");
    obscuredSiblings = [...document.body.children]
      .filter((element) => element !== backdrop && !element.contains(backdrop))
      .map((element) => ({ element, inert: element.inert, ariaHidden: element.getAttribute("aria-hidden") }));
    obscuredSiblings.forEach(({ element }) => {
      element.inert = true;
      element.setAttribute("aria-hidden", "true");
    });
    backdrop.hidden = false;
    document.addEventListener("keydown", onKeydown, true);
    options.onOpen?.();
    requestAnimationFrame(focusInitial);
  };
  const onClick = (event) => {
    if (event.target.closest("[data-dialog-close]")) close("control");
    if (event.target.closest("[data-dialog-discard]")) close("discard", { force: true });
    if (event.target.closest("[data-dialog-keep-editing]")) {
      dirtyGuardOpen = false;
      backdrop.classList.remove("has-discard-warning");
      const guard = backdrop.querySelector("[data-dialog-discard-warning]");
      if (guard) guard.hidden = true;
      focusInitial();
    }
    if (event.target === backdrop && options.closeOnBackdrop !== false) close("backdrop");
  };
  const onKeydown = (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      if (dirtyGuardOpen) backdrop.querySelector("[data-dialog-keep-editing]")?.click();
      else close("escape");
      return;
    }
    if (event.key !== "Tab") return;
    const items = focusableWithin(dialog);
    if (!items.length) return;
    const first = items[0];
    const last = items.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  backdrop.addEventListener("click", onClick);
  return {
    dialog,
    open,
    close,
    destroy() {
      removeMovement();
      delete backdrop.dataset.inatorDialogControlled;
      backdrop.removeEventListener("click", onClick);
      document.removeEventListener("keydown", onKeydown, true);
    },
    setBusy(busy, message = "") {
      dialog.setAttribute("aria-busy", String(Boolean(busy)));
      dialog.querySelectorAll("button, input, select, textarea").forEach((control) => {
        if (control.matches("[data-dialog-close], [data-dialog-keep-editing]")) return;
        control.disabled = Boolean(busy);
      });
      const status = dialog.querySelector("[data-dialog-status]");
      if (status && message) status.textContent = message;
    }
  };
}

let dialogSurfaceSequence = 0;

function appendDialogContent(parent, content) {
  const values = Array.isArray(content) ? content : [content];
  for (const value of values) {
    if (value == null) continue;
    if (value instanceof Node) parent.append(value);
    else parent.append(document.createTextNode(String(value)));
  }
}

export function assertDialogConformance(backdrop, { requireController = true } = {}) {
  if (!(backdrop instanceof HTMLElement) || !backdrop.classList.contains("inator-dialog-backdrop")) {
    throw new TypeError("An Inator dialog requires an .inator-dialog-backdrop root.");
  }
  const dialog = backdrop.querySelector(":scope > .inator-dialog[role='dialog'][aria-modal='true']");
  if (!dialog) throw new TypeError("An Inator dialog requires one labelled modal .inator-dialog region.");
  if (!dialog.getAttribute("aria-labelledby") && !dialog.getAttribute("aria-label")) {
    throw new TypeError("An Inator dialog requires an accessible label.");
  }
  if (!dialog.querySelector(".inator-dialog__heading[data-dialog-drag-handle]")) {
    throw new TypeError("An Inator dialog heading must be the drag handle.");
  }
  if (!dialog.querySelector(".inator-dialog__body")) {
    throw new TypeError("An Inator dialog requires an .inator-dialog__body.");
  }
  if (!dialog.querySelector(".inator-dialog__footer")) {
    throw new TypeError("An Inator dialog requires an .inator-dialog__footer.");
  }
  if (requireController && backdrop.dataset.inatorDialogControlled !== "true") {
    throw new TypeError("Inator-styled dialogs must install createDialogController and movable behavior.");
  }
  return dialog;
}

export function createDialogSurface({
  mount = document.body,
  context = "",
  title = "Dialog",
  description = "",
  bodyContent = [],
  footerContent = [],
  className = "",
  wide = false,
  controllerOptions = {}
} = {}) {
  if (!mount?.append) throw new TypeError("A dialog surface requires a mount element.");

  const backdrop = document.createElement("div");
  backdrop.className = "inator-dialog-backdrop";
  backdrop.hidden = true;

  const dialog = document.createElement("section");
  dialog.className = ["inator-dialog", wide ? "is-wide" : "", className].filter(Boolean).join(" ");
  dialog.setAttribute("role", "dialog");
  dialog.setAttribute("aria-modal", "true");
  dialog.tabIndex = -1;

  const heading = document.createElement("header");
  heading.className = "inator-dialog__heading";
  heading.dataset.dialogDragHandle = "";
  const contextNode = document.createElement("p");
  contextNode.className = "context";
  contextNode.textContent = context;
  const titleNode = document.createElement("h2");
  titleNode.id = "inator-dialog-" + (++dialogSurfaceSequence);
  titleNode.textContent = title;
  dialog.setAttribute("aria-labelledby", titleNode.id);
  const descriptionNode = document.createElement("p");
  descriptionNode.textContent = description;
  descriptionNode.hidden = !description;
  heading.append(contextNode, titleNode, descriptionNode);

  const body = document.createElement("div");
  body.className = "inator-dialog__body";
  appendDialogContent(body, bodyContent);
  const footer = document.createElement("footer");
  footer.className = "inator-dialog__footer";
  appendDialogContent(footer, footerContent);

  dialog.append(heading, body, footer);
  backdrop.append(dialog);
  mount.append(backdrop);
  const controller = createDialogController(backdrop, controllerOptions);

  return {
    backdrop,
    dialog,
    heading,
    body,
    footer,
    contextNode,
    titleNode,
    descriptionNode,
    controller,
    open: controller.open,
    close: controller.close,
    destroy() {
      controller.destroy();
      backdrop.remove();
    }
  };
}
