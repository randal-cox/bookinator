export function normalizeWorkspaceDiagnostics(input = {}) {
  const count = Number(input.count);
  return {
    count: Number.isSafeInteger(count) && count >= 0 ? count : 0,
    storageLabel: String(input.storageLabel ?? "Stored locally").trim() || "Stored locally",
    retentionLabel: String(input.retentionLabel ?? "").trim() || null,
    downloadHref: String(input.downloadHref ?? "").trim() || null,
    detail: String(input.detail ?? "").trim() || null
  };
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
}

function render(mount, rawModel, onDownload) {
  const model = normalizeWorkspaceDiagnostics(rawModel);
  const section = element("section", "inator-workspace-diagnostics");
  const copy = element("div", "inator-workspace-diagnostics__copy");
  copy.append(
    element("h2", "", "Diagnostics"),
    element("p", "", "Console and structural browser diagnostics are retained locally. Page content and screenshots are not captured.")
  );
  const facts = element("p", "inator-workspace-diagnostics__facts");
  facts.append(
    element("strong", "", `${model.count} ${model.count === 1 ? "entry" : "entries"}`),
    document.createTextNode(` · ${model.storageLabel}${model.retentionLabel ? ` · ${model.retentionLabel}` : ""}`)
  );
  copy.append(facts);
  if (model.detail) copy.append(element("p", "inator-workspace-diagnostics__detail", model.detail));

  let download;
  if (model.downloadHref) {
    download = element("a", "inator-workspace-diagnostics__download", "Download JSONL");
    download.href = model.downloadHref;
    download.download = "";
  } else {
    download = element("button", "inator-workspace-diagnostics__download", "Download JSONL");
    download.type = "button";
    download.disabled = !onDownload;
    download.addEventListener("click", () => onDownload?.(model));
  }
  section.append(copy, download);
  mount.replaceChildren(section);
  return model;
}

export function createWorkspaceDiagnosticsView({ mount, model, onDownload } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createWorkspaceDiagnosticsView requires a DOM mount element.");
  let current = render(mount, model, onDownload);
  return {
    get model() { return current; },
    update(nextModel) {
      current = render(mount, nextModel, onDownload);
      return current;
    },
    destroy() { mount.replaceChildren(); }
  };
}
