const ID = /^[a-z][a-z0-9.-]*$/;
const SOURCE_TYPES = new Set(["journal-article", "report", "regulation", "web-page", "software", "dataset", "book"]);
const CONTEXT_SCOPES = new Set(["direct-calculation", "full-result", "validation", "interpretation"]);
const CONTRIBUTION_KINDS = new Set(["parameter", "equation", "method", "dataset", "validation", "interpretation", "regulatory-definition"]);

const freeze = Object.freeze;
function text(value, label) { const result = String(value ?? "").trim(); if (!result) throw new TypeError(`${label} is required.`); return result; }
function stableId(value, label) { const result = text(value, label); if (!ID.test(result)) throw new TypeError(`${label} must be a stable lowercase id.`); return result; }
function list(value, label) { if (!Array.isArray(value)) throw new TypeError(`${label} must be an array.`); return value; }
function unique(records, label) { const seen = new Set(); for (const record of records) { if (seen.has(record.id)) throw new TypeError(`${label} ids must be unique: ${record.id}.`); seen.add(record.id); } return records; }

function author(value, index) {
  if (typeof value === "string") return freeze({ literal: text(value, `authors[${index}]`) });
  if (value?.literal) return freeze({ literal: text(value.literal, `authors[${index}].literal`) });
  const family = text(value?.family, `authors[${index}].family`);
  return freeze({ family, ...(value.given ? { given: text(value.given, `authors[${index}].given`) } : {}) });
}

function identifier(value, index) {
  return freeze({ scheme: stableId(value?.scheme, `identifiers[${index}].scheme`), value: text(value?.value, `identifiers[${index}].value`) });
}

export function defineCitationRegistry(source = {}) {
  const sources = unique(list(source.sources, "citation sources").map((item, index) => {
    const type = stableId(item.type, `sources[${index}].type`);
    if (!SOURCE_TYPES.has(type) && !type.startsWith("x-")) throw new TypeError(`sources[${index}].type is unknown; product extensions must start with x-.`);
    const authors = list(item.authors || [], `sources[${index}].authors`).map(author);
    const year = item.issued?.year == null ? null : Number(item.issued.year);
    if (year != null && (!Number.isInteger(year) || year < 1000 || year > 9999)) throw new TypeError(`sources[${index}].issued.year must be a four-digit year or null.`);
    const issued = freeze({ year, ...(item.issued?.literal ? { literal: text(item.issued.literal, "issued.literal") } : {}) });
    if (year == null && !issued.literal) throw new TypeError(`sources[${index}].issued requires a year or literal date.`);
    const identifiers = list(item.identifiers || [], `sources[${index}].identifiers`).map(identifier);
    if (!item.url && !identifiers.length) throw new TypeError(`sources[${index}] requires a URL or identifier.`);
    return freeze({
      id: stableId(item.id, `sources[${index}].id`), type, title: text(item.title, `sources[${index}].title`),
      authors: freeze(authors), issued, identifiers: freeze(identifiers),
      ...(item.containerTitle ? { containerTitle: text(item.containerTitle, "source.containerTitle") } : {}),
      ...(item.publisher ? { publisher: text(item.publisher, "source.publisher") } : {}),
      ...(item.version ? { version: text(item.version, "source.version") } : {}),
      ...(item.genre ? { genre: text(item.genre, "source.genre") } : {}),
      ...(item.url ? { url: text(item.url, "source.url") } : {}),
      ...(item.citationText ? { citationText: text(item.citationText, "source.citationText") } : {})
    });
  }), "citation source");
  return freeze({ schema: "inator.citation-registry.v1", id: stableId(source.id, "citation registry id"), sources: freeze(sources) });
}

export function defineCitationContext(source = {}) {
  const scope = stableId(source.scope, "citation context scope");
  if (!CONTEXT_SCOPES.has(scope) && !scope.startsWith("x-")) throw new TypeError("citation context scope is unknown; product extensions must start with x-.");
  const uses = unique(list(source.uses, "citation uses").map((item, index) => {
    const kind = stableId(item.kind, `uses[${index}].kind`);
    if (!CONTRIBUTION_KINDS.has(kind) && !kind.startsWith("x-")) throw new TypeError(`uses[${index}].kind is unknown; product extensions must start with x-.`);
    return freeze({ id: stableId(item.id, `uses[${index}].id`), sourceId: stableId(item.sourceId, `uses[${index}].sourceId`), kind, contribution: text(item.contribution, `uses[${index}].contribution`), via: freeze(list(item.via || [], `uses[${index}].via`).map((value, viaIndex) => stableId(value, `uses[${index}].via[${viaIndex}]`))) });
  }), "citation use");
  if (!uses.length) throw new TypeError("A citation context requires at least one use.");
  return freeze({ schema: "inator.citation-context.v1", id: stableId(source.id, "citation context id"), subjectId: stableId(source.subjectId, "citation context subjectId"), scope, scopeDescription: text(source.scopeDescription, "citation context scopeDescription"), uses: freeze(uses) });
}

export function resolveCitationContext(registrySource, contextSource) {
  const registry = registrySource?.schema === "inator.citation-registry.v1" ? registrySource : defineCitationRegistry(registrySource);
  const context = contextSource?.schema === "inator.citation-context.v1" ? contextSource : defineCitationContext(contextSource);
  const byId = new Map(registry.sources.map((source) => [source.id, source]));
  for (const use of context.uses) if (!byId.has(use.sourceId)) throw new TypeError(`Citation use ${use.id} references unknown source ${use.sourceId}.`);
  const sourceIds = [...new Set(context.uses.map(({ sourceId }) => sourceId))];
  return freeze({ schema: "inator.resolved-citations.v1", registryId: registry.id, contextId: context.id, subjectId: context.subjectId, scope: context.scope, scopeDescription: context.scopeDescription, sources: freeze(sourceIds.map((sourceId) => freeze({ source: byId.get(sourceId), uses: freeze(context.uses.filter((use) => use.sourceId === sourceId)) }))) });
}

export function citationContextArtifact(resolvedSource) {
  const resolved = resolvedSource?.schema === "inator.resolved-citations.v1" ? resolvedSource : (() => { throw new TypeError("citationContextArtifact requires resolved citations."); })();
  return freeze({ id: "citation-context", label: "Why these citations were used", filename: `${resolved.subjectId}-citation-context.json`, mediaType: "application/json", content: `${JSON.stringify(resolved, null, 2)}\n`, inspection: freeze({ mode: "structured-data", syntax: "json", description: resolved.scopeDescription }) });
}

function displayAuthor(value) { return value.literal || [value.family, value.given].filter(Boolean).join(", "); }
function bibtexText(value) { return String(value).replace(/\\/g, "\\textbackslash{}").replace(/([{}])/g, "\\$1"); }
function bibtexAuthor(value) { return value.literal ? `{{${bibtexText(value.literal)}}}` : bibtexText([value.family, value.given].filter(Boolean).join(", ")); }
function identifierValue(source, scheme) { return source.identifiers.find((item) => item.scheme === scheme)?.value; }
function cslType(type) { return ({ "journal-article": "article-journal", "web-page": "webpage", regulation: "legislation" })[type] || type; }
function risType(type) { return ({ "journal-article": "JOUR", report: "RPRT", regulation: "STAT", "web-page": "ELEC", software: "COMP", dataset: "DATA", book: "BOOK" })[type] || "GEN"; }

function exportArtifacts(sources, basename) {
  const csl = sources.map((source) => ({ id: source.id, type: cslType(source.type), title: source.title, author: source.authors, ...(source.issued.year ? { issued: { "date-parts": [[source.issued.year]] } } : {}), ...(source.containerTitle ? { "container-title": source.containerTitle } : {}), ...(source.publisher ? { publisher: source.publisher } : {}), ...(source.version ? { version: source.version } : {}), ...(source.url ? { URL: source.url } : {}), ...(identifierValue(source, "doi") ? { DOI: identifierValue(source, "doi") } : {}) }));
  const bibtex = sources.map((source) => {
    const kind = source.type === "journal-article" ? "article" : source.type === "book" ? "book" : "misc";
    const fields = [`author = {${source.authors.map(bibtexAuthor).join(" and ")}}`, `title = {${bibtexText(source.title)}}`, ...(source.issued.year ? [`year = {${source.issued.year}}`] : []), ...(source.containerTitle ? [`journal = {${bibtexText(source.containerTitle)}}`] : []), ...(source.publisher ? [`publisher = {${bibtexText(source.publisher)}}`] : []), ...(source.version ? [`note = {Version ${bibtexText(source.version)}}`] : []), ...(source.url ? [`url = {${bibtexText(source.url)}}`] : []), ...(identifierValue(source, "doi") ? [`doi = {${bibtexText(identifierValue(source, "doi"))}}`] : [])];
    return `@${kind}{${source.id},\n  ${fields.join(",\n  ")}\n}`;
  }).join("\n\n") + "\n";
  const ris = sources.map((source) => [
    `TY  - ${risType(source.type)}`, ...source.authors.map((value) => `AU  - ${displayAuthor(value)}`), `TI  - ${source.title}`,
    ...(source.issued.year ? [`PY  - ${source.issued.year}`] : []), ...(source.containerTitle ? [`JO  - ${source.containerTitle}`] : []),
    ...(source.publisher ? [`PB  - ${source.publisher}`] : []), ...(source.url ? [`UR  - ${source.url}`] : []),
    ...(identifierValue(source, "doi") ? [`DO  - ${identifierValue(source, "doi")}`] : []), ...(source.version ? [`N1  - Version ${source.version}`] : []), "ER  - "
  ].join("\n")).join("\n\n") + "\n";
  return freeze([
    freeze({ id: "csl-json", label: "CSL JSON", filename: `${basename}.json`, mediaType: "application/vnd.citationstyles.csl+json", content: `${JSON.stringify(csl, null, 2)}\n` }),
    freeze({ id: "bibtex", label: "BibTeX", filename: `${basename}.bib`, mediaType: "application/x-bibtex", content: bibtex }),
    freeze({ id: "ris", label: "RIS", filename: `${basename}.ris`, mediaType: "application/x-research-info-systems", content: ris })
  ]);
}

export function citationRegistryExportArtifacts(registrySource) {
  const registry = registrySource?.schema === "inator.citation-registry.v1" ? registrySource : defineCitationRegistry(registrySource);
  return exportArtifacts(registry.sources, `${registry.id}-bibliography`);
}

export function citationContextExportArtifacts(resolvedSource) {
  if (resolvedSource?.schema !== "inator.resolved-citations.v1") throw new TypeError("citationContextExportArtifacts requires resolved citations.");
  return exportArtifacts(resolvedSource.sources.map(({ source }) => source), `${resolvedSource.subjectId}-citations`);
}

export const CITATION_SOURCE_TYPES = freeze([...SOURCE_TYPES]);
export const CITATION_CONTEXT_SCOPES = freeze([...CONTEXT_SCOPES]);
export const CITATION_CONTRIBUTION_KINDS = freeze([...CONTRIBUTION_KINDS]);
