import { createToolButton } from "./action-bar.js";
import { createArtifactInspector, normalizeInspectableArtifacts } from "./artifact-inspector.js";
import { createDialogSurface } from "./dialog.js";
import { createInatorIcon } from "./icons.js";
import { defineGeneratedArtifactLedger, defineTrustSurface } from "./trust.js";
import { defineProductAbout } from "./product-about.js";
import { citationRegistryExportArtifacts, defineCitationRegistry } from "./citation-registry.js";

function element(tag, className = "", text = "") {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
}

function productContent(value) {
  const resolved = typeof value === "function" ? value() : value?.cloneNode?.(true) || value;
  if (resolved != null && !(resolved instanceof Node)) throw new TypeError("Disclosure introContent must be a Node or a function returning a Node.");
  return resolved;
}

function trustContract(value) {
  return defineTrustSurface(value);
}

function sameInspection(left = {}, right = {}) {
  return left.mode === right.mode && (left.syntax || "") === (right.syntax || "");
}

export function bindTrustArtifacts(trustValue, artifactValues, { generatedLedger = null } = {}) {
  const trust = trustContract(trustValue);
  if (!trust.reproduction) throw new TypeError("Inspectable Trust artifacts require a reproduction packet.");
  const artifacts = normalizeInspectableArtifacts(artifactValues);
  const supplied = new Map(artifacts.map((artifact) => [artifact.id, artifact]));
  const runtime = generatedLedger ? defineGeneratedArtifactLedger(generatedLedger) : null;
  const inspectable = [...trust.reproduction.artifacts.filter(({ inspection }) => inspection), ...(runtime?.artifacts || [])];
  const declaredIds = new Set(inspectable.map(({ id }) => id));
  if (declaredIds.size !== inspectable.length) throw new TypeError("Stable and generated Trust artifact ids must not collide.");
  for (const declared of inspectable) {
    const artifact = supplied.get(declared.id);
    if (!artifact) throw new TypeError(`Trust artifact ${declared.id} is declared inspectable but was not supplied.`);
    if (artifact.filename !== declared.filename) throw new TypeError(`Trust artifact ${declared.id} filename does not match its manifest.`);
    if (artifact.mediaType !== declared.mediaType) throw new TypeError(`Trust artifact ${declared.id} media type does not match its manifest.`);
    if (!sameInspection(artifact.inspection, declared.inspection)) throw new TypeError(`Trust artifact ${declared.id} inspection metadata does not match its manifest.`);
  }
  for (const artifact of artifacts) if (!declaredIds.has(artifact.id)) throw new TypeError(`Trust artifact ${artifact.id} is absent from the stable or generated manifest.`);
  return Object.freeze({ trust, artifacts, ...(runtime ? { generatedLedger: runtime } : {}) });
}

async function sha256(content) {
  if (!globalThis.crypto?.subtle) throw new TypeError("SHA-256 verification is unavailable in this environment.");
  const bytes = new TextEncoder().encode(content);
  const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}

export async function verifyTrustArtifacts(trustValue, artifactValues, options = {}) {
  const bound = bindTrustArtifacts(trustValue, artifactValues, options);
  const manifest = new Map([...bound.trust.reproduction.artifacts, ...(bound.generatedLedger?.artifacts || [])].map((artifact) => [artifact.id, artifact]));
  for (const artifact of bound.artifacts) {
    const expected = manifest.get(artifact.id).integrity.value;
    const actual = await sha256(artifact.content);
    if (actual !== expected) throw new TypeError(`Trust artifact ${artifact.id} does not match its declared SHA-256 digest.`);
  }
  return bound;
}

export async function captureGeneratedArtifacts({ id, snapshotId, artifacts: artifactValues, generatedAt = new Date().toISOString() } = {}) {
  const artifacts = normalizeInspectableArtifacts(artifactValues);
  const sourceById = new Map(artifactValues.map((artifact) => [artifact.id, artifact]));
  const declarations = await Promise.all(artifacts.map(async (artifact) => ({ id: artifact.id, label: artifact.label, role: sourceById.get(artifact.id).role, filename: artifact.filename, mediaType: artifact.mediaType, inspection: artifact.inspection, integrity: { algorithm: "sha256", value: await sha256(artifact.content) } })));
  const generatedLedger = defineGeneratedArtifactLedger({ id, snapshotId, generatedAt, artifacts: declarations });
  return Object.freeze({ artifacts, generatedLedger });
}

export function createTrustIcon() { return createInatorIcon("trust"); }

export function createTrustToolButton({ label = "Trust", ...options } = {}) {
  return createToolButton({ ...options, className: ["inator-trust-button", options.className].filter(Boolean).join(" "), icon: createTrustIcon(), label });
}

export function createCitationIcon() { return createInatorIcon("citation"); }

export function createCitationToolButton({ label = "Citation", ...options } = {}) {
  return createToolButton({ ...options, className: ["inator-citation-button", options.className].filter(Boolean).join(" "), icon: createCitationIcon(), label });
}

export function mountAboutDisclosure({ mount, kind, label, identity, description, icon, bodyContent, onDestroy = null } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("An About disclosure requires a mount element.");
  if (!new Set(["trust", "citation"]).has(kind)) throw new TypeError("An About disclosure kind must be trust or citation.");
  const trigger = createToolButton({ className: `inator-${kind}-button`, icon, label });
  const close = element("button", "", "Close"); close.type = "button"; close.dataset.dialogClose = "";
  const dialog = createDialogSurface({ context: "About this Inator", title: label, description, bodyContent, footerContent: close, className: `inator-trust-dialog inator-about-disclosure-dialog inator-about-disclosure-dialog--${kind}`, wide: true });
  const entry = element("section", `inator-about-disclosure inator-about-disclosure--${kind}`);
  entry.append(element("div", "inator-about-disclosure__identity", identity), trigger);
  mount.replaceChildren(entry);
  const open = () => dialog.open(trigger); trigger.addEventListener("click", open);
  return Object.freeze({ kind, root: entry, trigger, dialog, destroy() { trigger.removeEventListener("click", open); onDestroy?.(); dialog.destroy(); entry.remove(); } });
}

function citationArtifact(artifact, group, groupLabel, description) {
  return { ...artifact, id: `${group}-${artifact.id}`, label: `${groupLabel} · ${artifact.label}`, inspection: { mode: artifact.filename.endsWith(".json") ? "structured-data" : "text", syntax: artifact.filename.split(".").at(-1), description } };
}

export function mountAboutCitation({ mount, about: aboutValue, citationRegistry = null, introContent = null, label = "Citation" } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("About Citation requires a mount element.");
  const about = aboutValue?.schema === "inator.product-about.v1" ? aboutValue : defineProductAbout(aboutValue);
  const registry = citationRegistry ? (citationRegistry.schema === "inator.citation-registry.v1" ? citationRegistry : defineCitationRegistry(citationRegistry)) : null;
  const artifacts = [
    ...about.citation.exports.map((artifact) => citationArtifact(artifact, "software", "Software", `Portable citation for ${about.product.name}.`)),
    ...(registry ? citationRegistryExportArtifacts(registry).map((artifact) => citationArtifact(artifact, "bibliography", "Bibliography", `Complete ${about.product.name} bibliography.`)) : [])
  ];
  const body = element("div", "inator-about-disclosure__dialog");
  const summary = element("section", "inator-about-disclosure__summary");
  summary.append(element("p", "inator-information-kicker", "Attribution and export"), element("h3", "", "Cite this work or take its bibliography."), element("p", "inator-about-disclosure__citation", about.citation.text));
  const extra = productContent(introContent); if (extra) summary.append(extra);
  const files = element("div"); body.append(summary, files);
  const inspector = createArtifactInspector({ mount: files, artifacts, inset: true });
  const disclosure = mountAboutDisclosure({ mount, kind: "citation", label, identity: "Give the work—and its sources—proper credit.", description: "Human-readable attribution and portable reference-manager records come from the same structured sources.", icon: createCitationIcon(), bodyContent: body, onDestroy: () => inspector.destroy() });
  return Object.freeze({ ...disclosure, inspector, artifacts });
}

export function mountAboutCitationTrust(options = {}) { return mountAboutCitation(options); }

export function mountAboutTrust({ mount, trust: trustValue, artifacts = null, generatedLedger = null, introContent = null, label = "Trust" } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("About Trust requires a mount element.");
  const body = element("div", "inator-about-disclosure__dialog");
  const inspectorMount = element("div"); body.append(inspectorMount);
  const inspector = createTrustInspector({ mount: inspectorMount, trust: trustValue, artifacts, generatedLedger, introContent, inset: true });
  const disclosure = mountAboutDisclosure({ mount, kind: "trust", label, identity: "Inspect the evidence, boundaries, and provenance.", description: "Trust comes from inspectable evidence, explicit limits, and reproducible records—not from attribution alone.", icon: createTrustIcon(), bodyContent: body, onDestroy: () => inspector.destroy() });
  return Object.freeze({ ...disclosure, inspector });
}

export function assertTrustPresentationConformance({ trigger = null, inspector = null } = {}) {
  if (trigger) {
    if (!(trigger instanceof HTMLElement) || !trigger.classList.contains("inator-tool-button") || !trigger.querySelector(":scope > .inator-tool-button__icon")) throw new TypeError("A Trust trigger must be a shared icon-over-label tool button.");
    if (!/trust/i.test(trigger.getAttribute("aria-label") || trigger.textContent || "")) throw new TypeError("A Trust trigger requires an accessible Trust label.");
  }
  if (inspector) {
    const root = inspector.root || inspector;
    if (!(root instanceof HTMLElement) || !root.classList.contains("inator-trust-inspector") || !root.getAttribute("aria-label")) throw new TypeError("A Trust inspector requires a labelled shared root.");
    if (!root.querySelector(".inator-trust-inspector__section, .inator-trust-inspector__files")) throw new TypeError("A Trust inspector must expose contract records or artifacts.");
  }
  return true;
}

function renderProvenance(provenance) {
  const section = element("section", "inator-trust-inspector__section");
  section.append(element("h3", "", "How it was made"));
  const chain = element("ol", "inator-trust-inspector__chain");
  for (const step of provenance.steps) chain.append(element("li", "", step.label));
  section.append(chain);
  return section;
}

function renderEvidence(evidence) {
  const section = element("section", "inator-trust-inspector__section");
  section.append(element("h3", "", "Evidence"));
  const list = element("ul", "inator-trust-inspector__evidence");
  for (const entry of evidence.entries) {
    const item = element("li");
    item.dataset.status = entry.status;
    item.append(element("strong", "", entry.status), element("span", "", entry.summary));
    list.append(item);
  }
  section.append(list);
  return section;
}

function renderLimitations(limitations) {
  const section = element("section", "inator-trust-inspector__section inator-trust-inspector__limits");
  section.append(element("h3", "", "Boundaries"), element("p", "", limitations.boundary));
  const list = element("ul");
  for (const exclusion of limitations.doesNotEstablish) list.append(element("li", "", exclusion));
  section.append(list);
  if (limitations.openQuestions.length) {
    section.append(element("h4", "", "Open questions"));
    const questions = element("ul");
    for (const question of limitations.openQuestions) questions.append(element("li", "", question.text));
    section.append(questions);
  }
  return section;
}

function renderReproduction(reproduction) {
  const section = element("section", "inator-trust-inspector__section inator-trust-inspector__reproduction");
  section.append(element("h3", "", "Reproduction record"), element("p", "", reproduction.instructions));
  const list = element("ul");
  for (const artifact of reproduction.artifacts) list.append(element("li", "", `${artifact.label} — SHA-256 ${artifact.integrity.value.slice(0, 12)}…`));
  section.append(list);
  return section;
}

export function createTrustInspector({ mount, trust: trustValue, artifacts = null, generatedLedger = null, introContent = null, inset = true } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("A Trust inspector mount element is required.");
  const trust = trustContract(trustValue);
  const root = element("section", "inator-trust-inspector");
  root.setAttribute("aria-label", trust.title);
  if (introContent) { const intro = element("section", "inator-trust-inspector__intro"); intro.append(productContent(introContent)); root.append(intro); }
  if (trust.provenance) root.append(renderProvenance(trust.provenance));
  if (trust.evidence) root.append(renderEvidence(trust.evidence));
  if (trust.limitations) root.append(renderLimitations(trust.limitations));
  if (trust.reproduction) root.append(renderReproduction(trust.reproduction));
  let artifactInspector = null;
  if (artifacts) {
    const bound = bindTrustArtifacts(trust, artifacts, { generatedLedger });
    const files = element("section", "inator-trust-inspector__files");
    files.append(element("h3", "", "Inspect or take the records"));
    const fileMount = element("div");
    files.append(fileMount); root.append(files);
    artifactInspector = createArtifactInspector({ mount: fileMount, artifacts: bound.artifacts, inset });
  }
  mount.replaceChildren(root);
  const result = Object.freeze({ root, trust, artifactInspector, destroy() { artifactInspector?.destroy(); root.remove(); } });
  assertTrustPresentationConformance({ inspector: result });
  return result;
}

export function mountTrustDialog({ trigger, trust = null, artifacts = null, generatedLedger = null, resolveTrust = null, resolveArtifacts = null, introContent = null, verifyIntegrity = true, mount = document.body, context = "Evidence and provenance", title = "Trust & export", description = "Inspect the claims, boundaries, and records behind this result." } = {}) {
  if (!(trigger instanceof HTMLElement)) throw new TypeError("A Trust dialog requires a trigger element.");
  if (!trust && typeof resolveTrust !== "function") throw new TypeError("A Trust dialog requires trust data or resolveTrust.");
  const body = element("div", "inator-trust-dialog__content");
  const status = element("p", "inator-trust-dialog__status"); status.dataset.dialogStatus = ""; status.setAttribute("role", "status"); status.setAttribute("aria-live", "polite");
  body.append(status);
  const close = element("button", "", "Close"); close.type = "button"; close.dataset.dialogClose = "";
  const dialog = createDialogSurface({ mount, context, title, description, bodyContent: body, footerContent: close, className: "inator-trust-dialog", wide: true });
  let inspector = null;
  let generation = 0;
  const refresh = async () => {
    const active = ++generation;
    if (!status.isConnected) body.prepend(status);
    dialog.controller.setBusy(true, "Refreshing Trust records…"); status.textContent = "Refreshing Trust records…";
    try {
      const nextTrust = trustContract(resolveTrust ? await resolveTrust() : trust);
      const resolved = resolveArtifacts ? await resolveArtifacts(nextTrust) : { artifacts, generatedLedger };
      const nextArtifacts = Array.isArray(resolved) ? resolved : resolved?.artifacts;
      const nextLedger = Array.isArray(resolved) ? null : resolved?.generatedLedger;
      const bound = nextArtifacts ? (verifyIntegrity ? await verifyTrustArtifacts(nextTrust, nextArtifacts, { generatedLedger: nextLedger }) : bindTrustArtifacts(nextTrust, nextArtifacts, { generatedLedger: nextLedger })) : { trust: nextTrust, artifacts: null };
      if (active !== generation) return;
      inspector?.destroy(); status.remove();
      inspector = createTrustInspector({ mount: body, trust: bound.trust, artifacts: bound.artifacts, generatedLedger: bound.generatedLedger, introContent });
      dialog.controller.setBusy(false);
    } catch (error) {
      if (active !== generation) return;
      status.textContent = `Trust records could not be verified: ${error?.message || error}`;
      dialog.controller.setBusy(false);
    }
  };
  const open = () => { dialog.open(trigger); refresh(); };
  assertTrustPresentationConformance({ trigger });
  trigger.addEventListener("click", open);
  return Object.freeze({ dialog, refresh, open, destroy() { generation += 1; trigger.removeEventListener("click", open); inspector?.destroy(); dialog.destroy(); } });
}
