const paths = (...items) => Object.freeze(items);

// The shared action-bar icon family. Paired transfer actions intentionally use
// identical arrow proportions and the same horizontal tray.
export const INATOR_ICON_PATHS = Object.freeze({
  regimens: paths("M8 5h8", "M9 3h6v4H9z", "M7 7h10v14H7z", "M10 11h4M10 15h4"),
  outcomes: paths("M4 19V5", "M4 19h16", "m7 14 4-5 4 3 5-7"),
  parameters: paths("M4 7h7M15 7h5", "M4 17h4M12 17h8", "M11 4v6M8 14v6"),
  columns: paths("M4 5h4v14H4z", "M10 5h4v14h-4z", "M16 5h4v14h-4z"),
  filter: paths("M4 5h16l-6 7v6l-4 2v-8L4 5Z"),
  import: paths("M12 4v11", "m8 11 4 4 4-4", "M5 20h14"),
  export: paths("M12 15V4", "m8 8 4-4 4 4", "M5 20h14"),
  restore: paths("M5 8a8 8 0 1 1-1 7", "M5 3v5h5"),
  new: paths("M12 4v16", "M4 12h16"),
  archive: paths("M4 7h16", "M6 7v13h12V7", "M9 11h6", "M5 4h14v3H5z"),
  delete: paths("M4 7h16", "M9 7V4h6v3", "M7 7l1 13h8l1-13", "M10 11v5M14 11v5"),
  tidy: paths("m6 8 3 3 6-6", "M4 14h4l2 3h4l2-3h4v6H4v-6Z"),
  edit: paths("m5 17-1 4 4-1L19 9l-3-3L5 17Z", "m14 7 3 3"),
  inspect: paths("M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Z", "m16 16 4 4"),
  trust: paths("M12 2l2.3 3.7 4.2-.2-.2 4.2L22 12l-3.7 2.3.2 4.2-4.2-.2L12 22l-2.3-3.7-4.2.2.2-4.2L2 12l3.7-2.3-.2-4.2 4.2.2L12 2Z", "M12 6.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11Z", "m9 12 2 2 4-4.5"),
  citation: paths("M6 3h9l3 3v15H6Z", "M15 3v4h3", "M9 10h3v4H9Z", "m10 14-1 2", "M14 10h3v4h-3Z", "m15 14-1 2"),
  save: paths("m5 12 4 4L19 6"),
  cancel: paths("M6 6l12 12M18 6 6 18"),
  identity: paths("M5 4h10a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4V4Z", "M9 4v16"),
  machine: paths("M5 6h14v10H5z", "M9 20h6", "M12 16v4", "M8 10h.01M12 10h.01M16 10h.01"),
  models: paths("M12 3 5 7v7l7 4 7-4V10l-7-7Z", "m5 10 7 4 7-4", "M12 14v7"),
  analysis: paths("M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z", "M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6 7 7M17 17l1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4"),
  explore: paths("M12 3l3 6 6 3-6 3-3 6-3-6-6-3 6-3 3-6Z"),
  guide: paths("M9.5 9a2.6 2.6 0 1 1 4.1 2.1c-1.1.7-1.6 1.2-1.6 2.4", "M12 18h.01", "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z"),
  pipeline: paths("M8 5l11 7-11 7V5Z"),
  chapters: paths("M6 5h12M6 9h12M6 13h12M6 17h8"),
  summaries: paths("M6 4h12v16H6z", "M9 8h6M9 12h6M9 16h4"),
  dossier: paths("M7 3h7l4 4v14H7z", "M14 3v5h5", "M10 12h5M10 16h5"),
  reviewer: paths("M4 12l5 5L20 6"),
  connections: paths("M8 8l8 8M15 5h4v4M9 19H5v-4", "M14 10l3-3M10 14l-3 3"),
  reports: paths("M5 20V9M12 20V4M19 20v-7"),
  questions: paths("M8 8a4 4 0 1 1 6.4 3.2C12.7 12.3 12 13 12 15", "M12 19h.01"),
  publish: paths("M12 15V4", "m8 8 4-4 4 4", "M5 20h14"),
  elevator: paths("M7 21V4h10v17", "M4 21h16", "M9 8h6M9 12h6", "m10 17 2-2 2 2", "M12 15v5"),
  flyer: paths("M6 3h12v18H6z", "M9 7h6M9 11h6M9 15h4"),
  presentation: paths("M4 5h16v11H4z", "M12 16v5", "m8 21 4-5 4 5", "M8 9h8M8 12h5"),
  timing: paths("M4 19V5", "M4 19h16", "m7 15 4-5 3 2 5-7"),
  retry: paths("M5 8a8 8 0 1 1-1 7", "M5 3v5h5"),
  startOver: paths("M4 11a8 8 0 1 1 2.3 6.1", "M4 5v6h6"),
  collapse: paths("m7 10 5-5 5 5", "m7 17 5-5 5 5"),
  run: paths("M8 5l11 7-11 7V5Z"),
  fail: paths("M12 4v10", "M12 19h.01", "M4 20 12 3l8 17H4Z"),
  stop: paths("M7 7h10v10H7z"),
  stopAfter: paths("M7 7h10v10H7z", "M4 4v16"),
  resetZero: paths("M5 4v15h15", "M9 15h.01M9 11h.01M9 7h.01"),
  advance: paths("M5 12h12", "m13 7 5 5-5 5"),
  top: paths("M5 5h14", "m8 18 4-4 4 4", "M12 14V8"),
  raise: paths("m7 14 5-5 5 5", "M12 9v10"),
  lower: paths("m7 10 5 5 5-5", "M12 5v10"),
  pause: paths("M8 5v14M16 5v14"),
  resume: paths("M8 5l11 7-11 7V5Z"),
  dispatch: paths("M5 5v14", "M5 8h7a3 3 0 0 1 3 3v2a3 3 0 0 0 3 3h2", "m17 13 3 3-3 3"),
  reorder: paths("M8 6h11M8 12h8M8 18h5", "M5 4v16", "m3 18 2 2 2-2"),
  fit: paths("M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5", "m3 8 5-5M21 8l-5-5M3 16l5 5M21 16l-5 5")
});

export function createInatorIcon(name) {
  const definition = INATOR_ICON_PATHS[name];
  if (!definition) throw new TypeError(`Unknown Inator icon: ${name}`);
  const namespace = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(namespace, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("focusable", "false");
  svg.setAttribute("aria-hidden", "true");
  definition.forEach((d) => {
    const path = document.createElementNS(namespace, "path");
    path.setAttribute("d", d);
    svg.append(path);
  });
  return svg;
}
