import { createTabController } from "./tabs.js";
import { mountAboutCitationTrust } from "./trust-presentation.js";

export const PRODUCT_DOCS_SCHEMA = "inator.product-docs.v1";
export const PRODUCT_DOCS_SECTIONS = Object.freeze([
  Object.freeze({ id: "start", label: "Start here" }),
  Object.freeze({ id: "tasks", label: "Everyday tasks" }),
  Object.freeze({ id: "reference", label: "Reference" }),
  Object.freeze({ id: "faq", label: "FAQ" })
]);

const RECORDS = Object.freeze([
  { id: "milestones", label: "Milestones", description: "Committed outcomes and completed releases", path: "M9 36h30M13 36V23h9v13M26 36V12h9v24" },
  { id: "roadmap", label: "Roadmap", description: "Priorities, candidates, and planned work", path: "M10 37c8-17 18-9 27-27M29 10h8v8M10 37h8" },
  { id: "security", label: "Security", description: "Controls, evidence, gaps, and verification", path: "M24 7l14 6v10c0 9-6 15-14 19-8-4-14-10-14-19V13zM17 24l5 5 10-11" },
  { id: "privacy", label: "Privacy", description: "Ethics, data boundaries, and verified practice", path: "M24 41c9-5 14-12 14-22-6 0-11-4-14-10-3 6-8 10-14 10 0 10 5 17 14 22zM24 17v15M18 26h12" }
]);

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function requiredText(value, label) {
  const result = String(value ?? "").trim();
  if (!result) throw new TypeError(`${label} is required.`);
  return result;
}

function normalizedDocsEntry(source, label) {
  if (!source || typeof source !== "object") throw new TypeError(`${label} is required.`);
  const subsections = (source.subsections || []).map((item, index) => Object.freeze({
    id: requiredText(item.id, `${label}.subsections[${index}].id`),
    label: requiredText(item.label, `${label}.subsections[${index}].label`),
    content: item.content
  }));
  return Object.freeze({ content: source.content, subsections: Object.freeze(subsections) });
}

export function defineProductDocs(source = {}) {
  const sections = {};
  for (const section of PRODUCT_DOCS_SECTIONS) sections[section.id] = normalizedDocsEntry(source.sections?.[section.id], `sections.${section.id}`);
  return Object.freeze({ schema: PRODUCT_DOCS_SCHEMA, productLabel: requiredText(source.productLabel || "Inator", "productLabel"), heading: requiredText(source.heading || "Find your bearings. Then go as deep as you need.", "heading"), introduction: requiredText(source.introduction || "Start with orientation, follow an everyday task, or look up exact behavior.", "introduction"), sections: Object.freeze(sections) });
}

function appendContent(mount, content) {
  const resolved = typeof content === "function" ? content(mount) : content;
  if (resolved instanceof Node) mount.append(resolved);
  else if (resolved != null) mount.insertAdjacentHTML("beforeend", String(resolved));
}

export function createProductDocsFlow({ sections = [] } = {}) {
  const flow = element("div", "inator-docs-flow");
  for (const [index, source] of sections.entries()) {
    if (!source || typeof source !== "object") throw new TypeError(`sections[${index}] is required.`);
    const section = element("section", "inator-docs-section");
    if (source.id) section.id = String(source.id);
    if (source.heading) section.append(element("h2", "", source.heading));
    appendContent(section, source.content);
    flow.append(section);
  }
  return flow;
}

export function createProductFaq({ items = [] } = {}) {
  const list = element("div", "inator-faq-list");
  for (const [index, source] of items.entries()) {
    if (!source || typeof source !== "object") throw new TypeError(`items[${index}] is required.`);
    const details = element("details");
    if (source.open) details.open = true;
    details.append(element("summary", "", requiredText(source.question, `items[${index}].question`)));
    const answer = element("div", "inator-faq-answer");
    appendContent(answer, source.answer);
    details.append(answer);
    list.append(details);
  }
  return list;
}

function createSubsectionTabs(panel, sectionId, subsections) {
  if (!subsections.length) return null;
  panel.classList.add("inator-help-panel--subsections");
  const tabs = element("nav", "inator-docs-subtabs");
  tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", `${sectionId} topics`);
  const panels = [];
  subsections.forEach((subsection, index) => {
    const id = `inator-docs-${sectionId}-${subsection.id}`;
    const button = element("button", "", subsection.label);
    button.type = "button"; button.id = `${id}-tab`; button.setAttribute("role", "tab"); button.setAttribute("aria-controls", id); button.setAttribute("aria-selected", String(index === 0)); if (index) button.tabIndex = -1;
    const subpanel = element("section", "inator-docs-subpanel"); subpanel.id = id; subpanel.setAttribute("role", "tabpanel"); subpanel.setAttribute("aria-labelledby", button.id); subpanel.hidden = index !== 0; appendContent(subpanel, subsection.content);
    tabs.append(button); panels.push(subpanel);
  });
  panel.append(tabs, ...panels);
  return createTabController({ root: panel });
}

function recordShelf(basePath = "/") {
  const section = element("section", "inator-record-shelf");
  section.setAttribute("aria-labelledby", "inator-record-shelf-title");
  const header = element("header");
  header.append(element("p", "inator-information-kicker", "The work and the proof"), element("h2", "", "Inspect the records behind the promise."));
  header.lastChild.id = "inator-record-shelf-title";
  const links = element("div", "inator-record-links");
  for (const record of RECORDS) {
    const link = element("a", `inator-record-link inator-record-link--${record.id}`);
    link.href = `${basePath}${record.id}/`;
    link.innerHTML = `<svg viewBox="0 0 48 48" aria-hidden="true"><path d="${record.path}"/></svg><span><strong>${record.label}</strong><small>${record.description}</small></span>`;
    links.append(link);
  }
  section.append(header, links);
  return section;
}

function ecosystemIntroduction() {
  const introduction = element("div", "inator-ecosystem-intro");
  introduction.innerHTML = `<div><p class="inator-information-kicker">Shared foundations, independent products</p><h1>One member of a larger family.</h1><p>Each Inator owns its subject matter and its relationship with people. The ecosystem conserves the foundations that should not need reinvention: identity, workspaces, evidence, accessible interface patterns, exports, and release discipline.</p><a href="https://inator.com">Visit inator.com</a></div>`;
  return introduction;
}

export function createProductAboutPage({ root, productLabel, productContent, citationContent, about = null, citationRegistry = null, basePath = "/" } = {}) {
  if (!root || !productContent) throw new TypeError("createProductAboutPage requires root and productContent.");
  root.classList.add("inator-information-page", "inator-about-page");
  const tabs = element("nav", "inator-information-tabs");
  tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", "About");
  tabs.innerHTML = `<button type="button" role="tab" id="inator-about-product-tab" aria-controls="inator-about-product" aria-selected="true">${productLabel || "This Inator"}</button><button type="button" role="tab" id="inator-about-ecosystem-tab" aria-controls="inator-about-ecosystem" aria-selected="false" tabindex="-1">Inator ecosystem</button>`;
  const product = element("section"); product.id = "inator-about-product"; product.setAttribute("role", "tabpanel"); product.setAttribute("aria-labelledby", "inator-about-product-tab"); product.append(productContent);
  if (citationContent) product.append(citationContent);
  let citationTrust = null;
  if (about) { const citationMount = element("div", "inator-about-trust-mount"); product.append(citationMount); citationTrust = mountAboutCitationTrust({ mount: citationMount, about, citationRegistry }); }
  product.append(recordShelf(basePath));
  const ecosystem = element("section"); ecosystem.id = "inator-about-ecosystem"; ecosystem.setAttribute("role", "tabpanel"); ecosystem.setAttribute("aria-labelledby", "inator-about-ecosystem-tab"); ecosystem.hidden = true;
  ecosystem.append(ecosystemIntroduction());
  root.replaceChildren(tabs, product, ecosystem);
  const tabsController = createTabController({ root });
  return Object.freeze({ ...tabsController, citationTrust, destroy() { citationTrust?.destroy(); } });
}

export function createProductDocsPage({ root, docs, initialSection = "start" } = {}) {
  if (!root) throw new TypeError("createProductDocsPage requires root.");
  const manifest = docs?.schema === PRODUCT_DOCS_SCHEMA ? docs : defineProductDocs(docs);
  root.classList.add("inator-information-page", "inator-help-page");
  const header = element("header", "inator-help-heading");
  header.innerHTML = `<div><p>${manifest.productLabel} docs</p><h1>${manifest.heading}</h1><span>${manifest.introduction}</span></div>`;
  const tabs = element("nav", "inator-information-tabs"); tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", "Help sections");
  root.replaceChildren(header, tabs);
  const nestedControllers = [];
  PRODUCT_DOCS_SECTIONS.forEach((section, index) => {
    const entry = manifest.sections[section.id];
    const id = `inator-help-${section.id}`;
    const button = element("button", "", section.label);
    button.type = "button"; button.id = `${id}-tab`; button.setAttribute("role", "tab"); button.setAttribute("aria-controls", id); button.setAttribute("aria-selected", String(index === 0)); if (index) button.tabIndex = -1;
    const panel = element("section", "inator-help-panel"); panel.id = id; panel.setAttribute("role", "tabpanel"); panel.setAttribute("aria-labelledby", button.id); panel.hidden = index !== 0;
    if (entry.subsections.length) nestedControllers.push(createSubsectionTabs(panel, section.id, entry.subsections));
    else appendContent(panel, entry.content);
    tabs.append(button); root.append(panel);
  });
  const tabsController = createTabController({ root, initialTabId: `inator-help-${initialSection}-tab` });
  return Object.freeze({ manifest, tabsController, nestedControllers: Object.freeze(nestedControllers.filter(Boolean)) });
}

export function createProductHelpPage({ root, productLabel = "Inator", heading, introduction, sections = [] } = {}) {
  const byId = Object.fromEntries(sections.map((section) => [section.id, section]));
  const fallback = sections[0]?.content;
  return createProductDocsPage({ root, docs: { productLabel, heading, introduction, sections: {
    start: { content: byId.start?.content || byId.guide?.content || fallback },
    tasks: { content: byId.tasks?.content || byId.documentation?.content || fallback },
    reference: { content: byId.reference?.content || byId.documentation?.content || fallback },
    faq: { content: byId.faq?.content || fallback }
  } } });
}
