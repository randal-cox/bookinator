import { createInatorIcon } from "./icons.js";

let listViewSequence = 0;

const element = (tag, className = "", text = "") => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text) node.textContent = text;
  return node;
};

function selectionInstruction(selection) {
  if (selection.indeterminate) return "Select all visible rows";
  if (selection.checked) return "Clear visible selection";
  return "Select all visible rows, or restore the previous partial selection";
}

export function createListView({
  mount,
  model,
  filters = [],
  compactFilters = false,
  searchPlaceholder = "Search records",
  emptyTitle = "No matching records",
  emptyDetail = "Change the search or filters and try again.",
  columnButton = null,
  inlineActions = false,
  pageSizeOptions = [10, 25, 50, 100],
  selectable = true,
  selectionMode = "multiple",
  showRowActions = true,
  editLabel = (record) => `Edit ${record.name ?? "record"}`,
  onEdit = () => {},
  rowActionLabel = editLabel,
  rowActionIcon = "edit",
  onRowAction = onEdit,
  onChange = () => {}
}) {
  if (!(mount instanceof Element)) throw new TypeError("A list view needs a mount element");
  const collectionSurface = mount.parentElement;
  const surfaceChildren = collectionSurface ? [...collectionSurface.children] : [];
  if (
    !collectionSurface?.classList?.contains("inator-collection-surface")
    || !surfaceChildren.includes(mount)
    || (columnButton && !inlineActions && !surfaceChildren.some((child) => child.classList.contains("inator-action-bar")))
  ) {
    throw new TypeError(
      "A standard list view must be a direct child of an Inator collection surface; a column button also requires an adjacent action bar."
    );
  }

  const usefulFilters = filters.filter((filter) => (filter.options || []).length > 1);
  const viewId = `inator-list-${++listViewSequence}`;
  mount.classList.add("inator-list-root");
  const tools = element("div", "inator-list-tools");
  const searchLabel = element("label", "inator-list-search");
  searchLabel.append(element("span", "sr-only", "Search"));
  const search = element("input");
  search.type = "search";
  search.placeholder = searchPlaceholder;
  search.setAttribute("aria-label", searchPlaceholder);
  searchLabel.append(search);
  tools.append(searchLabel);

  const filterInputs = new Map();
  const filterTray = compactFilters && usefulFilters.length ? element("div", "inator-list-filter-menu") : null;
  const filterTraySummary = filterTray ? element("button", "inator-list-filter-trigger") : null;
  const filterTraySummaryLabel = filterTray ? element("span", "", "Filters") : null;
  const filterTrayFields = filterTray ? element("div", "inator-list-filter-fields") : null;
  if (filterTray) {
    filterTraySummary.type = "button";
    filterTraySummary.setAttribute("aria-expanded", "false");
    filterTrayFields.id = `${viewId}-filters`;
    filterTrayFields.hidden = true;
    filterTraySummary.setAttribute("aria-controls", filterTrayFields.id);
    filterTraySummary.append(createInatorIcon("filter"), filterTraySummaryLabel);
    filterTray.append(filterTraySummary, filterTrayFields);
    filterTraySummary.addEventListener("click", () => {
      const opening = filterTrayFields.hidden;
      filterTrayFields.hidden = !opening;
      filterTray.dataset.open = String(opening);
      filterTraySummary.setAttribute("aria-expanded", String(opening));
    });
    document.addEventListener("pointerdown", (event) => {
      if (!filterTrayFields.hidden && !filterTray.contains(event.target)) {
        filterTrayFields.hidden = true;
        filterTray.dataset.open = "false";
        filterTraySummary.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !filterTrayFields.hidden) {
        filterTrayFields.hidden = true;
        filterTray.dataset.open = "false";
        filterTraySummary.setAttribute("aria-expanded", "false");
        filterTraySummary.focus();
      }
    });
  }
  usefulFilters.forEach((filter) => {
    const label = element("label", "inator-list-filter");
    label.append(element("span", "sr-only", filter.label));
    const select = element("select");
    select.setAttribute("aria-label", filter.label);
    const all = element("option", "", filter.allLabel ?? `All ${filter.label.toLocaleLowerCase()}`);
    all.value = "";
    select.append(all);
    filter.options.forEach((option) => {
      const node = element("option", "", typeof option === "string" ? option : option.label);
      node.value = typeof option === "string" ? option : option.value;
      select.append(node);
    });
    label.append(select);
    (filterTrayFields || tools).append(label);
    filterInputs.set(filter.id, select);
  });
  if (inlineActions && (columnButton || filterTray)) {
    const compactActions = element("div", "inator-list-compact-actions");
    if (columnButton) {
      columnButton.classList.add("inator-list-compact-action");
      compactActions.append(columnButton);
    }
    if (filterTray) compactActions.append(filterTray);
    tools.append(compactActions);
  } else if (filterTray) tools.append(filterTray);

  const columnsMenu = element("div", "inator-column-menu");
  columnsMenu.id = `${viewId}-columns`;
  columnsMenu.hidden = true;
  columnsMenu.setAttribute("role", "menu");
  document.body.append(columnsMenu);
  if (columnButton) {
    columnButton.setAttribute("aria-controls", columnsMenu.id);
    columnButton.setAttribute("aria-expanded", "false");
    columnButton.setAttribute("aria-haspopup", "menu");
    columnButton.addEventListener("click", () => {
      const opening = columnsMenu.hidden;
      columnsMenu.hidden = !opening;
      columnButton.setAttribute("aria-expanded", String(opening));
      if (opening) {
        const anchor = columnButton.getBoundingClientRect();
        const desiredLeft = Math.min(anchor.left, window.innerWidth - columnsMenu.offsetWidth - 8);
        columnsMenu.style.left = `${Math.max(8, desiredLeft)}px`;
        columnsMenu.style.top = `${anchor.bottom + 5}px`;
      }
    });
    document.addEventListener("pointerdown", (event) => {
      if (!columnsMenu.hidden && !columnsMenu.contains(event.target) && !columnButton.contains(event.target)) {
        columnsMenu.hidden = true;
        columnButton.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && !columnsMenu.hidden) {
        columnsMenu.hidden = true;
        columnButton.setAttribute("aria-expanded", "false");
        columnButton.focus();
      }
    });
  }

  const frame = element("div", "inator-list-frame");
  const table = element("table", "inator-list-table");
  const head = element("thead");
  const body = element("tbody");
  table.append(head, body);
  frame.append(table);
  const footer = element("footer", "inator-list-footer");
  const footerSummary = element("span", "inator-list-summary");
  const count = element("span");
  const state = element("span");
  footerSummary.append(count, state);
  const paging = element("span", "inator-list-paging");
  const pageSizeLabel = element("label");
  pageSizeLabel.append(element("span", "", "Rows"));
  const pageSize = element("select");
  pageSize.setAttribute("aria-label", "Rows per page");
  pageSizeOptions.forEach((value) => {
    const option = element("option", "", String(value));
    option.value = String(value);
    pageSize.append(option);
  });
  pageSizeLabel.append(pageSize);
  const previousPage = element("button", "inator-page-button", "‹");
  previousPage.type = "button";
  previousPage.title = "Previous page";
  previousPage.setAttribute("aria-label", "Previous page");
  const pagePosition = element("span", "inator-page-position");
  const nextPage = element("button", "inator-page-button", "›");
  nextPage.type = "button";
  nextPage.title = "Next page";
  nextPage.setAttribute("aria-label", "Next page");
  paging.append(pageSizeLabel, previousPage, pagePosition, nextPage);
  footer.append(footerSummary, paging);
  mount.replaceChildren(tools, frame, footer);

  search.addEventListener("input", () => {
    model.setQuery(search.value);
    render();
  });
  filterInputs.forEach((select, id) => select.addEventListener("change", () => {
    model.setFilter(id, select.value);
    render();
  }));
  pageSize.addEventListener("change", () => { model.setPageSize(Number(pageSize.value)); render(); });
  previousPage.addEventListener("click", () => { model.setPage(model.snapshot().pagination.page - 1); render(); });
  nextPage.addEventListener("click", () => { model.setPage(model.snapshot().pagination.page + 1); render(); });

  function renderColumnMenu(snapshot) {
    columnsMenu.replaceChildren(...snapshot.allColumns.map((column) => {
      const label = element("label");
      const input = element("input");
      input.type = "checkbox";
      input.checked = snapshot.columns.some(({ id }) => id === column.id);
      input.disabled = column.required;
      input.addEventListener("change", () => {
        model.setColumnVisible(column.id, input.checked);
        render();
      });
      label.append(input, document.createTextNode(column.label));
      return label;
    }));
  }

  function render() {
    const snapshot = model.snapshot();
    search.value = snapshot.query;
    filterInputs.forEach((select, id) => { select.value = snapshot.filters[id]?.[0] ?? ""; });
    if (filterTraySummary) {
      const activeFilterCount = Object.values(snapshot.filters).filter((values) => values?.length).length;
      filterTraySummaryLabel.textContent = activeFilterCount ? `Filters (${activeFilterCount})` : "Filters";
    }
    if (![...pageSize.options].some((option) => Number(option.value) === snapshot.pagination.pageSize)) {
      const option = element("option", "", String(snapshot.pagination.pageSize));
      option.value = String(snapshot.pagination.pageSize);
      pageSize.append(option);
    }
    pageSize.value = String(snapshot.pagination.pageSize);
    renderColumnMenu(snapshot);

    const headerRow = element("tr");
    if (selectable) {
      const selectionHead = element("th", "inator-list-selection");
      if (selectionMode !== "single") {
        const selectVisible = element("input");
        selectVisible.type = "checkbox";
        selectVisible.checked = snapshot.selection.checked;
        selectVisible.indeterminate = snapshot.selection.indeterminate;
        selectVisible.disabled = snapshot.selection.totalCount === 0;
        selectVisible.title = selectionInstruction(snapshot.selection);
        selectVisible.setAttribute("aria-label", selectVisible.title);
        selectVisible.addEventListener("change", () => {
          model.cycleVisibleSelection();
          render();
        });
        selectionHead.append(selectVisible);
      } else selectionHead.append(element("span", "sr-only", "Select one row"));
      headerRow.append(selectionHead);
    }

    snapshot.columns.forEach((column) => {
      const cell = element("th");
      if (column.sortable) {
        const button = element("button", "inator-list-sort");
        const active = snapshot.sort?.id === column.id;
        if (active) cell.setAttribute("aria-sort", snapshot.sort.direction === "asc" ? "ascending" : "descending");
        button.append(document.createTextNode(column.label), element("span", "", active ? (snapshot.sort.direction === "asc" ? "↑" : "↓") : "↕"));
        button.addEventListener("click", () => { model.sortBy(column.id); render(); });
        cell.append(button);
      } else {
        cell.textContent = column.label;
      }
      headerRow.append(cell);
    });
    if (showRowActions) {
      const actionsHead = element("th", "inator-list-actions");
      actionsHead.append(element("span", "sr-only", "Row actions"));
      headerRow.append(actionsHead);
    }
    head.replaceChildren(headerRow);

    if (!snapshot.visibleRecords.length) {
      const row = element("tr");
      const cell = element("td", "inator-list-empty");
      cell.colSpan = snapshot.columns.length + Number(selectable) + Number(showRowActions);
      cell.append(element("strong", "", emptyTitle), document.createTextNode(emptyDetail));
      row.append(cell);
      body.replaceChildren(row);
    } else {
      body.replaceChildren(...snapshot.visibleRecords.map((record) => {
        const id = String(record.id);
        const row = element("tr");
        if (selectable) {
          row.dataset.selected = String(snapshot.selectedIds.has(id));
          const selectionCell = element("td", "inator-list-selection");
          const checkbox = element("input");
          checkbox.type = selectionMode === "single" ? "radio" : "checkbox";
          if (selectionMode === "single") checkbox.name = `${viewId}-selection`;
          checkbox.checked = snapshot.selectedIds.has(id);
          checkbox.setAttribute("aria-label", `Select ${record.name ?? "record"}`);
          checkbox.addEventListener("change", () => {
            if (selectionMode === "single") model.clearSelection();
            model.toggleSelection(id); render();
          });
          selectionCell.append(checkbox);
          row.append(selectionCell);
        }
        snapshot.columns.forEach((column) => {
          const cell = element("td", column.className ?? "");
          const raw = column.value(record);
          const rendered = column.render?.(record, raw);
          if (rendered instanceof Node) cell.append(rendered);
          else cell.textContent = rendered == null ? column.format(raw, record) : String(rendered);
          row.append(cell);
        });
        if (showRowActions) {
          const actionsCell = element("td", "inator-list-actions");
          const edit = element("button", "inator-row-action");
          edit.type = "button";
          edit.title = rowActionLabel(record);
          edit.setAttribute("aria-label", edit.title);
          edit.append(createInatorIcon(rowActionIcon));
          edit.addEventListener("click", () => onRowAction(record));
          actionsCell.append(edit);
          row.append(actionsCell);
        }
        return row;
      }));
    }

    const { pagination } = snapshot;
    count.textContent = pagination.matchingCount
      ? `${pagination.startIndex + 1}–${pagination.endIndex} of ${pagination.matchingCount}`
      : "0 records";
    if (pagination.matchingCount !== snapshot.records.length) count.textContent += ` (${snapshot.records.length} total)`;
    state.hidden = !selectable;
    state.textContent = selectable ? `${snapshot.selectedIds.size} selected` : "";
    pagePosition.textContent = `${pagination.page} / ${pagination.pageCount}`;
    previousPage.disabled = !pagination.hasPrevious;
    nextPage.disabled = !pagination.hasNext;
    onChange(snapshot);
    return snapshot;
  }

  return Object.freeze({ render, model });
}
