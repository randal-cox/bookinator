import { createListModel } from "./list-model.js";
import { createListView } from "./list-view.js";
import { createToolButton } from "./action-bar.js";
import { createInatorIcon } from "./icons.js";

const scheduleBucket = ({ milestoneId, state }) => milestoneId && ["scheduled", "delivered"].includes(state)
  ? "scheduled"
  : state === "declined" ? "declined" : "unscheduled";

const titleCase = (value) => String(value || "")
  .replace(/-/g, " ")
  .replace(/\b\w/g, (letter) => letter.toUpperCase());

function featureCell(item) {
  const cell = document.createElement("span");
  cell.className = "inator-roadmap-feature";
  const title = document.createElement("strong");
  title.textContent = item.title;
  const summary = document.createElement("span");
  summary.textContent = item.summary;
  cell.append(title, summary);
  return cell;
}

function milestoneCell(_item, label) {
  if (!label || label === "—") return label;
  const [version, ...titleParts] = String(label).split(" — ");
  const cell = document.createElement("span");
  cell.className = "inator-roadmap-milestone";
  const number = document.createElement("strong");
  number.textContent = version;
  const title = document.createElement("span");
  title.textContent = titleParts.join(" — ");
  cell.append(number, title);
  return cell;
}

export function createProductRoadmapModel(roadmap, { milestoneTitles = {}, initialState = {} } = {}) {
  if (!roadmap?.items) throw new TypeError("A normalized product roadmap is required");
  return createListModel({
    records: roadmap.items,
    columns: [
      { id: "title", label: "Feature", required: true, value: (item) => item.title, searchValue: (item) => `${item.title} ${item.summary}`, render: featureCell },
      {
        id: "schedule",
        label: "Plan",
        value: scheduleBucket,
        format: (value) => value === "scheduled" ? "In milestone" : titleCase(value)
      },
      {
        id: "milestone",
        label: "Milestone",
        value: (item) => item.milestoneId ? milestoneTitles[item.milestoneId] || item.milestoneId : "—",
        render: milestoneCell
      },
      { id: "tags", label: "Tags", value: (item) => item.tags.length, searchValue: (item) => item.tags.join(" "), filterValue: (item) => item.tags, format: (_count, item) => item.tags.join(", ") },
      { id: "ease", label: "Ease", value: (item) => item.ease },
      { id: "impact", label: "Impact", value: (item) => item.impact },
      { id: "payoff", label: "Payoff", value: (item) => item.payoff },
      { id: "risk", label: "Risk", value: (item) => item.risk, format: titleCase },
      { id: "confidence", label: "Confidence", value: (item) => item.confidence, format: titleCase },
      { id: "reviewed", label: "Reviewed", visible: false, value: (item) => item.lastReviewedAt }
    ],
    initialState: {
      pageSize: 25,
      sort: { id: "payoff", direction: "desc" },
      filters: { schedule: ["scheduled"] },
      ...initialState
    }
  });
}

export function createProductRoadmapView({
  mount,
  roadmap,
  milestoneTitles = {},
  initialState = {},
  onInspect = () => {},
  onChange = () => {}
} = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createProductRoadmapView requires a DOM mount element");
  const model = createProductRoadmapModel(roadmap, { milestoneTitles, initialState });
  const columns = createToolButton({ icon: createInatorIcon("columns"), label: "Columns" });
  const listMount = document.createElement("div");
  const surface = document.createElement("section");
  surface.className = "inator-collection-surface inator-roadmap-surface";
  surface.append(listMount);
  mount.replaceChildren(surface);

  const tags = [...new Set(roadmap.items.flatMap(({ tags: itemTags }) => itemTags))].sort();
  const scheduleLabels = { scheduled: "In a milestone", unscheduled: "Not yet scheduled", declined: "Declined" };
  const scheduleOptions = [...new Set(roadmap.items.map(scheduleBucket))].map((value) => ({ value, label: scheduleLabels[value] }));
  const list = createListView({
    mount: listMount,
    model,
    columnButton: columns,
    inlineActions: true,
    selectable: false,
    showRowActions: true,
    compactFilters: true,
    searchPlaceholder: "Search roadmap",
    emptyTitle: "No roadmap items match",
    emptyDetail: "Change the search or compact filters to include more ideas.",
    filters: [
      {
        id: "schedule",
        label: "Schedule",
        allLabel: "All planning states",
        options: scheduleOptions
      },
      { id: "tags", label: "Tag", options: tags }
    ],
    rowActionLabel: (item) => `Inspect ${item.title}`,
    rowActionIcon: "inspect",
    onRowAction: onInspect,
    onChange
  });
  return Object.freeze({ model, list, surface });
}
