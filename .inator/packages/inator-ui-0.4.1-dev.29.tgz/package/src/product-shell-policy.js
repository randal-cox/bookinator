const STANDARD_DESTINATIONS = Object.freeze([
  { id: "about", label: "About", route: "about", path: "about/", group: "product" },
  { id: "help", label: "Docs", route: "docs", path: "docs/", group: "product" },
  { id: "privacy", label: "Privacy", route: "privacy", path: "privacy/", group: "trust" },
  { id: "security", label: "Security", route: "security", path: "security/", group: "trust", capability: "security" },
  { id: "milestones", label: "Milestones", route: "milestones", path: "milestones/", group: "history", capability: "history" },
  { id: "releases", label: "Releases", route: "releases", path: "releases/", group: "history", capability: "history" },
  { id: "roadmap", label: "Proposed features", route: "roadmap", path: "roadmap/", group: "history", capability: "roadmap" },
  { id: "resources", label: "Resources", route: "resources", path: "resources/", group: "resources", capability: "resources", roles: ["developer", "team"] }
]);

function text(value, fallback = "") {
  const normalized = String(value ?? "").trim();
  return normalized || fallback;
}

function joinedRoute(base, path) {
  const root = text(base, "/");
  const prefix = root.endsWith("/") ? root : `${root}/`;
  return new URL(path, `https://inator.invalid${prefix.startsWith("/") ? prefix : `/${prefix}`}`).pathname;
}

function capabilitySet(policy, runtime) {
  return new Set([...(policy.capabilities || []), ...(runtime.capabilities || [])].map(String));
}

function identityRoles(identity = {}) {
  return new Set([...(identity.roles || []), ...(identity.identity?.roles || [])].map(String));
}

function allowedForRoles(item, roles) {
  return !item.roles?.length || item.roles.some((role) => roles.has(role));
}

function normalizedExtension(item, index) {
  if (!item?.href || !item?.label) throw new TypeError(`Product shell footer extension ${index + 1} requires href and label.`);
  return {
    id: text(item.id, `extension-${index + 1}`),
    href: String(item.href),
    route: text(item.route) || undefined,
    label: String(item.label),
    group: text(item.group, "extensions"),
    roles: Array.isArray(item.roles) ? item.roles.map(String) : [],
    capability: text(item.capability) || undefined,
    after: text(item.after) || undefined,
    before: text(item.before) || undefined
  };
}

function insertExtension(items, extension) {
  const before = extension.before && items.findIndex(({ id }) => id === extension.before);
  if (before !== false && before >= 0) items.splice(before, 0, extension);
  else {
    const after = extension.after && items.findIndex(({ id }) => id === extension.after);
    if (after !== false && after >= 0) items.splice(after + 1, 0, extension);
    else items.push(extension);
  }
}

function normalizedRollups(source = {}) {
  const rollups = {};
  for (const [destination, members] of Object.entries(source || {})) {
    const target = text(destination);
    if (!target || !Array.isArray(members)) throw new TypeError("Product shell rollups map a destination to an array of destination ids.");
    rollups[target] = Object.freeze([...new Set(members.map((member) => text(member)).filter(Boolean))]);
  }
  return Object.freeze(rollups);
}

export function defineProductShellPolicy(source = {}) {
  const base = text(source.base, "/");
  const omit = new Set((source.omit || []).map(String));
  const routes = source.routes || {};
  const labels = source.labels || {};
  const rollups = normalizedRollups(source.rollups);
  const rolledUp = new Set(Object.values(rollups).flat());
  const destinations = STANDARD_DESTINATIONS
    .filter(({ id }) => !omit.has(id) && routes[id] !== false)
    .map((item) => {
      const routePolicy = routes[item.id];
      return {
        ...item,
        href: text(typeof routePolicy === "object" ? routePolicy?.href : routePolicy) || joinedRoute(base, item.path),
        route: text(typeof routePolicy === "object" ? routePolicy?.route : "", item.route),
        label: text(labels[item.id], item.label)
      };
    });
  (source.extensions || []).map(normalizedExtension).forEach((item) => insertExtension(destinations, item));
  for (const target of Object.keys(rollups)) {
    if (!destinations.some(({ id }) => id === target)) throw new TypeError(`Product shell rollup target is unavailable: ${target}`);
  }
  return Object.freeze({
    schema: "inator.product-shell-policy.v1",
    base,
    capabilities: Object.freeze((source.capabilities || []).map(String)),
    rollups,
    destinations: Object.freeze(destinations.filter(({ id }) => !rolledUp.has(id)).map(Object.freeze))
  });
}

export function productShellFooterLinks(policySource = {}, runtime = {}) {
  const policy = policySource.schema === "inator.product-shell-policy.v1"
    ? policySource
    : defineProductShellPolicy(policySource);
  const capabilities = capabilitySet(policy, runtime);
  const roles = identityRoles(runtime.identity);
  const standardFooterIds = new Set(["about", "help", "resources"]);
  const links = policy.destinations
    .filter((item) => standardFooterIds.has(item.id))
    .filter((item) => !item.capability || capabilities.has(item.capability))
    .filter((item) => allowedForRoles(item, roles))
    .map(({ id, href, route, label, group }) => ({ id, href, route, label, group }));
  return links.map((item, index) => ({
    href: item.href,
    route: item.route,
    label: item.label,
    ...(index > 0 && item.group !== links[index - 1].group ? { separatorBefore: true } : {})
  }));
}

export { STANDARD_DESTINATIONS as PRODUCT_SHELL_STANDARD_DESTINATIONS };
