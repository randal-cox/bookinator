# @inator/ui

Framework-neutral shared Inator interface contracts.

The current executable standards cover action bars, structurally enforced list
collections, atomic dialogs and intake, product shells, roadmaps/releases,
resources, pipelines, Workspace capabilities, backup/restore, local
diagnostics, Workspace Errors, source lists, and compact table values.

Important composition points:

- createCollectionSurface plus createListView keeps actions and rows in one
  structural width contract.
- createDialogSurface creates dialog markup, movement, focus, and lifecycle
  together. Every direct createDialogController consumer must also load
  `@inator/ui/dialog.css`; importing that stylesheet without installing the
  controller is likewise nonconforming. Composite capability styles that open
  shared dialogs import it themselves.
- createWorkspaceCapabilityRegistry is the source for both
  workspaceUtilityFromCapabilities and createWorkspaceHost/router.
- Identity, Workspace backup/restore, and policy-gated Errors are shared
  capability views; product adapters retain persistence and domain semantics.
- formatCompactTimestamp/createCompactTimestamp own the stable table date/time
  grammar.
- selectedObject plus updateProductShellSelectionContext keeps active project
  or book names truthful in primary navigation.

Version 0.3.0 is the first stable installable release. rho.inator and the
structurally different fboe.inator consumer prove the installation and upgrade
contract through pinned, repository-owned archives. Run `npm run check` before
consumer migration.
