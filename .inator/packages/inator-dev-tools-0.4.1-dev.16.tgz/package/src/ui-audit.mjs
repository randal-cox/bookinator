import { readdir, readFile } from "node:fs/promises";
import { dirname, extname, join, normalize, relative, resolve } from "node:path";

export const UI_AUDIT_REVIEW_DAYS = 90;

export function createUIAuditBaseline(findings, now = new Date()) {
  const reviewedAt = new Date(now);
  const reviewAfter = new Date(reviewedAt); reviewAfter.setUTCDate(reviewAfter.getUTCDate() + UI_AUDIT_REVIEW_DAYS);
  return { schema: "inator.ui-audit-baseline.v2", reviewed: true, reviewedAt: reviewedAt.toISOString(), reviewAfter: reviewAfter.toISOString(), findings: [...findings] };
}

export function assertCurrentUIAuditBaseline(baseline, now = new Date()) {
  if (baseline?.schema !== "inator.ui-audit-baseline.v2" || !baseline.reviewed || !Array.isArray(baseline.findings) || !baseline.reviewedAt || !baseline.reviewAfter) throw new TypeError("UI audit baseline requires a dated v2 review; review it again with --accept-audit-baseline.");
  if (Number.isNaN(Date.parse(baseline.reviewAfter)) || Date.parse(baseline.reviewAfter) <= new Date(now).getTime()) throw new TypeError(`UI audit baseline review expired ${baseline.reviewAfter}; review it again with --accept-audit-baseline.`);
  return baseline;
}

async function filesBelow(directory, ignoredDirectories) {
  const output = []; let entries;
  try { entries = await readdir(directory, { withFileTypes: true }); }
  catch (error) { if (error.code === "ENOENT") return output; throw error; }
  for (const entry of entries) {
    if (entry.isDirectory() && ignoredDirectories.has(entry.name)) continue;
    const file = join(directory, entry.name);
    if (entry.isDirectory()) output.push(...await filesBelow(file, ignoredDirectories)); else output.push(file);
  }
  return output;
}

export async function auditUI({ projectDir, rulesPath, roots = null } = {}) {
  const root = resolve(projectDir || process.cwd());
  if (!rulesPath) throw new TypeError("UI audit requires a rulesPath.");
  const contract = JSON.parse(await readFile(resolve(rulesPath), "utf8"));
  const ignored = new Set(contract.ignoredDirectories || []);
  const sourceRoots = [...new Set([...(contract.scanRoots || ["apps", "packages"]), ...(roots || [])])];
  const scanRoots = sourceRoots.map((candidate) => resolve(root, candidate));
  let manifest = null;
  try { manifest = JSON.parse(await readFile(join(root, "inator.json"), "utf8")); }
  catch (error) { if (error.code !== "ENOENT") throw error; }
  const files = (await Promise.all(scanRoots.map((directory) => filesBelow(directory, ignored)))).flat();
  for (const candidate of contract.projectFiles || []) {
    const file = resolve(root, candidate);
    try { await readFile(file); if (!files.includes(file)) files.push(file); }
    catch (error) { if (error.code !== "ENOENT") throw error; }
  }
  const behaviorExtensions = new Set([".html", ".js", ".mjs", ".ts", ".tsx", ".jsx", ".py"]);
  const errors = []; const advisories = []; let checkedFiles = 0; let projectBehavior = "";
  for (const file of files) {
    const extension = extname(file); const projectPath = relative(root, file);
    const rules = contract.rules.filter((rule) => rule.extensions.includes(extension) && !(rule.allowedPaths || []).includes(projectPath));
    if (!rules.length && !behaviorExtensions.has(extension)) continue;
    checkedFiles += 1;
    const source = await readFile(file, "utf8"); let behavior = source;
    if (behaviorExtensions.has(extension)) projectBehavior += `\n${source}`;
    if (extension === ".html") for (const match of source.matchAll(/<script[^>]+src=["']([^"']+)["']/g)) {
      if (/^(?:https?:)?\/\//.test(match[1])) continue;
      try { behavior += `\n${await readFile(normalize(join(dirname(file), match[1])), "utf8")}`; } catch {}
    }
    for (const rule of rules) if (new RegExp(rule.pattern, rule.flags || "").test(source)
      && (!rule.requiredBehaviorPattern || !new RegExp(rule.requiredBehaviorPattern).test(behavior))) {
      const finding = `${projectPath}: [${rule.id}] ${rule.message}`;
      (rule.severity === "advisory" ? advisories : errors).push(finding);
    }
    if (extension !== ".css" && source.includes("inator-dialog") && projectPath !== "packages/ui/src/dialog.js" && !/createDialogController|createDialogSurface/.test(behavior)) errors.push(`${projectPath}: [UI-DIALOG-CONTROLLER] Inator-styled dialog lacks the shared controller or surface factory.`);
  }
  for (const rule of contract.projectRules || []) {
    const declaredCapability = rule.manifestCapability && manifest?.capabilities?.[rule.manifestCapability];
    const sourceTrigger = rule.triggerPattern && new RegExp(rule.triggerPattern, rule.flags || "").test(projectBehavior);
    if (!declaredCapability && !sourceTrigger) continue;
    if (new RegExp(rule.requiredBehaviorPattern, rule.flags || "").test(projectBehavior)) continue;
    const finding = `[${rule.id}] ${rule.message}`;
    (rule.severity === "advisory" ? advisories : errors).push(finding);
  }
  return { checkedFiles, scanRoots, errors, advisories };
}

export function formatUIAudit(result) {
  const findings = [...result.advisories, ...result.errors];
  return findings.length ? findings.join("\n") : `UI conformance passed: ${result.checkedFiles} authored files across ${result.scanRoots.length} source root${result.scanRoots.length === 1 ? "" : "s"}.`;
}
