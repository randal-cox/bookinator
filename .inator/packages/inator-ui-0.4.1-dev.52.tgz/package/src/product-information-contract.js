import { defineProductShellPolicy } from "./product-shell-policy.js";

export const PRODUCT_INFORMATION_CONTRACT_VERSION = "inator.product-information-contract.v1";
export const PRODUCT_INFORMATION_REQUIRED_DESTINATIONS = Object.freeze(["about", "help", "privacy", "security", "milestones", "releases", "roadmap"]);

const safeSource = (value, id) => {
  const source = String(value || "").trim();
  if (!source || source.startsWith("/") || source.split(/[\\/]/).includes("..")) throw new TypeError(`Product information ${id} requires a safe project-relative source.`);
  return source;
};

export function defineProductInformationContract(source = {}) {
  const records = source.records || {}; const normalized = {};
  for (const id of PRODUCT_INFORMATION_REQUIRED_DESTINATIONS) normalized[id] = Object.freeze({ source: safeSource(records[id]?.source || records[id], id) });
  for (const [id, record] of Object.entries(records)) if (!PRODUCT_INFORMATION_REQUIRED_DESTINATIONS.includes(id)) normalized[id] = Object.freeze({ source: safeSource(record?.source || record, id), extension: true });
  const productId = String(source.productId || "").trim();
  if (!productId) throw new TypeError("Product information productId is required.");
  return Object.freeze({ schema: PRODUCT_INFORMATION_CONTRACT_VERSION, productId, records: Object.freeze(normalized) });
}

export function createStandardProductShellPolicy({ information, base = "/", routes = {}, capabilities = [], extensions = [] } = {}) {
  const contract = information?.schema === PRODUCT_INFORMATION_CONTRACT_VERSION ? information : defineProductInformationContract(information);
  for (const id of Object.keys(routes)) if (!Object.hasOwn(contract.records, id)) throw new TypeError(`Product shell route ${id} has no declared information record.`);
  return defineProductShellPolicy({ base, routes, capabilities: [...new Set([...capabilities, "security", "history", "roadmap"])], extensions, strictInformation: true });
}
