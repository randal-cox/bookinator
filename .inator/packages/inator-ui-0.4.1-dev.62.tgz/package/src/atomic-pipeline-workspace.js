import {
  createActionBar,
  createActionRegion,
  createActionRow,
  createCollectionSurface,
  createToolButton,
  setToolButtonState
} from "./action-bar.js";
import { createDialogSurface } from "./dialog.js";
import { createConfirmationDialog } from "./confirmation-dialog.js";
import { createInatorIcon } from "./icons.js";
import { createListModel } from "./list-model.js";
import { createListView } from "./list-view.js";

const STATUS_RANK = Object.freeze({ running: 0, stopping: 1, waiting: 2, queued: 2, paused: 3, blocked: 4, failed: 5, complete: 6, stale: 7, superseded: 8, cancelled: 9, stopped: 10 });

const QUEUE_ACTIONS = Object.freeze({
  "move-top": Object.freeze({ icon: "top", label: "Head" }),
  "move-bottom": Object.freeze({ icon: "lower", label: "Tail" }),
  raise: Object.freeze({ icon: "raise", label: "Raise" }),
  lower: Object.freeze({ icon: "lower", label: "Lower" }),
  pause: Object.freeze({ icon: "pause", label: "Pause" }),
  resume: Object.freeze({ icon: "resume", label: "Resume" }),
  "stop-after": Object.freeze({ icon: "stopAfter", label: "Stop after" }),
  notify: Object.freeze({ icon: "questions", label: "Notify" })
});

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function button(icon, label, options = {}) {
  return createToolButton({ icon: createInatorIcon(icon), label, ...options });
}

function latestAttempt(unit) {
  return (unit.attempts || []).find(({ attemptId, id }) => (attemptId || id) === unit.acceptedAttemptId)
    || (unit.attempts || []).at(-1)
    || null;
}

function elapsedMilliseconds(attempt) {
  const start = attempt?.claimedAt || attempt?.startedAt;
  const finish = attempt?.finishedAt || attempt?.completedAt;
  if (!start || !finish) return null;
  const value = new Date(finish) - new Date(start);
  return Number.isFinite(value) && value >= 0 ? value : null;
}

export function pipelineTimingSummary(units = []) {
  const groups = new Map();
  for (const unit of units) {
    const kind = unit.method || unit.input?.provider || "unclassified";
    for (const attempt of unit.attempts || []) {
      const elapsed = elapsedMilliseconds(attempt);
      if (elapsed == null) continue;
      const values = groups.get(kind) || [];
      values.push({ elapsed, status: attempt.status || "unknown" });
      groups.set(kind, values);
    }
  }
  return [...groups].map(([kind, values]) => {
    const durations = values.map(({ elapsed }) => elapsed);
    const total = durations.reduce((sum, value) => sum + value, 0);
    return {
      kind,
      count: values.length,
      failures: values.filter(({ status }) => status === "failed").length,
      totalMilliseconds: total,
      averageMilliseconds: total / durations.length,
      maximumMilliseconds: Math.max(...durations)
    };
  }).sort((left, right) => right.totalMilliseconds - left.totalMilliseconds);
}

export function normalizeAtomicPipelineUnit(unit, index = 0) {
  const status = unit.status === "queued" ? "waiting" : String(unit.status || "waiting");
  const schedulingPolicy = unit.policy && typeof unit.policy === "object" ? unit.policy : {};
  const gate = unit.gate && typeof unit.gate === "object" ? unit.gate : {};
  return {
    ...unit,
    id: String(unit.workUnitId || unit.id || `pipeline-step-${index + 1}`),
    sequence: Number(unit.sequence ?? index + 1),
    label: String(unit.label || unit.workUnitId || unit.id || `Pipeline step ${index + 1}`),
    provider: String(unit.provider || unit.input?.provider || "local"),
    project: String(unit.project || unit.subject || unit.input?.title || unit.input?.name || "Project"),
    projectPriority: String(unit.projectPriority || "normal"),
    subject: String(unit.subject || unit.input?.title || unit.input?.name || unit.project || "Project"),
    status,
    statusLabel: status === "waiting" ? "Waiting" : status[0].toUpperCase() + status.slice(1).replaceAll("-", " "),
    schedulingPolicy,
    policy: [schedulingPolicy.required || unit.required ? "Required" : "", schedulingPolicy.pinned || unit.pinned ? "Pinned" : "", gate.state === "waiting" ? "Human gate" : "", schedulingPolicy.stopAfter || unit.stopAfter ? "Stop after" : "", schedulingPolicy.notifyOnComplete || unit.notifyOnComplete ? "Notify" : ""].filter(Boolean).join(" · ") || "—"
  };
}

function statusNode(record, inspect) {
  const wrapper = document.createElement("span");
  wrapper.className = "inator-pipeline-stage inator-pipeline-queue-status";
  wrapper.dataset.status = record.status === "waiting" ? "queued" : record.status;
  const badge = document.createElement("button");
  badge.type = "button";
  badge.className = "inator-pipeline-stage__status";
  badge.textContent = record.statusLabel;
  badge.title = `Inspect status, elapsed time, input, and output for ${record.label}`;
  badge.addEventListener("click", (event) => { event.preventDefault(); event.stopPropagation(); inspect(record, badge); });
  wrapper.append(badge);
  return wrapper;
}

function createInspector() {
  const tabs = document.createElement("div");
  tabs.className = "inator-run-inspector__tabs";
  tabs.setAttribute("role", "tablist");
  const panel = document.createElement("article");
  panel.className = "inator-run-inspector__panel";
  const body = document.createElement("div");
  body.className = "inator-run-inspector__content";
  body.append(tabs, panel);
  const done = document.createElement("button");
  done.type = "button";
  done.className = "primary";
  done.dataset.dialogClose = "";
  done.textContent = "Done";
  const surface = createDialogSurface({
    context: "Pipeline run",
    title: "Run details",
    description: "Status, timing, provenance, and saved payloads",
    bodyContent: body,
    footerContent: done,
    className: "inator-run-inspector is-resizable",
    wide: true,
    controllerOptions: { closeOnBackdrop: false }
  });
  let record = null;
  let selected = "overview";
  const controls = new Map();
  const attempt = () => latestAttempt(record);
  const show = (view) => {
    selected = view;
    controls.forEach((control, name) => control.setAttribute("aria-selected", String(name === view)));
    panel.replaceChildren();
    const current = attempt();
    if (view === "overview") {
      const facts = document.createElement("dl");
      facts.className = "inator-run-inspector__facts";
      const elapsed = elapsedMilliseconds(current);
      const rows = [
        ["State", record.statusLabel], ["Attempt", current?.attemptId || current?.id || "No attempt issued"],
        ["Worker", current?.workerId || current?.actor || "Not assigned"], ["Method", record.method || "Not recorded"],
        ["Claim", current?.claimGeneration ? `Generation ${current.claimGeneration}` : "Not issued"],
        ["Started", current?.claimedAt || current?.startedAt || "Not started"],
        ["Finished", current?.finishedAt || current?.completedAt || "Not finished"],
        ["Elapsed", elapsed == null ? "Not started" : elapsed < 60000 ? `${(elapsed / 1000).toFixed(elapsed < 10000 ? 1 : 0)} seconds` : `${Math.floor(elapsed / 60000)}m ${Math.round(elapsed % 60000 / 1000)}s`]
      ];
      rows.forEach(([term, value]) => { const dt = document.createElement("dt"); const dd = document.createElement("dd"); dt.textContent = term; dd.textContent = value; facts.append(dt, dd); });
      const heading = document.createElement("h3"); heading.textContent = "Attempt record";
      panel.append(heading, facts);
    } else {
      const heading = document.createElement("h3");
      heading.textContent = view === "input" ? "Input JSON" : "Output JSON";
      const payload = view === "input" ? record.input : attempt()?.output ?? record.result;
      const pre = document.createElement("pre"); pre.className = "inator-run-inspector__json"; pre.textContent = payload == null ? "Not available for this attempt." : JSON.stringify(payload, null, 2);
      panel.append(heading, pre);
    }
  };
  for (const view of ["overview", "input", "output"]) {
    const control = document.createElement("button");
    control.type = "button"; control.setAttribute("role", "tab");
    control.textContent = view === "overview" ? "Run details" : `${view[0].toUpperCase()}${view.slice(1)} JSON`;
    control.addEventListener("click", () => show(view));
    controls.set(view, control); tabs.append(control);
  }
  return {
    open(next, opener) {
      record = next; selected = "overview";
      surface.contextNode.textContent = attempt() ? "Saved pipeline attempt" : "Pipeline step";
      surface.titleNode.textContent = record.label;
      controls.get("input").disabled = !record.input;
      controls.get("output").disabled = !(attempt()?.output ?? record.result);
      show(selected); surface.open(opener);
    },
    destroy: surface.destroy
  };
}

function downloadable(content, type, filename) {
  const url = URL.createObjectURL(content instanceof Blob ? content : new Blob([content], { type }));
  const link = document.createElement("a"); link.href = url; link.download = filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportableTimingSvg(svg) {
  const clone = svg.cloneNode(true);
  clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
  clone.setAttribute("width", svg.viewBox.baseVal.width);
  clone.setAttribute("height", svg.viewBox.baseVal.height);
  const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
  style.textContent = `.timing-grid{stroke:#dce7f4;stroke-width:1}.timing-axis{stroke:#8091a8;stroke-width:1.25}.timing-bar{fill:#1769ce}.timing-bar.is-failure{fill:#a43a43}.timing-label{fill:#19395f;font:700 13px Arial,sans-serif}.timing-facts,.timing-tick,.timing-axis-title{fill:#52657f;font:600 11px Arial,sans-serif}`;
  clone.prepend(style);
  return new XMLSerializer().serializeToString(clone);
}

function timingCanvas(svg, scale = 2) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const url = URL.createObjectURL(new Blob([exportableTimingSvg(svg)], { type: "image/svg+xml;charset=utf-8" }));
    image.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = svg.viewBox.baseVal.width * scale; canvas.height = svg.viewBox.baseVal.height * scale;
      canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url); resolve(canvas);
    };
    image.onerror = (error) => { URL.revokeObjectURL(url); reject(error); };
    image.src = url;
  });
}

function timingChart(rows) {
  const width = 920; const labelWidth = 205; const right = 105; const top = 38; const rowHeight = 58; const bottom = 54;
  const height = top + Math.max(0, rows.length - 1) * rowHeight + bottom;
  const maximum = Math.max(1, ...rows.map(({ averageMilliseconds }) => averageMilliseconds));
  const x = (value) => labelWidth + value / maximum * (width - labelWidth - right);
  const y = (index) => top + index * rowHeight;
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`); svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", "Average elapsed time grouped by atomic pipeline step kind");
  const add = (name, attributes = {}, text = "") => {
    const node = document.createElementNS("http://www.w3.org/2000/svg", name);
    Object.entries(attributes).forEach(([key, value]) => node.setAttribute(key, value));
    if (text) node.textContent = text; svg.append(node); return node;
  };
  for (let index = 0; index <= 4; index += 1) {
    const value = maximum * index / 4; const at = x(value);
    add("line", { x1: at, x2: at, y1: top - 16, y2: y(rows.length - 1) + 17, class: "timing-grid" });
    add("text", { x: at, y: height - 22, "text-anchor": "middle", class: "timing-tick" }, `${(value / 1000).toFixed(2)}s`);
  }
  rows.forEach((row, index) => {
    const cy = y(index); const barWidth = Math.max(3, x(row.averageMilliseconds) - labelWidth);
    add("text", { x: labelWidth - 16, y: cy - 3, "text-anchor": "end", class: "timing-label" }, row.kind.replaceAll("-", " "));
    add("text", { x: labelWidth - 16, y: cy + 14, "text-anchor": "end", class: "timing-facts" }, `${row.count} attempt${row.count === 1 ? "" : "s"}${row.failures ? ` - ${row.failures} failed` : ""}`);
    const bar = add("rect", { x: labelWidth, y: cy - 14, width: barWidth, height: 22, rx: 5, class: `timing-bar${row.failures ? " is-failure" : ""}`, tabindex: 0 });
    const title = document.createElementNS("http://www.w3.org/2000/svg", "title"); title.textContent = `${row.kind}: ${(row.averageMilliseconds / 1000).toFixed(2)} seconds average, ${(row.maximumMilliseconds / 1000).toFixed(2)} seconds maximum`; bar.append(title);
    add("text", { x: Math.min(width - right + 8, labelWidth + barWidth + 8), y: cy + 3, class: "timing-facts" }, `${(row.averageMilliseconds / 1000).toFixed(2)}s avg`);
  });
  add("line", { x1: labelWidth, x2: width - right, y1: y(rows.length - 1) + 18, y2: y(rows.length - 1) + 18, class: "timing-axis" });
  add("text", { x: labelWidth + (width - labelWidth - right) / 2, y: height - 3, "text-anchor": "middle", class: "timing-axis-title" }, "Average elapsed time");
  return svg;
}

export async function createTimingPdf({ chartDataUrl, chartWidth, chartHeight, labels = {} }) {
  const { jsPDF } = await import("jspdf");
  const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "letter" });
  const pageWidth = pdf.internal.pageSize.getWidth(); const pageHeight = pdf.internal.pageSize.getHeight(); const margin = 34; const chartTop = 76; const footerTop = pageHeight - 62; const availableWidth = pageWidth - margin * 2; const availableHeight = footerTop - chartTop - 16; const ratio = Math.min(availableWidth / chartWidth, availableHeight / chartHeight);
  pdf.setTextColor(16, 39, 72); pdf.setFont("times", "bold"); pdf.setFontSize(16); pdf.text(labels.documentTitle || "Pipeline timing", margin, 32);
  pdf.setTextColor(82, 101, 127); pdf.setFont("helvetica", "bold"); pdf.setFontSize(10); pdf.text(labels.pdfSection || "Timing", pageWidth - margin, 32, { align: "right" });
  pdf.addImage(chartDataUrl, "PNG", margin, chartTop, chartWidth * ratio, chartHeight * ratio);
  pdf.setDrawColor(210, 222, 238); pdf.line(margin, footerTop, pageWidth - margin, footerTop); pdf.setFillColor(7, 95, 203); pdf.roundedRect(margin, footerTop + 12, 28, 28, 6, 6, "F"); pdf.setTextColor(255, 255, 255); pdf.setFont("times", "bold"); pdf.setFontSize(17); pdf.text(String(labels.appMark || "I").slice(0, 1).toUpperCase(), margin + 14, footerTop + 32, { align: "center" });
  pdf.setTextColor(20, 54, 99); pdf.setFont("helvetica", "bold"); pdf.setFontSize(10); pdf.text(labels.appName || "Inator", margin + 38, footerTop + 23); pdf.setTextColor(100, 117, 140); pdf.setFont("helvetica", "normal"); pdf.setFontSize(8); pdf.text(labels.appSubtitle || "Pipeline control room", margin + 38, footerTop + 35); pdf.setTextColor(42, 74, 116); pdf.setFont("helvetica", "bold"); pdf.text("Page 1 of 1", pageWidth - margin, footerTop + 28, { align: "right" });
  return pdf;
}

function createTimingDialog(labels = {}) {
  const report = document.createElement("div"); report.className = "inator-pipeline-timing-groups";
  const introduction = document.createElement("p"); introduction.textContent = "Completed attempts grouped by atomic step kind.";
  const actions = document.createElement("div"); actions.className = "inator-pipeline-timing-actions";
  const fit = button("fit", "Fit"); fit.setAttribute("aria-pressed", "false");
  const exportMenu = document.createElement("details"); exportMenu.className = "inator-pipeline-timing-export";
  const exportSummary = document.createElement("summary"); exportSummary.append(createInatorIcon("export"), Object.assign(document.createElement("span"), { textContent: "Export" }));
  const exportOptions = document.createElement("div"); exportOptions.setAttribute("role", "menu");
  ["SVG", "PNG", "PDF"].forEach((format) => { const control = document.createElement("button"); control.type = "button"; control.setAttribute("role", "menuitem"); control.dataset.format = format.toLowerCase(); control.textContent = format; exportOptions.append(control); });
  exportMenu.append(exportSummary, exportOptions); actions.append(fit, exportMenu);
  const body = document.createElement("div"); body.className = "inator-pipeline-timing-report"; body.append(introduction, actions, report);
  const done = document.createElement("button"); done.type = "button"; done.className = "primary"; done.dataset.dialogClose = ""; done.textContent = "Done";
  const surface = createDialogSurface({ context: labels.appName || "Developer report", title: "Pipeline timing", description: "Observed attempt durations by atomic step kind", bodyContent: body, footerContent: done, className: "inator-pipeline-timing-dialog", wide: true, controllerOptions: { closeOnBackdrop: false } });
  let fitted = false;
  fit.addEventListener("click", () => { fitted = !fitted; fit.setAttribute("aria-pressed", String(fitted)); report.dataset.fit = String(fitted); });
  exportOptions.addEventListener("click", async (event) => {
    const control = event.target.closest("button[data-format]"); if (!control) return;
    const svg = report.querySelector("svg"); if (!svg) return;
    control.disabled = true;
    try {
      const format = control.dataset.format; const slug = String(labels.appName || "inator").toLowerCase().replaceAll(/[^a-z0-9]+/g, "-").replaceAll(/^-|-$/g, "");
      if (format === "svg") downloadable(exportableTimingSvg(svg), "image/svg+xml;charset=utf-8", `${slug}-pipeline-timing.svg`);
      const canvas = format === "svg" ? null : await timingCanvas(svg);
      if (format === "png") canvas.toBlob((blob) => blob && downloadable(blob, "image/png", `${slug}-pipeline-timing.png`), "image/png");
      if (format === "pdf") {
        const pdf = await createTimingPdf({ chartDataUrl: canvas.toDataURL("image/png"), chartWidth: canvas.width, chartHeight: canvas.height, labels });
        pdf.save(`${slug}-pipeline-timing.pdf`);
      }
    } finally { control.disabled = false; exportMenu.open = false; }
  });
  return {
    open(units, opener) {
      const rows = pipelineTimingSummary(units);
      report.replaceChildren(); if (rows.length) report.append(timingChart(rows));
      if (!rows.length) report.textContent = "No completed attempt timings are available yet.";
      surface.open(opener);
    },
    destroy: surface.destroy
  };
}

export function createAtomicPipelineWorkspace({
  progressMount,
  queueMount,
  snapshot,
  onAction,
  referenceStorageKey = "inator.pipeline.reference.v1",
  labels = {},
  tidyEligible = (record) => record.status === "complete",
  supportedActions = ["move-top", "move-bottom", "stop-after", "notify"],
  showTidy = true,
  showTiming = true,
  showStartHere = true
} = {}) {
  if (!progressMount?.replaceChildren || !queueMount?.replaceChildren) throw new TypeError("Atomic pipeline workspace requires progress and queue mounts.");
  const inspector = createInspector();
  const timing = createTimingDialog(labels);
  const confirmation = createConfirmationDialog({
    context: "Queue cleanup",
    title: "Remove completed steps?",
    confirmLabel: "Tidy",
    danger: true
  });
  let current = snapshot || { state: "ready", units: [] };
  let selectedIds = new Set();
  let list = null;

  const act = async (action, unitIds = []) => {
    const next = await onAction?.({ action, unitIds, snapshot: current });
    if (next) update(next.snapshot || next);
    return next;
  };

  const renderProgress = (records) => {
    const completed = Number(current.progress?.completed ?? records.filter(({ status }) => status === "complete").length);
    const running = records.find(({ status }) => ["running", "stopping"].includes(status));
    const waiting = records.filter(({ status }) => status === "waiting");
    const incomplete = records.filter(({ status }) => !["complete", "cancelled", "stopped", "superseded"].includes(status));
    const durations = current.units.flatMap((unit) => unit.attempts || []).map(elapsedMilliseconds).filter((value) => value != null).slice(-5);
    const average = durations.length ? durations.reduce((sum, value) => sum + value, 0) / durations.length : null;
    const eta = average == null ? null : Math.round(average * (records.length - completed));
    const total = Number(current.progress?.total ?? records.length);
    const progressIncomplete = completed < total || incomplete.length > 0;
    const percent = total ? Math.round(completed / total * 100) : 0;
    let reference = new Date(current.progress?.referenceAt || Date.now());
    try { reference = new Date(localStorage.getItem(referenceStorageKey) || reference); } catch {}
    const section = document.createElement("section"); section.className = "inator-pipeline-run-progress";
    const progressStatus = !progressIncomplete ? "Complete"
      : waiting.length === 0 ? "No work is eligible"
        : eta == null ? "Estimating ETA" : `About ${Math.max(1, Math.ceil(eta / 60000))} min remaining`;
    const basis = current.progress?.basis || `Reference ${reference.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" })}`;
    const activity = running?.label || (waiting.length ? "Queue stopped; work is waiting" : progressIncomplete ? "Work is paused, blocked, or deferred" : "No work is waiting");
    section.innerHTML = `<div class="inator-pipeline-run-metrics"><strong class="inator-pipeline-run-name">${escapeHtml(labels.runName || "Current run")}</strong><span class="inator-pipeline-run-count">${completed.toLocaleString()} of ${total.toLocaleString()} steps complete</span><progress max="${total || 1}" value="${completed}"></progress><div class="inator-pipeline-run-percent"><strong>${percent}%</strong><span>${escapeHtml(progressStatus)}</span><small>${escapeHtml(basis)}</small></div><div class="inator-pipeline-current-job"><span aria-hidden="true"></span><strong>${escapeHtml(activity)}</strong></div></div><div class="inator-pipeline-run-controls"></div>`;
    const controls = section.querySelector(".inator-pipeline-run-controls");
    const timingButton = button("timing", "Timing"); timingButton.addEventListener("click", () => timing.open(current.units, timingButton));
    const selected = records.find(({ id }) => selectedIds.has(id));
    const startHere = button("top", "Start here", { disabled: selectedIds.size !== 1 || selected?.status !== "waiting" || Boolean(running) });
    startHere.addEventListener("click", async () => { await act("move-top", [...selectedIds]); await act("start"); });
    const runActive = Boolean(running) || ["running", "stopping"].includes(current.state);
    const run = button(runActive ? "stopAfter" : "run", runActive ? "Stop" : waiting.length ? completed ? "Resume" : "Start" : progressIncomplete ? "Unavailable" : "Complete", { className: runActive ? "inator-tool-button--danger" : "inator-tool-button--primary", disabled: !runActive && waiting.length === 0 });
    run.addEventListener("click", () => act(runActive ? "stop" : "start"));
    controls.append(...[showTiming ? timingButton : null, showStartHere ? startHere : null, run].filter(Boolean)); section.dataset.state = current.state || "ready";
    progressMount.replaceChildren(section);
  };

  const render = () => {
    const projects = new Map((current.projects || []).map((project) => [project.id, project]));
    const records = (current.units || []).map((unit, index) => {
      const project = projects.get(unit.projectId);
      return normalizeAtomicPipelineUnit({ ...unit, project: unit.project || project?.label, projectPriority: unit.projectPriority || project?.priority }, index);
    });
    selectedIds = new Set([...selectedIds].filter((id) => records.some((record) => record.id === id)));
    const columns = [
      { id: "sequence", label: "#", value: (record) => record.sequence },
      { id: "label", label: "Step", required: true, value: (record) => record.label },
      { id: "project", label: labels.project || "Project", required: true, value: (record) => record.project },
      { id: "projectPriority", label: "Priority", responsiveHideBelow: 980, value: (record) => record.projectPriority, filterValue: (record) => record.projectPriority },
      { id: "provider", label: "Provider", responsiveHideBelow: 850, value: (record) => record.provider },
      { id: "policy", label: "Policy", responsiveHideBelow: 980, value: (record) => record.policy },
      { id: "status", label: "Status", value: (record) => STATUS_RANK[record.status] ?? 99, filterValue: (record) => record.status, render: (record) => statusNode(record, inspector.open) }
    ];
    const model = createListModel({ columns, records, initialState: { pageSize: 10, sort: { id: "sequence", direction: "asc" }, selectedIds: [...selectedIds], rememberedSelection: [...selectedIds] } });
    const columnsButton = button("columns", "Columns");
    const tidyCount = records.filter(tidyEligible).length;
    const tidy = showTidy ? button("tidy", "Tidy", { disabled: tidyCount === 0, statusText: tidyCount ? tidyCount.toLocaleString() : "" }) : null;
    const actionButtons = new Map(supportedActions.map((action) => {
      const definition = QUEUE_ACTIONS[action];
      if (!definition) throw new TypeError(`Unsupported atomic pipeline action ${action}.`);
      const control = button(definition.icon, definition.label, { disabled: true });
      control.addEventListener("click", () => act(action, [...selectedIds]));
      return [action, control];
    }));
    const listMount = document.createElement("div");
    queueMount.replaceChildren(createCollectionSurface({ actionBar: createActionBar({ label: "Pipeline queue actions", rows: [createActionRow({ children: [createActionRegion({ children: [columnsButton, tidy].filter(Boolean) }), createActionRegion({ separated: true, children: [...actionButtons.values()] })] })] }), listMount }));
    list?.destroy?.();
    list = createListView({
      mount: listMount, model, columnButton: columnsButton,
      filters: [{ id: "status", label: "Status", options: [...new Set(records.map(({ status }) => status))] }, { id: "projectPriority", label: "Priority", options: [...new Set(records.map(({ projectPriority }) => projectPriority))] }, { id: "provider", label: "Provider", options: [...new Set(records.map(({ provider }) => provider))].sort() }],
      searchPlaceholder: `Search ${records.length.toLocaleString()} pipeline steps`, pageSizeOptions: [10, 25, 50, 100, records.length].filter((value, index, values) => value > 0 && values.indexOf(value) === index),
      onChange(state) {
        selectedIds = new Set(state.selectedIds); const count = selectedIds.size;
        const selected = records.filter(({ id }) => selectedIds.has(id));
        for (const [action, control] of actionButtons) {
          const actionable = action === "pause" ? selected.some(({ status }) => ["waiting", "running", "stopping"].includes(status))
            : action === "resume" ? selected.some(({ status }) => status === "paused")
              : action === "stop-after" ? count === 1
                : count > 0;
          setToolButtonState(control, { disabled: !actionable, statusText: count ? String(count) : "" });
        }
        renderProgress(records);
      }
    });
    tidy?.addEventListener("click", () => confirmation.open({
      title: `Remove ${tidyCount.toLocaleString()} completed ${tidyCount === 1 ? "step" : "steps"}?`,
      message: "They leave the active queue; the product remains responsible for any promised durable history.",
      confirmLabel: "Tidy",
      danger: true,
      onConfirm: () => act("remove-completed")
    }, tidy));
    list.render(); listMount.querySelectorAll(".inator-list-actions").forEach((cell) => cell.remove());
    renderProgress(records);
  };

  function update(next) { current = next || { state: "ready", units: [] }; render(); return current; }
  render();
  return { update, get snapshot() { return current; }, destroy() { list?.destroy?.(); inspector.destroy(); timing.destroy(); confirmation.destroy(); progressMount.replaceChildren(); queueMount.replaceChildren(); } };
}
