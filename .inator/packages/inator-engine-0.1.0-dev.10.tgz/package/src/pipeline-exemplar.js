import { assertPipelineSnapshotConformance, definePipelineSnapshot, pipelineDispatchOrder } from "./pipeline-contract.js";

const clone = (value) => JSON.parse(JSON.stringify(value));

export function createPopulatedPipelineExemplar() {
  return definePipelineSnapshot({
    schema: "inator.pipeline-snapshot.v1",
    id: "commons-populated-lab",
    runId: "commons-populated-lab",
    revision: 1,
    state: "running",
    projects: [
      { id: "project-cedar", label: "Cedar archive", detail: "High-priority local corpus", priority: "high" },
      { id: "project-fern", label: "Fern study", detail: "Ordinary scheduled work", priority: "normal" },
      { id: "project-moss", label: "Moss simulation", detail: "Human decision required", priority: "low" },
      { id: "project-ash", label: "Ash collection", detail: "Preserved but deferred", priority: "deferred", deferred: true }
    ],
    units: [
      {
        id: "cedar::extract", projectId: "project-cedar", label: "Extract evidence", method: "evidence.extract", provider: "local", status: "running", rank: 1,
        attempts: [{ id: "cedar::extract:2", status: "running", disposition: "candidate", claimGeneration: 2, workerId: "local-worker", startedAt: "2026-10-05T12:00:00Z" }],
        currentAttemptId: "cedar::extract:2",
        policy: { required: true, retry: "bounded", recovery: "retry-attempt", safeStopBoundary: "attempt" }, gate: { state: "not-required" },
        children: [
          { id: "cedar::extract::section-7", label: "Section 7", detail: "The local worker owns this operation.", method: "evidence.extract", status: "running", sequence: 1 },
          { id: "cedar::extract::section-8", label: "Section 8", detail: "Waiting behind the current operation.", method: "evidence.extract", status: "blocked", sequence: 2 }
        ]
      },
      {
        id: "fern::classify", projectId: "project-fern", label: "Classify records", method: "records.classify", provider: "local", status: "waiting", rank: 2,
        policy: { retry: "explicit", recovery: "replay-unit", safeStopBoundary: "unit" }, gate: { state: "not-required" },
        children: [
          { id: "fern::classify::record-21", label: "Record 21", method: "records.classify", status: "waiting", sequence: 1 },
          { id: "fern::classify::record-22", label: "Record 22", method: "records.classify", status: "waiting", sequence: 2 },
          { id: "fern::classify::record-23", label: "Record 23", method: "records.classify", status: "waiting", sequence: 3 }
        ]
      },
      {
        id: "fern::synthesize", projectId: "project-fern", label: "Synthesize findings", method: "findings.synthesize", provider: "local", status: "paused", rank: 3,
        policy: { paused: true, retry: "explicit", recovery: "manual", safeStopBoundary: "stage" }, gate: { state: "not-required" },
        children: [
          { id: "fern::synthesize::part-a", label: "Part A", method: "findings.synthesize", status: "paused", sequence: 1 },
          { id: "fern::synthesize::part-b", label: "Part B", method: "findings.synthesize", status: "paused", sequence: 2 }
        ]
      },
      {
        id: "moss::adjudicate", projectId: "project-moss", label: "Adjudicate boundary", method: "boundary.adjudicate", provider: "human", status: "blocked", rank: 4,
        policy: { retry: "never", recovery: "manual", safeStopBoundary: "unit" }, gate: { state: "waiting", prompt: "Approve the proposed boundary before derived work continues." },
        children: [{ id: "moss::adjudicate::decision", label: "Boundary decision", method: "boundary.adjudicate", provider: "human", status: "blocked", sequence: 1 }]
      },
      {
        id: "cedar::review", projectId: "project-cedar", label: "Review output", method: "output.review", provider: "local", status: "failed", rank: 5,
        attempts: [{ id: "cedar::review:1", status: "failed", disposition: "rejected", completedAt: "2026-10-05T11:58:00Z" }],
        policy: { retry: "explicit", recovery: "retry-attempt", safeStopBoundary: "attempt" }, gate: { state: "not-required" },
        children: [{ id: "cedar::review::section-6", label: "Section 6", detail: "The retained attempt failed validation.", method: "output.review", status: "failed", sequence: 1 }]
      },
      {
        id: "ash::index", projectId: "project-ash", label: "Index collection", method: "collection.index", provider: "local", status: "waiting", rank: 6,
        policy: { retry: "automatic", recovery: "replay-unit", safeStopBoundary: "unit" }, gate: { state: "not-required" },
        children: [
          { id: "ash::index::volume-3", label: "Volume 3", method: "collection.index", status: "waiting", sequence: 1 },
          { id: "ash::index::volume-4", label: "Volume 4", method: "collection.index", status: "waiting", sequence: 2 }
        ]
      }
    ],
    progress: { completed: 6, total: 17, active: 11, scope: "current-run", unit: "atomic operation", basis: "4 projects · 2 operations deferred by project policy", referenceAt: "2026-10-05T11:30:00Z" },
    controls: { start: true, stop: true, moveTop: true, projectPriority: true, pause: true, resume: true },
    completion: { machine: "incomplete", review: "product-owned" }
  });
}

export function createPipelineExemplarController(source = createPopulatedPipelineExemplar()) {
  let current = clone(source);
  const snapshot = () => definePipelineSnapshot(current);
  assertPipelineSnapshotConformance(snapshot());

  return Object.freeze({
    get snapshot() { return snapshot(); },
    apply(intent = {}) {
      if (intent.schema !== "inator.pipeline-control-intent.v1") throw new TypeError("Unsupported pipeline control intent.");
      if (Number(intent.expectedRevision) !== Number(current.revision)) {
        const error = new Error("The pipeline changed. Refresh the snapshot before applying another control.");
        error.code = "stale-pipeline-snapshot";
        error.snapshot = snapshot();
        throw error;
      }
      const selectedIds = new Set(intent.unitIds || []);
      if ([...selectedIds].some((id) => !current.units.some((unit) => unit.id === id))) throw new TypeError("The selected pipeline unit no longer exists.");
      if (intent.action === "start" && !current.units.some(({ status }) => status === "running")) {
        const next = pipelineDispatchOrder(snapshot())[0];
        if (next) current.units.find(({ id }) => id === next.id).status = "running";
        current.state = next ? "running" : "ready";
      } else if (intent.action === "stop") {
        const running = current.units.find(({ status }) => status === "running");
        if (running) running.status = "stopping";
        current.state = running ? "stopping" : "ready";
      } else if (intent.action === "move-top") {
        const selected = current.units.filter(({ id }) => selectedIds.has(id));
        const rest = current.units.filter(({ id }) => !selectedIds.has(id));
        current.units = [...selected, ...rest];
      } else if (["raise", "lower"].includes(intent.action)) {
        const levels = ["urgent", "high", "normal", "low", "deferred"];
        const direction = intent.action === "raise" ? -1 : 1;
        const projects = new Set(current.units.filter(({ id }) => selectedIds.has(id)).map(({ projectId }) => projectId));
        current.projects.forEach((project) => {
          if (!projects.has(project.id)) return;
          project.priority = levels[Math.max(0, Math.min(levels.length - 1, levels.indexOf(project.priority) + direction))];
          project.deferred = project.priority === "deferred";
        });
      } else if (["pause", "resume"].includes(intent.action)) {
        const paused = intent.action === "pause";
        current.units.forEach((unit) => {
          if (!selectedIds.has(unit.id) || unit.policy.required) return;
          unit.policy.paused = paused;
          unit.status = paused ? "paused" : "waiting";
          unit.children.forEach((child) => { child.status = paused ? "paused" : "waiting"; });
        });
      } else throw new TypeError(`Unsupported pipeline exemplar action ${intent.action}.`);
      current.units.forEach((unit, index) => { unit.sequence = index + 1; unit.rank = index + 1; });
      current.revision += 1;
      assertPipelineSnapshotConformance(snapshot());
      return snapshot();
    }
  });
}
