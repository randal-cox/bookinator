export const PIPELINE_SNAPSHOT_SCHEMA = "inator.pipeline-snapshot.v1";

export const PIPELINE_PROJECT_PRIORITIES = Object.freeze(["urgent", "high", "normal", "low", "deferred"]);
export const PIPELINE_UNIT_STATUSES = Object.freeze(["waiting", "running", "stopping", "paused", "blocked", "complete", "failed", "cancelled", "stale", "superseded"]);
export const PIPELINE_RETRY_POLICIES = Object.freeze(["explicit", "bounded", "automatic", "never"]);
export const PIPELINE_STOP_BOUNDARIES = Object.freeze(["attempt", "unit", "stage", "immediate"]);
export const PIPELINE_RECOVERY_POLICIES = Object.freeze(["retry-attempt", "replay-unit", "restart-project", "manual", "never"]);
export const PIPELINE_GATE_STATES = Object.freeze(["not-required", "waiting", "satisfied", "rejected"]);
export const PIPELINE_ATTEMPT_DISPOSITIONS = Object.freeze(["candidate", "accepted", "stale", "superseded", "rejected"]);

const priorityRank = Object.freeze(Object.fromEntries(PIPELINE_PROJECT_PRIORITIES.map((priority, index) => [priority, index])));

function plainObject(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object.`);
  return value;
}

function requiredText(value, label) {
  const text = String(value ?? "").trim();
  if (!text) throw new TypeError(`${label} is required.`);
  return text;
}

function optionalText(value) {
  const text = String(value ?? "").trim();
  return text || null;
}

function enumValue(value, values, label, fallback) {
  const normalized = String(value ?? fallback);
  if (!values.includes(normalized)) throw new TypeError(`${label} must be one of ${values.join(", ")}.`);
  return normalized;
}

function unique(records, label) {
  const ids = records.map(({ id }) => id);
  if (new Set(ids).size !== ids.length) throw new TypeError(`${label} ids must be unique.`);
}

function normalizeProject(source, index) {
  const value = plainObject(source, `Project ${index}`);
  return Object.freeze({
    ...value,
    id: requiredText(value.id, `Project ${index} id`),
    label: requiredText(value.label || value.displayName, `Project ${index} label`),
    detail: optionalText(value.detail),
    priority: enumValue(value.priority, PIPELINE_PROJECT_PRIORITIES, `Project ${index} priority`, "normal"),
    deferred: Boolean(value.deferred || value.priority === "deferred")
  });
}

function normalizeAttempt(source, unitId, index) {
  const value = plainObject(source, `Attempt ${index} for ${unitId}`);
  const id = requiredText(value.id || value.attemptId, `Attempt ${index} id`);
  return Object.freeze({
    ...value,
    id,
    attemptId: id,
    status: requiredText(value.status, `Attempt ${id} status`),
    claimGeneration: Number(value.claimGeneration || 0),
    inputSignature: optionalText(value.inputSignature),
    workerId: optionalText(value.workerId || value.actor),
    startedAt: optionalText(value.startedAt || value.claimedAt),
    completedAt: optionalText(value.completedAt || value.finishedAt),
    disposition: enumValue(value.disposition, PIPELINE_ATTEMPT_DISPOSITIONS, `Attempt ${id} disposition`, "candidate")
  });
}

function normalizeAtomicChild(source, unitId, index) {
  const value = plainObject(source, `Atomic work ${index} for ${unitId}`);
  const id = requiredText(value.id || value.workUnitId, `Atomic work ${index} id`);
  const status = enumValue(value.status === "queued" ? "waiting" : value.status, PIPELINE_UNIT_STATUSES, `Atomic work ${id} status`, "waiting");
  const attempts = (value.attempts || []).map((attempt, attemptIndex) => normalizeAttempt(attempt, id, attemptIndex));
  unique(attempts, `Atomic work ${id} attempt`);
  return Object.freeze({
    ...value,
    id,
    workUnitId: id,
    label: requiredText(value.label, `Atomic work ${id} label`),
    detail: optionalText(value.detail),
    method: requiredText(value.method || value.action || "pipeline.work", `Atomic work ${id} method`),
    provider: optionalText(value.provider) || "local",
    subject: optionalText(value.subject),
    sequence: Number.isFinite(Number(value.sequence)) ? Number(value.sequence) : index + 1,
    status,
    attempts: Object.freeze(attempts)
  });
}

function normalizeUnit(source, index, projectIds) {
  const value = plainObject(source, `Work unit ${index}`);
  const id = requiredText(value.id || value.workUnitId, `Work unit ${index} id`);
  const projectId = requiredText(value.projectId || value.workspaceId, `Work unit ${id} projectId`);
  if (!projectIds.has(projectId)) throw new TypeError(`Work unit ${id} references unknown project ${projectId}.`);
  const status = enumValue(value.status === "queued" ? "waiting" : value.status, PIPELINE_UNIT_STATUSES, `Work unit ${id} status`, "waiting");
  const policySource = value.policy && typeof value.policy === "object" ? value.policy : {};
  const policy = Object.freeze({
    ...policySource,
    required: Boolean(policySource.required ?? value.required),
    paused: Boolean(policySource.paused ?? status === "paused"),
    pinned: Boolean(policySource.pinned ?? value.pinned),
    stopAfter: Boolean(policySource.stopAfter ?? value.stopAfter),
    notifyOnComplete: Boolean(policySource.notifyOnComplete ?? value.notifyOnComplete),
    retry: enumValue(policySource.retry, PIPELINE_RETRY_POLICIES, `Work unit ${id} retry policy`, "explicit"),
    recovery: enumValue(policySource.recovery, PIPELINE_RECOVERY_POLICIES, `Work unit ${id} recovery policy`, "manual"),
    safeStopBoundary: enumValue(policySource.safeStopBoundary, PIPELINE_STOP_BOUNDARIES, `Work unit ${id} safe stop boundary`, "unit")
  });
  const gateSource = value.gate && typeof value.gate === "object" ? value.gate : {};
  const gate = Object.freeze({
    ...gateSource,
    state: enumValue(gateSource.state, PIPELINE_GATE_STATES, `Work unit ${id} gate state`, "not-required"),
    prompt: optionalText(gateSource.prompt),
    decisionId: optionalText(gateSource.decisionId),
    decidedAt: optionalText(gateSource.decidedAt)
  });
  const attempts = (value.attempts || []).map((attempt, attemptIndex) => normalizeAttempt(attempt, id, attemptIndex));
  unique(attempts, `Work unit ${id} attempt`);
  const children = (value.children || []).map((child, childIndex) => normalizeAtomicChild(child, id, childIndex));
  unique(children, `Work unit ${id} atomic work`);
  const attemptIds = new Set(attempts.map(({ id: attemptId }) => attemptId));
  const acceptedAttemptId = optionalText(value.acceptedAttemptId);
  const currentAttemptId = optionalText(value.currentAttemptId || value.claim?.attemptId);
  if (acceptedAttemptId && !attemptIds.has(acceptedAttemptId)) throw new TypeError(`Work unit ${id} acceptedAttemptId is unknown.`);
  if (currentAttemptId && !attemptIds.has(currentAttemptId)) throw new TypeError(`Work unit ${id} currentAttemptId is unknown.`);
  return Object.freeze({
    ...value,
    id,
    workUnitId: id,
    projectId,
    label: requiredText(value.label, `Work unit ${id} label`),
    detail: optionalText(value.detail),
    method: requiredText(value.method || value.action || "pipeline.work", `Work unit ${id} method`),
    provider: optionalText(value.provider) || "local",
    subject: optionalText(value.subject),
    sequence: Number.isFinite(Number(value.sequence)) ? Number(value.sequence) : index + 1,
    rank: Number.isFinite(Number(value.rank)) ? Number(value.rank) : index + 1,
    status,
    dependencyIds: Object.freeze([...(value.dependencyIds || [])].map((dependencyId) => requiredText(dependencyId, `Work unit ${id} dependency`))),
    attempts: Object.freeze(attempts),
    children: Object.freeze(children),
    acceptedAttemptId,
    currentAttemptId,
    inputSignature: optionalText(value.inputSignature),
    revision: Number(value.revision || 0),
    policy,
    gate
  });
}

export function definePipelineSnapshot(source = {}) {
  const value = plainObject(source, "Pipeline snapshot");
  const schema = requiredText(value.schema || value.protocolVersion, "Pipeline snapshot schema");
  if (schema !== PIPELINE_SNAPSHOT_SCHEMA) throw new TypeError(`Unsupported pipeline snapshot schema ${schema}.`);
  const projects = (value.projects || []).map(normalizeProject);
  unique(projects, "Project");
  const projectIds = new Set(projects.map(({ id }) => id));
  const units = (value.units || []).map((unit, index) => normalizeUnit(unit, index, projectIds));
  unique(units, "Work unit");
  const unitIds = new Set(units.map(({ id }) => id));
  for (const unit of units) for (const dependencyId of unit.dependencyIds) if (!unitIds.has(dependencyId)) throw new TypeError(`Work unit ${unit.id} dependency ${dependencyId} is unknown.`);
  const authoritative = units.filter(({ status, currentAttemptId }) => ["running", "stopping"].includes(status) && currentAttemptId);
  if (authoritative.length > 1) throw new TypeError("A pipeline snapshot may expose only one authoritative current attempt.");
  const progressSource = value.progress && typeof value.progress === "object" ? value.progress : {};
  const progress = Object.freeze({
    completed: Math.max(0, Number(progressSource.completed || 0)),
    total: Math.max(0, Number(progressSource.total || 0)),
    active: progressSource.active == null ? null : Math.max(0, Number(progressSource.active)),
    scope: optionalText(progressSource.scope),
    unit: optionalText(progressSource.unit),
    basis: optionalText(progressSource.basis),
    referenceAt: optionalText(progressSource.referenceAt)
  });
  if (progress.completed > progress.total) throw new TypeError("Pipeline progress completed cannot exceed total.");
  return Object.freeze({
    ...value,
    schema: PIPELINE_SNAPSHOT_SCHEMA,
    id: requiredText(value.id || value.runId, "Pipeline snapshot id"),
    runId: requiredText(value.runId || value.id, "Pipeline snapshot runId"),
    state: requiredText(value.state || "ready", "Pipeline snapshot state"),
    projects: Object.freeze(projects),
    units: Object.freeze(units),
    progress,
    controls: Object.freeze({ ...(value.controls || {}) }),
    completion: Object.freeze({ machine: value.completion?.machine || "incomplete", review: value.completion?.review || "incomplete" })
  });
}

export function pipelineSnapshotConformance(snapshotSource) {
  const snapshot = snapshotSource?.schema === PIPELINE_SNAPSHOT_SCHEMA && Object.isFrozen(snapshotSource) ? snapshotSource : definePipelineSnapshot(snapshotSource);
  const violations = [];
  const childIds = snapshot.units.flatMap(({ children }) => children.map(({ id }) => id));
  if (new Set(childIds).size !== childIds.length) violations.push("Atomic child ids must be unique across the snapshot.");
  const activeUnitCount = snapshot.units.reduce((count, unit) => count + (unit.children.length || (["complete", "cancelled", "superseded"].includes(unit.status) ? 0 : 1)), 0);
  const remaining = Math.max(0, snapshot.progress.total - snapshot.progress.completed);
  if (snapshot.progress.active != null && snapshot.progress.active !== activeUnitCount) {
    violations.push(`Progress active declares ${snapshot.progress.active}, but the snapshot exposes ${activeUnitCount} active atomic units.`);
  }
  if (snapshot.progress.scope === "current-run") {
    if (!snapshot.progress.unit) violations.push("Current-run progress must name its atomic unit.");
    if (remaining !== activeUnitCount) violations.push(`Current-run progress has ${remaining} remaining, but the snapshot exposes ${activeUnitCount} active atomic units.`);
    if (snapshot.units.some((unit) => unit.children.some((child) => ["complete", "cancelled", "superseded"].includes(child.status)))) {
      violations.push("Current-run child collections must contain active work only; completed history belongs in attempts or durable product history.");
    }
  }
  return Object.freeze({ conformant: violations.length === 0, violations: Object.freeze(violations), activeUnitCount, remaining });
}

export function assertPipelineSnapshotConformance(snapshotSource) {
  const result = pipelineSnapshotConformance(snapshotSource);
  if (!result.conformant) throw new TypeError(result.violations.join(" "));
  return result;
}

export function pipelineDispatchOrder(snapshotSource) {
  const snapshot = snapshotSource?.schema === PIPELINE_SNAPSHOT_SCHEMA && Object.isFrozen(snapshotSource) ? snapshotSource : definePipelineSnapshot(snapshotSource);
  const projects = new Map(snapshot.projects.map((project) => [project.id, project]));
  return snapshot.units.filter(({ status, policy, projectId, gate }) => status === "waiting" && !policy.paused && !["waiting", "rejected"].includes(gate.state) && !projects.get(projectId)?.deferred).sort((left, right) => {
    const leftProject = projects.get(left.projectId); const rightProject = projects.get(right.projectId);
    return Number(right.policy.pinned) - Number(left.policy.pinned)
      || Number(right.policy.required) - Number(left.policy.required)
      || priorityRank[leftProject.priority] - priorityRank[rightProject.priority]
      || left.rank - right.rank
      || left.sequence - right.sequence
      || left.id.localeCompare(right.id);
  });
}

export function pipelineControlIntent({ action, unitIds = [], expectedRevision = null } = {}) {
  const normalizedAction = requiredText(action, "Pipeline control action");
  const normalizedUnitIds = [...new Set(unitIds.map((id) => requiredText(id, "Pipeline control unit id")))];
  return Object.freeze({ schema: "inator.pipeline-control-intent.v1", action: normalizedAction, unitIds: Object.freeze(normalizedUnitIds), expectedRevision: expectedRevision == null ? null : Number(expectedRevision) });
}
