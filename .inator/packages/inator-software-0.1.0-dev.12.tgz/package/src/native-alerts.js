import { execFile as execFileCallback } from "node:child_process";
import { copyFile, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";

const execFile = promisify(execFileCallback);
const ALERT_APP_VERSION = "inator branded alert app v7";
const LAUNCH_SERVICES = "/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister";
const swiftSource = `import AppKit
import Foundation
import UserNotifications

let arguments = ProcessInfo.processInfo.arguments
guard arguments.count >= 4 else {
  FileHandle.standardError.write(Data("title, body, and receipt path are required\\n".utf8))
  exit(64)
}
let receiptURL = URL(fileURLWithPath: arguments[3])
func finish(_ receipt: String, code: Int32) {
  try? receipt.write(to: receiptURL, atomically: true, encoding: .utf8)
  exit(code)
}

_ = NSApplication.shared
NSApp.setActivationPolicy(.accessory)
let center = UNUserNotificationCenter.current()
let semaphore = DispatchSemaphore(value: 0)
var exitCode: Int32 = 1

center.requestAuthorization(options: [.alert, .sound]) { granted, authorizationError in
  guard authorizationError == nil, granted else {
    let detail = authorizationError?.localizedDescription ?? "System alerts are not allowed for this app."
    try? "authorization failed: \\(detail)".write(to: receiptURL, atomically: true, encoding: .utf8)
    semaphore.signal()
    return
  }
  let content = UNMutableNotificationContent()
  content.title = arguments[1]
  content.body = arguments[2]
  content.sound = .default
  let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: nil)
  center.add(request) { submissionError in
    if let submissionError {
      try? "notification submission failed: \\(submissionError.localizedDescription)".write(to: receiptURL, atomically: true, encoding: .utf8)
    } else {
      try? "submitted".write(to: receiptURL, atomically: true, encoding: .utf8)
      exitCode = 0
    }
    semaphore.signal()
  }
}

if semaphore.wait(timeout: .now() + 15) == .timedOut {
  try? "notification submission timed out".write(to: receiptURL, atomically: true, encoding: .utf8)
  exit(124)
}
exit(exitCode)
`;
const xmlEscape = value => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
const infoPlist = ({ productName, bundleIdentifier }) => `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleDevelopmentRegion</key><string>en</string>
  <key>CFBundleDisplayName</key><string>${xmlEscape(productName)}</string>
  <key>CFBundleExecutable</key><string>inator-alert</string>
  <key>CFBundleIconFile</key><string>inator-alert.icns</string>
  <key>CFBundleIdentifier</key><string>${xmlEscape(bundleIdentifier)}</string>
  <key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
  <key>CFBundleName</key><string>${xmlEscape(productName)}</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundleVersion</key><string>6</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>LSUIElement</key><true/>
</dict></plist>
`;
const ICON_VARIANTS = Object.freeze([
  [16, "icon_16x16.png"], [32, "icon_16x16@2x.png"],
  [32, "icon_32x32.png"], [64, "icon_32x32@2x.png"],
  [128, "icon_128x128.png"], [256, "icon_128x128@2x.png"],
  [256, "icon_256x256.png"], [512, "icon_256x256@2x.png"],
  [512, "icon_512x512.png"], [1024, "icon_512x512@2x.png"]
]);

export function createMacOSNotificationSender({ productName, bundleIdentifier, iconPath, artifactRoot, run = execFile } = {}) {
  if (!productName || !bundleIdentifier || !iconPath || !artifactRoot) throw new TypeError("A native alert sender requires productName, bundleIdentifier, iconPath, and artifactRoot.");
  const appPath = path.join(artifactRoot, `${productName} Alerts.app`);
  const preparedMarker = path.join(appPath, "Contents", ".inator-alert-ready");
  const preparedIdentity = `${ALERT_APP_VERSION}:${bundleIdentifier}`;
  const executablePath = path.join(appPath, "Contents", "MacOS", "inator-alert");
  let prepared = null;
  const prepare = async () => {
    if (process.platform !== "darwin") throw new Error("Native branded system alerts are only available on macOS.");
    const markerVersion = await readFile(preparedMarker, "utf8").then((value) => value.trim()).catch(() => null);
    if (markerVersion === preparedIdentity) return appPath;
    await mkdir(artifactRoot, { recursive: true });
    const iconset = path.join(artifactRoot, `${productName}.iconset`);
    const icns = path.join(artifactRoot, `${productName}.icns`);
    await run(LAUNCH_SERVICES, ["-u", appPath], { timeout: 5_000 }).catch(() => {});
    await rm(appPath, { recursive: true, force: true });
    await rm(iconset, { recursive: true, force: true });
    await rm(icns, { force: true });
    await mkdir(path.join(appPath, "Contents", "MacOS"), { recursive: true });
    await mkdir(path.join(appPath, "Contents", "Resources"), { recursive: true });
    const sourcePath = path.join(artifactRoot, `${productName}.alert-helper.swift`);
    await writeFile(sourcePath, swiftSource, { mode: 0o600 });
    await run("/usr/bin/swiftc", [sourcePath, "-framework", "AppKit", "-framework", "UserNotifications", "-o", executablePath], { timeout: 60_000 });
    await mkdir(iconset, { recursive: true });
    for (const [size, filename] of ICON_VARIANTS) await run("rsvg-convert", ["-w", String(size), "-h", String(size), iconPath, "-o", path.join(iconset, filename)], { timeout: 15_000 });
    await run("/usr/bin/iconutil", ["-c", "icns", iconset, "-o", icns], { timeout: 15_000 });
    await copyFile(icns, path.join(appPath, "Contents", "Resources", "inator-alert.icns"));
    const plist = path.join(appPath, "Contents", "Info.plist");
    await writeFile(plist, infoPlist({ productName, bundleIdentifier }), { mode: 0o600 });
    await writeFile(preparedMarker, `${preparedIdentity}\n`, { mode: 0o600 });
    await run("/usr/bin/codesign", ["--force", "--deep", "--sign", "-", appPath], { timeout: 15_000 });
    await run(LAUNCH_SERVICES, ["-f", appPath], { timeout: 5_000 });
    return appPath;
  };
  return {
    appPath,
    prepare: () => prepared ||= prepare(),
    async notify({ title = productName, body = "Status changed." } = {}) {
      await (prepared ||= prepare());
      const receiptPath = path.join(artifactRoot, `${productName}.alert-receipt-${process.pid}-${Date.now()}.txt`);
      await rm(receiptPath, { force: true });
      await run("/usr/bin/open", ["-n", "-W", appPath, "--args", String(title).slice(0, 120), String(body).slice(0, 500), receiptPath], { timeout: 25_000 });
      const receipt = await readFile(receiptPath, "utf8").then(value => value.trim()).catch(() => "missing submission receipt");
      await rm(receiptPath, { force: true });
      if (receipt !== "submitted") throw new Error(receipt);
      return { submitted: true, transport: "macos-branded-notification", sender: productName, bundleIdentifier };
    }
  };
}
