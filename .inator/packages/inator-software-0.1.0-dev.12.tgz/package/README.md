# @inator/software

Provider-neutral, stateful inventory contracts for locally available software.
Products supply observation and installation adapters; Commons owns normalized
identity, lifecycle state, retained failure evidence, and persistence semantics.

The package also owns `defineLocalRequirementsManifest()`: a declarative list of
native packages, commands, runtimes, Python packages, services, model providers,
models, and libraries required by each execution/publication profile. A public
reader can therefore declare a prepared artifact only, while the local workbench
declares Homebrew, Python, Ollama, and product-specific packages without either
surface inventing a new requirements schema.
