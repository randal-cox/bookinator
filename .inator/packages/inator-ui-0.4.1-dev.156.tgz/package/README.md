# @inator/ui

Framework-neutral shared Inator interface contracts.

The current executable standards cover action bars, structurally enforced list
collections, atomic dialogs and intake, product shells, roadmaps/releases,
resources, pipelines, Workspace capabilities, backup/restore, local
diagnostics, Workspace Errors, source lists, and compact table values.

Important composition points:

- createCollectionSurface plus createListView keeps actions and rows in one
  structural width contract.
- createDialogSurface creates dialog markup, movement, focus, and lifecycle
  together. Every direct createDialogController consumer must also load
  `@inator/ui/dialog.css`; importing that stylesheet without installing the
  controller is likewise nonconforming. Composite capability styles that open
  shared dialogs import it themselves.
- createWorkspaceCapabilityRegistry is the source for both
  workspaceUtilityFromCapabilities and createWorkspaceHost/router.
- Identity, Workspace backup/restore, and policy-gated Errors are shared
  capability views; product adapters retain persistence and domain semantics.
- formatCompactTimestamp/createCompactTimestamp own the stable table date/time
  grammar.
- selectedObject plus updateProductShellSelectionContext keeps active project
  or book names truthful in primary navigation.
- createPipelineNotificationCenter projects authoritative pipeline and machine
  pressure snapshots into one compact in-app signal rail and opt-in browser
  system alerts. Products supply snapshots; Commons owns transition semantics,
  severity, deduplication, and notification permission behavior.
- createAtomicPipelineWorkspace keeps diagnostic Provider and Policy columns off
  by default; products may request them with `defaultColumnVisibility` without
  redefining the shared pipeline table. Commons temporarily reveals and locks
  Policy while any row carries an active scheduling policy.
- createProductAboutContent plus createProductAboutPage supplies the standard
  About composition while leaving copy, special hero content, Trust claims,
  citations, and the explicit list of real governance records product-owned.
  Every consumer must pass `recordIds`, including an explicit empty array when
  it has no real governance destinations; omission is a contract error.
- defineProductInformationContract plus createStandardProductShellPolicy is the
  adoption path for the footer information architecture. It requires About,
  Help, Privacy, Security, Milestones, Releases, and Roadmap records, supplies
  the canonical labels and order, and rejects renaming or omission. Use the
  lower-level defineProductShellPolicy only for legacy migrations.

Version 0.3.0 is the first stable installable release. rho.inator and the
structurally different fboe.inator consumer prove the installation and upgrade
contract through pinned, repository-owned archives. Run `npm run check` before
consumer migration.
Privacy and Security are records, not parallel marketing pages. Define
product-owned facts with `defineProductPrivacy()` and `defineProductSecurity()`;
render them with `createProductPrivacyView()` and
`createProductSecurityView()`. Both contracts require stable IDs, explicit
implementation status, dated evidence references, and owned exceptions.
