import { INATOR_ICON_PATHS, createInatorIcon } from "./icons.js";

export const RESOURCE_CATALOG_SCHEMA = "inator.resources.v1";

export const RESOURCE_STATES = Object.freeze(["ready", "working", "planned", "retired"]);

const STATE_LABELS = Object.freeze({
  ready: "Ready",
  working: "In production",
  planned: "Planned",
  retired: "Retired"
});

function requiredText(value, field) {
  const text = String(value || "").trim();
  if (!text) throw new TypeError(`${field} is required`);
  return text;
}

function optionalText(value) {
  const text = String(value || "").trim();
  return text || "";
}

function isoDate(value, field) {
  const date = requiredText(value, field);
  const parsed = new Date(`${date}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== date) {
    throw new TypeError(`${field} must use a real YYYY-MM-DD date: ${date}`);
  }
  return date;
}

function normalizeAction(action, resourceId, index) {
  return Object.freeze({
    id: optionalText(action?.id) || `${resourceId}-action-${index + 1}`,
    label: requiredText(action?.label, `Action label for ${resourceId}`),
    href: requiredText(action?.href || action?.url, `Action URL for ${resourceId}`),
    primary: Boolean(action?.primary),
    download: Boolean(action?.download)
  });
}

function normalizeProduction(production, resourceId) {
  if (!production) return null;
  const method = production.method || "authored";
  if (!["authored", "generated", "mixed", "external"].includes(method)) {
    throw new TypeError(`Invalid production method for ${resourceId}: ${method}`);
  }
  return Object.freeze({
    method,
    source: optionalText(production.source),
    recipe: optionalText(production.recipe),
    output: optionalText(production.output)
  });
}

function normalizeResource(resource, index) {
  const id = requiredText(resource?.id, `Resource ${index + 1} id`);
  const state = resource.state || "ready";
  if (!RESOURCE_STATES.includes(state)) throw new TypeError(`Invalid resource state for ${id}: ${state}`);
  const actions = Object.freeze((resource.actions || []).map((action, actionIndex) => normalizeAction(action, id, actionIndex)));
  if (state === "ready" && actions.length === 0) throw new TypeError(`Ready resource ${id} requires at least one action`);
  const durationMinutes = resource.durationMinutes == null ? null : Number(resource.durationMinutes);
  if (durationMinutes !== null && (!Number.isFinite(durationMinutes) || durationMinutes <= 0)) {
    throw new TypeError(`Resource duration must be a positive number for ${id}`);
  }
  const roles = Object.freeze((resource.roles || [resource.role || "other"])
    .map((role) => requiredText(role, `Resource role for ${id}`)));
  const posterFit = optionalText(resource.posterFit) || "cover";
  if (!["cover", "contain"].includes(posterFit)) throw new TypeError(`Invalid poster fit for ${id}: ${posterFit}`);
  return Object.freeze({
    id,
    role: roles[0],
    roles,
    title: requiredText(resource.title, `Resource title for ${id}`),
    type: requiredText(resource.type, `Resource type for ${id}`),
    state,
    statusLabel: optionalText(resource.statusLabel || resource.status) || STATE_LABELS[state],
    description: requiredText(resource.description, `Resource description for ${id}`),
    date: resource.date ? isoDate(resource.date, `Resource date for ${id}`) : "",
    format: optionalText(resource.format),
    audience: optionalText(resource.audience),
    durationMinutes,
    tags: Object.freeze((resource.tags || []).map((tag) => requiredText(tag, `Tag for ${id}`))),
    posterUrl: optionalText(resource.posterUrl),
    posterFit,
    icon: optionalText(resource.icon),
    accent: optionalText(resource.accent),
    actions,
    production: normalizeProduction(resource.production, id)
  });
}

export function defineResourceCatalog(source = {}) {
  const ids = new Set();
  const resources = (source.resources || []).map((resource, index) => {
    const normalized = normalizeResource(resource, index);
    if (ids.has(normalized.id)) throw new TypeError(`Duplicate resource id: ${normalized.id}`);
    ids.add(normalized.id);
    return normalized;
  });
  return Object.freeze({
    schema: RESOURCE_CATALOG_SCHEMA,
    product: requiredText(source.product, "Resource catalog product"),
    updatedAt: isoDate(source.updatedAt, "Resource catalog update date"),
    resources: Object.freeze(resources)
  });
}

export function resourceFilterOptions(catalog) {
  const values = (field) => [...new Set(catalog.resources.map((resource) => resource[field]).filter(Boolean))].sort();
  return Object.freeze({ types: values("type"), states: values("state") });
}

export function filterResources(catalog, filters = {}) {
  const query = optionalText(filters.query).toLocaleLowerCase();
  const visible = catalog.resources.filter((resource) => {
    const haystack = [resource.title, resource.description, resource.type, resource.statusLabel, resource.format, resource.audience, ...resource.tags]
      .join(" ")
      .toLocaleLowerCase();
    return (!query || haystack.includes(query))
      && (!filters.type || resource.type === filters.type)
      && (!filters.state || resource.state === filters.state);
  });
  const sort = filters.sort || "date-desc";
  return [...visible].sort((left, right) => {
    if (sort === "title") return left.title.localeCompare(right.title);
    if (sort === "type") return left.type.localeCompare(right.type) || left.title.localeCompare(right.title);
    return (right.date || "").localeCompare(left.date || "") || left.title.localeCompare(right.title);
  });
}

export function resourceCoverage(catalog) {
  const readyRoles = new Set(catalog.resources
    .filter(({ state }) => state === "ready")
    .flatMap(({ role, roles }) => roles || [role]));
  return Object.freeze({
    overview: readyRoles.has("overview"),
    pitch: readyRoles.has("elevator-pitch"),
    talkOrVideo: readyRoles.has("talk") || readyRoles.has("video") || readyRoles.has("video-brief")
  });
}

export const RESOURCE_ACCESS_ROLES = Object.freeze(["team"]);

export function profileCanAccessResources(profile = {}) {
  const values = Array.isArray(profile) ? profile : profile.roles;
  const roles = new Set((Array.isArray(values) ? values : []).map((role) => String(role).trim()).filter(Boolean));
  return RESOURCE_ACCESS_ROLES.some((role) => roles.has(role));
}

export function resourceLibraryFooterLink(baseHref) {
  const base = String(baseHref || "/").replace(/\/?$/, "/");
  return { href: `${base}resources/`, route: "resources", label: "Resources" };
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function option(value, label) {
  const node = document.createElement("option");
  node.value = value;
  node.textContent = label;
  return node;
}

function visualFor(resource) {
  const visual = element("div", "inator-resource-visual");
  visual.dataset.type = resource.type.toLocaleLowerCase().replace(/[^a-z0-9]+/g, "-");
  if (resource.accent) visual.style.setProperty("--resource-accent", resource.accent);
  if (resource.posterUrl) {
    const image = document.createElement("img");
    image.src = resource.posterUrl;
    image.alt = "";
    visual.dataset.posterFit = resource.posterFit;
    visual.append(image);
  } else {
    const inferredIcon = resource.roles.includes("elevator-pitch")
      ? "elevator"
      : resource.roles.includes("talk") || /presentation|deck|slides?/iu.test(resource.type)
        ? "presentation"
        : resource.roles.includes("overview") || /brief|one.?pager|flyer/iu.test(resource.type)
          ? "flyer"
          : "reports";
    const icon = resource.icon || inferredIcon;
    if (!INATOR_ICON_PATHS[icon]) throw new TypeError(`Unknown resource icon: ${icon}`);
    visual.append(createInatorIcon(icon));
  }
  return visual;
}

function cardFor(resource) {
  const article = element("article", "inator-resource-card");
  article.dataset.state = resource.state;
  const content = element("div", "inator-resource-content");
  const heading = element("div", "inator-resource-heading");
  heading.append(element("span", "inator-resource-type", resource.type), element("span", "inator-resource-status", resource.statusLabel));
  content.append(heading, element("h2", "", resource.title));

  const facts = [resource.date, resource.format, resource.durationMinutes ? `${resource.durationMinutes} min` : ""].filter(Boolean);
  if (facts.length) content.append(element("p", "inator-resource-facts", facts.join(" · ")));
  content.append(element("p", "inator-resource-description", resource.description));
  if (resource.audience) {
    const audience = element("p", "inator-resource-audience");
    audience.append(element("strong", "", "Audience"), document.createTextNode(` ${resource.audience}`));
    content.append(audience);
  }
  if (resource.tags.length) {
    const tags = element("div", "inator-resource-tags");
    resource.tags.forEach((tag) => tags.append(element("span", "", tag)));
    content.append(tags);
  }
  if (resource.production?.source || resource.production?.recipe) {
    const production = element("p", "inator-resource-production");
    production.append(element("span", "", "↻"), document.createTextNode(resource.production.recipe ? " Rebuild recipe recorded" : " Source retained"));
    content.append(production);
  }

  const actions = element("nav", "inator-resource-actions");
  actions.setAttribute("aria-label", `${resource.title} actions`);
  resource.actions.forEach((action) => {
    const link = element("a", action.primary ? "primary" : "", action.label);
    link.href = action.href;
    if (action.download) link.download = "";
    actions.append(link);
  });
  if (!resource.actions.length) actions.append(element("span", "inator-resource-unavailable", "Not yet available"));
  article.append(visualFor(resource), content, actions);
  return article;
}

export function createResourceLibrary({ mount, catalog, initialFilters = {} } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("A resource-library mount element is required");
  if (!catalog?.resources) throw new TypeError("A normalized resource catalog is required");

  const options = resourceFilterOptions(catalog);
  const state = { query: "", type: "", state: "", sort: "date-desc", ...initialFilters };
  const controls = element("section", "inator-resource-controls");
  controls.setAttribute("aria-label", "Resource filters");

  const searchLabel = element("label", "inator-resource-search");
  searchLabel.append(element("span", "", "Search"));
  const search = document.createElement("input");
  search.type = "search";
  search.placeholder = "Titles, audiences, subjects, and formats";
  search.value = state.query;
  searchLabel.append(search);

  const selectControl = (label, entries, value) => {
    const wrapper = element("label");
    wrapper.append(element("span", "", label));
    const select = document.createElement("select");
    entries.forEach(([entryValue, entryLabel]) => select.append(option(entryValue, entryLabel)));
    select.value = value;
    wrapper.append(select);
    return { wrapper, select };
  };
  const type = selectControl("Type", [["", "All types"], ...options.types.map((value) => [value, value])], state.type);
  const status = selectControl("Status", [["", "All states"], ...RESOURCE_STATES.filter((value) => options.states.includes(value)).map((value) => [value, STATE_LABELS[value]])], state.state);
  const sort = selectControl("Sort", [["date-desc", "Newest"], ["title", "Title"], ["type", "Type"]], state.sort);
  controls.append(searchLabel, type.wrapper, status.wrapper, sort.wrapper);

  const summary = element("div", "inator-resource-summary");
  const count = element("span");
  const clear = element("button", "", "Clear filters");
  clear.type = "button";
  summary.append(count, clear);
  const list = element("section", "inator-resource-list");
  list.setAttribute("aria-live", "polite");

  const render = () => {
    const resources = filterResources(catalog, state);
    count.textContent = `${resources.length} of ${catalog.resources.length} resources`;
    clear.hidden = !state.query && !state.type && !state.state && state.sort === "date-desc";
    list.replaceChildren(...resources.map(cardFor));
    if (!resources.length) list.append(element("p", "inator-resource-empty", "No resources match these filters."));
    return resources;
  };

  search.addEventListener("input", () => { state.query = search.value; render(); });
  type.select.addEventListener("input", () => { state.type = type.select.value; render(); });
  status.select.addEventListener("input", () => { state.state = status.select.value; render(); });
  sort.select.addEventListener("input", () => { state.sort = sort.select.value; render(); });
  clear.addEventListener("click", () => {
    Object.assign(state, { query: "", type: "", state: "", sort: "date-desc" });
    search.value = "";
    type.select.value = "";
    status.select.value = "";
    sort.select.value = "date-desc";
    render();
    search.focus();
  });
  mount.className = "inator-resource-library";
  mount.replaceChildren(controls, summary, list);
  render();
  return Object.freeze({ render, filters: state, controls: Object.freeze({ search, type: type.select, status: status.select, sort: sort.select }) });
}

export function createProductResourcePage({ root, catalog, productLabel = "Inator", heading = "Resources", introduction = "Maintained material for explaining and sharing this product.", initialFilters = {} } = {}) {
  if (!(root instanceof HTMLElement)) throw new TypeError("A product resource-page root element is required");
  if (!catalog?.resources) throw new TypeError("A normalized resource catalog is required");
  root.classList.add("inator-information-page", "inator-resource-page");
  const header = element("header", "inator-resource-page__heading");
  header.append(
    element("p", "", `${requiredText(productLabel, "Resource product label")} resources`),
    element("h1", "", requiredText(heading, "Resource heading")),
    element("span", "", requiredText(introduction, "Resource introduction"))
  );
  const libraryMount = element("div", "inator-resource-page__library");
  root.replaceChildren(header, libraryMount);
  const library = createResourceLibrary({ mount: libraryMount, catalog, initialFilters });
  return Object.freeze({ catalog, library });
}
