function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
}

function normalizedTests(tests = []) {
  return tests.map((test, index) => ({
    id: String(test.id || `tester-${index + 1}`),
    label: String(test.label || "Run test"),
    description: String(test.description || "Run this diagnostic check."),
    actionLabel: String(test.actionLabel || "Run test"),
    onRun: typeof test.onRun === "function" ? test.onRun : null
  }));
}

export const STANDARD_WORKSPACE_TESTER_DEFINITIONS = Object.freeze([
  Object.freeze({ id: "commons-shell", label: "Commons shell", description: "Verify that the shared product header, navigation, and footer are mounted." }),
  Object.freeze({ id: "local-storage", label: "Local persistence", description: "Verify that this browser can write, read, and remove product-local state." })
]);

export function createStandardWorkspaceTesters({ documentRef = globalThis.document, storage = globalThis.localStorage } = {}) {
  return STANDARD_WORKSPACE_TESTER_DEFINITIONS.map((definition) => ({ ...definition,
    onRun: definition.id === "commons-shell" ? async () => {
      if (!documentRef.querySelector("[data-inator-product-header] nav") || !documentRef.querySelector("[data-inator-product-footer]")) throw new Error("The Commons product shell is not fully mounted.");
    } : async () => {
      const key = "inator.commons.tester.persistence"; const value = String(Date.now());
      storage.setItem(key, value);
      if (storage.getItem(key) !== value) throw new Error("Local persistence did not return the value that was written.");
      storage.removeItem(key);
    }
  }));
}

export function composeWorkspaceTesters(productTests = [], options = {}) {
  const tests = [...createStandardWorkspaceTesters(options), ...normalizedTests(productTests)];
  const ids = new Set();
  for (const test of tests) { if (ids.has(test.id)) throw new TypeError(`Duplicate Workspace tester id: ${test.id}.`); ids.add(test.id); }
  return tests;
}

export function createWorkspaceTestersView({ mount, tests = [] } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createWorkspaceTestersView requires a DOM mount element.");
  const section = element("section", "inator-workspace-testers");
  const header = element("header", "inator-workspace-testers__header");
  header.append(
    element("h2", "", "Testers"),
    element("p", "", "Developer-only checks for shared controls and product integrations. These do not appear in ordinary operational surfaces.")
  );
  const list = element("div", "inator-workspace-testers__list");
  for (const test of normalizedTests(tests)) {
    const item = element("article", "inator-workspace-testers__item");
    const copy = element("div", "inator-workspace-testers__copy");
    copy.append(element("h3", "", test.label), element("p", "", test.description));
    const status = element("p", "inator-workspace-testers__status");
    status.setAttribute("role", "status");
    status.setAttribute("aria-live", "polite");
    const button = element("button", "inator-workspace-testers__run", test.actionLabel);
    button.type = "button";
    button.disabled = !test.onRun;
    button.addEventListener("click", async () => {
      button.disabled = true;
      status.dataset.tone = "active";
      status.textContent = "Running…";
      try {
        await test.onRun?.();
        status.dataset.tone = "success";
        status.textContent = "Test completed.";
      } catch (error) {
        status.dataset.tone = "error";
        status.textContent = error?.message || "The test failed.";
      } finally {
        button.disabled = !test.onRun;
      }
    });
    item.append(copy, button, status);
    list.append(item);
  }
  if (!list.childElementCount) list.append(element("p", "inator-workspace-testers__empty", "This product has not registered any testers."));
  section.append(header, list);
  mount.replaceChildren(section);
  return { destroy() { mount.replaceChildren(); } };
}

export function testersWorkspaceCapability({ tests = [], includeStandard = true, ...options } = {}) {
  const composedTests = includeStandard ? composeWorkspaceTesters(tests) : normalizedTests(tests);
  return {
    id: "testers",
    label: "Testers",
    detail: `${composedTests.length} developer ${composedTests.length === 1 ? "test" : "tests"}`,
    icon: "inspect",
    route: "workspace-testers",
    href: "/workspace/testers/",
    order: 900,
    requiredRoles: ["developer"],
    createView: ({ mount }) => createWorkspaceTestersView({ mount, tests: composedTests }),
    ...options
  };
}
