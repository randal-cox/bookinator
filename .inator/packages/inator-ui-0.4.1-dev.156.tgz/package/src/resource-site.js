import { createResourceLibrary } from "./resources.js";

function requiredText(value, field) {
  const text = String(value || "").trim();
  if (!text) throw new TypeError(field + " is required");
  return text;
}

function destinationLink(destination) {
  const link = document.createElement("a");
  link.className = "inator-resource-destination";
  link.dataset.tone = destination.tone || "quiet";
  link.href = requiredText(destination.href, "Resource destination URL");
  if (destination.current) link.setAttribute("aria-current", "page");
  const icon = document.createElement("span");
  icon.className = "inator-resource-destination__icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = String(destination.icon || destination.label || "↗").trim().slice(0, 1);
  const copy = document.createElement("span");
  const kicker = document.createElement("small");
  kicker.textContent = String(destination.kicker || "Open").trim();
  const label = document.createElement("strong");
  label.textContent = requiredText(destination.label, "Resource destination label");
  copy.append(kicker, label);
  link.append(icon, copy);
  return link;
}

export function createResourceSite({ mount, catalog, brand = {}, destinations = [], lede = "" } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("A resource-site mount element is required");
  if (!catalog?.resources) throw new TypeError("A normalized resource catalog is required");
  const header = document.createElement("header");
  header.className = "inator-resource-site-header";
  const top = document.createElement("div");
  top.className = "inator-resource-site-header__top";
  const identity = document.createElement("a");
  identity.className = "inator-resource-site-brand";
  identity.href = requiredText(brand.href || "/", "Resource brand URL");
  if (brand.image?.src) {
    const image = document.createElement("img");
    image.src = brand.image.src;
    image.alt = brand.image.alt || "";
    image.width = brand.image.width || 64;
    image.height = brand.image.height || 64;
    identity.append(image);
  }
  const title = document.createElement("span");
  title.className = "inator-resource-site-title";
  const name = document.createElement("strong");
  name.textContent = brand.label || catalog.product;
  const detail = document.createElement("small");
  detail.textContent = brand.detail || "Resources";
  title.append(name, detail);
  identity.append(title);
  const nav = document.createElement("nav");
  nav.className = "inator-resource-destinations";
  nav.setAttribute("aria-label", catalog.product + " destinations");
  destinations.forEach((destination) => nav.append(destinationLink(destination)));
  top.append(identity, nav);
  header.append(top);
  if (lede) {
    const description = document.createElement("p");
    description.className = "inator-resource-site-lede";
    description.textContent = lede;
    header.append(description);
  }
  const libraryMount = document.createElement("div");
  libraryMount.className = "inator-resource-site-library";
  mount.className = "inator-resource-site";
  mount.replaceChildren(header, libraryMount);
  const library = createResourceLibrary({ mount: libraryMount, catalog });
  return Object.freeze({ library, header, destinations: nav });
}
