import { setInatorTooltip } from "./tooltip.js";

function filesFrom(value) {
  return Array.from(value ?? []).filter(Boolean);
}

export function installFileIntake(target, {
  accept = "",
  multiple = true,
  onFiles,
  onError = (error) => console.error(error),
  title = "Choose files or drop them here"
} = {}) {
  if (!target?.addEventListener) throw new TypeError("A file-intake target is required.");
  if (typeof onFiles !== "function") throw new TypeError("File intake requires an onFiles callback.");

  const input = document.createElement("input");
  input.type = "file";
  input.multiple = Boolean(multiple);
  input.accept = accept;
  input.hidden = true;
  input.tabIndex = -1;
  input.setAttribute("aria-hidden", "true");
  document.body.append(input);

  const listeners = [];
  const listen = (element, type, handler) => {
    element.addEventListener(type, handler);
    listeners.push(() => element.removeEventListener(type, handler));
  };

  const acceptFiles = async (value) => {
    const received = filesFrom(value);
    const files = multiple ? received : received.slice(0, 1);
    if (!files.length) return [];
    target.setAttribute("aria-busy", "true");
    try {
      await onFiles(files);
      return files;
    } finally {
      target.removeAttribute("aria-busy");
      input.value = "";
    }
  };
  const safelyAccept = (value) => {
    acceptFiles(value).catch(onError);
  };

  target.classList.add("inator-tool-button--intake");
  if (!target.dataset.inatorTooltip) setInatorTooltip(target, title);
  listen(target, "click", () => input.click());
  listen(input, "change", () => safelyAccept(input.files));
  for (const type of ["dragenter", "dragover"]) {
    listen(target, type, (event) => {
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = "copy";
      target.classList.add("is-dragover");
    });
  }
  for (const type of ["dragleave", "drop"]) {
    listen(target, type, (event) => {
      event.preventDefault();
      target.classList.remove("is-dragover");
      if (type === "drop") safelyAccept(event.dataTransfer?.files);
    });
  }

  return {
    input,
    acceptFiles,
    destroy() {
      listeners.splice(0).forEach((remove) => remove());
      target.classList.remove("inator-tool-button--intake", "is-dragover");
      target.removeAttribute("aria-busy");
      input.remove();
    }
  };
}
