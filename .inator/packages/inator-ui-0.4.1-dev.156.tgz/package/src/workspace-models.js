import { createWorkspaceDisclosureGroup } from "./workspace-disclosure.js";
import { createNavigationTabs } from "./tabs.js";

const element = (tag, className = "", text = null) => { const node = document.createElement(tag); if (className) node.className = className; if (text != null) node.textContent = String(text); return node; };
const size = bytes => bytes ? `${(bytes / 2 ** 30).toFixed(1)} GB` : "Size unknown";
const time = value => { const date = new Date(value); return Number.isNaN(date.valueOf()) ? "Unknown" : new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date); };

function systemTabs(active, navigation = {}) {
  return createNavigationTabs({ activeId: active, label: "Local system views", className: "inator-system-tabs", items: [["machine", "Machine"], ["models", "Models"]].map(([id, label]) => ({ id, label, href: navigation[id] || `/workspace/${id}/` })) });
}
function action(label, kind, payload, onAction, disabled = false, danger = false) {
  const button = element("button", `inator-system-action${danger ? " inator-system-action--danger" : ""}`, label); button.type = "button"; button.disabled = disabled; button.dataset.action = kind; button.addEventListener("click", () => onAction?.({ action: kind, ...payload })); return button;
}
export function createWorkspaceModelsView({ mount, model, navigation, onRefresh, onAction, reportStatus } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("Models view requires a mount.");
  const render = value => {
    const busy = ["running", "loading", "draining", "cancel-requested"].includes(value.queue?.state); const operations = new Set(value.provider.operations || []);
    reportStatus?.({ label: value.provider.running ? "Ready" : "Needs attention", tone: value.provider.running ? "success" : "warning" });
    const page = element("section", "inator-system-surface"); const header = element("header", "inator-system-header"); const heading = element("div", "inator-system-heading");
    heading.append(element("p", "plain-kicker", "Local computation"), element("h1", "", "Models"), element("p", "", "Local readers, specialists, and their assignments."));
    const summary = element("div", "inator-system-summary"); const providerReady = value.provider.running && value.provider.apiReachable; summary.dataset.status = providerReady ? "ready" : "warning";
    summary.append(element("b", "inator-system-summary__mark", providerReady ? "✓" : "!"), element("strong", "", providerReady ? `${value.provider.providerId} is ready` : `${value.provider.providerId} needs attention`), element("small", "", `Version ${value.provider.providerVersion}`));
    const refresh = action("Refresh", "refresh", {}, async () => update(await onRefresh?.())); refresh.classList.add("inator-system-refresh"); summary.append(refresh); header.append(heading, summary);
    const meta = element("p", "inator-system-meta", `Inventory checked ${time(value.provider.checkedAt)}${value.provider.diagnostic ? ` · ${value.provider.diagnostic}` : ""}`);
    const body = element("div", "inator-system-groups"); const queue = element("div", `inator-model-queue${busy ? " running" : ""}`, value.queue?.label || value.queue?.state || "No model work is active."); queue.setAttribute("role", "status"); queue.setAttribute("aria-live", "polite"); body.append(queue);
    const healthChecks = element("div", "inator-provider-health");
    const providerLabel = value.provider.label || ({ ollama: "Ollama" }[value.provider.providerId] || value.provider.providerId || "Model provider");
    const providerStates = [["Installed", value.provider.installed], ["Running", value.provider.running], ["API reachable", value.provider.apiReachable], ...(value.provider.inferenceVerified == null ? [] : [["Recent inference verified", value.provider.inferenceVerified]])];
    for (const [label, state] of providerStates) { const fact = element("div", "inator-provider-fact"); fact.dataset.status = state == null ? "unknown" : state ? "ready" : "warning"; fact.append(element("b", "", state == null ? "?" : state ? "✓" : "!"), element("span", "", label), element("strong", "", state == null ? "Not checked" : state ? "Yes" : "No")); healthChecks.append(fact); }
    const providerWarnings = providerStates.filter(([, state]) => state === false).length;
    const providerUnknown = providerStates.filter(([, state]) => state == null).length;
    const providerReadyCount = providerStates.filter(([, state]) => state === true).length;
    const providerHealthSummary = [providerWarnings ? `${providerWarnings} need attention` : null, providerReadyCount ? `${providerReadyCount} ready` : null, providerUnknown ? `${providerUnknown} not checked` : null].filter(Boolean).join(" · ");
    body.append(createWorkspaceDisclosureGroup({ id: "provider-health", namespace: "models", title: `${providerLabel} health`, summary: providerHealthSummary, statuses: providerStates.map(([, state]) => state == null ? "unknown" : state ? "ready" : "warning"), content: healthChecks }));
    if (value.components?.length) {
      const specialistGrid = element("div", "inator-specialist-grid");
      for (const component of value.components) { const item = element("article", "inator-specialist"); item.dataset.status = component.status || "unknown"; item.append(element("b", "", component.status === "ready" ? "✓" : "!"), element("strong", "", component.label), element("span", "", component.value || component.modelId || "Unknown"), element("p", "", component.detail || "No status detail is available.")); specialistGrid.append(item); }
      body.append(createWorkspaceDisclosureGroup({ id: "local-specialists", namespace: "models", title: "Local specialists", summary: `${value.components.length} configured`, statuses: value.components.map(component => component.status || "unknown"), content: specialistGrid }));
    }
    const roleGrid = element("div", "inator-model-grid");
    for (const role of value.roles) { const row = element("article", "inator-model-role"); const copy = element("div"); copy.append(element("strong", "", role.label), element("p", "", role.purpose || "Product-defined model role"), element("small", "", `Needs ${role.requiredCapabilities.join(", ") || "product-defined capabilities"}`)); const select = document.createElement("select"); select.setAttribute("aria-label", `Assign ${role.label}`); select.append(new Option("Not assigned", "")); for (const id of role.compatibleModelIds) select.append(new Option(id, id)); select.value = role.assignedModelId || ""; select.disabled = busy; select.addEventListener("change", () => onAction?.({ action: "assign-role", roleId: role.id, modelId: select.value, scope: "default" })); row.append(copy, select); roleGrid.append(row); }
    body.append(createWorkspaceDisclosureGroup({ id: "product-roles", namespace: "models", title: "Product roles", summary: `${value.roles.length} ${value.roles.length === 1 ? "role" : "roles"}`, statuses: value.roles.map(role => role.assignedModelId ? "ready" : "warning"), content: roleGrid }));
    const catalogList = element("div", "inator-model-list");
    for (const item of value.catalog) { const row = element("article", "inator-model-option"); const copy = element("div"); copy.append(element("strong", "", item.label || item.modelId), element("span", "", item.modelId || item.id), element("p", "", item.purpose || item.description || "Product recommendation"), element("small", "", `${size(item.sizeBytes)} · approval required`)); const controls = element("div", "inator-system-actions"); controls.append(action("Inspect", "inspect-model", { modelId: item.modelId || item.id }, onAction), action(item.installed ? "Installed" : "Install", "plan-install", { modelId: item.modelId || item.id }, onAction, busy || !operations.has("install") || item.installed)); row.append(copy, controls); catalogList.append(row); }
    if (!value.catalog.length) catalogList.append(element("p", "inator-system-empty", "No product catalog recommendations are configured.")); body.append(createWorkspaceDisclosureGroup({ id: "recommended-catalog", namespace: "models", title: "Recommended model catalog", summary: `${value.catalog.length} ${value.catalog.length === 1 ? "model" : "models"}`, status: value.catalog.length ? "ready" : "warning", content: catalogList, open: false }));
    const inventoryList = element("div", "inator-model-list");
    for (const item of value.inventory) { const row = element("article", "inator-model-option"); const copy = element("div"); copy.append(element("strong", "", item.label || item.modelId), element("span", "", item.modelId), element("p", "", [item.loaded ? "Resident in memory" : "Installed, not loaded", item.families.join(", "), item.parameters, item.quantization, item.contextTokens ? `${item.contextTokens} context` : null, size(item.sizeBytes)].filter(Boolean).join(" · ")), element("small", "", item.digest || item.revision || "Revision unavailable")); const controls = element("div", "inator-system-actions"); controls.append(action("Inspect", "inspect-model", { modelId: item.modelId }, onAction), action(item.loaded ? "Unload" : "Uninstall", item.loaded ? "plan-unload" : "plan-remove", { modelId: item.modelId }, onAction, busy || !operations.has(item.loaded ? "unload" : "remove"), !item.loaded)); row.append(copy, controls); inventoryList.append(row); }
    if (!value.inventory.length) inventoryList.append(element("p", "inator-system-empty", "No models are installed. Review the catalog before planning an install.")); body.append(createWorkspaceDisclosureGroup({ id: "installed-models", namespace: "models", title: "Installed Ollama models", summary: `${value.inventory.length} installed`, status: value.inventory.length ? "ready" : "warning", content: inventoryList, open: false }));
    page.append(header, meta, body); mount.replaceChildren(systemTabs("models", navigation), page);
  };
  const update = next => { if (next) model = next; render(model); }; render(model); return { update, destroy() { mount.replaceChildren(); } };
}

export function modelsWorkspaceCapability(options = {}) { return { id: "models", label: "Models", detail: "Providers, roles, and installed models", icon: "models", route: "workspace-models", href: "/workspace/models/", order: 230, menu: { id: "local-system", label: "Local system", detail: "Machine, software, and models", icon: "machine", href: "/workspace/machine/", route: "workspace-machine" }, createView: ({ mount, adapter }) => createWorkspaceModelsView({ mount, ...adapter }), ...options }; }
