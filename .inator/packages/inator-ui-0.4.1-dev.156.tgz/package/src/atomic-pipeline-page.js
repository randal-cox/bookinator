import { createAtomicPipelineWorkspace } from "./atomic-pipeline-workspace.js";
import { createPageIntro } from "./page-intro.js";

export const ATOMIC_PIPELINE_PAGE_TITLE = "Pipeline";
export const ATOMIC_PIPELINE_PAGE_DESCRIPTION = "One durable activity per unit of work. Projects coordinate policy, priority, throttling, and recovery without collapsing independently settled tasks.";

function countStatus(units, statuses) {
  const accepted = new Set(statuses);
  return units.filter(unit => accepted.has(unit.status)).length;
}

export function atomicPipelinePageSummary(snapshot = {}) {
  const units = Array.isArray(snapshot.units) ? snapshot.units : [];
  const waiting = countStatus(units, ["waiting"]);
  const running = countStatus(units, ["running", "retrying"]);
  const complete = countStatus(units, ["complete"]);
  const attention = countStatus(units, ["blocked", "failed", "paused", "stalled"]);
  return `${waiting.toLocaleString()} queued · ${running.toLocaleString()} running · ${complete.toLocaleString()} complete · ${attention.toLocaleString()} need attention`;
}

export function createAtomicPipelinePage({ mount, snapshot, ...workspaceOptions } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createAtomicPipelinePage requires a DOM mount element.");
  const page = document.createElement("section");
  page.className = "inator-atomic-pipeline-page";
  const intro = createPageIntro({ title: ATOMIC_PIPELINE_PAGE_TITLE, description: ATOMIC_PIPELINE_PAGE_DESCRIPTION, summary: atomicPipelinePageSummary(snapshot), className: "inator-atomic-pipeline-page__intro" });
  const summary = intro.summary;
  const renderSummary = current => { summary.textContent = atomicPipelinePageSummary(current); };
  renderSummary(snapshot);
  const progressMount = document.createElement("div");
  const queueMount = document.createElement("div");
  page.append(intro.element, progressMount, queueMount);
  mount.replaceChildren(page);
  const requestedStatus = new URLSearchParams(globalThis.location?.search || "").get("status");
  const attentionStatus = requestedStatus || null;
  const workspace = createAtomicPipelineWorkspace({
    ...workspaceOptions,
    initialFilters: attentionStatus ? { ...(workspaceOptions.initialFilters || {}), status: [attentionStatus] } : workspaceOptions.initialFilters,
    snapshot,
    progressMount,
    queueMount
  });
  return {
    page,
    update(nextSnapshot) {
      renderSummary(nextSnapshot);
      workspace.update(nextSnapshot);
    },
    destroy() {
      workspace.destroy?.();
      page.remove();
    }
  };
}
