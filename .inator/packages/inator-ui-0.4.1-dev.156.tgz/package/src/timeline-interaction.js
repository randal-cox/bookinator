function finite(value, label) {
  const number = Number(value);
  if (!Number.isFinite(number)) throw new TypeError(`${label} must be finite.`);
  return number;
}

export function timelineSelectionRange({ domainStart, domainEnd, selectionStart, selectionEnd, plotStart = 0, plotEnd = 1 } = {}) {
  const domainFrom = new Date(domainStart).getTime();
  const domainTo = new Date(domainEnd).getTime();
  const plotFrom = finite(plotStart, "plotStart");
  const plotTo = finite(plotEnd, "plotEnd");
  if (!Number.isFinite(domainFrom) || !Number.isFinite(domainTo) || domainTo <= domainFrom) throw new TypeError("Timeline domain must have an increasing start and end.");
  if (plotTo <= plotFrom) throw new TypeError("Timeline plot must have an increasing start and end.");
  const clamp = value => Math.max(plotFrom, Math.min(plotTo, finite(value, "selection position")));
  const left = Math.min(clamp(selectionStart), clamp(selectionEnd));
  const right = Math.max(clamp(selectionStart), clamp(selectionEnd));
  const at = position => new Date(domainFrom + (position - plotFrom) / (plotTo - plotFrom) * (domainTo - domainFrom));
  return Object.freeze({ start: at(left), end: at(right) });
}

export function installTimelineBrush({ svg, domainStart, domainEnd, plotStart = 20, plotEnd = 980, plotTop = 5, plotBottom = 60, minimumDragPixels = 7, onZoom, onReset } = {}) {
  if (!svg?.addEventListener || svg.namespaceURI !== "http://www.w3.org/2000/svg") throw new TypeError("Timeline brush requires an SVG element.");
  const selection = document.createElementNS(svg.namespaceURI, "rect");
  selection.setAttribute("class", "inator-timeline-brush-selection");
  selection.setAttribute("y", String(plotTop));
  selection.setAttribute("height", String(plotBottom - plotTop));
  selection.hidden = true;
  svg.append(selection);
  svg.classList.add("inator-timeline-brush");

  let origin = null;
  const plotPosition = clientX => {
    const bounds = svg.getBoundingClientRect();
    return Math.max(plotStart, Math.min(plotEnd, plotStart + (clientX - bounds.left) / Math.max(1, bounds.width) * (plotEnd - plotStart)));
  };
  const clear = () => { origin = null; selection.hidden = true; selection.removeAttribute("width"); };
  const pointerDown = event => {
    if (event.button !== 0) return;
    origin = plotPosition(event.clientX);
    selection.setAttribute("x", String(origin)); selection.setAttribute("width", "0"); selection.hidden = false;
    svg.setPointerCapture?.(event.pointerId);
  };
  const pointerMove = event => {
    if (origin == null) return;
    const current = plotPosition(event.clientX);
    selection.setAttribute("x", String(Math.min(origin, current)));
    selection.setAttribute("width", String(Math.abs(current - origin)));
  };
  const pointerUp = event => {
    if (origin == null) return;
    const finish = plotPosition(event.clientX);
    const pixels = Math.abs(finish - origin) / (plotEnd - plotStart) * svg.getBoundingClientRect().width;
    const start = origin;
    clear();
    if (pixels < minimumDragPixels) return;
    event.preventDefault();
    onZoom?.(timelineSelectionRange({ domainStart, domainEnd, selectionStart: start, selectionEnd: finish, plotStart, plotEnd }));
  };
  const doubleClick = event => { event.preventDefault(); clear(); onReset?.(); };
  svg.addEventListener("pointerdown", pointerDown);
  svg.addEventListener("pointermove", pointerMove);
  svg.addEventListener("pointerup", pointerUp);
  svg.addEventListener("pointercancel", clear);
  svg.addEventListener("dblclick", doubleClick);
  return { destroy() { clear(); selection.remove(); svg.classList.remove("inator-timeline-brush"); svg.removeEventListener("pointerdown", pointerDown); svg.removeEventListener("pointermove", pointerMove); svg.removeEventListener("pointerup", pointerUp); svg.removeEventListener("pointercancel", clear); svg.removeEventListener("dblclick", doubleClick); } };
}
