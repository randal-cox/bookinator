let sequence = 0;

function normalizedSections(sections) {
  return (sections || []).map(section => ({
    id: String(section?.id || "").trim(),
    label: String(section?.label || "").trim(),
    content: String(section?.content || "").trim()
  })).filter(section => section.id && section.label && section.content);
}

/**
 * Attach a substantial, interactive preview to an existing trigger.
 * Use setInatorTooltip for short passive explanations; preview cards are for
 * content that needs reading, tabs, scrolling, or interaction.
 */
export function createPreviewCard({ trigger, label, sections, preferenceKey = null, openDelay = 0, closeDelay = 120 } = {}) {
  if (!(trigger instanceof HTMLElement)) throw new TypeError("An Inator preview card requires a trigger element.");
  const choices = normalizedSections(sections);
  if (!choices.length) throw new TypeError("An Inator preview card requires at least one labelled content section.");

  const card = document.createElement("span");
  card.className = "inator-preview-card";
  card.id = `inator-preview-card-${++sequence}`;
  card.setAttribute("popover", "manual");
  card.setAttribute("role", "group");
  card.setAttribute("aria-label", String(label || "Preview"));
  trigger.setAttribute("aria-describedby", card.id);

  const tabs = document.createElement("span");
  tabs.className = "inator-preview-card__tabs";
  tabs.setAttribute("aria-label", "Preview detail");
  const content = document.createElement("span");
  content.className = "inator-preview-card__content";
  let selected = preferenceKey ? localStorage.getItem(preferenceKey) : null;
  if (!choices.some(section => section.id === selected)) selected = choices[0].id;

  const select = id => {
    selected = choices.some(section => section.id === id) ? id : choices[0].id;
    if (preferenceKey) localStorage.setItem(preferenceKey, selected);
    content.textContent = choices.find(section => section.id === selected).content;
    for (const button of tabs.querySelectorAll("button")) button.setAttribute("aria-pressed", String(button.dataset.previewSection === selected));
  };
  if (choices.length > 1) for (const section of choices) {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = section.label;
    button.dataset.previewSection = section.id;
    button.addEventListener("click", event => { event.preventDefault(); event.stopPropagation(); select(section.id); });
    tabs.append(button);
  }

  let openTimer = null;
  let closeTimer = null;
  const open = () => {
    clearTimeout(closeTimer);
    clearTimeout(openTimer);
    openTimer = setTimeout(() => {
      const rect = trigger.getBoundingClientRect();
      const cardWidth = Math.min(512, innerWidth - 24);
      card.style.setProperty("--inator-preview-card-left", `${Math.min(Math.max(12, rect.left), innerWidth - cardWidth - 12)}px`);
      card.style.setProperty("--inator-preview-card-top", `${Math.min(innerHeight - 220, rect.bottom + 8)}px`);
      if (!card.matches(":popover-open")) card.showPopover?.();
    }, openDelay);
  };
  const close = () => {
    clearTimeout(openTimer);
    closeTimer = setTimeout(() => {
      if (!trigger.matches(":hover") && !card.matches(":hover") && trigger !== document.activeElement && !card.contains(document.activeElement)) card.hidePopover?.();
    }, closeDelay);
  };
  trigger.addEventListener("mouseenter", open);
  trigger.addEventListener("mouseleave", close);
  trigger.addEventListener("focus", open);
  trigger.addEventListener("blur", close);
  card.addEventListener("mouseenter", () => clearTimeout(closeTimer));
  card.addEventListener("mouseleave", close);
  card.addEventListener("focusout", close);
  card.append(tabs, content);
  select(selected);

  return { card, select, open, close: () => card.hidePopover?.() };
}
