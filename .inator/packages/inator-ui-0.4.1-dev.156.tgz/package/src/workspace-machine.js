import { createWorkspaceDisclosureGroup } from "./workspace-disclosure.js";
import { createNavigationTabs } from "./tabs.js";

const element = (tag, className = "", text = null) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
};

const readable = value => typeof value === "number" && value > 1048576
  ? `${(value / 2 ** 30).toFixed(1)} GB`
  : value == null ? "Unknown"
    : typeof value === "object" ? Object.entries(value).map(([key, item]) => `${key} ${readable(item)}`).join(", ") : String(value);
const time = value => { const date = new Date(value); return Number.isNaN(date.valueOf()) ? "Unknown" : new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date); };
const statusLabel = status => status === "ready" ? "Ready" : status === "blocked" ? "Blocked" : status === "repairable" ? "Repair available" : "Needs attention";
const statusMark = status => status === "ready" ? "✓" : status === "blocked" ? "×" : "!";

function systemTabs(active, navigation = {}) {
  return createNavigationTabs({ activeId: active, label: "Local system views", className: "inator-system-tabs", items: [["machine", "Machine"], ["models", "Models"]].map(([id, label]) => ({ id, label, href: navigation[id] || `/workspace/${id}/` })) });
}

export function createWorkspaceMachineView({ mount, manifest, navigation, onRefresh, onRepair, reportStatus } = {}) {
  if (!mount?.replaceChildren) throw new TypeError("Machine view requires a mount.");
  const render = value => {
    reportStatus?.({ label: value.status, tone: value.status === "ready" ? "success" : value.status === "blocked" ? "danger" : "warning" });
    const page = element("section", "inator-system-surface");
    const header = element("header", "inator-system-header");
    const heading = element("div", "inator-system-heading");
    heading.append(element("p", "plain-kicker", "Local computation"), element("h1", "", "Machine"), element("p", "", "Readiness, capacity, and current conditions on this computer."));
    const summary = element("div", "inator-system-summary"); summary.dataset.status = value.status;
    summary.append(element("b", "inator-system-summary__mark", statusMark(value.status)), element("strong", "", statusLabel(value.status)), element("small", "", `${value.machine.platform} ${value.machine.architecture}`));
    const refresh = element("button", "inator-system-action inator-system-refresh", "Refresh"); refresh.type = "button";
    refresh.addEventListener("click", async () => { refresh.disabled = true; refresh.textContent = "Refreshing…"; try { update(await onRefresh?.()); } finally { refresh.disabled = false; refresh.textContent = "Refresh"; } });
    summary.append(refresh); header.append(heading, summary);
    const meta = element("p", "inator-system-meta", `Policy ${value.policy.id} ${value.policy.version} · checked ${time(value.generatedAt)}`);
    const groups = element("div", "inator-system-groups");
    for (const guidance of value.guidance || []) {
      const content = element("aside", "inator-hardware-advice");
      content.append(element("p", "", guidance.message || guidance.description || "No guidance is available."));
      groups.append(createWorkspaceDisclosureGroup({ id: guidance.id, namespace: "machine", title: guidance.title, summary: guidance.summary || "Guidance", status: guidance.status || "ready", content, open: guidance.open }));
    }
    for (const category of [...new Set(value.checks.map(check => check.category))]) {
      const categoryChecks = value.checks.filter(item => item.category === category);
      const needsAttention = categoryChecks.filter(check => check.status !== "ready").length;
      const list = element("div", "inator-system-checks");
      for (const check of categoryChecks) {
        const row = element("article", "inator-system-check"); row.dataset.status = check.status;
        const mark = element("b", "inator-system-check__mark", statusMark(check.status)); mark.setAttribute("aria-label", statusLabel(check.status));
        const copy = element("div", "inator-system-check__copy");
        copy.append(element("strong", "", check.label), element("span", "inator-system-check__value", readable(check.observedValue)), element("p", "", check.explanation || "No explanation supplied."), element("small", "", check.requirement ? `Requires ${readable(check.requirement)}` : `Observed ${time(check.observedAt)}`));
        row.append(mark, copy);
        if (check.repairAction) { const repair = element("button", "inator-system-action", check.repairAction.label || "Repair"); repair.type = "button"; repair.addEventListener("click", () => onRepair?.(check)); row.append(repair); }
        list.append(row);
      }
      groups.append(createWorkspaceDisclosureGroup({ id: category, namespace: "machine", title: category, summary: needsAttention ? `${needsAttention} need attention` : `${categoryChecks.length} ready`, statuses: categoryChecks.map(check => check.status), content: list }));
    }
    page.append(header, meta, groups); mount.replaceChildren(systemTabs("machine", navigation), page);
  };
  const update = next => { if (next) manifest = next; render(manifest); };
  render(manifest); return { update, destroy() { mount.replaceChildren(); } };
}

export function machineWorkspaceCapability(options = {}) {
  return { id: "machine", label: "Machine", detail: "Readiness, resources, and repair", icon: "machine", route: "workspace-machine", href: "/workspace/machine/", order: 220, menu: { id: "local-system", label: "Local system", detail: "Machine, software, and models", icon: "machine", href: "/workspace/machine/", route: "workspace-machine" }, createView: ({ mount, adapter }) => createWorkspaceMachineView({ mount, ...adapter }), ...options };
}
