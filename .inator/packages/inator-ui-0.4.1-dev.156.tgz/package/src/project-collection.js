import {
  createActionBar,
  createActionRegion,
  createActionRow,
  createCollectionSurface,
  createToolButton,
  setToolButtonState
} from "./action-bar.js";
import { createInatorIcon } from "./icons.js";
import { installFileIntake } from "./intake.js";
import { createListModel } from "./list-model.js";
import { createListView } from "./list-view.js";
import { createProjectImageEditor } from "./project-image-editor.js";

export const PROJECT_COLLECTION_SCHEMA = "inator.project-collection.v1";
export const PROJECT_PRIORITIES = Object.freeze(["urgent", "high", "normal", "low"]);
export const PROJECT_LIFECYCLES = Object.freeze(["active", "shelved", "archived"]);
export const PROJECT_COLLECTION_ISSUES = Object.freeze({
  REMOVAL_UNRESOLVED: "project-removal-unresolved",
  IMAGE_OVERRIDE_UNRESOLVED: "project-image-override-unresolved"
});

const text = (value) => String(value ?? "").trim();
const element = (tag, className = "", content = "") => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (content) node.textContent = content;
  return node;
};

function requiredHandler(handlers, name) {
  if (typeof handlers?.[name] !== "function") {
    throw new TypeError(`A Project collection requires handlers.${name}.`);
  }
}

export function normalizeProjectCollectionRecord(record, project = {}) {
  const id = text(project.id?.(record) ?? record?.id);
  const name = text(project.name?.(record) ?? record?.name);
  if (!id) throw new TypeError("Every Project collection record requires a stable id.");
  if (!name) throw new TypeError(`Project ${id} requires a name.`);
  const rawImage = project.image?.(record) ?? record?.image ?? null;
  const image = rawImage?.src ? Object.freeze({
    assetId: text(rawImage.assetId || rawImage.id),
    src: String(rawImage.src),
    alt: String(rawImage.alt ?? ""),
    position: text(rawImage.position) || "50% 50%",
    provenanceRef: text(rawImage.provenanceRef)
  }) : null;
  const priority = text(project.priority?.(record) ?? record?.priority).toLocaleLowerCase();
  const lifecycle = text(project.lifecycle?.(record) ?? record?.lifecycle).toLocaleLowerCase();
  return Object.freeze({
    source: record,
    id,
    name,
    secondary: text(project.secondary?.(record) ?? record?.secondary),
    image,
    current: Boolean(project.current?.(record) ?? record?.current),
    priority: PROJECT_PRIORITIES.includes(priority) ? priority : "normal",
    lifecycle: PROJECT_LIFECYCLES.includes(lifecycle) ? lifecycle : "active",
    searchText: text(project.searchText?.(record) ?? record?.searchText)
  });
}

export function defineProjectCollection(input = {}) {
  const vocabulary = Object.freeze({
    singular: text(input.vocabulary?.singular) || "Project",
    plural: text(input.vocabulary?.plural) || "Projects"
  });
  const handlers = input.handlers || {};
  requiredHandler(handlers, "importFiles");
  requiredHandler(handlers, "exportProjects");
  const records = (input.records || []).map((record) => normalizeProjectCollectionRecord(record, input.project));
  const issues = [];
  if (!handlers.deleteProjects && !handlers.archiveProjects) issues.push(Object.freeze({
    id: PROJECT_COLLECTION_ISSUES.REMOVAL_UNRESOLVED,
    message: `${vocabulary.plural} do not yet declare safe delete or archive behavior.`
  }));
  if (!handlers.saveProjectImage && !handlers.editImage) issues.push(Object.freeze({
    id: PROJECT_COLLECTION_ISSUES.IMAGE_OVERRIDE_UNRESOLVED,
    message: `${vocabulary.plural} do not yet allow a user to override the app-supplied image.`
  }));
  return Object.freeze({
    schema: PROJECT_COLLECTION_SCHEMA,
    vocabulary,
    records,
    project: Object.freeze({ ...(input.project || {}) }),
    handlers: Object.freeze({ ...handlers }),
    import: Object.freeze({ accept: input.import?.accept || "", multiple: input.import?.multiple !== false }),
    columns: Object.freeze([...(input.columns || [])]),
    filters: Object.freeze([...(input.filters || [])]),
    actions: Object.freeze({
      creation: Object.freeze([...(input.actions?.creation || [])]),
      selection: Object.freeze([...(input.actions?.selection || [])])
    }),
    preferencesKey: text(input.preferencesKey),
    pipeline: input.pipeline ? Object.freeze({ ...input.pipeline }) : null,
    initialState: Object.freeze({ pageSize: 10, ...(input.initialState || {}) }),
    conformance: Object.freeze({ issues: Object.freeze(issues) })
  });
}

export function projectCollectionConformance(input = {}) {
  const contract = input?.schema === PROJECT_COLLECTION_SCHEMA ? input : defineProjectCollection(input);
  return contract.conformance;
}

function imageCell(record, contract, refresh) {
  const button = element("button", "inator-project-image");
  button.type = "button";
  button.setAttribute("aria-label", `Edit image for ${record.name}`);
  if (record.image) {
    const image = document.createElement("img");
    image.src = record.image.src;
    image.alt = record.image.alt;
    image.style.objectPosition = record.image.position;
    button.append(image);
  } else {
    const fallback = element("span", "inator-project-image__fallback", record.name.slice(0, 1).toLocaleUpperCase());
    fallback.setAttribute("aria-hidden", "true");
    button.append(fallback);
  }
  button.addEventListener("click", async () => {
    if (contract.handlers.saveProjectImage) {
      const automaticImage = contract.project.automaticImage?.(record.source) || null;
      const candidates = contract.project.imageCandidates?.(record.source) || [];
      const selection = contract.project.imageSelection?.(record.source) || (record.image?.assetId ? { mode: "asset", assetId: record.image.assetId } : { mode: "automatic" });
      const editor = createProjectImageEditor({
        project: record.source,
        vocabulary: contract.vocabulary.singular,
        automaticImage,
        candidates,
        selection,
        onSave: async (next) => { await contract.handlers.saveProjectImage(record.source, next); refresh?.(); }
      });
      editor.open(button);
      return;
    }
    if (contract.handlers.editImage) { await contract.handlers.editImage(record.source, button); refresh?.(); }
  });
  button.disabled = typeof contract.handlers.saveProjectImage !== "function" && typeof contract.handlers.editImage !== "function";
  return button;
}

function identityCell(record, contract, refresh) {
  const identity = element("div", "inator-project-identity");
  const input = element("input", "inator-project-name");
  input.type = "text";
  input.value = record.name;
  input.maxLength = Number(contract.project.nameMaxLength) || 160;
  input.setAttribute("aria-label", `Rename ${record.name}`);
  let committed = record.name;
  const save = async () => {
    const next = input.value.trim();
    input.setCustomValidity("");
    if (!next || next === committed) { input.value = committed; return; }
    if (!contract.handlers.renameProject) { input.value = committed; return; }
    input.disabled = true;
    input.setAttribute("aria-busy", "true");
    try {
      await contract.handlers.renameProject(record.source, next);
      committed = next;
      refresh?.();
    } catch (error) {
      input.value = committed;
      input.setCustomValidity(error?.message || `Could not rename ${contract.vocabulary.singular.toLocaleLowerCase()}.`);
      input.reportValidity();
    } finally {
      input.disabled = false;
      input.removeAttribute("aria-busy");
    }
  };
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") { event.preventDefault(); input.blur(); }
    if (event.key === "Escape") { input.value = committed; input.blur(); }
  });
  input.addEventListener("blur", save);
  identity.append(input);
  const meta = element("div", "inator-project-identity__meta");
  if (record.secondary) meta.append(element("small", "inator-project-secondary", record.secondary));
  identity.append(meta);
  return identity;
}

function priorityCell(record, contract) {
  const select = element("select", `inator-project-priority inator-project-priority--${record.priority}`);
  select.setAttribute("aria-label", `Priority for ${record.name}`);
  for (const value of PROJECT_PRIORITIES) select.append(new Option(value[0].toLocaleUpperCase() + value.slice(1), value, false, value === record.priority));
  select.addEventListener("change", async () => {
    const previous = record.priority;
    select.disabled = true;
    try {
      await contract.pipeline?.setPriority?.(record.source, select.value);
      select.className = `inator-project-priority inator-project-priority--${select.value}`;
    } catch (error) {
      select.value = previous;
      select.setCustomValidity(error?.message || "Could not change priority.");
      select.reportValidity();
    } finally { select.disabled = false; }
  });
  return select;
}

export function createProjectCollection(input = {}) {
  let contract = input?.schema === PROJECT_COLLECTION_SCHEMA ? input : defineProjectCollection(input);
  const columnsButton = createToolButton({ icon: createInatorIcon("columns"), label: "Columns" });
  const newButton = contract.handlers.newProject ? createToolButton({ icon: createInatorIcon("new"), label: "New", onClick: () => contract.handlers.newProject() }) : null;
  const importWell = createToolButton({ icon: createInatorIcon("import"), label: "Import", className: "inator-project-import-well", statusText: "Drop or choose" });
  const duplicateButton = contract.handlers.duplicateProjects ? createToolButton({ icon: createInatorIcon("duplicate"), label: "Duplicate", disabled: true }) : null;
  const exportButton = createToolButton({ icon: createInatorIcon("export"), label: "Export" });
  const deleteButton = contract.handlers.deleteProjects ? createToolButton({ icon: createInatorIcon("delete"), label: "Delete", className: "inator-tool-button--danger", disabled: true }) : null;
  const firstRegion = createActionRegion({ children: [columnsButton, newButton, ...contract.actions.creation, importWell].filter(Boolean) });
  const secondRegion = createActionRegion({ separated: true, children: [duplicateButton, ...contract.actions.selection, exportButton, deleteButton].filter(Boolean) });
  const actionBar = createActionBar({ label: `${contract.vocabulary.singular} actions`, rows: [createActionRow({ children: [firstRegion, secondRegion] })] });
  const listMount = element("div");
  const elementRoot = createCollectionSurface({ actionBar, listMount });
  elementRoot.classList.add("inator-project-collection");
  const refresh = () => input.onRefresh?.();
  const columns = [
    { id: "image", label: "Image", required: true, sortable: false, searchable: false, value: (record) => record.image?.assetId || record.image?.src || "", render: (record) => imageCell(record, contract, refresh) },
    { id: "name", label: contract.vocabulary.singular, required: true, searchValue: (record) => `${record.name} ${record.secondary} ${record.searchText}`, value: (record) => record.name, render: (record) => identityCell(record, contract, refresh) },
    ...(contract.pipeline ? [
      { id: "priority", label: "Priority", value: (record) => PROJECT_PRIORITIES.indexOf(record.priority), filterValue: (record) => record.priority, render: (record) => priorityCell(record, contract) },
      ...(contract.pipeline.progressColumn ? [{ ...contract.pipeline.progressColumn, id: "progress", label: contract.pipeline.progressColumn.label || "Analysis" }] : [])
    ] : []),
    ...contract.columns
  ];
  const model = createListModel({ records: contract.records, columns, initialState: contract.initialState });
  const selectedRecords = () => {
    const selected = model.snapshot().selectedIds;
    return contract.records.filter((record) => selected.has(record.id));
  };
  const exportRecords = () => selectedRecords().length ? selectedRecords() : contract.records;
  const updateActions = () => {
    const count = model.snapshot().selectedIds.size;
    if (duplicateButton) setToolButtonState(duplicateButton, { label: "Duplicate", disabled: count !== 1 });
    if (deleteButton) setToolButtonState(deleteButton, { label: "Delete", disabled: count === 0 });
  };
  const list = createListView({
    mount: listMount,
    model,
    columnButton: columnsButton,
    filters: contract.filters,
    compactFilters: contract.filters.length > 1,
    preferencesKey: contract.preferencesKey,
    searchPlaceholder: `Search ${contract.vocabulary.plural.toLocaleLowerCase()}`,
    emptyTitle: `No ${contract.vocabulary.plural.toLocaleLowerCase()} yet`,
    emptyDetail: `Choose New or drop files on Import to add ${contract.vocabulary.plural.toLocaleLowerCase()}.`,
    rowActionIcon: "edit",
    rowActionLabel: (record) => `Edit ${record.name}`,
    onRowAction: (record, trigger) => (contract.handlers.editProject || contract.handlers.openProject)?.(record.source, trigger),
    rowClassName: (record) => record.current ? "inator-project-row--current" : "",
    isCurrentRow: (record) => record.current,
    onChange: updateActions
  });
  installFileIntake(importWell, { ...contract.import, title: `Choose ${contract.vocabulary.plural.toLocaleLowerCase()} or drop them here`, onFiles: (files) => contract.handlers.importFiles(files) });
  exportButton.addEventListener("click", () => contract.handlers.exportProjects(exportRecords().map((record) => record.source), exportButton));
  duplicateButton?.addEventListener("click", () => contract.handlers.duplicateProjects(selectedRecords().map((record) => record.source), duplicateButton));
  deleteButton?.addEventListener("click", () => contract.handlers.deleteProjects(selectedRecords().map((record) => record.source), deleteButton));
  list.render();
  updateActions();
  return Object.freeze({ element: elementRoot, actionBar, model, list, importWell, update(nextInput) {
    contract = nextInput?.schema === PROJECT_COLLECTION_SCHEMA ? nextInput : defineProjectCollection(nextInput);
    model.setRecords(contract.records);
    list.render();
    updateActions();
  } });
}
