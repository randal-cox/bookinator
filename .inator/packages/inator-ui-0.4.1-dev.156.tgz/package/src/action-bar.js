export const ACTION_STATUSES = Object.freeze([
  "idle",
  "running",
  "complete",
  "warning",
  "failed"
]);

const STATUS_LABELS = Object.freeze({
  idle: "",
  running: "Running",
  complete: "Complete",
  warning: "Needs attention",
  failed: "Failed"
});

const clamp = (value, minimum, maximum) => Math.min(Math.max(value, minimum), maximum);

export function actionIdentifier(label = "action") {
  const slug = String(label).trim().toLocaleLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  return `inator:${slug || "action"}`;
}

function appendElements(parent, elements = []) {
  for (const element of elements) if (element) parent.append(element);
  return parent;
}

export function createActionRegion({ align = "start", separated = false, children = [] } = {}) {
  const region = document.createElement("div");
  region.className = [
    "inator-action-region",
    separated ? "inator-action-region--separated" : ""
  ].filter(Boolean).join(" ");
  region.dataset.align = align;
  return appendElements(region, children);
}

export function createActionRow({ children = [] } = {}) {
  const row = document.createElement("div");
  row.className = "inator-action-row";
  return appendElements(row, children);
}

export function createActionSection({ label, children = [] } = {}) {
  const text = String(label || "").trim();
  if (!text) throw new TypeError("An action section requires a visible label.");
  const section = document.createElement("fieldset");
  section.className = "inator-action-section";
  const legend = document.createElement("legend");
  legend.textContent = text;
  section.append(legend, ...children);
  return section;
}

export function createActionSectionGroup({ children = [] } = {}) {
  const group = document.createElement("div");
  group.className = "inator-action-section-group";
  return appendElements(group, children);
}

export function createActionBar({ label = "Workspace actions", rows = [] } = {}) {
  const bar = document.createElement("nav");
  bar.className = "inator-action-bar";
  bar.setAttribute("aria-label", label);
  appendElements(bar, rows);
  return assertActionBarConformance(bar);
}

export function assertActionBarConformance(bar) {
  if (!bar?.classList?.contains("inator-action-bar")) {
    throw new TypeError("Action-bar conformance requires an .inator-action-bar root.");
  }
  for (const control of bar.querySelectorAll("button, summary, a[href]")) {
    if (control.dataset.inatorActionLayout === "text") {
      if (!control.dataset.inatorActionException?.trim()) {
        throw new TypeError("A text-first action-bar exception requires data-inator-action-exception rationale.");
      }
      continue;
    }
    if (!control.classList.contains("inator-tool-button")
      || !control.querySelector(":scope > .inator-tool-button__icon")
      || !control.querySelector(":scope > .inator-tool-button__label")) {
      throw new TypeError("Action-bar controls require a shared icon-over-label tool button.");
    }
  }
  return bar;
}

export function createCollectionSurface({ actionBar, listMount } = {}) {
  if (!actionBar?.classList?.contains("inator-action-bar")) {
    throw new TypeError("A collection surface requires an Inator action bar.");
  }
  if (!listMount?.replaceChildren) {
    throw new TypeError("A collection surface requires a list mount element.");
  }
  const surface = document.createElement("section");
  surface.className = "inator-collection-surface";
  surface.append(actionBar, listMount);
  return surface;
}

export function createActionSpacer() {
  const spacer = document.createElement("span");
  spacer.className = "inator-action-spacer";
  spacer.setAttribute("aria-hidden", "true");
  return spacer;
}

export function createActionMeta(text = "") {
  const meta = document.createElement("span");
  meta.className = "inator-action-meta";
  meta.textContent = String(text);
  return meta;
}

export function normalizeActionState(input = {}) {
  const status = ACTION_STATUSES.includes(input.status) ? input.status : "idle";
  const progressMaximum = Number.isFinite(input.progressMaximum) && input.progressMaximum > 0
    ? input.progressMaximum
    : 100;
  const hasProgress = Number.isFinite(input.progressValue);
  const progressValue = hasProgress ? clamp(input.progressValue, 0, progressMaximum) : null;

  return {
    label: String(input.label ?? "Action").trim() || "Action",
    status,
    statusText: String(input.statusText ?? STATUS_LABELS[status]).trim(),
    current: Boolean(input.current),
    pressed: typeof input.pressed === "boolean" ? input.pressed : null,
    disabled: Boolean(input.disabled),
    progressValue,
    progressMaximum,
    progressPercent: progressValue === null ? null : (progressValue / progressMaximum) * 100
  };
}

export function actionAccessibleLabel(input = {}) {
  const state = normalizeActionState(input);
  const parts = [state.label];
  if (state.current) parts.push("current view");
  if (state.statusText) parts.push(state.statusText);
  if (state.progressValue !== null) parts.push(`${Math.round(state.progressPercent)} percent`);
  return parts.join(" ");
}

function ensureStatusElement(button) {
  let status = button.querySelector(".inator-tool-button__status");
  if (!status) {
    status = document.createElement("small");
    status.className = "inator-tool-button__status";
    status.setAttribute("aria-hidden", "true");
    button.append(status);
  }
  return status;
}

export function setToolButtonState(button, input = {}) {
  const label = input.label ?? button.dataset.label ?? button.textContent;
  const state = normalizeActionState({ ...input, label });
  const statusElement = ensureStatusElement(button);

  button.dataset.label = state.label;
  button.dataset.status = state.status;
  button.disabled = state.disabled;
  button.removeAttribute("aria-label");
  if (!button.dataset.inatorTooltip) button.removeAttribute("aria-description");
  button.style.removeProperty("--inator-action-progress");

  if (state.current) button.setAttribute("aria-current", "page");
  else button.removeAttribute("aria-current");
  if (state.pressed === null) button.removeAttribute("aria-pressed");
  else button.setAttribute("aria-pressed", String(state.pressed));
  if (state.progressPercent !== null) {
    button.style.setProperty("--inator-action-progress", `${state.progressPercent}%`);
  }

  statusElement.textContent = state.statusText;
  statusElement.hidden = !state.statusText;
  return state;
}

export function decorateToolControl(element, { icon, label, className = "", statusText = "" } = {}) {
  if (!element?.replaceChildren) throw new TypeError("A tool control requires a DOM element.");
  const visibleLabel = String(label ?? element.textContent ?? "Action").trim() || "Action";
  element.className = [element.className, "inator-tool-button", className].filter(Boolean).join(" ");
  element.dataset.action = actionIdentifier(visibleLabel);
  const iconElement = document.createElement("span");
  iconElement.className = "inator-tool-button__icon";
  iconElement.setAttribute("aria-hidden", "true");
  if (icon instanceof Node) iconElement.append(icon.cloneNode(true));
  else iconElement.textContent = String(icon ?? "·");

  const labelElement = document.createElement("strong");
  labelElement.className = "inator-tool-button__label";
  labelElement.textContent = visibleLabel;

  const statusElement = document.createElement("span");
  statusElement.className = "inator-tool-button__status";
  statusElement.textContent = String(statusText ?? "");
  statusElement.hidden = !statusElement.textContent;
  element.replaceChildren(iconElement, labelElement, statusElement);
  return element;
}

export function createToolButton({ icon, label, className = "", onClick, ...stateInput }) {
  const button = document.createElement("button");
  button.type = "button";
  decorateToolControl(button, { icon, label, className });

  setToolButtonState(button, { ...stateInput, label });
  if (onClick) button.addEventListener("click", onClick);
  return button;
}

export function createToolMenu({ icon, label, items = [], onSelect = null, className = "" } = {}) {
  if (!label || !items.length) throw new TypeError("A tool menu requires a label and at least one item.");
  const menu = document.createElement("div"); menu.className = ["inator-tool-menu", className].filter(Boolean).join(" ");
  const trigger = document.createElement("button"); trigger.type = "button"; decorateToolControl(trigger, { icon, label }); trigger.setAttribute("aria-haspopup", "menu"); trigger.setAttribute("aria-expanded", "false");
  const panel = document.createElement("div"); panel.className = "inator-tool-menu__panel"; panel.setAttribute("role", "menu"); panel.setAttribute("aria-label", label);
  panel.popover = "auto";
  const choices = document.createElement("div"); choices.className = "inator-tool-menu__choices"; panel.append(choices);
  const isOpen = () => trigger.getAttribute("aria-expanded") === "true";
  const close = () => {
    trigger.setAttribute("aria-expanded", "false");
    panel.dataset.open = "false";
    // Safari can undo hidePopover() when it runs inside the menu item's click
    // dispatch. Close after that dispatch, and tolerate an already-closed panel.
    queueMicrotask(() => { try { panel.hidePopover(); } catch { /* The panel may already be closed or detached. */ } });
  };
  const controls = new Map();
  for (const item of items) {
    if (!item?.id || !item?.label) throw new TypeError("Each tool-menu item requires id and label.");
    const control = createToolButton({ icon: item.icon, label: item.label, disabled: item.disabled, statusText: item.statusText || "" }); control.setAttribute("role", "menuitem"); control.dataset.menuItem = item.id;
    control.addEventListener("click", (event) => {
      if (control.disabled) return;
      event.preventDefault();
      event.stopPropagation();
      close();
      // The trigger is the stable focus-return target. Returning focus to an
      // item inside a closed popover makes Safari reopen the menu when a
      // dialog closes.
      // Let Safari remove the popover from the top layer before a selected
      // action opens a modal dialog and makes the action bar inert.
      requestAnimationFrame(() => onSelect?.(item.id, item, trigger, control));
    }); choices.append(control); controls.set(item.id, control);
  }
  let disabled = false;
  trigger.addEventListener("click", () => { if (disabled) return; if (isOpen()) { close(); return; } const rect = trigger.getBoundingClientRect(); panel.style.left = `${Math.max(8, Math.min(innerWidth - 326, rect.left))}px`; panel.style.top = `${Math.min(innerHeight - 12, rect.bottom + 5)}px`; panel.showPopover(); panel.dataset.open = "true"; trigger.setAttribute("aria-expanded", "true"); });
  panel.addEventListener("toggle", event => { const open = event.newState === "open"; panel.dataset.open = String(open); trigger.setAttribute("aria-expanded", String(open)); });
  const setDisabled = value => { disabled = Boolean(value); menu.dataset.disabled = String(disabled); trigger.disabled = disabled; trigger.setAttribute("aria-disabled", String(disabled)); if (disabled) close(); };
  menu.append(trigger, panel);
  return Object.freeze({ element: menu, trigger, controls, setDisabled, close });
}
