export const PRODUCT_HISTORY_SCHEMA = "inator.product-history.v1";

export const MILESTONE_STATUSES = Object.freeze(["released", "active", "next", "later"]);

const STATUS_LABELS = Object.freeze({
  released: "Released",
  active: "Now",
  next: "Next",
  later: "Later"
});

function requiredText(value, field) {
  const text = String(value || "").trim();
  if (!text) throw new TypeError(`${field} is required`);
  return text;
}

function isoDate(value, field) {
  const date = requiredText(value, field);
  const parsed = new Date(`${date}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(parsed.valueOf()) || parsed.toISOString().slice(0, 10) !== date) {
    throw new TypeError(`${field} must use a real YYYY-MM-DD date: ${date}`);
  }
  return date;
}

function normalizeDeliverable(deliverable, index, milestoneStatus) {
  const source = typeof deliverable === "string" ? { label: deliverable } : deliverable || {};
  const fallbackState = milestoneStatus === "released" ? "complete" : "planned";
  const state = source.state || fallbackState;
  if (!["complete", "active", "planned"].includes(state)) throw new TypeError(`Invalid deliverable state: ${state}`);
  return Object.freeze({
    id: source.id || `item-${index + 1}`,
    label: requiredText(source.label, "Deliverable label"),
    state
  });
}

function normalizeRelease(release) {
  if (!release) return null;
  const version = requiredText(release.version, "Release version");
  const date = isoDate(release.date, "Release date");
  return Object.freeze({ version, date, title: String(release.title || "").trim() });
}

export function defineProductHistory(source = {}) {
  const ids = new Set();
  const milestones = (source.milestones || []).map((milestone, index) => {
    const id = requiredText(milestone.id, "Milestone id");
    if (ids.has(id)) throw new TypeError(`Duplicate milestone id: ${id}`);
    ids.add(id);
    const status = milestone.status || "later";
    if (!MILESTONE_STATUSES.includes(status)) throw new TypeError(`Invalid milestone status: ${status}`);
    const release = normalizeRelease(milestone.release);
    if (status === "released" && !release) throw new TypeError(`Released milestone ${id} requires release metadata`);
    if (release && status !== "released") throw new TypeError(`Only released milestones may include release metadata: ${id}`);
    return Object.freeze({
      id,
      title: requiredText(milestone.title, "Milestone title"),
      summary: requiredText(milestone.summary, "Milestone summary"),
      status,
      targetVersion: release?.version || (milestone.targetVersion ? requiredText(milestone.targetVersion, "Milestone target version") : null),
      release,
      deliverables: Object.freeze((milestone.deliverables || []).map((item, itemIndex) => normalizeDeliverable(item, itemIndex, status))),
      order: index
    });
  });
  return Object.freeze({
    schema: PRODUCT_HISTORY_SCHEMA,
    product: requiredText(source.product, "Product name"),
    updatedAt: isoDate(source.updatedAt, "History update date"),
    milestones: Object.freeze(milestones)
  });
}

export function productMilestoneLabels(history) {
  if (!history?.milestones) throw new TypeError("A normalized product history is required");
  return Object.fromEntries(history.milestones.map((milestone) => [
    milestone.id,
    `${milestone.release?.version || milestone.targetVersion || "Unscheduled"} — ${milestone.title}`
  ]));
}

function milestoneVersion(milestone) {
  return milestone.release?.version || milestone.targetVersion || "Unscheduled";
}

function compareMilestoneVersions(left, right) {
  const statusOrder = { active: 0, next: 1, later: 2, released: 3 };
  const statusDifference = statusOrder[left.status] - statusOrder[right.status];
  if (statusDifference) return statusDifference;
  const parts = (milestone) => milestoneVersion(milestone).split(".").map((part) => Number.parseInt(part, 10));
  const leftParts = parts(left);
  const rightParts = parts(right);
  for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
    const difference = left.status === "released"
      ? (rightParts[index] || 0) - (leftParts[index] || 0)
      : (leftParts[index] || 0) - (rightParts[index] || 0);
    if (difference) return difference;
  }
  return left.status === "released" ? right.order - left.order : left.order - right.order;
}

export function milestonesFromHistory(history) {
  if (!history?.milestones) throw new TypeError("A normalized product history is required");
  return [...history.milestones].sort(compareMilestoneVersions);
}

export function releasesFromHistory(history) {
  return [...history.milestones]
    .filter(({ release }) => release)
    .sort((left, right) => right.release.date.localeCompare(left.release.date) || right.order - left.order);
}

export function productHistoryFooterLinks(baseHref) {
  const base = String(baseHref || "/").replace(/\/?$/, "/");
  return [
    { href: `${base}roadmap/`, route: "roadmap", label: "Roadmap" },
    { href: `${base}releases/`, route: "releases", label: "Releases" }
  ];
}

export function productHistoryFooterLink(href, { route = "product-history", label = "Roadmap & releases" } = {}) {
  return { href: String(href || "/history/"), route, label };
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function metric(value, label) {
  const node = element("div");
  node.append(element("strong", "", value), element("span", "", label));
  return node;
}

function overview(history, mode, entries) {
  const section = element("section", "inator-history-overview");
  if (mode === "releases") {
    const latest = entries[0]?.release;
    section.append(
      metric(String(entries.length), `release${entries.length === 1 ? "" : "s"} recorded`),
      metric(latest?.version || "—", "latest version"),
      metric(latest?.date || "—", "latest release")
    );
    return section;
  }
  const released = entries.filter(({ status }) => status === "released").length;
  const openItems = entries.flatMap(({ deliverables }) => deliverables).filter(({ state }) => state !== "complete").length;
  section.append(
    metric(String(entries.length), "milestones"),
    metric(String(released), "released"),
    metric(String(openItems), "open deliverables")
  );
  return section;
}

function historyEntry(milestone, mode) {
  const item = element("li", "inator-history-entry");
  item.dataset.status = milestone.status;
  const signal = element("div", "inator-history-signal");
  signal.append(element("i"), element("span", "", mode === "releases" ? milestone.release.version : `${milestoneVersion(milestone)} · ${STATUS_LABELS[milestone.status]}`));

  const article = element("article");
  const header = element("header");
  const heading = element("div");
  const releaseTitle = mode === "releases" ? milestone.release?.title : "";
  if (releaseTitle && releaseTitle !== milestone.title) {
    heading.append(element("p", "inator-history-release-context", `Milestone · ${milestone.title}`));
  }
  const milestoneTitle = mode === "releases" ? releaseTitle || milestone.title : `${milestoneVersion(milestone)} — ${milestone.title}`;
  heading.append(element("h2", "", milestoneTitle), element("p", "", milestone.summary));
  header.append(heading);
  if (milestone.release) {
    const time = element("time", "", milestone.release.date);
    time.dateTime = milestone.release.date;
    header.append(time);
  }

  const list = element("ul", "inator-history-deliverables");
  for (const deliverable of milestone.deliverables) {
    const row = element("li", "", deliverable.label);
    row.dataset.state = deliverable.state;
    list.append(row);
  }
  article.append(header, list);
  item.append(signal, article);
  return item;
}

export function createProductHistoryView({ mount, history, mode = "roadmap" } = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("A product-history mount element is required");
  if (!history?.milestones) throw new TypeError("A normalized product history is required");
  if (!["roadmap", "releases"].includes(mode)) throw new TypeError(`Unknown product-history mode: ${mode}`);
  const entries = mode === "releases" ? releasesFromHistory(history) : milestonesFromHistory(history);
  mount.classList.remove("inator-history--roadmap", "inator-history--releases");
  mount.classList.add("inator-history", `inator-history--${mode}`);
  const list = element("ol", "inator-history-ledger");
  entries.forEach((milestone) => list.append(historyEntry(milestone, mode)));
  if (!entries.length) list.append(element("li", "inator-history-empty", "No releases have been recorded yet."));
  mount.replaceChildren(overview(history, mode, entries), list);
  return { mode, entries };
}

export function createProductHistoryTabs({
  mount,
  history,
  initialMode = "roadmap",
  onChange = () => {}
} = {}) {
  if (!(mount instanceof HTMLElement)) throw new TypeError("A product-history tabs mount element is required");
  if (!history?.milestones) throw new TypeError("A normalized product history is required");
  const modes = ["roadmap", "releases"];
  let mode = modes.includes(initialMode) ? initialMode : "roadmap";
  const wrapper = element("section", "inator-history-tabs");
  const tablist = element("div", "inator-history-tabs__list");
  tablist.setAttribute("role", "tablist");
  tablist.setAttribute("aria-label", "Product history view");
  const panel = element("div", "inator-history-tabs__panel");
  panel.id = "inator-history-panel";
  panel.setAttribute("role", "tabpanel");
  panel.tabIndex = 0;
  const buttons = new Map();

  const select = (nextMode, { focus = false, notify = true } = {}) => {
    if (!modes.includes(nextMode)) throw new TypeError("Unknown product-history tab: " + nextMode);
    mode = nextMode;
    for (const [candidate, button] of buttons) {
      const selected = candidate === mode;
      button.setAttribute("aria-selected", String(selected));
      button.tabIndex = selected ? 0 : -1;
    }
    createProductHistoryView({ mount: panel, history, mode });
    panel.setAttribute("aria-labelledby", "inator-history-tab-" + mode);
    if (focus) buttons.get(mode)?.focus();
    if (notify) onChange({ mode });
    return mode;
  };

  for (const candidate of modes) {
    const button = element("button", "", candidate === "roadmap" ? "Roadmap" : "Releases");
    button.type = "button";
    button.id = "inator-history-tab-" + candidate;
    button.setAttribute("role", "tab");
    button.setAttribute("aria-controls", panel.id);
    button.addEventListener("click", () => select(candidate));
    buttons.set(candidate, button);
    tablist.append(button);
  }
  tablist.addEventListener("keydown", (event) => {
    const index = modes.indexOf(mode);
    let next = null;
    if (event.key === "ArrowRight") next = modes[(index + 1) % modes.length];
    if (event.key === "ArrowLeft") next = modes[(index - 1 + modes.length) % modes.length];
    if (event.key === "Home") next = modes[0];
    if (event.key === "End") next = modes.at(-1);
    if (!next) return;
    event.preventDefault();
    select(next, { focus: true });
  });
  wrapper.append(tablist, panel);
  mount.replaceChildren(wrapper);
  select(mode, { notify: false });
  return {
    get mode() { return mode; },
    select,
    destroy() { mount.replaceChildren(); }
  };
}
