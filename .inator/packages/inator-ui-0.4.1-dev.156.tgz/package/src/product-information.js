import { createTabController } from "./tabs.js";
import { createInatorIcon } from "./icons.js";
import { mountAboutCitation, mountAboutTrust } from "./trust-presentation.js";

export const PRODUCT_DOCS_SCHEMA = "inator.product-docs.v1";
export const PRODUCT_ABOUT_TABS = Object.freeze(["product", "ecosystem"]);

export function normalizeProductAboutTab(value) {
  return value === "ecosystem" ? "ecosystem" : "product";
}

function aboutTabFromLocation(locationObject = globalThis.location) {
  const match = String(locationObject?.hash || "").match(/^#about\/(product|ecosystem)$/);
  return normalizeProductAboutTab(match?.[1]);
}

function writeAboutTabToLocation(tab, { locationObject = globalThis.location, historyObject = globalThis.history } = {}) {
  if (!locationObject || !historyObject?.replaceState) return;
  const hash = `#about/${normalizeProductAboutTab(tab)}`;
  if (locationObject.hash !== hash) historyObject.replaceState(historyObject.state, "", hash);
}
export const PRODUCT_DOCS_SECTIONS = Object.freeze([
  Object.freeze({ id: "start", label: "Start here" }),
  Object.freeze({ id: "tasks", label: "Everyday tasks" }),
  Object.freeze({ id: "reference", label: "Reference" }),
  Object.freeze({ id: "faq", label: "FAQ" })
]);

export const PRODUCT_ABOUT_RECORDS = Object.freeze([
  { id: "milestones", label: "Milestones", description: "Committed outcomes and completed releases", icon: '<path d="M9 36h30M13 36V23h9v13M26 36V12h9v24"/>' },
  { id: "roadmap", label: "Roadmap", description: "Priorities, candidates, and planned work", icon: '<path d="M5 11 16 7l15 5 12-4v30l-12 4-15-5-11 4Z"/><path d="M16 7v30M31 12v30" opacity=".65"/><path d="M10 32c4-8 9-3 13-9 4-6 7-8 15-9" class="inator-record-icon-accent" stroke-dasharray="2.5 4"/><circle cx="10" cy="32" r="2.25" class="inator-record-icon-origin"/><circle cx="38" cy="14" r="2.5" class="inator-record-icon-destination"/>' },
  { id: "security", label: "Security", description: "Controls, evidence, gaps, and verification", icon: '<path d="M14 22v-7c0-8 4-12 10-12s10 4 10 12v7"/><rect x="9" y="21" width="30" height="23" rx="6"/><circle cx="24" cy="31" r="2.5" class="inator-record-icon-origin"/><path d="M24 34v5" class="inator-record-icon-accent"/>' },
  { id: "privacy", label: "Privacy", description: "Ethics, data boundaries, and verified practice", icon: '<rect x="7" y="5" width="15" height="9" rx="2"/><rect x="26" y="5" width="15" height="9" rx="2"/><rect x="3" y="17" width="15" height="9" rx="2"/><rect x="22" y="17" width="15" height="9" rx="2"/><rect x="40" y="17" width="5" height="9" rx="2"/><rect x="7" y="29" width="15" height="9" rx="2"/><rect x="26" y="29" width="15" height="9" rx="2"/><path d="M5 43h38" class="inator-record-icon-accent"/>' }
]);

export function normalizeProductAboutRecordIds(recordIds = []) {
  if (!Array.isArray(recordIds)) throw new TypeError("About recordIds must be an array.");
  const known = new Set(PRODUCT_ABOUT_RECORDS.map(({ id }) => id));
  const normalized = recordIds.map((id) => requiredText(id, "About record id"));
  if (new Set(normalized).size !== normalized.length) throw new TypeError("About recordIds must be unique.");
  for (const id of normalized) if (!known.has(id)) throw new TypeError(`Unknown About record id: ${id}.`);
  const available = new Set(normalized);
  return Object.freeze(PRODUCT_ABOUT_RECORDS.map(({ id }) => id).filter((id) => available.has(id)));
}

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = text;
  return node;
}

function requiredText(value, label) {
  const result = String(value ?? "").trim();
  if (!result) throw new TypeError(`${label} is required.`);
  return result;
}

export function createInformationGraphic({ icon = "guide", label, className = "" } = {}) {
  const figure = element("figure", ["inator-information-graphic", className].filter(Boolean).join(" "));
  figure.setAttribute("role", "img");
  figure.setAttribute("aria-label", requiredText(label, "Information graphic label"));
  const iconMount = element("span", "inator-information-graphic__icon");
  iconMount.setAttribute("aria-hidden", "true");
  iconMount.append(createInatorIcon(icon));
  figure.append(iconMount);
  return figure;
}

function normalizedDocsEntry(source, label) {
  if (!source || typeof source !== "object") throw new TypeError(`${label} is required.`);
  const subsections = (source.subsections || []).map((item, index) => Object.freeze({
    id: requiredText(item.id, `${label}.subsections[${index}].id`),
    label: requiredText(item.label, `${label}.subsections[${index}].label`),
    content: item.content
  }));
  return Object.freeze({ content: source.content, subsections: Object.freeze(subsections) });
}

export function defineProductDocs(source = {}) {
  const sections = {};
  for (const section of PRODUCT_DOCS_SECTIONS) sections[section.id] = normalizedDocsEntry(source.sections?.[section.id], `sections.${section.id}`);
  return Object.freeze({ schema: PRODUCT_DOCS_SCHEMA, productLabel: requiredText(source.productLabel || "Inator", "productLabel"), heading: requiredText(source.heading || "Find your bearings. Then go as deep as you need.", "heading"), introduction: requiredText(source.introduction || "Start with orientation, follow an everyday task, or look up exact behavior.", "introduction"), sections: Object.freeze(sections) });
}

function appendContent(mount, content) {
  const resolved = typeof content === "function" ? content(mount) : content;
  if (resolved instanceof Node) mount.append(resolved);
  else if (resolved != null) mount.insertAdjacentHTML("beforeend", String(resolved));
}

export function createProductAboutContent({ kicker = "About this Inator", heading, summary, sections = [], heroContent = null } = {}) {
  const content = element("div", "inator-product-about");
  const hero = element("header", "inator-product-about__hero");
  hero.append(
    element("p", "inator-information-kicker", requiredText(kicker, "kicker")),
    element("h1", "", requiredText(heading, "heading")),
    element("p", "inator-product-about__summary", requiredText(summary, "summary"))
  );
  appendContent(hero, heroContent);
  content.append(hero);
  if (sections.length) {
    const grid = element("div", "inator-product-about__sections");
    sections.forEach((source, index) => {
      if (!source || typeof source !== "object") throw new TypeError(`sections[${index}] is required.`);
      const section = element("section");
      section.append(element("h2", "", requiredText(source.heading, `sections[${index}].heading`)));
      appendContent(section, source.content);
      grid.append(section);
    });
    content.append(grid);
  }
  return content;
}

export function createProductDocsFlow({ sections = [] } = {}) {
  const flow = element("div", "inator-docs-flow");
  for (const [index, source] of sections.entries()) {
    if (!source || typeof source !== "object") throw new TypeError(`sections[${index}] is required.`);
    const section = element("section", "inator-docs-section");
    if (source.id) section.id = String(source.id);
    if (source.heading) section.append(element("h2", "", source.heading));
    appendContent(section, source.content);
    flow.append(section);
  }
  return flow;
}

export function createProductFaq({ items = [] } = {}) {
  const list = element("div", "inator-faq-list");
  for (const [index, source] of items.entries()) {
    if (!source || typeof source !== "object") throw new TypeError(`items[${index}] is required.`);
    const details = element("details");
    if (source.open) details.open = true;
    details.append(element("summary", "", requiredText(source.question, `items[${index}].question`)));
    const answer = element("div", "inator-faq-answer");
    appendContent(answer, source.answer);
    details.append(answer);
    list.append(details);
  }
  return list;
}

function createSubsectionTabs(panel, sectionId, subsections) {
  if (!subsections.length) return null;
  panel.classList.add("inator-help-panel--subsections");
  const tabs = element("nav", "inator-docs-subtabs");
  tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", `${sectionId} topics`);
  const panels = [];
  subsections.forEach((subsection, index) => {
    const id = `inator-docs-${sectionId}-${subsection.id}`;
    const button = element("button", "", subsection.label);
    button.type = "button"; button.id = `${id}-tab`; button.setAttribute("role", "tab"); button.setAttribute("aria-controls", id); button.setAttribute("aria-selected", String(index === 0)); if (index) button.tabIndex = -1;
    const subpanel = element("section", "inator-docs-subpanel"); subpanel.id = id; subpanel.setAttribute("role", "tabpanel"); subpanel.setAttribute("aria-labelledby", button.id); subpanel.hidden = index !== 0; appendContent(subpanel, subsection.content);
    tabs.append(button); panels.push(subpanel);
  });
  panel.append(tabs, ...panels);
  return createTabController({ root: panel });
}

function recordShelf(basePath = "/", recordIds) {
  const section = element("section", "inator-record-shelf");
  section.setAttribute("aria-labelledby", "inator-record-shelf-title");
  const header = element("header");
  header.append(element("p", "inator-information-kicker", "The work and the proof"), element("h2", "", "Inspect the records behind the promise."));
  header.lastChild.id = "inator-record-shelf-title";
  const links = element("div", "inator-record-links");
  const available = new Set(normalizeProductAboutRecordIds(recordIds));
  for (const record of PRODUCT_ABOUT_RECORDS.filter(({ id }) => available.has(id))) {
    const link = element("a", `inator-record-link inator-record-link--${record.id}`);
    link.href = `${basePath}${record.id}/`;
    link.innerHTML = `<svg viewBox="0 0 48 48" aria-hidden="true">${record.icon}</svg><span><strong>${record.label}</strong><small>${record.description}</small></span>`;
    links.append(link);
  }
  section.append(header, links);
  return section;
}

function ecosystemIntroduction() {
  const introduction = element("div", "inator-ecosystem-intro");
  introduction.innerHTML = `<header class="inator-ecosystem-intro__hero"><p class="inator-information-kicker">Common Ground for independent tools</p><h1>Software should show its work.</h1><p>An Inator is allowed to be small, peculiar, and deeply specialized. It is not allowed to be vague about what it did, where the evidence came from, what remains uncertain, or who gets the final say.</p></header><div class="inator-ecosystem-intro__ethic"></div><footer class="inator-ecosystem-intro__systems"><p><strong>Commons supplies the common machinery:</strong> accessible responsive shells, workspaces, action bars, dialogs, artifact inspectors, citations, history, backups, diagnostics, deployment manifests, and conformance tests.</p><a href="https://inator.com">Explore the Inator ecosystem</a></footer>`;
  const principles = [
    { icon: "export", title: "Your work stays yours.", copy: "Local-first workspaces, portable exports, explicit network boundaries, and verified backups keep custody with the person doing the work. Products can travel to ordinary web hosting when their job no longer requires local computation." },
    { icon: "trust", title: "Claims travel with proof.", copy: "Provenance, citations, limitations, reproducible artifacts, and visible failures stay attached to results. Trust is something a person can inspect, copy, download, and challenge—not a badge the interface awards itself." },
    { icon: "reviewer", title: "People remain authoritative.", copy: "Durable pipelines can automate long work, resume safely, retain superseded attempts, and stop at a human decision. Machine assistance proposes and records; it does not quietly rewrite judgment." }
  ];
  const ethic = introduction.querySelector(".inator-ecosystem-intro__ethic");
  principles.forEach(({ icon, title, copy }) => {
    const section = element("section");
    const iconMount = element("span", `inator-ecosystem-intro__principle-icon inator-ecosystem-intro__principle-icon--${icon}`);
    iconMount.append(createInatorIcon(icon));
    section.append(iconMount, element("h2", "", title), element("p", "", copy));
    ethic.append(section);
  });
  return introduction;
}

export function createProductAboutPage({ root, productLabel, productContent, citationContent, about = null, citationRegistry = null, trust = null, trustArtifacts = null, trustGeneratedLedger = null, trustIntroContent = null, basePath = "/", recordIds } = {}) {
  if (!root || !productContent) throw new TypeError("createProductAboutPage requires root and productContent.");
  if (!Array.isArray(recordIds)) throw new TypeError("createProductAboutPage requires an explicit recordIds array.");
  root.classList.add("inator-information-page", "inator-about-page");
  const tabs = element("nav", "inator-information-tabs inator-tabs");
  tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", "About");
  tabs.innerHTML = `<button type="button" role="tab" id="inator-about-product-tab" aria-controls="inator-about-product" aria-selected="true">${productLabel || "This Inator"}</button><button type="button" role="tab" id="inator-about-ecosystem-tab" aria-controls="inator-about-ecosystem" aria-selected="false" tabindex="-1">Inator ecosystem</button>`;
  const product = element("section"); product.id = "inator-about-product"; product.setAttribute("role", "tabpanel"); product.setAttribute("aria-labelledby", "inator-about-product-tab"); product.append(productContent);
  if (citationContent) product.append(citationContent);
  let trustDisclosure = null; let citationDisclosure = null;
  if (trust || about) {
    const disclosures = element("div", "inator-about-disclosures"); product.append(disclosures);
    if (trust) { const trustMount = element("div"); disclosures.append(trustMount); trustDisclosure = mountAboutTrust({ mount: trustMount, trust, artifacts: trustArtifacts, generatedLedger: trustGeneratedLedger, introContent: trustIntroContent }); }
    if (about) { const citationMount = element("div"); disclosures.append(citationMount); citationDisclosure = mountAboutCitation({ mount: citationMount, about, citationRegistry }); }
  }
  const availableRecordIds = normalizeProductAboutRecordIds(recordIds);
  if (availableRecordIds.length) product.append(recordShelf(basePath, availableRecordIds));
  const ecosystem = element("section"); ecosystem.id = "inator-about-ecosystem"; ecosystem.setAttribute("role", "tabpanel"); ecosystem.setAttribute("aria-labelledby", "inator-about-ecosystem-tab"); ecosystem.hidden = true;
  ecosystem.append(ecosystemIntroduction());
  root.replaceChildren(tabs, product, ecosystem);
  const initialTabId = aboutTabFromLocation() === "ecosystem" ? "inator-about-ecosystem-tab" : "inator-about-product-tab";
  const tabsController = createTabController({ root, initialTabId, onSelect(tab) {
    writeAboutTabToLocation(tab.id === "inator-about-ecosystem-tab" ? "ecosystem" : "product");
  } });
  return Object.freeze({ ...tabsController, trustDisclosure, citationDisclosure, citationTrust: citationDisclosure, destroy() { trustDisclosure?.destroy(); citationDisclosure?.destroy(); } });
}

export function createProductDocsPage({ root, docs, initialSection = "start", onSelect = null } = {}) {
  if (!root) throw new TypeError("createProductDocsPage requires root.");
  const manifest = docs?.schema === PRODUCT_DOCS_SCHEMA ? docs : defineProductDocs(docs);
  root.classList.add("inator-information-page", "inator-help-page");
  const header = element("header", "inator-help-heading");
  header.innerHTML = `<div><p>${manifest.productLabel} help</p><h1>${manifest.heading}</h1><span>${manifest.introduction}</span></div>`;
  const tabs = element("nav", "inator-information-tabs inator-tabs"); tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", "Help sections");
  root.replaceChildren(header, tabs);
  const nestedControllers = [];
  PRODUCT_DOCS_SECTIONS.forEach((section, index) => {
    const entry = manifest.sections[section.id];
    const id = `inator-help-${section.id}`;
    const button = element("button", "", section.label);
    button.type = "button"; button.id = `${id}-tab`; button.setAttribute("role", "tab"); button.setAttribute("aria-controls", id); button.setAttribute("aria-selected", String(index === 0)); if (index) button.tabIndex = -1;
    const panel = element("section", "inator-help-panel"); panel.id = id; panel.setAttribute("role", "tabpanel"); panel.setAttribute("aria-labelledby", button.id); panel.hidden = index !== 0;
    if (entry.subsections.length) nestedControllers.push(createSubsectionTabs(panel, section.id, entry.subsections));
    else appendContent(panel, entry.content);
    tabs.append(button); root.append(panel);
  });
  const tabsController = createTabController({
    root,
    initialTabId: `inator-help-${initialSection}-tab`,
    onSelect(tab) { onSelect?.(tab.id.replace(/^inator-help-/, "").replace(/-tab$/, ""), tab); }
  });
  return Object.freeze({ manifest, tabsController, nestedControllers: Object.freeze(nestedControllers.filter(Boolean)) });
}

export function createProductHelpPage({ root, productLabel = "Inator", heading, introduction, sections = [] } = {}) {
  const byId = Object.fromEntries(sections.map((section) => [section.id, section]));
  const fallback = sections[0]?.content;
  return createProductDocsPage({ root, docs: { productLabel, heading, introduction, sections: {
    start: { content: byId.start?.content || byId.guide?.content || fallback },
    tasks: { content: byId.tasks?.content || byId.documentation?.content || fallback },
    reference: { content: byId.reference?.content || byId.documentation?.content || fallback },
    faq: { content: byId.faq?.content || fallback }
  } } });
}
