import { createDialogSurface } from "./dialog.js";
import { setInatorTooltip } from "./tooltip.js";

const TERMINAL_FAILURES = new Set(["failed", "blocked"]);

export function notificationRecoveryGuidance({ userAgent = globalThis.navigator?.userAgent || "", platform = globalThis.navigator?.platform || "", secureContext = globalThis.isSecureContext } = {}) {
  const agent = String(userAgent);
  const system = /Win/i.test(platform) ? "Windows" : /Linux/i.test(platform) ? "Linux" : /Mac/i.test(platform) ? "macOS" : "your operating system";
  const browser = /Edg\//i.test(agent) ? "Edge" : /Firefox\//i.test(agent) ? "Firefox" : /Chrome\//i.test(agent) && !/Edg\//i.test(agent) ? "Chrome" : /Safari\//i.test(agent) && !/Chrome\//i.test(agent) ? "Safari" : "your browser";
  const browserStep = browser === "Safari"
    ? "In Safari, open Settings > Websites > Notifications and allow this site if it is listed."
    : browser === "Firefox"
      ? "In Firefox, open Settings > Privacy & Security > Permissions > Notifications > Settings and allow this site."
      : browser === "Chrome"
        ? "In Chrome, open Settings > Privacy and security > Site settings > Notifications and allow this site."
        : browser === "Edge"
          ? "In Edge, open Settings > Cookies and site permissions > Notifications and allow this site."
          : "Open this browser's site-notification settings and allow this site.";
  const systemStep = system === "macOS"
    ? `In System Settings > Notifications, allow notifications for ${browser}.`
    : system === "Windows"
      ? `In Settings > System > Notifications, enable notifications for ${browser}.`
      : system === "Linux"
        ? `In your desktop notification settings, enable notifications for ${browser}.`
        : `In your operating-system notification settings, enable notifications for ${browser}.`;
  return Object.freeze({
    browser,
    system,
    lead: secureContext === false
      ? "This address is not eligible for browser notifications. Use the installed app's native alerts, or open the hosted app over HTTPS."
      : `${browser} has not granted notification permission for this site.`,
    steps: secureContext === false ? [systemStep] : [browserStep, systemStep, "Return here and choose Try again."]
  });
}

function counts(snapshot = {}) {
  const units = Array.isArray(snapshot.units) ? snapshot.units : [];
  return {
    failed: units.filter(unit => unit.status === "failed").length,
    blocked: units.filter(unit => unit.status === "blocked").length,
    running: units.filter(unit => unit.status === "running").length,
    actionable: units.filter(unit => ["waiting", "queued", "running", "stopping", "paused", "failed", "blocked"].includes(unit.status)).length
  };
}

export function pipelineOperationalState({ pipeline = {}, machinePressure = {}, services = {} } = {}) {
  pipeline ||= {};
  machinePressure ||= {};
  services ||= {};
  const blockedLanes = Array.isArray(machinePressure.blockedLanes) ? machinePressure.blockedLanes : [];
  const supervisorUnavailable = services.supervisor?.available === false;
  return Object.freeze({
    state: String(pipeline.state || "unknown"),
    supervisorUnavailable,
    supervisorError: supervisorUnavailable ? String(services.supervisor?.error || "Supervisor is unavailable.") : null,
    pressureReason: blockedLanes.length ? String(machinePressure.reason || "machine-pressure") : null,
    blockedLanes: [...blockedLanes],
    ...counts(pipeline)
  });
}

export function pipelineNotificationTransitions(previous, next, { productName = "Inator" } = {}) {
  if (!previous) return [];
  const events = [];
  if (!previous.supervisorUnavailable && next.supervisorUnavailable) events.push({ id: "supervisor-unavailable", tone: "error", title: `${productName} coordination unavailable`, body: "The shared Supervisor cannot be reached. Pipeline work cannot be safely claimed until it recovers." });
  if (previous.supervisorUnavailable && !next.supervisorUnavailable) events.push({ id: "supervisor-recovered", tone: "success", title: `${productName} coordination restored`, body: "The shared Supervisor is reachable again and eligible work can continue." });
  const previousPressure = userFacingPressure(previous);
  const nextPressure = userFacingPressure(next);
  if (!previousPressure && nextPressure) events.push({ id: `pressure:${nextPressure}`, tone: "warning", title: `${productName} work deferred`, body: "Machine protection is delaying new heavy work. It will resume automatically when conditions recover." });
  if (previousPressure && !nextPressure) events.push({ id: `pressure-cleared:${previousPressure}`, tone: "success", title: `${productName} work resumed`, body: "Machine conditions recovered and waiting work is eligible to continue." });
  if (previous.state !== next.state && next.state === "stopped") events.push({ id: "pipeline-stopped", tone: "error", title: `${productName} pipeline stopped`, body: "The pipeline is no longer running. Open Pipeline to inspect its state." });
  if (previous.state !== next.state && next.state === "running" && !previous.pressureReason) events.push({ id: "pipeline-running", tone: "success", title: `${productName} pipeline resumed`, body: "Pipeline work is running again." });
  if (previous.state !== next.state && next.state === "complete") events.push({ id: "pipeline-complete", tone: "success", title: `${productName} pipeline complete`, body: "All currently eligible work has finished." });
  if (next.failed > previous.failed) events.push({ id: `failed:${next.failed}`, tone: "error", title: `${productName} pipeline needs attention`, body: `${next.failed} ${next.failed === 1 ? "activity has" : "activities have"} failed.` });
  if (next.blocked > previous.blocked && next.state !== "running" && next.running === 0) events.push({ id: `blocked:${next.blocked}`, tone: "warning", title: `${productName} pipeline needs review`, body: `${next.blocked} ${next.blocked === 1 ? "activity is" : "activities are"} blocked.` });
  return events;
}

function userFacingPressure(current = {}) {
  // CPU saturation is expected while an authorized local-model lease is doing
  // useful work, and it commonly outlives that lease for a short handoff gap.
  // Admission may still defer the next heavy claim and diagnostics retain the
  // evidence, but a self-clearing CPU sample is not an actionable user alert.
  // Thermal, memory, and power pressure remain user-facing.
  if (current.pressureReason === "machine-cpu-pressure") return null;
  return current.pressureReason || null;
}

export function currentPipelineNotifications(current, { productName = "Inator" } = {}) {
  const events = [];
  if (current.supervisorUnavailable) events.push({ id: "supervisor-unavailable", tone: "error", title: `${productName} coordination unavailable`, body: "The shared Supervisor cannot be reached. Pipeline work cannot be safely claimed until it recovers." });
  const pressure = userFacingPressure(current);
  if (pressure) events.push({ id: `pressure:${pressure}`, tone: "warning", title: `${productName} work deferred`, body: "Machine protection is delaying new heavy work. It will resume automatically when conditions recover." });
  if (current.state === "stopped" && current.actionable) events.push({ id: "pipeline-stopped", tone: "error", title: `${productName} pipeline stopped`, body: "The pipeline is not running while actionable work remains." });
  if (current.failed) events.push({ id: `failed:${current.failed}`, tone: "error", title: `${productName} pipeline needs attention`, body: `${current.failed} ${current.failed === 1 ? "activity has" : "activities have"} failed.` });
  // A retained review item is row-level work, not an operational emergency
  // while the queue is productively running. Promote it to the global signal
  // only when no activity is running and the pipeline has stopped advancing.
  if (current.blocked && current.state !== "running" && current.running === 0) events.push({ id: `blocked:${current.blocked}`, tone: "warning", title: `${productName} pipeline needs review`, body: `${current.blocked} ${current.blocked === 1 ? "activity is" : "activities are"} blocked.` });
  return events;
}

export function createPipelineNotificationCenter({ mount, productName = "Inator", notification = globalThis.Notification, nativeAlerts = null, showSystemAlertTester = false, maxVisible = 4, pipelineHref = "/workspace/pipeline/" } = {}) {
  if (!mount) throw new TypeError("mount is required.");
  const root = document.createElement("section"); root.className = "inator-pipeline-signals"; root.setAttribute("aria-label", "Pipeline notifications");
  const live = document.createElement("div"); live.className = "inator-pipeline-signals__live"; live.setAttribute("role", "status"); live.setAttribute("aria-live", "polite");
  const history = document.createElement("ol"); history.className = "inator-pipeline-signals__history";
  const openPipeline = document.createElement("a"); openPipeline.className = "inator-pipeline-signals__open"; openPipeline.href = pipelineHref; openPipeline.textContent = "Open Pipeline";
  const permission = document.createElement("button"); permission.type = "button"; permission.className = "inator-pipeline-signals__permission"; permission.textContent = "Enable system alerts";
  const events = []; let current = null;
  const permissionState = () => nativeAlerts ? "native" : notification?.permission || "unsupported";
  const recovery = nativeAlerts ? {
    lead: `${productName} could not obtain macOS notification permission.`,
    steps: [`In System Settings > Notifications, allow notifications for ${productName}.`, "Return here and choose Try again."]
  } : notificationRecoveryGuidance();
  const permissionInstructions = document.createElement("div");
  const permissionLead = document.createElement("p"); permissionLead.textContent = recovery.lead;
  const permissionSteps = document.createElement("ol");
  for (const instruction of recovery.steps) { const item = document.createElement("li"); item.textContent = instruction; permissionSteps.append(item); }
  const permissionStatus = document.createElement("p"); permissionStatus.className = "inator-system-alerts-dialog__status"; permissionStatus.setAttribute("role", "status"); permissionStatus.setAttribute("aria-live", "polite");
  permissionInstructions.append(permissionLead, permissionSteps, permissionStatus);
  const dismissPermission = document.createElement("button"); dismissPermission.type = "button"; dismissPermission.dataset.dialogClose = ""; dismissPermission.textContent = "Not now";
  const retryPermission = document.createElement("button"); retryPermission.type = "button"; retryPermission.className = "primary"; retryPermission.textContent = "Try again";
  const permissionDialog = createDialogSurface({ context: "Pipeline notifications", title: "Enable system alerts", description: "Allow macOS notifications for important pipeline changes", bodyContent: permissionInstructions, footerContent: [dismissPermission, retryPermission] });
  const sendSystemAlert = async ({ title, body, tag }) => {
    if (nativeAlerts) return nativeAlerts.notify({ title, body, tag });
    if (notification && permissionState() === "granted") return new notification(title, { body, tag });
    return null;
  };
  const notifyPermissionGranted = () => sendSystemAlert({ title: `${productName} alerts enabled`, body: "Future important pipeline changes can appear as system notifications.", tag: "inator-pipeline:permission" });
  const requestPermission = async () => {
    if (nativeAlerts) {
      try {
        await nativeAlerts.request();
        await notifyPermissionGranted();
        permissionStatus.textContent = "System alerts are enabled.";
        permissionDialog.close("granted");
        renderPermission(); render(); return "granted";
      } catch (error) {
        permissionStatus.textContent = error?.message || "System alerts could not be enabled.";
        permissionDialog.open(permission);
        renderPermission(); render();
        throw error;
      }
    }
    let result = permissionState();
    if (result === "default") result = await notification?.requestPermission?.();
    if (result === "granted") { notifyPermissionGranted(); permissionStatus.textContent = "System alerts are enabled."; permissionDialog.close("granted"); }
    else permissionStatus.textContent = "Notifications are still blocked. Check both Safari and macOS notification settings, then try again.";
    renderPermission(); render(); return result || "unsupported";
  };
  const renderPermission = () => {
    const state = permissionState();
    permission.hidden = !showSystemAlertTester || (!nativeAlerts && (!notification || state === "granted"));
    permission.disabled = false;
    permission.textContent = nativeAlerts ? "Test system alerts" : state === "denied" ? "Fix system alerts" : "Enable system alerts";
    setInatorTooltip(permission, state === "denied" ? "Allow notifications for this site in browser settings." : "Allow operating-system notifications for future pipeline changes while this page is in the background.");
  };
  const render = () => { history.replaceChildren(...events.slice(0, maxVisible).map(event => { const item = document.createElement("li"); item.dataset.tone = event.tone; const title = document.createElement("strong"); title.textContent = event.title; const body = document.createElement("span"); body.textContent = event.body; item.append(title, body); return item; })); root.hidden = !events.length; const tone = events.some(event => event.tone === "error") ? "error" : events.some(event => event.tone === "warning") ? "warning" : events.length ? "success" : ""; root.dataset.tone = tone; const attentionStatus = current?.failed ? "failed" : current?.blocked ? "blocked" : null; const destination = new URL(pipelineHref, globalThis.location?.href || "http://localhost/"); if (attentionStatus) destination.searchParams.set("status", attentionStatus); else destination.searchParams.delete("status"); openPipeline.href = `${destination.pathname}${destination.search}${destination.hash}`; const mark = document.querySelector(".inator-product-brand-mark"); let indicator = mark?.querySelector("[data-pipeline-signal]"); if (tone && mark) { if (!indicator) { indicator = document.createElement("span"); indicator.className = "inator-product-brand-status"; indicator.dataset.pipelineSignal = "true"; indicator.setAttribute("role", "status"); mark.append(indicator); } indicator.dataset.tone = tone; indicator.setAttribute("aria-label", events[0]?.title || "Pipeline status"); setInatorTooltip(indicator, events[0]?.body || ""); } else indicator?.remove(); };
  permission.addEventListener("click", async () => {
    if (!nativeAlerts && permissionState() === "denied") { permissionStatus.textContent = ""; permissionDialog.open(permission); }
    else await requestPermission();
  });
  retryPermission.addEventListener("click", requestPermission);
  root.append(live, openPipeline, history, permission); mount.append(root); renderPermission(); render();
  return Object.freeze({
    root,
    async requestSystemPermission() { return requestPermission(); },
    update(value) {
      const next = pipelineOperationalState(value);
      const transitions = current ? pipelineNotificationTransitions(current, next, { productName }) : [];
      const announce = Boolean(current);
      current = next;
      events.splice(0, events.length, ...currentPipelineNotifications(next, { productName }));
      for (const event of transitions) {
        live.textContent = `${event.title}. ${event.body}`;
        if (announce && (nativeAlerts || (notification && permissionState() === "granted")) && document.visibilityState !== "visible") void sendSystemAlert({ title: event.title, body: event.body, tag: `inator-pipeline:${event.id}` });
      }
      if (!transitions.length && events[0]) live.textContent = `${events[0].title}. ${events[0].body}`;
      render(); return transitions;
    },
    destroy() { permissionDialog.destroy(); root.remove(); }
  });
}

export const PIPELINE_NOTIFICATION_FAILURE_STATES = Object.freeze([...TERMINAL_FAILURES]);
