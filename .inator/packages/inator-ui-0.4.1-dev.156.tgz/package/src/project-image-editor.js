import { createDialogSurface } from "./dialog.js";

const text = (value) => String(value ?? "").trim();

function imageCandidate(candidate = {}) {
  const assetId = text(candidate.assetId || candidate.id);
  const src = candidate.src || candidate.path;
  if (!assetId || !src) return null;
  return Object.freeze({
    assetId,
    src: String(src),
    alt: String(candidate.alt || ""),
    label: text(candidate.label || candidate.person || candidate.alt || assetId),
    provenance: text(candidate.provenance || candidate.provenanceRef)
  });
}

function choice({ mode, assetId = "", image = null, label, detail = "" }) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "inator-project-image-choice";
  button.dataset.imageMode = mode;
  button.dataset.assetId = assetId;
  if (image?.src) {
    const preview = document.createElement("img");
    preview.src = image.src;
    preview.alt = image.alt || "";
    button.append(preview);
  } else {
    const fallback = document.createElement("span");
    fallback.className = "inator-project-image-choice__automatic";
    fallback.setAttribute("aria-hidden", "true");
    fallback.textContent = "A";
    button.append(fallback);
  }
  const copy = document.createElement("span");
  copy.className = "inator-project-image-choice__copy";
  const name = document.createElement("strong");
  name.textContent = label;
  copy.append(name);
  if (detail) {
    const note = document.createElement("small");
    note.textContent = detail;
    copy.append(note);
  }
  button.append(copy);
  return button;
}

export function createProjectImageEditor({
  project,
  vocabulary = "Project",
  automaticImage = null,
  candidates = [],
  selection = null,
  accept = "image/*",
  onSave,
  mount = document.body
} = {}) {
  if (typeof onSave !== "function") throw new TypeError("A Project image editor requires onSave.");
  const normalized = candidates.map(imageCandidate).filter(Boolean);
  let selected = selection?.mode === "asset" && text(selection.assetId)
    ? { mode: "asset", assetId: text(selection.assetId) }
    : { mode: "automatic" };
  let stagedFile = null;
  let stagedUrl = "";

  const body = document.createElement("div");
  body.className = "inator-project-image-editor";
  const explanation = document.createElement("p");
  explanation.className = "inator-project-image-editor__explanation";
  explanation.textContent = `Use the ${vocabulary.toLocaleLowerCase()}'s automatic image, choose a recorded asset, or supply your own. Your choice overrides the automatic image until you restore Automatic.`;
  const choices = document.createElement("div");
  choices.className = "inator-project-image-choices";
  choices.setAttribute("role", "list");
  const automatic = choice({
    mode: "automatic",
    image: automaticImage,
    label: "Automatic",
    detail: automaticImage?.label || "Chosen by this app"
  });
  choices.append(automatic, ...normalized.map((candidate) => choice({
    mode: "asset",
    assetId: candidate.assetId,
    image: candidate,
    label: candidate.label,
    detail: candidate.provenance || "Recorded project asset"
  })));

  const upload = document.createElement("label");
  upload.className = "inator-project-image-upload";
  upload.tabIndex = 0;
  const uploadTitle = document.createElement("strong");
  uploadTitle.textContent = "Choose, drop, or paste an image";
  const uploadDetail = document.createElement("span");
  uploadDetail.textContent = "Your image becomes the explicit override.";
  const input = document.createElement("input");
  input.type = "file";
  input.accept = accept;
  input.hidden = true;
  upload.append(uploadTitle, uploadDetail, input);
  const status = document.createElement("p");
  status.className = "inator-project-image-editor__status";
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");
  body.append(explanation, choices, upload, status);

  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.className = "secondary";
  cancel.textContent = "Cancel";
  cancel.dataset.dialogClose = "";
  const save = document.createElement("button");
  save.type = "button";
  save.className = "primary";
  save.textContent = "Save image";
  let surface = null;
  surface = createDialogSurface({
    mount,
    context: `${vocabulary} image`,
    title: text(project?.name) || `Choose ${vocabulary.toLocaleLowerCase()} image`,
    description: "Automatic suggestions never outrank a choice you make.",
    bodyContent: body,
    footerContent: [cancel, save],
    className: "inator-project-image-dialog",
    wide: true,
    resizable: true,
    controllerOptions: { onClose: () => { cleanup(); queueMicrotask(() => surface?.destroy()); } }
  });

  function cleanup() {
    if (stagedUrl) URL.revokeObjectURL(stagedUrl);
    stagedUrl = "";
    stagedFile = null;
  }
  function markSelection() {
    choices.querySelectorAll("[data-image-mode]").forEach((button) => {
      const active = button.dataset.imageMode === selected.mode
        && (selected.mode !== "asset" || button.dataset.assetId === selected.assetId);
      button.classList.toggle("is-selected", active);
      button.setAttribute("aria-pressed", String(active));
    });
    upload.classList.toggle("is-selected", selected.mode === "upload");
  }
  function stage(file) {
    if (!file || !String(file.type).startsWith("image/")) {
      status.textContent = "Choose an image file.";
      return;
    }
    if (stagedUrl) URL.revokeObjectURL(stagedUrl);
    stagedFile = file;
    stagedUrl = URL.createObjectURL(file);
    selected = { mode: "upload", file };
    upload.style.setProperty("--inator-project-upload-preview", `url("${stagedUrl.replaceAll('"', '\\"')}")`);
    uploadTitle.textContent = file.name || "Pasted image";
    uploadDetail.textContent = "Ready to save as your override";
    status.textContent = `${file.name || "Image"} selected.`;
    markSelection();
  }
  choices.addEventListener("click", (event) => {
    const button = event.target.closest("[data-image-mode]");
    if (!button) return;
    selected = button.dataset.imageMode === "asset"
      ? { mode: "asset", assetId: button.dataset.assetId }
      : { mode: "automatic" };
    markSelection();
  });
  input.addEventListener("change", () => stage(input.files?.[0]));
  upload.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); input.click(); }
  });
  for (const eventName of ["dragenter", "dragover"]) upload.addEventListener(eventName, (event) => { event.preventDefault(); upload.classList.add("is-dragging"); });
  for (const eventName of ["dragleave", "drop"]) upload.addEventListener(eventName, (event) => { event.preventDefault(); upload.classList.remove("is-dragging"); });
  upload.addEventListener("drop", (event) => stage(event.dataTransfer?.files?.[0]));
  surface.dialog.addEventListener("paste", (event) => {
    const file = [...(event.clipboardData?.files || [])].find((item) => String(item.type).startsWith("image/"));
    if (file) { event.preventDefault(); stage(file); }
  });
  save.addEventListener("click", async () => {
    surface.controller.setBusy(true, "Saving image…");
    status.textContent = "Saving image…";
    try {
      await onSave(selected.mode === "upload" ? { mode: "upload", file: stagedFile } : { ...selected });
      surface.close("save", { force: true });
    } catch (error) {
      surface.controller.setBusy(false);
      status.textContent = error?.message || "Could not save this image.";
    }
  });
  markSelection();
  return Object.freeze({ ...surface, open: surface.open, selection: () => ({ ...selected }) });
}
