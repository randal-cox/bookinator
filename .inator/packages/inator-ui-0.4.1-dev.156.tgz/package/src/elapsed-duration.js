const SECOND = 1;
const MINUTE = 60;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;

const COMPACT_UNITS = Object.freeze([
  [365 * DAY, "y"],
  [30 * DAY, "mo"],
  [DAY, "d"],
  [HOUR, "h"],
  [MINUTE, "m"],
  [SECOND, "s"]
]);

function compactParts(values, maxParts) {
  return values.filter(([, value]) => value > 0).slice(0, maxParts).map(([suffix, value]) => `${value}${suffix}`).join(" ") || "0s";
}

export function formatElapsedDuration(seconds, { maxParts = 2 } = {}) {
  if (!Number.isFinite(seconds)) return "Duration unknown";
  let remaining = Math.max(0, Math.floor(seconds));
  const values = [];
  for (const [size, suffix] of COMPACT_UNITS) {
    const value = Math.floor(remaining / size);
    values.push([suffix, value]);
    remaining -= value * size;
  }
  return compactParts(values, Math.max(1, maxParts));
}

function addUtcMonthsClamped(source, months) {
  const result = new Date(source);
  const day = result.getUTCDate();
  result.setUTCDate(1);
  result.setUTCMonth(result.getUTCMonth() + months);
  const lastDay = new Date(Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)).getUTCDate();
  result.setUTCDate(Math.min(day, lastDay));
  return result;
}

export function formatCalendarElapsed(startValue, endValue, { maxParts = 2 } = {}) {
  const start = new Date(startValue); const end = new Date(endValue);
  if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) return "Duration unknown";
  if (end < start) return formatCalendarElapsed(end, start, { maxParts });
  let calendarMonths = (end.getUTCFullYear() - start.getUTCFullYear()) * 12 + end.getUTCMonth() - start.getUTCMonth();
  let cursor = addUtcMonthsClamped(start, calendarMonths);
  while (cursor > end && calendarMonths > 0) cursor = addUtcMonthsClamped(start, --calendarMonths);
  const remainingSeconds = Math.max(0, Math.floor((end - cursor) / 1000));
  const years = Math.floor(calendarMonths / 12); const months = calendarMonths % 12;
  const days = Math.floor(remainingSeconds / DAY);
  const hours = Math.floor((remainingSeconds % DAY) / HOUR);
  const minutes = Math.floor((remainingSeconds % HOUR) / MINUTE);
  const seconds = remainingSeconds % MINUTE;
  return compactParts([["y", years], ["mo", months], ["d", days], ["h", hours], ["m", minutes], ["s", seconds]], Math.max(1, maxParts));
}
