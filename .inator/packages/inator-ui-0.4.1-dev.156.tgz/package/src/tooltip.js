let stylesInstalled = false;

function installStyles() {
  if (stylesInstalled || typeof document === "undefined") return;
  stylesInstalled = true;
  const style = document.createElement("style");
  style.dataset.inatorTooltipStyles = "true";
  style.textContent = `
[data-inator-tooltip]{position:relative}
[data-inator-tooltip]::after{content:attr(data-inator-tooltip);position:absolute;z-index:10000;left:50%;top:calc(100% + 8px);width:max-content;max-width:min(32rem,calc(100vw - 32px));padding:8px 10px;border:1px solid color-mix(in srgb,currentColor 22%,transparent);border-radius:8px;background:#10243f;color:#fff;font:500 .875rem/1.35 system-ui,-apple-system,sans-serif;text-align:left;white-space:normal;box-shadow:0 8px 28px rgba(8,24,45,.24);opacity:0;visibility:hidden;pointer-events:none;transform:translate(-50%,-3px);transition:opacity .12s ease .45s,transform .12s ease .45s,visibility 0s linear .57s}
[data-inator-tooltip]:hover::after,[data-inator-tooltip]:focus-visible::after,[data-inator-tooltip]:focus-within::after{opacity:1;visibility:visible;transform:translate(-50%,0);transition-delay:.45s,.45s,0s}
@media (prefers-reduced-motion:reduce){[data-inator-tooltip]::after{transition:none}}
`;
  document.head.append(style);
}

export function setInatorTooltip(node, text) {
  if (!node?.setAttribute) throw new TypeError("An Inator tooltip requires a DOM element.");
  installStyles();
  node.removeAttribute("title");
  const value = String(text ?? "").trim();
  if (!value) {
    delete node.dataset.inatorTooltip;
    node.removeAttribute("aria-description");
    return node;
  }
  node.dataset.inatorTooltip = value;
  node.setAttribute("aria-description", value);
  return node;
}
