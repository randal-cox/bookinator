export function createPageIntro({ title, description, summary = null, className = "" } = {}) {
  if (!title) throw new TypeError("createPageIntro requires a title.");
  const header = document.createElement("header");
  header.className = ["inator-page-intro", className].filter(Boolean).join(" ");
  const heading = document.createElement("h1");
  heading.textContent = title;
  const copy = document.createElement("div");
  copy.className = "inator-page-intro__copy";
  const body = document.createElement("p");
  body.textContent = description || "";
  copy.append(body);
  let status = null;
  if (summary != null) {
    status = document.createElement("p");
    status.className = "inator-page-intro__summary";
    status.textContent = summary;
    copy.append(status);
  }
  header.append(heading, copy);
  return { element: header, heading, copy, description: body, summary: status };
}
