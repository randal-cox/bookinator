import { createWorkspaceBackupView } from "./workspace-backup.js";
import { createWorkspaceErrorsView } from "./workspace-errors.js";
import { createWorkspaceIdentityView } from "./workspace-identity.js";

export const WORKSPACE_BASE_CAPABILITY_IDS = Object.freeze([
  "identity",
  "workspace",
  "errors"
]);

const BASE = Object.freeze({
  identity: Object.freeze({
    id: "identity",
    label: "Identity",
    detail: "Names and roles used for attribution",
    icon: "identity",
    route: "workspace-identity",
    href: "/workspace/identity/",
    order: 100,
    required: true,
    createView: ({ mount, adapter = {} }) => createWorkspaceIdentityView({ mount, ...adapter })
  }),
  workspace: Object.freeze({
    id: "workspace",
    label: "Backup",
    detail: "Back up, inspect, download, and restore local application state",
    icon: "archive",
    route: "workspace",
    href: "/workspace/",
    order: 200,
    required: true,
    createView: ({ mount, adapter = {} }) => createWorkspaceBackupView({ mount, ...adapter })
  }),
  errors: Object.freeze({
    id: "errors",
    label: "Errors",
    detail: "Inspect retained local diagnostic incidents",
    icon: "inspect",
    route: "workspace-errors",
    href: "/workspace/errors/",
    order: 300,
    required: false,
    enabled: false,
    requiredRoles: ["developer"],
    createView: ({ mount, adapter = {} }) => createWorkspaceErrorsView({ mount, ...adapter })
  })
});

function text(value) {
  return String(value ?? "").trim();
}

function normalizeStatus(status) {
  if (!status) return null;
  const label = text(typeof status === "string" ? status : status.label);
  return label ? {
    label,
    tone: text(status.tone || "neutral")
  } : null;
}

function normalizeError(error) {
  const count = Number(error?.count);
  return Number.isSafeInteger(count) && count > 0
    ? {
        count,
        label: text(error.label) || count + " unresolved " + (count === 1 ? "incident" : "incidents")
      }
    : null;
}

function normalizeCapability(input, fallback = {}, sequence = 0) {
  const capability = { ...fallback, ...input };
  const id = text(capability.id);
  const label = text(capability.label);
  const route = text(capability.route || id);
  const href = text(capability.href);
  if (!id || !label || !route || !href) {
    throw new TypeError("Workspace capabilities require stable id, label, route, and href.");
  }
  if (typeof capability.createView !== "function") {
    throw new TypeError("Workspace capability " + id + " requires a render/controller factory.");
  }
  return Object.freeze({
    ...capability,
    id,
    label,
    detail: text(capability.detail),
    icon: text(capability.icon),
    route,
    href,
    order: Number.isFinite(capability.order) ? capability.order : 1000 + sequence,
    required: Boolean(capability.required),
    enabled: capability.enabled !== false,
    requiredRoles: [...new Set((capability.requiredRoles || []).map(text).filter(Boolean))],
    status: normalizeStatus(capability.status),
    error: normalizeError(capability.error),
    menu: capability.menu ? Object.freeze({
      id: text(capability.menu.id || capability.id),
      label: text(capability.menu.label || capability.label),
      detail: text(capability.menu.detail || capability.detail),
      icon: text(capability.menu.icon || capability.icon),
      href: text(capability.menu.href || capability.href),
      route: text(capability.menu.route || capability.route)
    }) : null,
    createView: capability.createView
  });
}

function allowed(capability, context) {
  if (!capability.enabled) return false;
  if (typeof capability.visible === "function" && !capability.visible(context)) return false;
  if (capability.visible === false) return false;
  const roles = new Set((context.roles || []).map(text));
  return capability.requiredRoles.every((role) => roles.has(role));
}

export function pipelineWorkspaceCapability(options = {}) {
  return {
    id: "pipeline",
    label: "Pipeline",
    detail: "Inspect and control shared processing",
    icon: "pipeline",
    route: "pipeline",
    href: "/pipeline/",
    order: 210,
    ...options
  };
}

export function createWorkspaceCapabilityRegistry({
  base = {},
  extensions = [],
  context = {}
} = {}) {
  const candidates = [
    normalizeCapability(base.identity, BASE.identity, 0),
    normalizeCapability(base.workspace, BASE.workspace, 1)
  ];
  if (base.errors?.enabled === true) {
    candidates.push(normalizeCapability(base.errors, { ...BASE.errors, enabled: true }, 2));
  }
  extensions.forEach((extension, index) => {
    const normalized = normalizeCapability(extension, {}, index + 3);
    if (WORKSPACE_BASE_CAPABILITY_IDS.includes(normalized.id)) {
      throw new TypeError("Extension capability id collides with reserved base id " + normalized.id + ".");
    }
    candidates.push(normalized);
  });

  const ids = new Set();
  for (const capability of candidates) {
    if (ids.has(capability.id)) throw new TypeError("Duplicate Workspace capability id " + capability.id + ".");
    ids.add(capability.id);
  }

  const capabilities = candidates
    .filter((capability) => capability.required || allowed(capability, context))
    .sort((left, right) => left.order - right.order || left.label.localeCompare(right.label));
  const byId = new Map(capabilities.map((capability) => [capability.id, capability]));

  return Object.freeze({
    context: Object.freeze({ ...context, roles: Object.freeze([...(context.roles || [])]) }),
    capabilities: Object.freeze(capabilities),
    get(id) { return byId.get(String(id)) || null; },
    forRoute(route) {
      const wanted = text(route);
      return capabilities.find((capability) => capability.route === wanted) || null;
    }
  });
}

export function workspaceUtilityFromCapabilities(registry, {
  label = "Workspace",
  detail = "",
  icon = "archive",
  ariaLabel = "",
  error = null
} = {}) {
  if (!registry?.capabilities) throw new TypeError("A Workspace capability registry is required.");
  return {
    label,
    detail,
    icon,
    ariaLabel,
    error,
    menuLabel: label,
    items: [...registry.capabilities.reduce((items, capability) => {
      const menu = capability.menu || capability;
      const id = menu.id || capability.id;
      const existing = items.get(id);
      if (existing) {
        existing.routes.push(capability.route);
        if (!existing.status && capability.status) existing.status = capability.status;
        if (!existing.error && capability.error) existing.error = capability.error;
      } else items.set(id, {
        id, href: menu.href || capability.href, route: menu.route || capability.route,
        routes: [capability.route], label: menu.label || capability.label,
        detail: menu.detail || capability.detail, icon: menu.icon || capability.icon,
        status: capability.status, error: capability.error
      });
      return items;
    }, new Map()).values()]
  };
}

export function createWorkspaceHost({
  mount,
  registry,
  adapters = {},
  onNavigate = () => {}
} = {}) {
  if (!mount?.replaceChildren) throw new TypeError("A Workspace host requires a mount element.");
  if (!registry?.capabilities) throw new TypeError("A Workspace capability registry is required.");

  let activeId = null;
  let activeController = null;

  const navigate = (id) => {
    const capability = registry.get(id);
    if (!capability) throw new TypeError("Unknown or unavailable Workspace capability " + id + ".");
    activeController?.destroy?.();
    mount.replaceChildren();
    activeController = capability.createView({
      mount,
      capability,
      registry,
      context: registry.context,
      adapter: adapters[capability.id] || {}
    }) || null;
    activeId = capability.id;
    onNavigate({ capability, controller: activeController });
    return activeController;
  };

  return {
    get activeId() { return activeId; },
    get activeController() { return activeController; },
    navigate,
    navigateRoute(route) {
      const capability = registry.forRoute(route);
      if (!capability) throw new TypeError("Unknown or unavailable Workspace route " + route + ".");
      return navigate(capability.id);
    },
    destroy() {
      activeController?.destroy?.();
      activeController = null;
      activeId = null;
      mount.replaceChildren();
    }
  };
}

export function createWorkspaceRouter({
  host,
  registry,
  windowObject = globalThis.window,
  resolveLocation = (location) => location?.pathname || ""
} = {}) {
  if (!host?.navigate || !registry?.capabilities) {
    throw new TypeError("Workspace routing requires a host and capability registry.");
  }
  const resolve = () => {
    const value = resolveLocation(windowObject?.location);
    return registry.get(value) || registry.forRoute(value)
      || registry.capabilities.find(({ href }) => href === value)
      || null;
  };
  const onPopState = () => {
    const capability = resolve();
    if (capability) host.navigate(capability.id);
  };
  windowObject?.addEventListener?.("popstate", onPopState);

  return {
    start(fallbackId = registry.capabilities[0]?.id) {
      const capability = resolve() || registry.get(fallbackId);
      if (capability) return host.navigate(capability.id);
      return null;
    },
    navigate(id, { replace = false } = {}) {
      const capability = registry.get(id);
      if (!capability) throw new TypeError("Unknown or unavailable Workspace capability " + id + ".");
      const method = replace ? "replaceState" : "pushState";
      windowObject?.history?.[method]?.({}, "", capability.href);
      return host.navigate(id);
    },
    destroy() {
      windowObject?.removeEventListener?.("popstate", onPopState);
      host.destroy();
    }
  };
}
