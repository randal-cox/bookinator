# @inator/models

Provider-neutral model inventory, explicit install planning and approval,
verification, role compatibility, and invocation contracts. Ollama is the first
adapter, not the architecture. Installation, selection, permission, loading,
and invocation remain separate states.

`defineModelInventory`, `reduceModelInventory`, and
`createModelInventoryStore` keep observations from any model provider in one
durable state contract. Provider identity is explicit; machine hostnames,
process IDs, paths, and service URLs are deliberately excluded from durable
capabilities.

`createModelWorkHandler` is the bridge to `@inator/engine`: it reports
connecting, generating, and committing activity through the attempt context,
and records provider-reported input tokens, output tokens, and wall time as
usage. The Ollama adapter maps a hard `model-output` or `output` work-budget
limit to `num_predict`; advisory limits remain observable without silently
changing execution.
