import { defineModelRecord, defineProviderCapabilities, MODEL_PROTOCOL_VERSION } from "./index.js";
import { execFile as execFileCallback } from "node:child_process";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";

const json = async (response) => { if (!response.ok) throw new Error(`Ollama returned HTTP ${response.status}.`); return response.json(); };
const execFile = promisify(execFileCallback);

export function ollamaExecutableCandidates({ platform = process.platform, homeDirectory = os.homedir(), environment = process.env, command = "ollama" } = {}) {
  const managedRoot = platform === "darwin"
    ? path.join(homeDirectory, "Library", "Application Support", "Inator", "providers", "ollama")
    : platform === "win32"
      ? path.join(environment.LOCALAPPDATA || path.join(homeDirectory, "AppData", "Local"), "Inator", "providers", "ollama")
      : path.join(environment.XDG_DATA_HOME || path.join(homeDirectory, ".local", "share"), "inator", "providers", "ollama");
  if (platform === "darwin") return [path.join("/Applications", "Ollama.app", "Contents", "Resources", "ollama"), path.join(managedRoot, "current", "ollama"), command];
  if (platform === "win32") return [path.join(environment.LOCALAPPDATA || path.join(homeDirectory, "AppData", "Local"), "Programs", "Ollama", "ollama.exe"), path.join(managedRoot, "current", "ollama.exe"), command];
  return [path.join(managedRoot, "current", "ollama"), "/usr/local/bin/ollama", command];
}

export function ollamaInstallationGuidance({ platform = process.platform } = {}) {
  const platformName = platform === "darwin" ? "macOS" : platform === "win32" ? "Windows" : "Linux";
  return Object.freeze({ automatic: false, platform: platformName, url: "https://ollama.com/download", message: `Install Ollama for ${platformName} from the official Ollama distribution, then reopen the app. A system package manager is not required.` });
}

async function ndjson(response, onEvent) {
  if (!response.ok) throw new Error(`Ollama returned HTTP ${response.status}.`);
  const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ""; let final = null;
  while (true) { const { done, value } = await reader.read(); buffer += decoder.decode(value || new Uint8Array(), { stream: !done }); const lines = buffer.split(/\r?\n/); buffer = lines.pop() || ""; for (const line of lines.filter(Boolean)) { final = JSON.parse(line); await onEvent?.(final); } if (done) break; }
  if (buffer.trim()) { final = JSON.parse(buffer); await onEvent?.(final); }
  return final;
}

export class OllamaProvider {
  constructor({ fetch: fetchImpl = globalThis.fetch, endpoint = "http://127.0.0.1:11434", version = "unknown", run = execFile, executableCandidates = ollamaExecutableCandidates() } = {}) { this.fetch = fetchImpl; this.endpoint = endpoint.replace(/\/$/, ""); this.version = version; this.run = run; this.executableCandidates = executableCandidates; }
  async capabilities() { return defineProviderCapabilities({ providerId: "ollama", providerVersion: this.version, location: "local", operations: ["inventory", "install", "remove", "invoke", "unload"], features: { structuredOutput: true, streaming: true, cancellation: true, unload: true } }); }
  async status() {
    try { const value = await json(await this.fetch(`${this.endpoint}/api/version`)); this.version = String(value.version || "unknown"); return { installed: true, running: true, version: this.version }; }
    catch (apiError) {
      for (const executable of this.executableCandidates) {
        try { const result = await this.run(executable, ["--version"], { timeout: 3_000 }); const match = `${result.stdout || ""}\n${result.stderr || ""}`.match(/(?:client version is|ollama version is|ollama version)\s+([\w.-]+)/i); this.version = match?.[1] || "unknown"; return { installed: true, running: false, version: this.version, command: executable, diagnostic: apiError.message }; } catch { /* Try the next known executable location. */ }
      }
      return { installed: false, running: false, version: null, diagnostic: apiError.message, installation: ollamaInstallationGuidance() };
    }
  }
  async inventory() {
    const [tags, running] = await Promise.all([json(await this.fetch(`${this.endpoint}/api/tags`)), this.fetch(`${this.endpoint}/api/ps`).then(json).catch(() => ({ models: [] }))]);
    const loaded = new Set((running.models || []).map((item) => item.name || item.model));
    return (tags.models || []).map((item) => defineModelRecord({ providerId: "ollama", modelId: item.name || item.model, revision: item.modified_at || null, digest: item.digest || null, sizeBytes: item.size, installed: true, loaded: loaded.has(item.name || item.model), families: item.details?.families || [item.details?.family].filter(Boolean), capabilities: String(item.name || item.model).includes("embed") ? ["embedding"] : ["chat", "structured-output"] }));
  }
  async install(plan, { signal, onProgress } = {}) { if (plan?.protocolVersion !== MODEL_PROTOCOL_VERSION || plan.state !== "approved" || plan.providerId !== "ollama") throw new TypeError("Ollama installation requires an approved compatible plan."); return ndjson(await this.fetch(`${this.endpoint}/api/pull`, { method: "POST", signal, headers: { "content-type": "application/json" }, body: JSON.stringify({ model: plan.model.modelId, stream: true }) }), (event) => onProgress?.({ status: event.status || "downloading", completedBytes: event.completed ?? null, totalBytes: event.total ?? plan.estimatedBytes ?? null, digest: event.digest || null })); }
  async remove(modelId) { return json(await this.fetch(`${this.endpoint}/api/delete`, { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: modelId }) })); }
  async unload(modelId) { return json(await this.fetch(`${this.endpoint}/api/generate`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ model: modelId, keep_alive: 0 }) })); }
  async invoke(request, { signal, onActivity, budget = null } = {}) {
    const outputLimit = budget?.limits?.find(({ id, enforcement }) => enforcement !== "soft" && ["model-output", "output"].includes(id));
    const requestedMaximum = Number(request.options?.num_predict);
    const budgetMaximum = Number(outputLimit?.maximum);
    const numPredict = Number.isFinite(budgetMaximum) ? Math.min(Number.isFinite(requestedMaximum) ? requestedMaximum : budgetMaximum, budgetMaximum) : request.options?.num_predict;
    const options = { ...request.options, ...(numPredict == null ? {} : { num_predict: numPredict }) };
    let content = ""; const final = await ndjson(await this.fetch(`${this.endpoint}/api/chat`, { method: "POST", signal, headers: { "content-type": "application/json" }, body: JSON.stringify({ model: request.modelId, messages: request.messages, format: request.outputSchema || undefined, ...(request.think == null ? {} : { think: request.think }), options, stream: true }) }), async (event) => {
      const delta = event.message?.content || ""; content += delta;
      await onActivity?.({ type: event.done ? "completed" : "token", modelId: request.modelId, delta, content, completedBytes: new TextEncoder().encode(content).byteLength });
    });
    return { requestId: request.requestId, provider: { id: "ollama", version: this.version }, model: { id: request.modelId, digest: final?.model_digest || null }, promptVersion: request.promptVersion, schemaVersion: request.schemaVersion, content, termination: { done: Boolean(final?.done), reason: final?.done_reason || null, requestedOutputTokens: Number.isFinite(numPredict) ? numPredict : null }, metrics: { totalDurationNs: final?.total_duration || null, promptTokens: final?.prompt_eval_count || null, outputTokens: final?.eval_count || null } };
  }
}
