import { createInatorIcon } from "./icons.js";

export const WORKSPACE_IDENTITY_FIELD_IDS = Object.freeze([
  "shortName",
  "longName",
  "roles"
]);

export const INATOR_STANDARD_ROLE_OPTIONS = Object.freeze([
  Object.freeze({
    id: "developer",
    icon: "inspect",
    label: "Developer",
    description: "Access diagnostics and engineering tools."
  }),
  Object.freeze({
    id: "team",
    icon: "identity",
    label: "Team representative",
    description: "Access team resources, slide decks, and presentation materials."
  })
]);

export const DEFAULT_WORKSPACE_IDENTITY_FIELDS = Object.freeze([
  Object.freeze({
    id: "shortName",
    label: "Short name",
    type: "text",
    required: true,
    description: "Used in compact attribution."
  }),
  Object.freeze({
    id: "longName",
    label: "Long name",
    type: "text",
    required: true,
    description: "Used where full attribution is useful."
  }),
  Object.freeze({
    id: "roles",
    label: "Roles",
    type: "roles",
    required: false,
    description: "Explicit local capability roles."
  })
]);

const text = (value) => String(value ?? "").trim();

function normalizeRoles(value) {
  const values = Array.isArray(value) ? value : String(value ?? "").split(",");
  return [...new Set(values.map(text).filter(Boolean))];
}

function normalizeRoleOptions(value = []) {
  const seen = new Set();
  return value.map((option) => {
    const source = typeof option === "string" ? { id: option } : option || {};
    const id = text(source.id);
    if (!id || seen.has(id)) return null;
    seen.add(id);
    return {
      id,
      label: text(source.label) || id,
      description: text(source.description),
      icon: text(source.icon) || "identity"
    };
  }).filter(Boolean);
}

export function normalizeWorkspaceIdentity(value = {}) {
  return {
    ...value,
    shortName: text(value.shortName),
    longName: text(value.longName),
    roles: normalizeRoles(value.roles)
  };
}

export function validateWorkspaceIdentity(value = {}, fields = DEFAULT_WORKSPACE_IDENTITY_FIELDS) {
  const identity = normalizeWorkspaceIdentity(value);
  const errors = {};
  for (const field of fields) {
    const raw = field.id === "roles" ? identity.roles : identity[field.id];
    if (field.required && (!raw || (Array.isArray(raw) && !raw.length))) {
      errors[field.id] = field.label + " is required.";
      continue;
    }
    const message = field.validate?.(raw, identity);
    if (message) errors[field.id] = String(message);
  }
  return {
    valid: Object.keys(errors).length === 0,
    errors,
    identity
  };
}

function element(tag, className, value) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (value != null) node.textContent = String(value);
  return node;
}

export function createWorkspaceIdentityView({
  mount,
  model = {},
  fields = DEFAULT_WORKSPACE_IDENTITY_FIELDS,
  roleOptions = [],
  wording = {},
  onSave = async (identity) => identity
} = {}) {
  if (!mount?.replaceChildren) throw new TypeError("createWorkspaceIdentityView requires a DOM mount element.");
  const labels = {
    title: wording.title || "Identity",
    description: wording.description || "Names and roles used for local attribution.",
    save: wording.save || "Save",
    saved: wording.saved || "Identity saved."
  };
  const standardRoles = normalizeRoleOptions(roleOptions);
  let baseline = normalizeWorkspaceIdentity(model);
  let current = { ...baseline, roles: [...baseline.roles] };
  let saving = false;

  const form = element("form", "inator-workspace-identity");
  const header = element("header", "inator-workspace-identity__header");
  header.append(element("h2", "", labels.title), element("p", "", labels.description));
  const fieldset = element("div", "inator-workspace-identity__fields");
  const controls = new Map();
  const errors = new Map();
  const roleButtons = new Map();

  let retainedRoles = null;
  for (const definition of fields) {
    if (definition.id === "roles" && standardRoles.length) {
      const group = element("section", "inator-workspace-identity__field inator-workspace-identity__role-options");
      const heading = element("strong", "", definition.label);
      const detail = element("small", "", definition.description || "");
      const input = element("input", "");
      input.type = "hidden";
      input.name = definition.id;
      input.value = current.roles.join(", ");
      const buttons = element("div", "inator-workspace-identity__role-buttons");
      buttons.setAttribute("role", "group");
      buttons.setAttribute("aria-label", "Available roles");

      for (const option of standardRoles) {
        const button = element("button", "");
        button.type = "button";
        button.dataset.roleOption = option.id;
        button.setAttribute("aria-pressed", "false");
        button.append(createInatorIcon(option.icon), element("span", "", option.label));
        if (option.description) {
          button.title = option.description;
          button.setAttribute("aria-label", option.label + ": " + option.description);
        }
        button.addEventListener("click", (event) => {
          event.preventDefault();
          event.stopPropagation();
          const next = normalizeRoles(input.value);
          const index = next.indexOf(option.id);
          if (index >= 0) next.splice(index, 1);
          else next.push(option.id);
          input.value = next.join(", ");
          input.dispatchEvent(new Event("input", { bubbles: true }));
        });
        buttons.append(button);
        roleButtons.set(option.id, button);
      }

      retainedRoles = element("small", "inator-workspace-identity__retained-roles");
      retainedRoles.hidden = true;
      const error = element("small", "inator-workspace-identity__error");
      error.hidden = true;
      group.append(heading);
      if (detail.textContent) group.append(detail);
      group.append(buttons, retainedRoles, error, input);
      fieldset.append(group);
      controls.set(definition.id, input);
      errors.set(definition.id, error);
      continue;
    }

    const label = element("label", "inator-workspace-identity__field");
    const heading = element("strong", "", definition.label);
    const input = definition.type === "textarea"
      ? element("textarea", "")
      : definition.type === "select"
        ? element("select", "")
        : element("input", "");
    if (input.tagName === "INPUT") input.type = "text";
    input.name = definition.id;
    input.required = Boolean(definition.required);
    const value = definition.id === "roles" ? current.roles.join(", ") : current[definition.id];
    if (input.tagName === "SELECT") {
      for (const option of definition.options || []) {
        const source = typeof option === "string" ? { value: option, label: option } : option;
        const node = element("option", "", source.label ?? source.value);
        node.value = String(source.value ?? "");
        input.append(node);
      }
    }
    input.value = value ?? "";
    const detail = element("small", "", definition.description || "");
    const error = element("small", "inator-workspace-identity__error");
    error.hidden = true;
    label.append(heading, input);
    if (detail.textContent) label.append(detail);
    label.append(error);
    fieldset.append(label);
    controls.set(definition.id, input);
    errors.set(definition.id, error);
  }

  const footer = element("footer", "inator-workspace-identity__footer");
  const status = element("span", "");
  status.setAttribute("role", "status");
  status.setAttribute("aria-live", "polite");
  const save = element("button", "primary", labels.save);
  save.type = "submit";
  footer.append(status, save);
  form.append(header, fieldset, footer);
  mount.replaceChildren(form);

  const read = () => {
    const next = { ...current };
    for (const definition of fields) {
      const value = controls.get(definition.id)?.value ?? "";
      next[definition.id] = definition.id === "roles" ? normalizeRoles(value) : text(value);
    }
    return normalizeWorkspaceIdentity(next);
  };
  const changed = (value) => JSON.stringify(value) !== JSON.stringify(baseline);
  const renderState = () => {
    current = read();
    const validation = validateWorkspaceIdentity(current, fields);
    for (const [id, node] of errors) {
      node.textContent = validation.errors[id] || "";
      node.hidden = !node.textContent;
    }
    for (const [id, button] of roleButtons) {
      button.setAttribute("aria-pressed", String(validation.identity.roles.includes(id)));
    }
    if (retainedRoles) {
      const knownRoles = new Set(standardRoles.map(({ id }) => id));
      const retained = validation.identity.roles.filter((role) => !knownRoles.has(role));
      retainedRoles.textContent = retained.length ? "Other assigned roles retained: " + retained.join(", ") : "";
      retainedRoles.hidden = retained.length === 0;
    }
    save.disabled = saving || !validation.valid || !changed(validation.identity);
    save.dataset.dirty = String(changed(validation.identity));
    return validation;
  };
  const onInput = () => {
    status.textContent = "";
    renderState();
  };
  form.addEventListener("input", onInput);
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const validation = renderState();
    if (!validation.valid || !changed(validation.identity) || saving) return;
    saving = true;
    save.disabled = true;
    form.setAttribute("aria-busy", "true");
    status.textContent = "Saving\u2026";
    try {
      const saved = normalizeWorkspaceIdentity(await onSave(validation.identity) || validation.identity);
      baseline = saved;
      current = { ...saved, roles: [...saved.roles] };
      for (const definition of fields) {
        controls.get(definition.id).value = definition.id === "roles"
          ? current.roles.join(", ")
          : current[definition.id] ?? "";
      }
      status.textContent = labels.saved;
    } catch (error) {
      status.textContent = "Could not save identity: " + (error?.message || error);
    } finally {
      saving = false;
      form.setAttribute("aria-busy", "false");
      renderState();
    }
  });
  renderState();

  return {
    get value() { return read(); },
    get dirty() { return changed(read()); },
    validate: renderState,
    update(nextModel) {
      baseline = normalizeWorkspaceIdentity(nextModel);
      current = { ...baseline, roles: [...baseline.roles] };
      for (const definition of fields) {
        controls.get(definition.id).value = definition.id === "roles"
          ? current.roles.join(", ")
          : current[definition.id] ?? "";
      }
      return renderState();
    },
    destroy() {
      form.removeEventListener("input", onInput);
      mount.replaceChildren();
    }
  };
}
