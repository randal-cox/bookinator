import { normalizeProductUtility } from "./utility-status.js";
import { INATOR_ICON_PATHS, createInatorIcon } from "./icons.js";

function canonicalPath(href) {
  if (!href) return "";
  try {
    const url = new URL(href, "https://inator.invalid");
    const pathname = url.pathname === "/" ? "/" : url.pathname.replace(/\/$/, "");
    const hashRoute = url.hash.startsWith("#/") ? url.hash.replace(/\/$/, "") : "";
    return `${pathname}${hashRoute}`;
  } catch {
    const value = String(href);
    const hashRoute = value.match(/#\/[^?]*/u)?.[0]?.replace(/\/$/, "") || "";
    const pathname = value.replace(/[?#].*$/, "").replace(/\/$/, "") || "/";
    return `${pathname}${hashRoute}`;
  }
}

function isHomeDuplicate(item, brandHref) {
  return item?.route?.toLowerCase() === "home" || canonicalPath(item?.href) === canonicalPath(brandHref);
}

export function normalizeProductShellConfig(config = {}) {
  if (!config.brand?.href) throw new TypeError("A product shell brand home URL is required.");
  if (config.footer?.brand || config.footer?.status) throw new TypeError("Product footers contain navigation only; identity and live status belong in the header.");

  const navigation = [...(config.navigation || [])];
  if (config.contextItem) {
    const requestedPosition = Number.isInteger(config.contextItem.position)
      ? config.contextItem.position
      : navigation.length;
    const position = Math.max(0, Math.min(requestedPosition, navigation.length));
    navigation.splice(position, 0, { ...config.contextItem, contextual: true });
  }

  const secondaryItems = [...(config.secondaryNavigation?.items || [])]
    .filter((item) => item?.href && item?.label)
    .filter((item) => !isHomeDuplicate(item, config.brand.href));
  const secondaryNavigation = secondaryItems.length ? {
    ...config.secondaryNavigation,
    label: String(config.secondaryNavigation?.label || "Context"),
    parentRoute: String(config.secondaryNavigation?.parentRoute || config.active || ""),
    active: String(config.secondaryNavigation?.active || ""),
    items: secondaryItems
  } : null;

  return {
    ...config,
    navigation: navigation
      .filter((item) => item?.label && (item?.href || item?.items?.some((child) => child?.href && child?.label)))
      .filter((item) => item?.items?.length || !isHomeDuplicate(item, config.brand.href))
      .map(normalizedPrimaryNavigationItem),
    secondaryNavigation,
    utility: normalizeProductUtility(config.utility),
    footer: {
      ...(config.footer || {}),
      links: [...(config.footer?.links || [])]
    }
  };
}

function resolveMount(root, mount, selector) {
  if (typeof mount === "string") return root.querySelector(mount);
  return mount || root.querySelector(selector);
}

function appendImage(parent, image) {
  if (!image?.src) return;
  const img = document.createElement("img");
  img.src = image.src;
  img.alt = image.alt || "";
  if (image.width) img.width = image.width;
  if (image.height) img.height = image.height;
  parent.append(img);
}

function appendBrandImage(parent, brand, contextClass) {
  if (!brand.image?.src) return;
  const mark = document.createElement("span");
  mark.className = `inator-product-brand-mark ${contextClass}__mark`;
  appendImage(mark, brand.image);
  if (brand.status?.label) {
    const status = document.createElement("span");
    status.className = `inator-product-brand-status ${contextClass}__status`;
    status.dataset.tone = brand.status.tone || "neutral";
    status.setAttribute("role", "status");
    status.setAttribute("aria-label", brand.status.label);
    if (brand.status.detail) status.title = brand.status.detail;
    mark.append(status);
  }
  parent.append(mark);
}

function appendLabel(parent, { label, detail }) {
  const value = document.createElement("span");
  value.className = "inator-product-label";
  const strong = document.createElement("strong");
  strong.textContent = label;
  value.append(strong);
  if (detail) {
    const small = document.createElement("small");
    small.textContent = detail;
    value.append(small);
  }
  parent.append(value);
}

function shellSeparator(className, orientation) {
  const separator = document.createElement("span");
  separator.className = className;
  separator.setAttribute("role", "separator");
  separator.setAttribute("aria-orientation", orientation);
  return separator;
}

function appendError(parent, error, className = "inator-product-utility__error") {
  if (!error) return;
  const alert = document.createElement("span");
  alert.className = className;
  alert.setAttribute("role", "status");
  alert.setAttribute("aria-label", error.label);
  const pulse = document.createElement("span");
  pulse.setAttribute("aria-hidden", "true");
  const count = document.createElement("small");
  count.setAttribute("aria-hidden", "true");
  count.textContent = String(error.count);
  alert.append(pulse, count);
  parent.append(alert);
}

function normalizedNavigationItem(item) {
  if (!item.selectedObject) return item;
  const displayName = String(item.selectedObject.displayName || "").trim();
  const emptyLabel = String(item.selectedObject.emptyLabel || "No project selected").trim();
  return { ...item, detail: displayName || emptyLabel };
}

function normalizedPrimaryNavigationItem(item) {
  const items = (item.items || [])
    .filter((child) => child?.href && child?.label)
    .map(normalizedNavigationItem);
  return items.length ? { ...item, href: undefined, items } : normalizedNavigationItem(item);
}

function navigationItem(rawItem) {
  const item = normalizedNavigationItem(rawItem);
  const link = document.createElement("a");
  link.href = item.href;
  if (item.route) link.dataset.route = item.route;
  if (item.contextual) link.dataset.inatorContextLink = "";
  appendLabel(link, item);
  appendError(link, item.error, "inator-product-utility-menu__error");
  appendUtilityStatus(link, item.status);
  return link;
}

function utilityIcon(parent, iconValue) {
  if (!iconValue) return;
  const icon = document.createElement("span");
  icon.className = "inator-product-utility__icon";
  icon.setAttribute("aria-hidden", "true");
  if (typeof iconValue === "string" && INATOR_ICON_PATHS[iconValue]) icon.append(createInatorIcon(iconValue));
  else if (typeof iconValue === "string") { if (globalThis.console?.warn) console.warn(`[inator]: Unknown icon key ${iconValue}; icon omitted.`); return; }
  else if (iconValue instanceof Node) icon.append(iconValue.cloneNode(true));
  else return;
  parent.append(icon);
}

function appendUtilityStatus(parent, status) {
  if (!status) return;
  const node = document.createElement("small");
  node.className = "inator-product-utility-menu__status";
  node.dataset.tone = status.tone;
  node.textContent = status.label;
  parent.append(node);
}

function installMenuInteractions({ wrapper, button, panel }) {
  const itemLinks = () => [...panel.querySelectorAll("[role='menuitem']")];
  const close = ({ restoreFocus = false } = {}) => {
    panel.hidden = true;
    button.setAttribute("aria-expanded", "false");
    if (restoreFocus) button.focus();
  };
  const open = ({ focus = "first" } = {}) => {
    panel.hidden = false;
    button.setAttribute("aria-expanded", "true");
    const items = itemLinks();
    if (focus === "first") items[0]?.focus();
    if (focus === "last") items.at(-1)?.focus();
  };
  const toggle = () => panel.hidden ? open({ focus: null }) : close();
  const onButtonClick = () => toggle();
  const onButtonKeydown = (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      open({ focus: event.key === "ArrowDown" ? "first" : "last" });
    } else if (event.key === "Escape" && !panel.hidden) {
      event.preventDefault();
      close({ restoreFocus: true });
    }
  };
  const onPanelKeydown = (event) => {
    const items = itemLinks();
    const index = items.indexOf(document.activeElement);
    if (event.key === "Escape") {
      event.preventDefault();
      close({ restoreFocus: true });
    } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const step = event.key === "ArrowDown" ? 1 : -1;
      items[(index + step + items.length) % items.length]?.focus();
    } else if (event.key === "Home" || event.key === "End") {
      event.preventDefault();
      items[event.key === "Home" ? 0 : items.length - 1]?.focus();
    }
  };
  const onOutside = (event) => {
    if (!panel.hidden && !wrapper.contains(event.target)) close();
  };
  button.addEventListener("click", onButtonClick);
  button.addEventListener("keydown", onButtonKeydown);
  panel.addEventListener("keydown", onPanelKeydown);
  const onPanelClick = () => close();
  panel.addEventListener("click", onPanelClick);
  document.addEventListener("pointerdown", onOutside);
  return () => {
    document.removeEventListener("pointerdown", onOutside);
    button.removeEventListener("click", onButtonClick);
    button.removeEventListener("keydown", onButtonKeydown);
    panel.removeEventListener("keydown", onPanelKeydown);
    panel.removeEventListener("click", onPanelClick);
  };
}

function renderUtility(config) {
  const utility = config.utility;
  if (!utility) return { element: null, cleanup: () => {} };

  if (!utility.items.length) {
    if (!utility.href) return { element: null, cleanup: () => {} };
    const link = document.createElement("a");
    link.className = "inator-product-utility";
    link.href = utility.href;
    if (utility.route) link.dataset.route = utility.route;
    if (utility.ariaLabel) link.setAttribute("aria-label", utility.ariaLabel);
    if (utility.route && utility.route === config.active) link.setAttribute("aria-current", "page");
    appendError(link, utility.error);
    utilityIcon(link, utility.icon);
    appendLabel(link, utility);
    return { element: link, cleanup: () => {} };
  }

  const wrapper = document.createElement("div");
  wrapper.className = "inator-product-utility-menu";
  const button = document.createElement("button");
  button.type = "button";
  button.className = "inator-product-utility";
  button.setAttribute("aria-haspopup", "menu");
  button.setAttribute("aria-expanded", "false");
  button.setAttribute("aria-label", utility.ariaLabel || `Open ${utility.label || "Workspace"} menu`);
  if (utility.items.some(({ route, routes = [] }) => (route && route === config.active) || routes.includes(config.active))) button.dataset.active = "true";
  appendError(button, utility.error);
  utilityIcon(button, utility.icon);
  appendLabel(button, utility);

  const panel = document.createElement("div");
  panel.className = "inator-product-utility-menu__panel";
  panel.setAttribute("role", "menu");
  panel.setAttribute("aria-label", utility.menuLabel || utility.label || "Workspace");
  panel.hidden = true;

  for (const item of utility.items) {
    const link = document.createElement("a");
    link.href = item.href;
    link.setAttribute("role", "menuitem");
    if (item.route) link.dataset.route = item.route;
    if (item.ariaLabel) link.setAttribute("aria-label", item.ariaLabel);
    if ((item.route && item.route === config.active) || item.routes?.includes(config.active)) link.setAttribute("aria-current", "page");
    utilityIcon(link, item.icon);
    appendLabel(link, item);
    appendError(link, item.error, "inator-product-utility-menu__error");
    appendUtilityStatus(link, item.status);
    panel.append(link);
  }

  wrapper.append(button, panel);
  return { element: wrapper, cleanup: installMenuInteractions({ wrapper, button, panel }) };
}

function renderNavigationMenu(item, config) {
  const wrapper = document.createElement("div");
  wrapper.className = "inator-product-nav-menu";
  const button = document.createElement("button");
  button.type = "button";
  button.className = "inator-product-nav-menu__trigger";
  button.setAttribute("aria-haspopup", "menu");
  button.setAttribute("aria-expanded", "false");
  button.setAttribute("aria-label", item.ariaLabel || "Open " + item.label + " menu");
  if (item.items.some(({ route }) => route && route === config.active)) button.dataset.active = "true";
  appendLabel(button, item);

  const panel = document.createElement("div");
  panel.className = "inator-product-utility-menu__panel inator-product-nav-menu__panel";
  panel.setAttribute("role", "menu");
  panel.setAttribute("aria-label", item.menuLabel || item.label);
  panel.hidden = true;
  for (const child of item.items) {
    if (child.separatorBefore) panel.append(shellSeparator("inator-product-menu-separator", "horizontal"));
    const link = document.createElement("a");
    link.href = child.href;
    link.setAttribute("role", "menuitem");
    if (child.route) link.dataset.route = child.route;
    if (child.route && child.route === config.active) link.setAttribute("aria-current", "page");
    utilityIcon(link, child.icon);
    appendLabel(link, child);
    panel.append(link);
    if (child.separatorAfter) panel.append(shellSeparator("inator-product-menu-separator", "horizontal"));
  }
  wrapper.append(button, panel);
  return { element: wrapper, cleanup: installMenuInteractions({ wrapper, button, panel }) };
}

function compactMenuLabel(value) {
  const label = document.createElement("span"); label.className = "inator-product-header-menu__section"; label.setAttribute("role", "presentation"); label.textContent = value; return label;
}

function compactMenuLink(item, config) {
  const link = document.createElement("a"); link.href = item.href; link.setAttribute("role", "menuitem");
  if (item.route) link.dataset.route = item.route;
  if (item.contextual) link.dataset.inatorContextLink = "";
  if (item.route && item.route === config.active) link.setAttribute("aria-current", "page");
  utilityIcon(link, item.icon); appendLabel(link, item); appendError(link, item.error, "inator-product-utility-menu__error"); appendUtilityStatus(link, item.status); return link;
}

function renderCompactHeaderMenu(config) {
  const wrapper = document.createElement("div"); wrapper.className = "inator-product-header-menu";
  const button = document.createElement("button"); button.type = "button"; button.className = "inator-product-header-menu__trigger"; button.setAttribute("aria-haspopup", "menu"); button.setAttribute("aria-expanded", "false"); button.setAttribute("aria-label", `Open ${config.brand.label} navigation menu`); button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg><span>Menu</span>';
  const panel = document.createElement("div"); panel.className = "inator-product-header-menu__panel inator-product-utility-menu__panel"; panel.setAttribute("role", "menu"); panel.setAttribute("aria-label", `${config.brand.label} navigation`); panel.hidden = true;
  for (const item of config.navigation) { if (item.items?.length) { panel.append(compactMenuLabel(item.label)); for (const child of item.items) panel.append(compactMenuLink(child, config)); } else panel.append(compactMenuLink(item, config)); }
  if (config.secondaryNavigation?.items.length) { panel.append(shellSeparator("inator-product-menu-separator", "horizontal"), compactMenuLabel(config.secondaryNavigation.label)); for (const item of config.secondaryNavigation.items) panel.append(compactMenuLink(item, { ...config, active: config.secondaryNavigation.active })); }
  if (config.utility) { panel.append(shellSeparator("inator-product-menu-separator", "horizontal"), compactMenuLabel(config.utility.label || "Workspace")); if (config.utility.items.length) for (const item of config.utility.items) panel.append(compactMenuLink(item, config)); else if (config.utility.href) panel.append(compactMenuLink(config.utility, config)); }
  wrapper.append(button, panel);
  const cleanupMenu = installMenuInteractions({ wrapper, button, panel }); const compactHeader = globalThis.matchMedia?.("(max-width: 920px)");
  const closeOnWide = () => { if (!compactHeader?.matches) { panel.hidden = true; button.setAttribute("aria-expanded", "false"); } };
  compactHeader?.addEventListener?.("change", closeOnWide);
  return { element: wrapper, cleanup() { compactHeader?.removeEventListener?.("change", closeOnWide); cleanupMenu(); } };
}

function createSkipLink(mount) {
  const main = mount.ownerDocument?.querySelector("main");
  if (!main) return null;
  if (!main.id) main.id = "inator-main-content";
  if (!main.hasAttribute("tabindex")) main.tabIndex = -1;
  main.classList.add("inator-main-content");
  const link = document.createElement("a");
  link.className = "inator-skip-link";
  link.href = "#" + main.id;
  link.textContent = "Skip to content";
  return link;
}

function renderHeader(mount, config) {
  mount._inatorShellCleanup?.();
  mount._inatorShellCleanup = null;
  mount.className = "inator-product-header";
  const cleanups = [];
  const skipLink = createSkipLink(mount);

  const brand = document.createElement("a");
  brand.className = "inator-product-brand";
  brand.href = config.brand.href;
  brand.setAttribute("aria-label", config.brand.ariaLabel || `${config.brand.label} home`);
  if (config.active === "home") brand.setAttribute("aria-current", "page");
  appendBrandImage(brand, config.brand, "inator-product-brand");
  appendLabel(brand, config.brand);

  const nav = document.createElement("nav");
  nav.className = "inator-product-nav";
  nav.setAttribute("aria-label", config.navigationLabel || config.brand.label);
  for (const item of config.navigation) {
    if (item.items?.length) {
      const rendered = renderNavigationMenu(item, config);
      nav.append(rendered.element);
      cleanups.push(rendered.cleanup);
    } else {
      nav.append(navigationItem(item));
    }
  }
  const activeRoute = config.secondaryNavigation?.parentRoute || config.active || "";
  for (const link of nav.querySelectorAll("[data-route]")) {
    if (link.dataset.route === activeRoute) link.setAttribute("aria-current", "page");
  }

  const children = [skipLink, brand, nav].filter(Boolean);
  const renderedUtility = renderUtility(config);
  if (renderedUtility.element) {
    children.push(renderedUtility.element);
    cleanups.push(renderedUtility.cleanup);
  }
  const compactMenu = renderCompactHeaderMenu(config);
  children.push(compactMenu.element);
  cleanups.push(compactMenu.cleanup);
  mount._inatorShellCleanup = () => cleanups.forEach((cleanup) => cleanup());

  if (config.secondaryNavigation) {
    mount.classList.add("has-secondary-navigation");
    const secondary = document.createElement("nav");
    secondary.className = "inator-product-secondary-nav";
    secondary.setAttribute("aria-label", config.secondaryNavigation.label);

    const label = document.createElement("span");
    label.className = "inator-product-secondary-nav__label";
    label.textContent = config.secondaryNavigation.label;
    secondary.append(label);

    for (const item of config.secondaryNavigation.items) {
      const link = navigationItem(item);
      if (item.route === config.secondaryNavigation.active) link.setAttribute("aria-current", "page");
      secondary.append(link);
    }
    children.push(secondary);
  }

  mount.replaceChildren(...children);
}

function renderFooter(mount, config) {
  mount._inatorFooterCleanup?.();
  mount.className = "inator-product-footer";
  const children = [];
  let footerCleanup = () => {};

  if (config.footer.links.length) {
    const wrapper = document.createElement("div");
    wrapper.className = "inator-product-footer-menu";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "inator-product-footer-menu__trigger";
    button.setAttribute("aria-haspopup", "menu");
    button.setAttribute("aria-expanded", "false");
    button.setAttribute("aria-label", `Open ${config.brand.label} footer menu`);
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg><span>Menu</span>';
    const nav = document.createElement("nav");
    nav.className = "inator-product-footer-links";
    nav.setAttribute("aria-label", `${config.brand.label} footer`);
    nav.setAttribute("role", "menu");
    nav.hidden = false;
    for (const item of config.footer.links) {
      if (item.separatorBefore) nav.append(shellSeparator("inator-product-footer-separator", "vertical"));
      const link = document.createElement("a");
      link.href = item.href;
      link.textContent = item.label;
      link.setAttribute("role", "menuitem");
      if (item.standardView) link.dataset.inatorStandardView = item.standardView;
      if (item.route && item.route === config.active) link.setAttribute("aria-current", "page");
      nav.append(link);
      if (item.separatorAfter) nav.append(shellSeparator("inator-product-footer-separator", "vertical"));
    }
    wrapper.append(button, nav);
    const compactFooter = globalThis.matchMedia?.("(max-width: 920px)");
    const applyFooterLayout = () => { nav.hidden = Boolean(compactFooter?.matches); button.setAttribute("aria-expanded", "false"); };
    applyFooterLayout();
    compactFooter?.addEventListener?.("change", applyFooterLayout);
    const cleanupMenu = installMenuInteractions({ wrapper, button, panel: nav });
    footerCleanup = () => { compactFooter?.removeEventListener?.("change", applyFooterLayout); cleanupMenu(); };
    children.push(wrapper);
  }

  mount.replaceChildren(...children);
  mount._inatorFooterCleanup = footerCleanup;
}

export function mountProductShell({
  root = document,
  headerMount,
  footerMount,
  ...rawConfig
} = {}) {
  const config = normalizeProductShellConfig(rawConfig);
  const header = resolveMount(root, headerMount, "[data-inator-product-header]");
  const footer = resolveMount(root, footerMount, "[data-inator-product-footer]");
  if (header) renderHeader(header, config);
  if (footer) renderFooter(footer, config);
  return config;
}

export function updateProductShellSelectionContext({
  root = document,
  route,
  displayName = "",
  emptyLabel = "No project selected"
} = {}) {
  if (!route) throw new TypeError("A navigation route is required.");
  const links = [...root.querySelectorAll(".inator-product-nav [data-route], .inator-product-header-menu [data-route]")]
    .filter((candidate) => candidate.dataset.route === String(route));
  if (!links.length) return null;
  const value = String(displayName || "").trim() || String(emptyLabel || "No project selected").trim();
  for (const link of links) {
    let detail = link.querySelector("small");
    if (!detail) { detail = document.createElement("small"); (link.querySelector("span") || link).append(detail); }
    detail.textContent = value;
  }
  return value;
}

export function updateProductShellContext({ root = document, label, href } = {}) {
  for (const link of root.querySelectorAll("[data-inator-context-link]")) {
    const detail = link.querySelector("small");
    if (detail) detail.textContent = label || "Untitled";
    if (href) link.href = href;
  }
}
