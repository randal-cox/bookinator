import { decorateToolControl } from "./action-bar.js";
import { createInatorIcon } from "./icons.js";

function required(value, label) {
  const text = String(value ?? "").trim();
  if (!text) throw new TypeError(`${label} is required.`);
  return text;
}

function escapeXml(value) {
  return String(value ?? "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}

export function defineReportBranding(value = {}) {
  return Object.freeze({
    appName: required(value.appName, "Report appName"),
    appSubtitle: required(value.appSubtitle, "Report appSubtitle"),
    appIconSvg: required(value.appIconSvg, "Report appIconSvg")
  });
}

export function createBrandedSvgReport({ branding: rawBranding, documentTitle, sectionTitle, bodySvg, width, bodyHeight, footerNote = "" } = {}) {
  const branding = defineReportBranding(rawBranding); const headerHeight = 82; const footerHeight = 66; const reportWidth = Number(width); const contentHeight = Number(bodyHeight);
  if (!Number.isFinite(reportWidth) || reportWidth <= 0 || !Number.isFinite(contentHeight) || contentHeight <= 0) throw new TypeError("Branded SVG reports require positive width and bodyHeight.");
  const icon = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(branding.appIconSvg)}`; const height = headerHeight + contentHeight + footerHeight;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${reportWidth}" height="${height}" viewBox="0 0 ${reportWidth} ${height}"><rect width="100%" height="100%" fill="#fff"/><text x="28" y="39" fill="#173b63" font-family="Georgia,serif" font-size="23" font-weight="700">${escapeXml(required(documentTitle, "Report documentTitle"))}</text><text x="${reportWidth - 28}" y="39" text-anchor="end" fill="#173b63" font-family="Arial,sans-serif" font-size="16" font-weight="700">${escapeXml(required(sectionTitle, "Report sectionTitle"))}</text><g transform="translate(0 ${headerHeight})">${String(bodySvg).replace(/^<svg[^>]*>|<\/svg>$/g, "")}</g><line x1="28" x2="${reportWidth - 28}" y1="${headerHeight + contentHeight + 10}" y2="${headerHeight + contentHeight + 10}" stroke="#cbdadd"/><image href="${icon}" x="28" y="${headerHeight + contentHeight + 18}" width="38" height="38"/><text x="76" y="${headerHeight + contentHeight + 34}" fill="#173b63" font-family="Arial,sans-serif" font-size="15" font-weight="700">${escapeXml(branding.appName)}</text><text x="76" y="${headerHeight + contentHeight + 51}" fill="#61747d" font-family="Arial,sans-serif" font-size="11">${escapeXml(branding.appSubtitle)}</text>${footerNote ? `<text x="${reportWidth - 28}" y="${headerHeight + contentHeight + 42}" text-anchor="end" fill="#61747d" font-family="Arial,sans-serif" font-size="11">${escapeXml(footerNote)}</text>` : ""}</svg>`;
}

export function drawBrandedPdfFrame(pdf, { branding: rawBranding, documentTitle, sectionTitle, pageNumber, pageCount } = {}) {
  const branding = defineReportBranding(rawBranding); const width = pdf.internal.pageSize.getWidth(); const height = pdf.internal.pageSize.getHeight(); const margin = 42; const footerTop = height - 72;
  pdf.setTextColor(23, 59, 99); pdf.setFont("helvetica", "bold"); pdf.setFontSize(18); pdf.text(required(documentTitle, "Report documentTitle"), margin, 40); pdf.setFontSize(12); pdf.text(required(sectionTitle, "Report sectionTitle"), width - margin, 37, { align: "right" });
  pdf.setDrawColor(202, 220, 222); pdf.line(margin, footerTop, width - margin, footerTop); pdf.setFillColor(16, 36, 59); pdf.roundedRect(margin, footerTop + 10, 24, 24, 6, 6, "F"); pdf.setDrawColor(50, 196, 212); pdf.setLineWidth(2); pdf.circle(margin + 13, footerTop + 21, 6); pdf.line(margin + 17, footerTop + 25, margin + 22, footerTop + 30);
  pdf.setTextColor(23, 59, 99); pdf.setFont("helvetica", "bold"); pdf.setFontSize(11); pdf.text(branding.appName, margin + 31, footerTop + 22); pdf.setTextColor(97, 116, 125); pdf.setFont("helvetica", "normal"); pdf.setFontSize(8); pdf.text(branding.appSubtitle, margin + 31, footerTop + 34); pdf.setTextColor(41, 74, 107); pdf.setFont("helvetica", "bold"); pdf.setFontSize(9); pdf.text(`Page ${pageNumber} of ${pageCount}`, width - margin, footerTop + 27, { align: "right" });
  return Object.freeze({ contentTop: 64, contentBottom: footerTop - 12, margin, width, height });
}

export async function createBrandedChartPdf({ branding, documentTitle, sectionTitle, chartDataUrl, chartWidth, chartHeight, orientation = "portrait" } = {}) {
  const { jsPDF } = await import("jspdf"); const pdf = new jsPDF({ orientation, unit: "pt", format: "letter" });
  const frame = drawBrandedPdfFrame(pdf, { branding, documentTitle, sectionTitle, pageNumber: 1, pageCount: 1 });
  const availableWidth = frame.width - frame.margin * 2; const availableHeight = frame.contentBottom - frame.contentTop;
  const ratio = Math.min(availableWidth / Number(chartWidth), availableHeight / Number(chartHeight));
  if (!Number.isFinite(ratio) || ratio <= 0) throw new TypeError("Branded chart PDFs require positive chart dimensions.");
  const width = Number(chartWidth) * ratio; const height = Number(chartHeight) * ratio;
  pdf.addImage(required(chartDataUrl, "Chart data URL"), "PNG", frame.margin + (availableWidth - width) / 2, frame.contentTop + (availableHeight - height) / 2, width, height);
  return pdf;
}

export function createChartExportControl({ formats = ["svg", "png", "pdf"], label = "Export", onExport } = {}) {
  if (typeof onExport !== "function") throw new TypeError("Chart export requires an onExport callback.");
  const menu = document.createElement("details"); menu.className = "inator-chart-export";
  const summary = document.createElement("summary"); decorateToolControl(summary, { icon: createInatorIcon("export"), label }); summary.title = "Export chart";
  const choices = document.createElement("div"); choices.setAttribute("role", "menu");
  for (const rawFormat of formats) {
    const format = String(rawFormat).toLocaleLowerCase(); const control = document.createElement("button"); control.type = "button"; control.setAttribute("role", "menuitem"); control.dataset.format = format; control.textContent = format.toLocaleUpperCase(); choices.append(control);
  }
  choices.addEventListener("click", async event => {
    const control = event.target.closest("button[data-format]"); if (!control) return;
    control.disabled = true;
    try { await onExport(control.dataset.format, control); menu.open = false; }
    finally { control.disabled = false; }
  });
  menu.append(summary, choices); return menu;
}
