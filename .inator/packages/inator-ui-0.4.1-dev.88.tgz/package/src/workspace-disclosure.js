const element = (tag, className = "", text = null) => {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text != null) node.textContent = String(text);
  return node;
};

const stablePart = value => String(value || "")
  .trim()
  .toLowerCase()
  .replace(/[^a-z0-9]+/g, "-")
  .replace(/^-|-$/g, "");

function preferenceKey(namespace, id) {
  const stableNamespace = stablePart(namespace);
  const stableId = stablePart(id);
  if (!stableNamespace || !stableId) throw new TypeError("Workspace disclosure groups require stable namespace and id values.");
  return `inator.workspace-disclosures.v1:${stableNamespace}:${stableId}`;
}

function readPreference(storage, key, defaultOpen) {
  try {
    const value = storage?.getItem?.(key);
    return value === "open" ? true : value === "closed" ? false : defaultOpen;
  } catch { return defaultOpen; }
}

function writePreference(storage, key, open) {
  try { storage?.setItem?.(key, open ? "open" : "closed"); } catch {}
}

const severity = Object.freeze({ ready: 0, unknown: 1, repairable: 2, warning: 2, blocked: 3 });
const statusLabel = status => status === "ready" ? "Ready" : status === "blocked" ? "Blocked" : status === "repairable" ? "Repair available" : status === "warning" ? "Needs attention" : "Unknown";
const statusMark = status => status === "ready" ? "✓" : status === "blocked" ? "×" : status === "unknown" ? "?" : "!";

export function worstWorkspaceDisclosureStatus(statuses = []) {
  return [...statuses].reduce((worst, candidate) => (severity[candidate] ?? severity.unknown) > severity[worst] ? candidate : worst, "ready");
}

export function createWorkspaceDisclosureGroup({ id, namespace, title, summary, content, statuses = [], status = worstWorkspaceDisclosureStatus(statuses), open = true, storage = globalThis.localStorage } = {}) {
  if (!title) throw new TypeError("A Workspace disclosure group requires a title.");
  if (!(content instanceof Node)) throw new TypeError("A Workspace disclosure group requires Node content.");
  const key = preferenceKey(namespace, id);
  const details = element("details", "inator-system-group inator-system-category");
  details.dataset.groupId = String(id);
  details.open = readPreference(storage, key, Boolean(open));
  const heading = element("summary");
  const state = severity[status] == null ? "unknown" : status;
  const summaryMeta = element("span", "inator-system-category__summary");
  const mark = element("b", "inator-system-category__mark", statusMark(state));
  mark.dataset.status = state;
  mark.setAttribute("aria-label", `Worst state: ${statusLabel(state)}`);
  summaryMeta.append(mark, element("span", "", summary || ""));
  heading.append(element("h2", "", title), summaryMeta);
  details.append(heading, content);
  details.addEventListener("toggle", () => writePreference(storage, key, details.open));
  return details;
}
