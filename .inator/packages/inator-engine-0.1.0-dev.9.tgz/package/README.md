# @inator/engine

Early, headless contracts and a first durable vertical slice for Inator
computation. The package contains no product stages, UI, provider client,
ambient workspace authority, or service installation behavior.

The first consumer is rho.inator. Its synthetic evidence-refinement workflow
exercises exact input signatures, typed dependencies, retained attempts,
selective invalidation, claim generations, and local-only worker placement.

This package is deliberately pre-release. book.inator is an archaeology source
and later compatibility target; it is not the first runtime migration.

## Observable demo runner

`createDemoPipeline()` (also available from the browser-safe
`@inator/engine/demo` subpath) is a deliberately slow, headless pipeline used by the
Commons engine-room lab and consumer conformance tests. Its default tasks wait
two seconds apiece. It exercises one authoritative job at a time, monotonically
increasing claim generations, task-boundary stopping, requested failure, retry,
and retained attempt history. Products may replace its task names while keeping
the same lifecycle; it is not a production scheduler.

## Durable vertical slice

`DurableControlPlane` replays an append-only JSONL ledger, reconstructs eligible
work after restart, issues leased claims, retains every result, and prevents an
expired worker from applying a late result after a newer generation claims the
same unit.

`installJsonLineWorker()` is the first worker-process adapter. The included
`inator-demo-worker` executable accepts one bounded work envelope per line on
standard input and returns one result envelope per line on standard output. It
is a proving transport, not the final local socket or LaunchAgent runtime.
Neither side opens a product database or scans a workspace.

Model providers remain outside the engine. `@inator/models` supplies a
`createModelWorkHandler()` adapter that plugs into `executeWork()` under a
namespaced method such as `models.invoke`; the durable engine sees only the
transport-neutral work and result envelopes.
