import { ENGINE_PROTOCOL_VERSION, defineResultEnvelope, defineWorkEnvelope } from "./index.js";

export async function executeWork(workSource, { worker, handlers, signal } = {}) {
  const work = defineWorkEnvelope(workSource); const handler = handlers?.[work.method];
  if (!handler) throw new TypeError(`Worker does not support ${work.method}.`);
  const startedAt = new Date().toISOString();
  try {
    const output = await handler(work.input, { work, worker, signal });
    return defineResultEnvelope({ protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: work.workspaceId, runId: work.runId, workUnitId: work.workUnitId, attemptId: work.attemptId, claimGeneration: work.claimGeneration, inputSignature: work.inputSignature, status: "succeeded", worker: { id: worker.id, version: worker.version }, startedAt, finishedAt: new Date().toISOString(), output });
  } catch (error) {
    return defineResultEnvelope({ protocolVersion: ENGINE_PROTOCOL_VERSION, workspaceId: work.workspaceId, runId: work.runId, workUnitId: work.workUnitId, attemptId: work.attemptId, claimGeneration: work.claimGeneration, inputSignature: work.inputSignature, status: signal?.aborted ? "cancelled" : "failed", worker: { id: worker.id, version: worker.version }, startedAt, finishedAt: new Date().toISOString(), error: { name: error.name, message: error.message } });
  }
}

export function installJsonLineWorker({ input = process.stdin, output = process.stdout, worker = { id: "worker-local", version: "dev" }, handlers = {} } = {}) {
  input.setEncoding("utf8"); let buffer = ""; let chain = Promise.resolve();
  input.on("data", (chunk) => { buffer += chunk; const lines = buffer.split(/\r?\n/); buffer = lines.pop(); for (const line of lines.filter(Boolean)) chain = chain.then(async () => { try { output.write(`${JSON.stringify({ ok: true, result: await executeWork(JSON.parse(line), { worker, handlers }) })}\n`); } catch (error) { output.write(`${JSON.stringify({ ok: false, error: { name: error.name, message: error.message } })}\n`); } }); });
  return { close: () => input.destroy() };
}

