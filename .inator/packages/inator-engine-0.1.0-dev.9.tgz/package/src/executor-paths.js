import os from "node:os";
import path from "node:path";

export const EXECUTOR_LAUNCH_AGENT_LABEL = "com.inator.pipeline-executor";

export function executorPaths({ homeDirectory = os.homedir(), temporaryDirectory = os.tmpdir(), userId = process.getuid?.() ?? os.userInfo().username } = {}) {
  const support = path.join(homeDirectory, "Library", "Application Support", "Inator", "executor");
  const logs = path.join(homeDirectory, "Library", "Logs", "Inator");
  return Object.freeze({
    supportDirectory: support,
    socketPath: path.join(temporaryDirectory, `inator-${userId}`, "executor.sock"),
    statePath: path.join(support, "install.json"),
    plistPath: path.join(homeDirectory, "Library", "LaunchAgents", `${EXECUTOR_LAUNCH_AGENT_LABEL}.plist`),
    stdoutPath: path.join(logs, "executor.log"),
    stderrPath: path.join(logs, "executor-error.log")
  });
}
