import http from "node:http";
import net from "node:net";
import { chmod, mkdir, rm } from "node:fs/promises";
import path from "node:path";
import { executeWork } from "./worker-runtime.js";

const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));

async function jsonBody(request, maximumBytes = 1024 * 1024) {
  const chunks = []; let size = 0;
  for await (const chunk of request) { size += chunk.length; if (size > maximumBytes) throw new Error("Work envelope exceeds 1 MiB."); chunks.push(chunk); }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {};
}

function respond(response, status, value) {
  const body = `${JSON.stringify(value)}\n`;
  response.writeHead(status, { "content-type": "application/json", "content-length": Buffer.byteLength(body) }); response.end(body);
}

function listening(socketPath) {
  return new Promise((resolve) => {
    const socket = net.createConnection({ path: socketPath });
    socket.once("connect", () => { socket.destroy(); resolve(true); });
    socket.once("error", () => resolve(false));
  });
}

export function createExecutorService({ socketPath, version = "dev", workerId = "inator-local-executor", handlers = {} } = {}) {
  if (!socketPath) throw new TypeError("socketPath is required.");
  let handled = 0; let active = 0; const startedAt = new Date().toISOString();
  const builtins = { "commons.wait": async (input = {}) => { const waitMs = Math.max(0, Math.min(Number(input.waitMs) || 0, 60_000)); await wait(waitMs); return { summary: input.summary || `Waited ${(waitMs / 1000).toFixed(1)} seconds.`, waitMs }; }, ...handlers };
  const server = http.createServer(async (request, response) => {
    try {
      const url = new URL(request.url, "http://inator.local");
      if (request.method === "GET" && url.pathname === "/v1/status") return respond(response, 200, { label: "com.inator.pipeline-executor", version, pid: process.pid, state: active ? "working" : "idle", active, handled, startedAt });
      if (request.method === "POST" && url.pathname === "/v1/execute") {
        const work = await jsonBody(request); active += 1;
        try { const result = await executeWork(work, { worker: { id: workerId, version }, handlers: builtins }); handled += 1; return respond(response, 200, result); }
        finally { active -= 1; }
      }
      return respond(response, 404, { error: "Unknown executor route." });
    } catch (error) { return respond(response, 400, { error: error.message }); }
  });
  return Object.freeze({
    async start() { await mkdir(path.dirname(socketPath), { recursive: true, mode: 0o700 }); if (await listening(socketPath)) throw new Error(`An Inator executor is already listening at ${socketPath}.`); await rm(socketPath, { force: true }); await new Promise((resolve, reject) => { server.once("error", reject); server.listen(socketPath, () => { server.off("error", reject); resolve(); }); }); await chmod(socketPath, 0o600); return this; },
    async close() { if (server.listening) await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve())); await rm(socketPath, { force: true }); },
    socketPath
  });
}

export function createExecutorClient({ socketPath, timeoutMs = 65_000 } = {}) {
  const request = (method, pathname, body = null) => new Promise((resolve, reject) => {
    const payload = body == null ? "" : JSON.stringify(body); const operation = http.request({ socketPath, method, path: pathname, headers: payload ? { "content-type": "application/json", "content-length": Buffer.byteLength(payload) } : {} }, (response) => { const chunks = []; response.on("data", (chunk) => chunks.push(chunk)); response.on("end", () => { const value = JSON.parse(Buffer.concat(chunks).toString("utf8")); response.statusCode >= 400 ? reject(new Error(value.error)) : resolve(value); }); });
    operation.on("error", reject); operation.setTimeout(timeoutMs, () => operation.destroy(new Error("Executor request timed out."))); operation.end(payload);
  });
  return Object.freeze({ status: () => request("GET", "/v1/status"), execute: (work) => request("POST", "/v1/execute", work) });
}
