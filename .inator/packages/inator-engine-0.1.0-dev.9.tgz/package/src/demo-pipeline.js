const DEFAULT_TASKS = Object.freeze([
  Object.freeze({ id: "receive", label: "Receive work", detail: "Freeze the input and issue a claim.", method: "commons.demo.receive" }),
  Object.freeze({ id: "prepare", label: "Prepare inputs", detail: "Resolve the synthetic dependencies.", method: "commons.demo.prepare" }),
  Object.freeze({ id: "compute", label: "Run computation", detail: "Spend two visible seconds doing pretend work.", method: "commons.demo.compute" }),
  Object.freeze({ id: "validate", label: "Validate result", detail: "Check that the result still belongs to this claim.", method: "commons.demo.validate" }),
  Object.freeze({ id: "publish", label: "Apply result", detail: "Make the current result available to the product.", method: "commons.demo.publish" })
]);

const clone = (value) => structuredClone(value);
const timestamp = (now) => new Date(now()).toISOString();

function normalizeTasks(tasks) {
  if (!Array.isArray(tasks) || tasks.length === 0) throw new TypeError("Demo pipeline requires at least one task.");
  const normalized = tasks.map((task, index) => ({
    id: String(task.id || "").trim(),
    label: String(task.label || "").trim(),
    detail: String(task.detail || "").trim() || null,
    method: String(task.method || "").trim() || "commons.demo.wait",
    sequence: index
  }));
  if (normalized.some(({ id, label }) => !id || !label)) throw new TypeError("Every demo task requires an id and label.");
  if (new Set(normalized.map(({ id }) => id)).size !== normalized.length) throw new TypeError("Demo task ids must be unique.");
  return normalized;
}

/**
 * An intentionally slow, headless pipeline for exercising product adapters.
 * It models claims, task-boundary stopping, failure, retry, and retained attempts.
 */
export function createDemoPipeline({
  id = "commons-engine-room",
  label = "Synthetic computation",
  workspaceId = "commons-lab",
  tasks = DEFAULT_TASKS,
  taskDelayMs = 2000,
  workerId = "worker-local-demo",
  now = Date.now,
  wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds))
} = {}) {
  const definitions = normalizeTasks(tasks);
  if (!Number.isFinite(taskDelayMs) || taskDelayMs < 0) throw new TypeError("taskDelayMs must be a non-negative number.");

  let runSequence = 0;
  let attemptSequence = 0;
  let claimGeneration = 0;
  let status = "queued";
  let stopRequested = false;
  let failNextTask = false;
  let activePromise = null;
  let events = [];
  const listeners = new Set();
  let stages = freshStages();

  function freshStages() {
    return definitions.map((task) => ({ ...task, status: "queued", attempts: [] }));
  }

  function currentStage() {
    return stages.find(({ status: stageStatus }) => stageStatus === "running") || null;
  }

  function nextStage() {
    return stages.find(({ status: stageStatus }) => !["complete"].includes(stageStatus)) || null;
  }

  function controls() {
    return {
      start: {
        label: status === "stopped" ? "Resume demonstration" : "Run demonstration",
        visible: ["queued", "stopped", "complete"].includes(status),
        enabled: status !== "complete"
      },
      stop: {
        label: "Stop after task",
        visible: ["running", "stopping"].includes(status),
        enabled: status === "running",
        reason: status === "stopping" ? "The current task will finish before the pipeline stops." : null
      },
      retry: { label: "Retry failed task", visible: status === "failed", enabled: status === "failed" }
    };
  }

  function snapshot() {
    const active = currentStage();
    const completed = stages.filter(({ status: stageStatus }) => stageStatus === "complete").length;
    const currentAttempt = active?.attempts.at(-1) || null;
    const currentJobId = active ? `job-${currentAttempt.id}` : null;
    return clone({
      id,
      label,
      workspaceId,
      status,
      claimGeneration,
      taskDelayMs,
      stopRequested,
      failNextTask,
      activity: {
        state: status,
        text: active
          ? `${status === "stopping" ? "Finishing" : "Running"} ${active.label.toLowerCase()}`
          : status === "complete" ? "All synthetic work is complete"
            : status === "failed" ? "A synthetic failure is retained for inspection"
              : status === "stopped" ? "Stopped cleanly at a task boundary"
                : "Ready to issue the first claim",
        task: active?.label || null,
        actor: active ? workerId : null
      },
      progress: { completed, total: stages.length, label: `${completed} of ${stages.length} tasks complete`, basis: "accepted tasks" },
      stages: stages.map((stage, index) => ({
        ...stage,
        dependsOn: index ? [stages[index - 1].id] : [],
        actor: stage.status === "running" ? workerId : null,
        currentAttemptId: stage.status === "running" ? stage.attempts.at(-1)?.id : null,
        acceptedAttemptId: stage.status === "complete" ? stage.attempts.findLast(({ status: attemptStatus }) => attemptStatus === "succeeded")?.id : null,
        inspectRef: `demo://${id}/stage/${stage.id}`
      })),
      jobs: active ? [{
        id: currentJobId,
        stageId: active.id,
        label: active.label,
        status,
        attemptId: currentAttempt.id,
        startedAt: currentAttempt.startedAt,
        authoritative: true
      }] : [],
      currentJobId,
      controls: controls(),
      events
    });
  }

  function recordEvent(type, detail) {
    events = [...events, { sequence: events.length + 1, at: timestamp(now), type, detail }];
  }

  function publish(type, detail) {
    recordEvent(type, detail);
    const value = snapshot();
    for (const listener of listeners) listener(value);
    return value;
  }

  async function execute() {
    while (true) {
      const stage = nextStage();
      if (!stage) {
        status = "complete";
        publish("pipeline.completed", "All tasks accepted.");
        return snapshot();
      }
      if (stage.status === "failed") stage.status = "queued";
      claimGeneration += 1;
      attemptSequence += 1;
      const attempt = {
        id: `attempt-${attemptSequence}`,
        status: "running",
        actor: workerId,
        method: stage.method,
        startedAt: timestamp(now),
        completedAt: null,
        durationSeconds: null,
        claimGeneration,
        input: {
          workspaceId,
          runId: `run-${runSequence}`,
          workUnitId: stage.id,
          task: { id: stage.id, method: stage.method },
          dependencies: stages.slice(0, stage.sequence).map(({ id: dependencyId, attempts }) => ({
            stageId: dependencyId,
            acceptedAttemptId: attempts.findLast(({ status: attemptStatus }) => attemptStatus === "succeeded")?.id || null
          }))
        },
        output: null,
        inspectRef: `demo://${id}/attempt/${attemptSequence}`,
        diagnostics: []
      };
      stage.status = "running";
      stage.attempts.push(attempt);
      status = stopRequested ? "stopping" : "running";
      publish("task.claimed", `${stage.label} claimed at generation ${claimGeneration}.`);
      await wait(taskDelayMs);

      if (failNextTask) {
        failNextTask = false;
        attempt.status = "failed";
        attempt.completedAt = timestamp(now);
        attempt.durationSeconds = taskDelayMs / 1000;
        attempt.diagnostics = [{ code: "DEMO_REQUESTED_FAILURE", message: "The lab requested this synthetic failure.", severity: "error" }];
        stage.status = "failed";
        status = "failed";
        stopRequested = false;
        publish("task.failed", `${stage.label} failed by request; its attempt was retained.`);
        return snapshot();
      }

      attempt.status = "succeeded";
      attempt.completedAt = timestamp(now);
      attempt.durationSeconds = taskDelayMs / 1000;
      attempt.output = {
        synthetic: true,
        stageId: stage.id,
        accepted: true,
        message: `${stage.label} produced a demonstration result.`,
        summary: `Wasted ${(taskDelayMs / 1000).toFixed(1)} seconds of clock time.`
      };
      stage.status = "complete";
      // Do not publish a running state between jobs: once this stage is complete
      // there is no authoritative job until the next claim is issued.
      recordEvent("task.succeeded", `${stage.label} completed and was accepted.`);
      if (stopRequested) {
        stopRequested = false;
        status = "stopped";
        publish("pipeline.stopped", "The pipeline stopped after the current task completed.");
        return snapshot();
      }
    }
  }

  function start() {
    if (activePromise) return activePromise;
    if (status === "complete") return Promise.resolve(snapshot());
    stopRequested = false;
    runSequence += 1;
    publish("pipeline.started", `Run ${runSequence} started.`);
    activePromise = execute().finally(() => { activePromise = null; });
    return activePromise;
  }

  function stop() {
    if (status !== "running") return snapshot();
    stopRequested = true;
    status = "stopping";
    return publish("pipeline.stopping", "Stop requested; the current task remains authoritative until it finishes.");
  }

  function retry() {
    if (status !== "failed") return Promise.resolve(snapshot());
    return start();
  }

  function requestFailure() {
    failNextTask = true;
    return publish("failure.armed", "The next task to finish will fail synthetically.");
  }

  function reset() {
    if (activePromise) throw new Error("Cannot reset the demo pipeline while a task is running.");
    status = "queued";
    stopRequested = false;
    failNextTask = false;
    stages = freshStages();
    events = [];
    return publish("pipeline.reset", "The demonstration returned to its initial state.");
  }

  function subscribe(listener, { emitCurrent = true } = {}) {
    if (typeof listener !== "function") throw new TypeError("Demo pipeline listener must be a function.");
    listeners.add(listener);
    if (emitCurrent) listener(snapshot());
    return () => listeners.delete(listener);
  }

  return Object.freeze({ snapshot, subscribe, start, stop, retry, requestFailure, reset });
}

export { DEFAULT_TASKS as DEMO_PIPELINE_TASKS };
