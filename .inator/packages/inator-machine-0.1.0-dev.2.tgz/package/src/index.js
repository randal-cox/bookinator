import { statfs } from "node:fs/promises";
import { execFile as execFileCallback } from "node:child_process";
import os from "node:os";
import { promisify } from "node:util";

export const MACHINE_SNAPSHOT_VERSION = "inator-machine.0.1-draft";
export const READINESS_MANIFEST_VERSION = "inator-readiness.0.1-draft";
export const READINESS_STATUSES = Object.freeze(["ready", "repairable", "warning", "blocked", "unknown"]);

const finiteOrNull = (value) => value == null || value === "" ? null : Number.isFinite(Number(value)) ? Number(value) : null;

export function defineMachineSnapshot(source) {
  if (!source || typeof source !== "object" || Array.isArray(source)) throw new TypeError("Machine snapshot must be an object.");
  for (const field of ["hostname", "username", "homeDirectory", "workspacePath", "ipAddress"]) if (Object.hasOwn(source, field)) throw new TypeError(`Machine snapshot must not expose ${field}.`);
  const memoryBytes = finiteOrNull(source.memory?.totalBytes);
  const freeDiskBytes = finiteOrNull(source.storage?.freeBytes);
  return Object.freeze({
    schemaVersion: MACHINE_SNAPSHOT_VERSION,
    observedAt: String(source.observedAt || new Date().toISOString()),
    platform: String(source.platform || "unknown"),
    release: String(source.release || "unknown"),
    architecture: String(source.architecture || "unknown"),
    cpu: Object.freeze({ logicalCores: finiteOrNull(source.cpu?.logicalCores), model: String(source.cpu?.model || "unknown") }),
    memory: Object.freeze({ totalBytes: memoryBytes, state: memoryBytes == null ? "unknown" : "known" }),
    storage: Object.freeze({ freeBytes: freeDiskBytes, state: freeDiskBytes == null ? "unknown" : "known" }),
    power: Object.freeze({ source: source.power?.source || "unknown", state: source.power?.state || "unknown" }),
    thermal: Object.freeze({ state: source.thermal?.state || "unknown" })
  });
}

const execFile = promisify(execFileCallback);

function macPower(source) {
  if (/AC Power/i.test(source)) return { source: "ac", state: "connected" };
  if (/Battery Power/i.test(source)) return { source: "battery", state: "discharging" };
  return { source: "unknown", state: "unknown" };
}

function macThermal(source) {
  const limits = [...source.matchAll(/(?:CPU|GPU)_Speed_Limit\s*=\s*(\d+)/g)].map((match) => Number(match[1]));
  if (!limits.length) return { state: "unknown" };
  return { state: Math.min(...limits) < 100 ? "constrained" : "nominal" };
}

export async function inspectLocalMachine({ storagePath = process.cwd(), now = () => new Date(), run = execFile } = {}) {
  let freeBytes = null;
  try { const value = await statfs(storagePath); freeBytes = Number(value.bavail) * Number(value.bsize); } catch {}
  let power = { source: "unknown", state: "unknown" }; let thermal = { state: "unknown" };
  if (os.platform() === "darwin") {
    try { power = macPower((await run("pmset", ["-g", "batt"], { timeout: 2_000 })).stdout || ""); } catch {}
    try { thermal = macThermal((await run("pmset", ["-g", "therm"], { timeout: 2_000 })).stdout || ""); } catch {}
  }
  return defineMachineSnapshot({
    observedAt: now().toISOString(), platform: os.platform(), release: os.release(), architecture: os.arch(),
    cpu: { logicalCores: os.cpus()?.length || null, model: os.cpus()?.[0]?.model || "unknown" },
    memory: { totalBytes: os.totalmem() || null }, storage: { freeBytes }, power, thermal
  });
}

export function evaluateMachineCapabilities(snapshotSource, requirements = {}) {
  const snapshot = defineMachineSnapshot(snapshotSource);
  const checks = [];
  const add = (id, label, actual, minimum, unit) => {
    const unknown = actual == null; const ok = !unknown && actual >= minimum;
    checks.push(Object.freeze({ id, label, status: unknown ? "unknown" : ok ? "ready" : "blocked", actual, minimum, unit }));
  };
  if (requirements.platforms?.length) checks.push(Object.freeze({ id: "platform", label: "Operating system", status: requirements.platforms.includes(snapshot.platform) ? "ready" : "blocked", actual: snapshot.platform, allowed: [...requirements.platforms] }));
  if (requirements.architectures?.length) checks.push(Object.freeze({ id: "architecture", label: "Architecture", status: requirements.architectures.includes(snapshot.architecture) ? "ready" : "blocked", actual: snapshot.architecture, allowed: [...requirements.architectures] }));
  if (requirements.minimumMemoryBytes != null) add("memory", "Physical memory", snapshot.memory.totalBytes, requirements.minimumMemoryBytes, "bytes");
  if (requirements.minimumFreeDiskBytes != null) add("storage", "Free storage", snapshot.storage.freeBytes, requirements.minimumFreeDiskBytes, "bytes");
  return Object.freeze({ status: checks.some(({ status }) => status === "blocked") ? "blocked" : checks.some(({ status }) => status === "unknown") ? "unknown" : "ready", checks: Object.freeze(checks) });
}

export function createReadinessManifest({ snapshot: source, policy, now = () => new Date() } = {}) {
  const snapshot = defineMachineSnapshot(source); if (!policy?.id || !policy?.version) throw new TypeError("Readiness policy id and version are required.");
  const checks = (policy.checks || []).map((definition) => { const observed = definition.observe?.(snapshot) ?? null; const assessment = definition.assess?.(observed, snapshot) || { status: observed == null ? "unknown" : "ready" }; if (!READINESS_STATUSES.includes(assessment.status)) throw new TypeError(`Invalid readiness status ${assessment.status}.`); return Object.freeze({ id: String(definition.id), category: String(definition.category || "machine"), label: String(definition.label || definition.id), required: definition.required !== false, status: assessment.status, observedValue: observed, requirement: definition.requirement || null, explanation: String(assessment.explanation || definition.explanation || ""), observedAt: snapshot.observedAt, freshness: definition.freshness || { maxAgeSeconds: 60 }, repairAction: assessment.repairAction || null }); });
  const required = checks.filter((check) => check.required); const overall = required.some(({ status }) => status === "blocked") ? "blocked" : required.some(({ status }) => status === "unknown") ? "unknown" : checks.some(({ status }) => ["warning", "repairable"].includes(status)) ? "warning" : "ready";
  return Object.freeze({ schemaVersion: READINESS_MANIFEST_VERSION, policy: Object.freeze({ id: policy.id, version: policy.version }), generatedAt: now().toISOString(), machine: snapshot, status: overall, checks: Object.freeze(checks) });
}
