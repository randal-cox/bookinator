# @inator/models

Provider-neutral model inventory, explicit install planning and approval,
verification, role compatibility, and invocation contracts. Ollama is the first
adapter, not the architecture. Installation, selection, permission, loading,
and invocation remain separate states.

`defineModelInventory`, `reduceModelInventory`, and
`createModelInventoryStore` keep observations from any model provider in one
durable state contract. Provider identity is explicit; machine hostnames,
process IDs, paths, and service URLs are deliberately excluded from durable
capabilities.
