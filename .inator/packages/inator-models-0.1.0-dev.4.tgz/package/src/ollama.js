import { defineModelRecord, defineProviderCapabilities, MODEL_PROTOCOL_VERSION } from "./index.js";
import { execFile as execFileCallback } from "node:child_process";
import { promisify } from "node:util";

const json = async (response) => { if (!response.ok) throw new Error(`Ollama returned HTTP ${response.status}.`); return response.json(); };
const execFile = promisify(execFileCallback);

async function ndjson(response, onEvent) {
  if (!response.ok) throw new Error(`Ollama returned HTTP ${response.status}.`);
  const reader = response.body.getReader(); const decoder = new TextDecoder(); let buffer = ""; let final = null;
  while (true) { const { done, value } = await reader.read(); buffer += decoder.decode(value || new Uint8Array(), { stream: !done }); const lines = buffer.split(/\r?\n/); buffer = lines.pop() || ""; for (const line of lines.filter(Boolean)) { final = JSON.parse(line); onEvent?.(final); } if (done) break; }
  if (buffer.trim()) { final = JSON.parse(buffer); onEvent?.(final); }
  return final;
}

export class OllamaProvider {
  constructor({ fetch: fetchImpl = globalThis.fetch, endpoint = "http://127.0.0.1:11434", version = "unknown", run = execFile } = {}) { this.fetch = fetchImpl; this.endpoint = endpoint.replace(/\/$/, ""); this.version = version; this.run = run; }
  async capabilities() { return defineProviderCapabilities({ providerId: "ollama", providerVersion: this.version, location: "local", operations: ["inventory", "install", "remove", "invoke", "unload"], features: { structuredOutput: true, streaming: true, cancellation: true, unload: true } }); }
  async status() {
    try { const value = await json(await this.fetch(`${this.endpoint}/api/version`)); this.version = String(value.version || "unknown"); return { installed: true, running: true, version: this.version }; }
    catch (apiError) { try { const result = await this.run("ollama", ["--version"], { timeout: 3_000 }); const match = `${result.stdout || ""}\n${result.stderr || ""}`.match(/(?:client version is|ollama version is|ollama version)\s+([\w.-]+)/i); this.version = match?.[1] || "unknown"; return { installed: true, running: false, version: this.version, diagnostic: apiError.message }; } catch { return { installed: false, running: false, version: null, diagnostic: apiError.message }; } }
  }
  async inventory() {
    const [tags, running] = await Promise.all([json(await this.fetch(`${this.endpoint}/api/tags`)), this.fetch(`${this.endpoint}/api/ps`).then(json).catch(() => ({ models: [] }))]);
    const loaded = new Set((running.models || []).map((item) => item.name || item.model));
    return (tags.models || []).map((item) => defineModelRecord({ providerId: "ollama", modelId: item.name || item.model, revision: item.modified_at || null, digest: item.digest || null, sizeBytes: item.size, installed: true, loaded: loaded.has(item.name || item.model), families: item.details?.families || [item.details?.family].filter(Boolean), capabilities: String(item.name || item.model).includes("embed") ? ["embedding"] : ["chat", "structured-output"] }));
  }
  async install(plan, { signal, onProgress } = {}) { if (plan?.protocolVersion !== MODEL_PROTOCOL_VERSION || plan.state !== "approved" || plan.providerId !== "ollama") throw new TypeError("Ollama installation requires an approved compatible plan."); return ndjson(await this.fetch(`${this.endpoint}/api/pull`, { method: "POST", signal, headers: { "content-type": "application/json" }, body: JSON.stringify({ model: plan.model.modelId, stream: true }) }), (event) => onProgress?.({ status: event.status || "downloading", completedBytes: event.completed ?? null, totalBytes: event.total ?? plan.estimatedBytes ?? null, digest: event.digest || null })); }
  async remove(modelId) { return json(await this.fetch(`${this.endpoint}/api/delete`, { method: "DELETE", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: modelId }) })); }
  async unload(modelId) { return json(await this.fetch(`${this.endpoint}/api/generate`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ model: modelId, keep_alive: 0 }) })); }
  async invoke(request, { signal, onActivity } = {}) {
    let content = ""; const final = await ndjson(await this.fetch(`${this.endpoint}/api/chat`, { method: "POST", signal, headers: { "content-type": "application/json" }, body: JSON.stringify({ model: request.modelId, messages: request.messages, format: request.outputSchema || undefined, options: request.options, stream: true }) }), (event) => { content += event.message?.content || ""; onActivity?.({ type: event.done ? "completed" : "token", modelId: request.modelId }); });
    return { requestId: request.requestId, provider: { id: "ollama", version: this.version }, model: { id: request.modelId, digest: final?.model_digest || null }, promptVersion: request.promptVersion, schemaVersion: request.schemaVersion, content, metrics: { totalDurationNs: final?.total_duration || null, promptTokens: final?.prompt_eval_count || null, outputTokens: final?.eval_count || null } };
  }
}
