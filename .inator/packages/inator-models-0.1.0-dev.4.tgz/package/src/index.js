export const MODEL_PROTOCOL_VERSION = "inator-models.0.1-draft";
export const MODEL_INVENTORY_VERSION = "inator-model-inventory.0.1-draft";

const required = (value, label) => { const text = String(value || "").trim(); if (!text) throw new TypeError(`${label} is required.`); return text; };
const object = (value, label) => { if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object.`); return value; };

export function defineProviderCapabilities(source) {
  const value = object(source, "Provider capabilities");
  for (const field of ["hostname", "pid", "baseUrl", "absolutePath"]) if (Object.hasOwn(value, field)) throw new TypeError(`Provider durable capabilities cannot contain ${field}.`);
  return Object.freeze({ protocolVersion: MODEL_PROTOCOL_VERSION, providerId: required(value.providerId, "providerId"), providerVersion: String(value.providerVersion || "unknown"), location: value.location === "remote" ? "remote" : "local", operations: Object.freeze([...new Set(value.operations || [])]), features: Object.freeze({ structuredOutput: Boolean(value.features?.structuredOutput), streaming: Boolean(value.features?.streaming), cancellation: Boolean(value.features?.cancellation), unload: Boolean(value.features?.unload) }) });
}

export function defineModelRecord(source) {
  const value = object(source, "Model record");
  const sizeBytes = value.sizeBytes == null ? null : Number(value.sizeBytes);
  return Object.freeze({ providerId: required(value.providerId, "model providerId"), modelId: required(value.modelId, "modelId"), label: String(value.label || value.modelId), revision: value.revision ? String(value.revision) : null, digest: value.digest ? String(value.digest) : null, sizeBytes: Number.isFinite(sizeBytes) ? sizeBytes : null, parameters: value.parameters || null, quantization: value.quantization || null, contextTokens: value.contextTokens == null ? null : Number(value.contextTokens), provenance: value.provenance || null, installed: Boolean(value.installed), loaded: Boolean(value.loaded), families: Object.freeze([...(value.families || [])]), capabilities: Object.freeze([...(value.capabilities || [])]) });
}

export function defineModelInventory(source = {}) {
  const value = object(source, "Model inventory");
  const providers = (value.providers || []).map(defineProviderCapabilities);
  const providerIds = new Set(providers.map(({ providerId }) => providerId));
  if (providerIds.size !== providers.length) throw new TypeError("Model inventory provider ids must be unique.");
  const records = (value.records || []).map(defineModelRecord);
  for (const record of records) if (!providerIds.has(record.providerId)) throw new TypeError(`Model ${record.modelId} names unknown provider ${record.providerId}.`);
  if (new Set(records.map(({ providerId, modelId }) => `${providerId}:${modelId}`)).size !== records.length) throw new TypeError("Model inventory identities must be unique within a provider.");
  return Object.freeze({ schemaVersion: MODEL_INVENTORY_VERSION, revision: Math.max(0, Number(value.revision) || 0), observedAt: String(value.observedAt || new Date().toISOString()), providers: Object.freeze(providers), records: Object.freeze(records) });
}

export function reduceModelInventory(inventorySource, event, { now = () => new Date() } = {}) {
  const inventory = defineModelInventory(inventorySource); const action = object(event, "Model inventory event");
  const providerId = required(action.providerId, "event providerId"); const modelId = required(action.modelId, "event modelId");
  if (!inventory.providers.some((provider) => provider.providerId === providerId)) throw new TypeError(`Unknown model provider ${providerId}.`);
  const records = inventory.records.filter((record) => record.providerId !== providerId || record.modelId !== modelId);
  const current = inventory.records.find((record) => record.providerId === providerId && record.modelId === modelId);
  if (action.type === "observed") records.push(defineModelRecord({ ...current, ...action.record, providerId, modelId }));
  else if (action.type === "removed") records.push(defineModelRecord({ ...current, providerId, modelId, installed: false, loaded: false }));
  else if (action.type === "loaded") records.push(defineModelRecord({ ...current, providerId, modelId, installed: true, loaded: true }));
  else if (action.type === "unloaded") records.push(defineModelRecord({ ...current, providerId, modelId, loaded: false }));
  else throw new TypeError(`Unknown model inventory event ${action.type}.`);
  return defineModelInventory({ ...inventory, revision: inventory.revision + 1, observedAt: now().toISOString(), records });
}

export function createModelInventoryStore({ load, save, initial = { providers: [], records: [] }, now = () => new Date() } = {}) {
  if (typeof save !== "function") throw new TypeError("Model inventory store requires save.");
  let state = null; const read = async () => state ||= defineModelInventory(typeof load === "function" ? await load() || initial : initial);
  return Object.freeze({ async snapshot() { return read(); }, async dispatch(event) { state = reduceModelInventory(await read(), event, { now }); await save(state); return state; } });
}

export function defineModelRole(source) {
  const value = object(source, "Model role");
  return Object.freeze({ id: required(value.id, "role id"), label: required(value.label, "role label"), purpose: String(value.purpose || ""), requiredCapabilities: Object.freeze([...(value.requiredCapabilities || [])]), preferredFamilies: Object.freeze([...(value.preferredFamilies || [])]), minimumMemoryBytes: value.minimumMemoryBytes == null ? null : Number(value.minimumMemoryBytes) });
}

export function planRoleAssignment({ role, modelId, inventory = [], scope = "default" } = {}) { const definition=defineModelRole(role); const model=inventory.map(defineModelRecord).find(item=>item.modelId===modelId); const blockers=[]; if(!model?.installed)blockers.push("model-not-installed"); else if(!definition.requiredCapabilities.every(item=>model.capabilities.includes(item)))blockers.push("model-incompatible"); return Object.freeze({ id:`assign:${scope}:${definition.id}:${modelId||"none"}`, protocolVersion:MODEL_PROTOCOL_VERSION, state:blockers.length?"blocked":"awaiting-approval", roleId:definition.id, modelId:modelId||null, scope, blockers:Object.freeze(blockers) }); }

export function compatibleModels(roleSource, inventory = [], machine = null) {
  const role = defineModelRole(roleSource);
  if (role.minimumMemoryBytes && (!machine?.memory?.totalBytes || machine.memory.totalBytes < role.minimumMemoryBytes)) return [];
  return inventory.map(defineModelRecord).filter((model) => model.installed && role.requiredCapabilities.every((capability) => model.capabilities.includes(capability))).sort((left, right) => Number(role.preferredFamilies.includes(right.families[0])) - Number(role.preferredFamilies.includes(left.families[0])) || (left.sizeBytes || Infinity) - (right.sizeBytes || Infinity));
}

export function planModelInstall({ provider, model, role = null, machine = null } = {}) {
  const capabilities = defineProviderCapabilities(provider); const record = defineModelRecord({ ...model, providerId: model?.providerId || capabilities.providerId });
  const blockers = [];
  if (capabilities.location !== "local") blockers.push("provider-not-local");
  if (!capabilities.operations.includes("install")) blockers.push("install-not-supported");
  if (record.installed) blockers.push("already-installed");
  if (role?.minimumMemoryBytes && (!machine?.memory?.totalBytes || machine.memory.totalBytes < role.minimumMemoryBytes)) blockers.push("insufficient-or-unknown-memory");
  return Object.freeze({ id: `install:${record.providerId}:${record.modelId}`, protocolVersion: MODEL_PROTOCOL_VERSION, providerId: record.providerId, model: record, roleId: role?.id || null, estimatedBytes: record.sizeBytes, state: blockers.length ? "blocked" : "awaiting-approval", blockers: Object.freeze(blockers) });
}

export function approveModelInstall(plan, actor) {
  if (plan?.state !== "awaiting-approval") throw new TypeError("Only an install plan awaiting approval can be approved.");
  return Object.freeze({ ...plan, state: "approved", approval: Object.freeze({ actorId: required(actor?.id, "approval actor id"), approvedAt: required(actor?.approvedAt, "approval time") }) });
}

export function verifyModelInstall(plan, inventory = []) {
  const installed = inventory.map(defineModelRecord).find((model) => model.providerId === plan.providerId && model.modelId === plan.model.modelId && model.installed);
  return Object.freeze({ planId: plan.id, verified: Boolean(installed), model: installed || null, reason: installed ? "installed-model-observed" : "installed-model-not-observed" });
}

export function defineModelRequest(source) {
  const value = object(source, "Model request");
  if (value.placement?.mode !== "local-only" && !value.placement?.allowedProviderIds?.includes(value.providerId)) throw new TypeError("Model request placement does not authorize its provider.");
  return Object.freeze({ protocolVersion: MODEL_PROTOCOL_VERSION, requestId: required(value.requestId, "requestId"), providerId: required(value.providerId, "providerId"), modelId: required(value.modelId, "modelId"), promptVersion: required(value.promptVersion, "promptVersion"), schemaVersion: required(value.schemaVersion, "schemaVersion"), placement: Object.freeze({ ...value.placement }), messages: Object.freeze([...(value.messages || [])]), options: Object.freeze({ ...(value.options || {}) }), outputSchema: value.outputSchema || null });
}

export function createModelWorkHandler({ providers, onActivity } = {}) {
  return async (input, context = {}) => {
    const request = defineModelRequest(input); const provider = providers?.get?.(request.providerId) || providers?.[request.providerId];
    if (!provider) throw new TypeError(`Model provider ${request.providerId} is not registered.`);
    const advertised = defineProviderCapabilities(await provider.capabilities());
    if (advertised.providerId !== request.providerId || advertised.location !== "local") throw new TypeError("Provider placement is not authorized for this request.");
    return provider.invoke(request, { signal: context.signal, onActivity: (event) => onActivity?.({ requestId: request.requestId, ...event }) });
  };
}

export function createModelsWorkspaceModel({ provider, inventory = [], roles = [], assignments = {}, catalog = [], machine = null, queue = null, hardwareAdvice = "" } = {}) {
  const health = defineProviderCapabilities(provider.capabilities); const models = inventory.map(defineModelRecord); const normalizedRoles = roles.map(defineModelRole).map((role) => Object.freeze({ ...role, assignedModelId: assignments[role.id] || null, compatibleModelIds: Object.freeze(compatibleModels(role, models, machine).map(({ modelId }) => modelId)) }));
  return Object.freeze({ schemaVersion: "inator-model-workspace.0.2-draft", provider: Object.freeze({ ...health, installed: provider.installed ?? null, running: provider.running ?? null, apiReachable: provider.apiReachable ?? null, inferenceVerified: provider.inferenceVerified ?? null, checkedAt: provider.checkedAt || null, diagnostic: provider.diagnostic || null }), inventory: Object.freeze(models), roles: Object.freeze(normalizedRoles), catalog: Object.freeze(catalog.map((item) => Object.freeze({ ...item, installed: models.some(model => model.modelId === (item.modelId || item.id) && model.installed) }))), hardwareAdvice: String(hardwareAdvice || ""), queue: queue ? Object.freeze({ ...queue }) : null });
}
